<?php
/**
 * حالت قفل: لایسنس فعال نیست.
 *
 * وقتی لایسنس راست‌چین فعال نشده باشد، افزونه هیچ بخشی از خودش را بارگذاری
 * نمی‌کند: نه منوی پیشخوان، نه ویجت روی سایت، نه API، نه اینباکس. فقط همین
 * فایل بارگذاری می‌شود تا پیام راهنما نمایش داده شود و فعال‌سازی مسدود گردد.
 *
 * @package Gapineh
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * پیام اصلی.
 *
 * @return string
 */
function gapineh_locked_message() {
	return __( 'برای فعال‌سازی افزونه، بخش‌های دامنه خود را در سایت راست‌چین فعال نمایید.', 'gapineh' );
}

/**
 * نشانی پنل کاربری راست‌چین.
 *
 * @return string
 */
function gapineh_rtl_panel_url() {
	return 'https://rtl-theme.com/user/';
}

/**
 * متن جزئیات بر اساس وضعیت لایسنس.
 *
 * @return string
 */
function gapineh_locked_detail() {
	$status = class_exists( 'Gapineh_License' ) ? Gapineh_License::status() : 'lib_missing';

	switch ( $status ) {
		case 'inactive':
			return __( 'لایسنس روی این دامنه فعال نیست. در پنل راست‌چین، بخش «دامنه‌ها» را باز کنید و دامنهٔ همین سایت را فعال (ثبت) کنید. اگر دامنه را عوض کرده‌اید، دامنهٔ تازه را اضافه کنید.', 'gapineh' );
		case 'no_loader':
			return __( 'افزونهٔ ionCube Loader روی این سرور فعال نیست و بدون آن نمی‌توان لایسنس را بررسی کرد. از هاستینگ بخواهید آن را فعال کند، سپس صفحه را دوباره باز کنید.', 'gapineh' );
		case 'hash_mismatch':
			return __( 'فایل کتابخانهٔ لایسنس در پوشهٔ افزونه با این نسخه نمی‌خواند. بستهٔ رسمی را دوباره از پنل راست‌چین نصب کنید.', 'gapineh' );
		default:
			return __( 'کتابخانهٔ لایسنس در پوشهٔ افزونه نیست؛ بستهٔ نصب ناقص است. فایل ZIP را دوباره از پنل راست‌چین دانلود و نصب کنید.', 'gapineh' );
	}
}

/**
 * اعلان پیشخوان، بالای همهٔ صفحات، فقط برای مدیر.
 */
function gapineh_locked_admin_notice() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	$panel = gapineh_rtl_panel_url();
	printf(
		'<div class="notice notice-error gapineh-locked"><h2 style="margin:8px 0 6px">%s</h2><p style="font-size:14px;margin:0 0 8px">%s</p><p>%s</p><p><a class="button button-primary" href="%s" target="_blank" rel="noopener">%s</a></p></div>',
		esc_html__( 'گپینه فعال نشده است', 'gapineh' ),
		esc_html( gapineh_locked_message() ),
		esc_html( gapineh_locked_detail() ),
		esc_url( $panel ),
		esc_html__( 'باز کردن پنل راست‌چین', 'gapineh' )
	);
}
add_action( 'admin_notices', 'gapineh_locked_admin_notice' );
add_action( 'network_admin_notices', 'gapineh_locked_admin_notice' );

/**
 * مسدود کردن فعال‌سازی: اگر کسی افزونه را فعال کند، بلافاصله غیرفعال می‌شود
 * و پیام راهنما نشان داده می‌شود.
 */
function gapineh_locked_activate() {
	if ( ! function_exists( 'get_plugins' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}
	deactivate_plugins( plugin_basename( GAPINEH_FILE ), true );
	set_transient( 'gapineh_locked_notice', 1, 60 );

	wp_die(
		'<h1>' . esc_html__( 'گپینه فعال نشد', 'gapineh' ) . '</h1>'
		. '<p>' . esc_html( gapineh_locked_message() ) . '</p>'
		. '<p>' . esc_html( gapineh_locked_detail() ) . '</p>'
		. '<p><a class="button button-primary" href="' . esc_url( gapineh_rtl_panel_url() ) . '" target="_blank" rel="noopener">'
		. esc_html__( 'باز کردن پنل راست‌چین', 'gapineh' ) . '</a></p>',
		esc_html__( 'گپینه', 'gapineh' ),
		array( 'back_link' => true )
	);
}
register_activation_hook( GAPINEH_FILE, 'gapineh_locked_activate' );

/**
 * نمایش پیام پس از تلاش ناموفق برای فعال‌سازی (در صفحهٔ افزونه‌ها).
 */
function gapineh_locked_after_activation_notice() {
	if ( ! get_transient( 'gapineh_locked_notice' ) ) {
		return;
	}
	delete_transient( 'gapineh_locked_notice' );
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	printf(
		'<div class="notice notice-error is-dismissible"><p><strong>%s</strong></p><p>%s</p><p>%s</p></div>',
		esc_html__( 'گپینه فعال نشد.', 'gapineh' ),
		esc_html( gapineh_locked_message() ),
		esc_html( gapineh_locked_detail() )
	);
}
add_action( 'admin_notices', 'gapineh_locked_after_activation_notice' );
