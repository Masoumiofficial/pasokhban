<?php
/**
 * بررسی لایسنس راست‌چین — همین فایل، کدِ مرحلهٔ اول راهنمای راست‌چین است.
 *
 * قرارگیری: ریشهٔ افزونه، کنار gapineh.php. اسکریپت بسته‌بندی، فایل کتابخانهٔ
 * RTL_License_b0e384722fc261db.php (نسخهٔ ionCube راست‌چین) را هم کنار همین
 * فایل می‌گذارد؛ هر دو باید با هم در بسته باشند.
 *
 * نکتهٔ مهم: کتابخانهٔ راست‌چین با ionCube رمزنگاری شده است. اگر روی سرور
 * مشتری ionCube Loader نصب نباشد، آن فایل به‌جای اجرا، پیام «Script error»
 * چاپ می‌کند و با exit(199) از ادامهٔ بارگذاری جلوگیری می‌کند — یعنی کل
 * سایت سفید می‌شد. برای همین برنامه را داخل نگهبان extension_loaded می‌گذاریم:
 * بدون Loader، افزونه بی‌خطا در حالت آزاد کار می‌کند و در پیشخوان پیام
 * راهنما نشان داده می‌شود.
 *
 * @package Gapineh
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // دسترسی مستقیم ممنوع
}

// آیا ionCube Loader روی این سرور هست؟ (نام افزونهٔ PHP در نسخه‌های ۱۰+ «ionCube Loader» است)
$gapineh_ioncube = extension_loaded( 'ionCube Loader' ) || function_exists( 'ioncube_loader_version' );
if ( ! defined( 'GAPINEH_LOADER_OK' ) ) {
	define( 'GAPINEH_LOADER_OK', (bool) $gapineh_ioncube );
}

if ( $gapineh_ioncube ) {

	// --------------------------------------------------------------------------------------------------- Start RTL License
	$rtlLicenseClassName  = 'RTL_License_b0e384722fc261db';
	$rtlLicenseFilePath   = __DIR__ . DIRECTORY_SEPARATOR . $rtlLicenseClassName . '.php';
	$rtlLicenseFileHash   = @sha1_file($rtlLicenseFilePath);

	if ( $rtlLicenseFileHash === '5210705eb2491e92815cd01b5877475e4a69fcba' && file_exists($rtlLicenseFilePath) ) {
		require_once $rtlLicenseFilePath;

		if ( class_exists($rtlLicenseClassName) && method_exists($rtlLicenseClassName, 'isActive') ) {
			$rtlLicenseClass = new $rtlLicenseClassName();

			if ( $rtlLicenseClass->{'isActive'}() === true ) {
				// Product is Active Now, Enable Pro Features
				if ( ! defined( 'GAPINEH_PRO' ) ) {
					define( 'GAPINEH_PRO', true );
				}
				if ( function_exists( 'do_action' ) ) {
					do_action( 'gapineh_pro_active' );
				}
			}
		}
	}
	// ----------------------------------------------------------------------------------------------------- End RTL License

}

// متغیرهای قطعه‌کد در دامنهٔ سراسری نمانند.
unset( $gapineh_ioncube, $rtlLicenseClassName, $rtlLicenseFilePath, $rtlLicenseFileHash );
if ( isset( $rtlLicenseClass ) ) {
	unset( $rtlLicenseClass );
}
