<?php
/**
 * بررسی لایسنس راست‌چین — این فایل در روز انتشار برای رمزنگاری به راست‌چین
 * داده می‌شود و نسخهٔ رمزشده‌اش جایگزین همین فایل در بستهٔ نهایی می‌شود.
 *
 * فایل لایسنس خریدار (RTL_License_b0e384722fc261db.php) باید در همین پوشه،
 * کنار همین فایل و کنار gapineh.php باشد. اگر نباشد یا هش‌اش نخواند،
 * افزونه در حالت آزاد و بدون هیچ خطایی کار می‌کند.
 *
 * @package Gapineh
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // دسترسی مستقیم ممنوع
}

// --------------------------------------------------------------------------------------------------- Start RTL License
$rtlLicenseClassName  = 'RTL_License_b0e384722fc261db';
$rtlLicenseFilePath   = __DIR__ . DIRECTORY_SEPARATOR . $rtlLicenseClassName . '.php';
$rtlLicenseFileHash   = @sha1_file($rtlLicenseFilePath);

if ( $rtlLicenseFileHash === '5210705eb2491e92815cd01b5877475e4a69fcba' && file_exists($rtlLicenseFilePath) ) {
	require_once $rtlLicenseFilePath;

	if ( class_exists($rtlLicenseClassName) && method_exists($rtlLicenseClassName, 'isActive') ) {
		$rtlLicenseClass = new $rtlLicenseClassName();

		if ( $rtlLicenseClass->{'isActive'}() === true ) {
			// Product is Active Now, Enable Pro Features
			if ( ! defined( 'GAPINEH_PRO' ) ) {
				define( 'GAPINEH_PRO', true );
			}
			if ( function_exists( 'do_action' ) ) {
				do_action( 'gapineh_pro_active' );
			}
		}
	}
}
// ----------------------------------------------------------------------------------------------------- End RTL License

// متغیرهای قطعه‌کد در دامنهٔ سراسری نمانند.
unset( $rtlLicenseClassName, $rtlLicenseFilePath, $rtlLicenseFileHash );
if ( isset( $rtlLicenseClass ) ) {
	unset( $rtlLicenseClass );
}
