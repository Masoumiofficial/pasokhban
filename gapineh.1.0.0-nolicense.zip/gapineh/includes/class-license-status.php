<?php
/**
 * وضعیت لایسنس و دروازهٔ قابلیت‌های نسخهٔ کامل.
 *
 * بررسی واقعی لایسنس در فایل رمزنگاری‌شدهٔ ریشهٔ افزونه (gapineh-license.php)
 * انجام می‌شود و آن فایل در صورت لایسنس معتبر ثابت GAPINEH_PRO را تعریف
 * می‌کند. این فایل خواناست و فقط وضعیت را می‌خواند تا در پیشخوان نمایش
 * داده شود و قابلیت‌ها بتوانند با gapineh_is_pro() دروازه بگذارند.
 *
 * @package Gapineh
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Gapineh_License {

	/** نام فایل بررسی لایسنس در ریشهٔ افزونه. */
	const CHECK_FILE = 'gapineh-license.php';

	/** الگوی فایل لایسنس خریدار که راست‌چین صادر می‌کند. */
	const LICENSE_PATTERN = 'RTL_License_*.php';

	/**
	 * یکی از: active | inactive | invalid | missing
	 *
	 * - active   : لایسنس معتبر و فعال است.
	 * - inactive : فایل بررسی اجرا شد ولی isActive() منفی بود (منقضی/فعال‌نشده).
	 * - invalid  : فایل لایسنس هست ولی هش نمی‌خواند یا فایل بررسی بارگذاری نشده.
	 * - missing  : فایل لایسنس خریدار در پوشهٔ افزونه نیست (حالت آزاد).
	 *
	 * @return string
	 */
	public static function status() {
		// اگر فایل لایسنس (راست‌چین یا نمایشی) ثابت را ست کرده باشد، فعال است.
		if ( defined( 'GAPINEH_PRO' ) && GAPINEH_PRO ) {
			return 'active';
		}
		if ( ! self::check_file_exists() ) {
			return 'lib_missing';
		}
		if ( ! self::loader_available() ) {
			return 'no_loader';
		}
		if ( ! self::class_loaded() ) {
			return 'hash_mismatch';
		}
		return 'inactive';
	}

	/**
	 * آیا نسخهٔ کامل فعال است؟
	 *
	 * همان نتیجهٔ status() به‌صورت بولین؛ تنها وقتی true است که لایسنس
	 * راست‌چین معتبر باشد و ثابت GAPINEH_PRO تعریف شده باشد.
	 *
	 * @return bool
	 */
	public static function is_pro() {
		return 'active' === self::status();
	}

	/**
	 * آیا فایل(های) لایسنس خریدار در ریشهٔ افزونه هست؟
	 *
	 * @return bool
	 */
	public static function check_file_exists() {
		foreach ( self::license_files() as $file ) {
			if ( is_readable( $file ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * آیا ionCube Loader روی سرور هست؟
	 *
	 * کتابخانهٔ لایسنس راست‌چین با ionCube رمزنگاری شده است؛ بدون این افزونهٔ
	 * PHP، فایل کتابخانه با exit(199) اجرای افزونه را متوقف می‌کند. برای همین
	 * در gapineh-license.php پیش از هر include این شرط بررسی می‌شود.
	 *
	 * @return bool
	 */
	public static function loader_available() {
		$info = self::loader_info();
		return ! empty( $info['ok'] );
	}

	/**
	 * تشخیص دقیق ionCube Loader + اطلاعاتی که برای هاستینگ لازم است.
	 *
	 * بعضی هاست‌ها افزونهٔ ionCube را با نام دیگری ثبت می‌کنند یا تابع
	 * ioncube_loader_version() را با disable_functions می‌بندند؛ پس سه مسیر
	 * مستقل بررسی می‌شود تا «ندارد» اشتباه گزارش نشود.
	 *
	 * @return array
	 */
	public static function loader_info() {
		static $info = null;
		if ( null !== $info ) {
			return $info;
		}

		$method  = '';
		$ok      = false;
		$exts    = function_exists( 'get_loaded_extensions' ) ? get_loaded_extensions() : array();
		$matched = array();

		foreach ( $exts as $ext ) {
			if ( false !== stripos( (string) $ext, 'ioncube' ) ) {
				$matched[] = (string) $ext;
			}
		}
		if ( $matched ) {
			$ok     = true;
			$method = 'extension: ' . implode( ', ', $matched );
		} elseif ( function_exists( 'ioncube_loader_version' ) ) {
			$ok     = true;
			$method = 'function: ioncube_loader_version()';
		} else {
			// zend_extension در php.ini ثبت شده ولی ماژول لود نشده؟ (نصب نیمه‌کاره)
			$zend = (string) ini_get( 'zend_extension' );
			if ( '' !== $zend && false !== stripos( $zend, 'ioncube' ) ) {
				$method = 'zend_extension ثبت شده ولی لود نشده: ' . $zend;
			}
		}

		$info = array(
			'ok'     => $ok,
			'method' => $method,
			'php'    => PHP_VERSION,
			'exts'   => $matched,
			'zend'   => (string) ini_get( 'zend_extension' ),
			'func'   => function_exists( 'ioncube_loader_version' ) ? (string) @ioncube_loader_version() : '',
		);
		return $info;
	}

	/**
	 * چند خط اطلاعات فنی برای فرستادن به هاستینگ.
	 *
	 * @return string
	 */
	public static function loader_report() {
		$i    = self::loader_info();
		$lines = array(
			'ionCube Loader: ' . ( $i['ok'] ? 'فعال' : 'غیرفعال' ),
			'PHP: ' . $i['php'],
		);
		if ( $i['ok'] && '' !== $i['method'] ) {
			$lines[] = 'نحوهٔ تشخیص: ' . $i['method'];
		}
		if ( '' !== $i['func'] ) {
			$lines[] = 'نسخهٔ Loader: ' . $i['func'];
		}
		if ( '' !== $i['zend'] ) {
			$lines[] = 'zend_extension: ' . $i['zend'];
		}
		$lines[] = 'افزونه‌های حاوی ioncube: ' . ( $i['exts'] ? implode( ', ', $i['exts'] ) : 'هیچ' );
		return implode( "\n", $lines );
	}

	/**
	 * آیا کلاس لایسنس راست‌چین بارگذاری شده؟ (یعنی هش فایل لایسنس خواند)
	 *
	 * @return bool
	 */
	public static function class_loaded() {
		foreach ( self::license_files() as $file ) {
			$name = basename( $file, '.php' );
			if ( class_exists( $name ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * فایل(های) لایسنس خریدار در ریشهٔ افزونه.
	 *
	 * @return array
	 */
	public static function license_files() {
		$found = glob( GAPINEH_PATH . self::LICENSE_PATTERN );
		return is_array( $found ) ? $found : array();
	}

	/**
	 * برچسب فارسی وضعیت.
	 *
	 * @param string $status
	 * @return string
	 */
	public static function label( $status = '' ) {
		$status = $status ? $status : self::status();
		$map    = array(
			'active'        => ( defined( 'GAPINEH_DEMO_LICENSE' ) && GAPINEH_DEMO_LICENSE )
				? 'لایسنس نمایشی فعال است'
				: 'لایسنس فعال است',
			'inactive'      => 'لایسنس غیرفعال است',
			'hash_mismatch' => 'فایل لایسنس معتبر نیست',
			'no_loader'     => 'این سرور ionCube Loader ندارد',
			'lib_missing'   => 'کتابخانهٔ لایسنس نصب نشده',
		);
		return isset( $map[ $status ] ) ? $map[ $status ] : $map['lib_missing'];
	}

	/**
	 * توضیح کوتاه راهنما برای هر وضعیت.
	 *
	 * @param string $status
	 * @return string
	 */
	public static function hint( $status = '' ) {
		$status = $status ? $status : self::status();
		switch ( $status ) {
			case 'active':
				return ( defined( 'GAPINEH_DEMO_LICENSE' ) && GAPINEH_DEMO_LICENSE )
					? 'این بستهٔ نمایشی است و همهٔ بخش‌ها باز است؛ برای نصب واقعی از بستهٔ رسمی استفاده کنید.'
					: 'همهٔ قابلیت‌های نسخهٔ کامل فعال است.';
			case 'inactive':
				return 'لایسنس شناسایی شد ولی فعال نیست؛ از پنل راست‌چین وضعیت لایسنس و دامنه را بررسی کنید.';
			case 'hash_mismatch':
				return 'فایل کتابخانهٔ لایسنس در پوشهٔ افزونه هست ولی با این نسخه نمی‌خواند؛ بسته را دوباره نصب کنید.';
			case 'no_loader':
				return 'برای فعال‌سازی لایسنس، افزونهٔ رایگان ionCube Loader در PHP لازم است. در کنترل پنل هاست (بخش PHP → Extensions یا Select PHP Version) فعالش کنید، صفحه را دوباره باز کنید و دامنه را در پنل راست‌چین فعال نمایید. تا آن زمان بخش‌های وابسته به لایسنس نمایش داده نمی‌شوند.';
			default:
				return 'کتابخانهٔ RTL_License_…php کنار gapineh.php نیست؛ بستهٔ نصب ناقص است.';
		}
	}

	/**
	 * آیا وضعیت، نیاز به اعلان به مدیر دارد؟
	 *
	 * @param string $status
	 * @return bool
	 */
	public static function needs_notice( $status = '' ) {
		$status = $status ? $status : self::status();
		return in_array( $status, array( 'inactive', 'hash_mismatch', 'no_loader', 'lib_missing' ), true );
	}

	/**
	 * ردیف وضعیت برای بالای صفحهٔ تنظیمات.
	 */
	public static function render_status_row() {
		$status = self::status();
		$class  = 'active' === $status ? 'ok' : ( in_array( $status, array( 'no_loader', 'lib_missing' ), true ) ? 'warn' : 'bad' );
		?>
		<div class="psb-set-status psb-license <?php echo esc_attr( $class ); ?>">
			<span class="dot"></span>
			<strong><?php echo esc_html( self::label( $status ) ); ?></strong>
			<span class="psb-license-hint"><?php echo esc_html( self::hint( $status ) ); ?></span>
		</div>
		<?php
	}

	/**
	 * اعلان خطا فقط وقتی فایل لایسنس هست ولی درست خوانده نمی‌شود.
	 */
	public static function admin_notice() {
		if ( self::is_pro() ) {
			return;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		// فقط در صفحهٔ افزونه‌ها و پیشخوان، تا همه‌جا مزاحم نشود.
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		$here   = $screen ? (string) $screen->id : '';
		if ( ! in_array( $here, array( 'plugins', 'dashboard', 'plugins-network' ), true ) ) {
			return;
		}

		printf(
			'<div class="notice notice-error"><p><strong>%s</strong></p><p>%s</p><p><a class="button button-primary" href="%s" target="_blank" rel="noopener">%s</a></p></div>',
			esc_html__( 'برای فعال‌سازی افزونه، بخش‌های دامنه خود را در سایت راست‌چین فعال نمایید.', 'gapineh' ),
			esc_html( self::hint() ),
			esc_url( 'https://rtl-theme.com/user/' ),
			esc_html__( 'باز کردن پنل راست‌چین', 'gapineh' )
		);
	}
}

/**
 * دروازهٔ قابلیت‌های نسخهٔ کامل.
 *
 * فیلتر gapineh_is_pro برای تست یا لایسنس‌های جایگزین در دسترس است.
 *
 * @return bool
 */
function gapineh_is_pro() {
	return (bool) apply_filters( 'gapineh_is_pro', Gapineh_License::is_pro() );
}

add_action( 'admin_notices', array( 'Gapineh_License', 'admin_notice' ) );
