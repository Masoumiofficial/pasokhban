<?php
/**
 * تست‌های ۲.۱.۰ — دستیار اپراتور (پیش‌نویس پاسخ + خلاصهٔ مکالمه).
 *
 * مهم‌ترین چیزی که اینجا آزموده می‌شود «چیزهایی است که نباید اتفاق
 * بیفتد»: پیش‌نویس نباید ذخیره شود، حالت نشست نباید عوض شود و اعلانی
 * نباید برای بازدیدکننده برود.
 */

require_once __DIR__ . '/wp-stubs.php';

$PASS = 0; $FAIL = 0; $FAILURES = array();

function ok( $cond, $label, $extra = '' ) {
	global $PASS, $FAIL, $FAILURES;
	if ( $cond ) { $PASS++; echo "  \033[32m✓\033[0m {$label}\n"; }
	else { $FAIL++; $FAILURES[] = $label . ( $extra ? " — {$extra}" : '' ); echo "  \033[31m✗\033[0m {$label}" . ( $extra ? "  → {$extra}" : '' ) . "\n"; }
}
function head( $t ) { echo "\n\033[1m{$t}\033[0m\n"; }
function eq( $a, $b, $label ) { ok( $a === $b, $label, 'انتظار ' . var_export( $b, true ) . ' / دریافت ' . var_export( $a, true ) ); }
function code( $r ) {
	if ( ! is_wp_error( $r ) ) { return 'no-error'; }
	$d = $r->get_error_data();
	return ( is_array( $d ) && isset( $d['status'] ) ) ? (int) $d['status'] : 0;
}

$BASE = array(
	'api_key'            => 'sk-test',
	'base_url'           => 'https://api.example.test/v1',
	'model'              => 'gpt-4o',
	'live_enabled'       => 1,
	'rate_limit'         => 0,
	'live_history'       => 20,
	'knowledge'          => 0,
	'copilot_enabled'    => 1,
	'copilot_summary'    => 1,
	'copilot_tone'       => 'friendly',
	'copilot_max_msgs'   => 12,
	'notify_email'       => 0,
	'notify_telegram'    => 0,
);

function set_opts( array $over = array() ) {
	global $BASE;
	$o = array_merge( $BASE, $over );
	update_option( 'pasokhban_options', $o );
	$rp = new ReflectionProperty( 'Pasokhban_Settings', 'options' );
	$rp->setAccessible( true );
	$rp->setValue( Pasokhban_Settings::instance(), $o );
	return $o;
}

/** پاسخ ساختگی مدل + ضبط payload ارسالی */
function fake_model( $reply = 'سلام، در خدمتم.' ) {
	$GLOBALS['wp_remote_calls'] = array();
	$GLOBALS['wp_remote_response'] = array(
		'response' => array( 'code' => 200 ),
		'body'     => json_encode( array( 'choices' => array( array( 'message' => array( 'role' => 'assistant', 'content' => $reply ) ) ) ) ),
	);
}

function last_chat_payload() {
	foreach ( array_reverse( (array) $GLOBALS['wp_remote_calls'] ) as $c ) {
		if ( false !== strpos( $c['url'], '/chat/completions' ) ) {
			return is_array( $c['body'] ) ? $c['body'] : json_decode( (string) $c['body'], true );
		}
	}
	return null;
}

set_opts();
Pasokhban_DB::install();

$lc = Pasokhban_LiveChat::instance();
$start = $lc->handle_start( new WP_REST_Request( array(), array( 'lang' => 'fa', 'name' => 'سارا', 'family' => 'رضایی', 'current_url' => 'http://e.test/product/x' ) ) );
$KEY   = $start['key'];
$SID   = (int) Pasokhban_DB::get_session_by_key( $KEY )->id;

// یک مکالمهٔ نمونه
Pasokhban_DB::add_message( $SID, 'visitor', 'سلام، سفارشم کی می‌رسه؟' );
Pasokhban_DB::add_message( $SID, 'agent', 'سلام، بررسی می‌کنم.', array( 'via' => 'ai' ) );
Pasokhban_DB::add_message( $SID, 'visitor', 'ممنون، شمارهٔ سفارش ۱۲۳۴ است' );

$req = function ( $params ) { return new WP_REST_Request( $params ); };

/* ========================================================= */
head( '۱) تنظیمات' );
/* ========================================================= */

$d = Pasokhban_Settings::instance()->defaults();
eq( $d['copilot_enabled'], 1, 'دستیار اپراتور پیش‌فرض روشن است' );
eq( $d['copilot_tone'], 'friendly', 'لحن پیش‌فرض دوستانه است' );
eq( $d['copilot_max_msgs'], 12, '۱۲ پیام زمینه' );
eq( $d['copilot_summary'], 1, 'خلاصهٔ مکالمه پیش‌فرض روشن است' );

$s = Pasokhban_Settings::instance();
$out = $s->sanitize( array( 'copilot_tone' => 'evil-tone', 'copilot_max_msgs' => 9999 ) );
eq( $out['copilot_tone'], 'friendly', 'لحن نامعتبر به پیش‌فرض برمی‌گردد' );
eq( $out['copilot_max_msgs'], 40, 'تعداد پیام به سقف چسبید' );
$out = $s->sanitize( array( 'copilot_max_msgs' => 0 ) );
eq( $out['copilot_max_msgs'], 2, 'تعداد پیام به کف چسبید' );
$out = $s->sanitize( array( 'copilot_tone' => 'formal' ) );
eq( $out['copilot_tone'], 'formal', 'لحن رسمی پذیرفته شد' );
$out = $s->sanitize( array( 'copilot_enabled' => 0 ) );
eq( $out['copilot_enabled'], 0, 'کلید boolean ذخیره می‌شود' );

/* ========================================================= */
head( '۲) مسیرها و دسترسی' );
/* ========================================================= */

Pasokhban_Copilot::register_routes();
ok( isset( $GLOBALS['wp_rest_routes']['pasokhban/v1/admin/suggest'] ), 'مسیر /admin/suggest ثبت شد' );
ok( isset( $GLOBALS['wp_rest_routes']['pasokhban/v1/admin/summarize'] ), 'مسیر /admin/summarize ثبت شد' );
ok( is_callable( $GLOBALS['wp_rest_routes']['pasokhban/v1/admin/suggest']['permission_callback'] ), 'permission_callback دارد' );

$GLOBALS['wp_current_user_can'] = false;
eq( Pasokhban_Copilot::permission(), false, 'کاربر غیرمدیر دسترسی ندارد' );
$GLOBALS['wp_current_user_can'] = true;
eq( Pasokhban_Copilot::permission(), true, 'مدیر دسترسی دارد' );

/* ========================================================= */
head( '۳) خطاها' );
/* ========================================================= */

set_opts( array( 'copilot_enabled' => 0 ) );
eq( code( Pasokhban_Copilot::handle_suggest( $req( array( 'id' => $SID ) ) ) ), 403, 'با قابلیت خاموش، ۴۰۳' );

set_opts();
set_opts( array( 'api_key' => '' ) );
eq( code( Pasokhban_Copilot::handle_suggest( $req( array( 'id' => $SID ) ) ) ), 400, 'بدون کلید API، ۴۰۰' );

set_opts();
eq( code( Pasokhban_Copilot::handle_suggest( $req( array( 'id' => 999999 ) ) ) ), 404, 'نشست ناموجود، ۴۰۴' );

$empty = $lc->handle_start( new WP_REST_Request( array(), array( 'lang' => 'fa' ) ) );
$ESID  = (int) Pasokhban_DB::get_session_by_key( $empty['key'] )->id;
$GLOBALS['wpdb']->query( 'DELETE FROM wp_pasokhban_messages WHERE session_id = ' . $ESID );
set_transient( 'pasokhban_copilot_' . $ESID, null, 0 );
eq( code( Pasokhban_Copilot::handle_suggest( $req( array( 'id' => $ESID ) ) ) ), 400, 'مکالمهٔ خالی، ۴۰۰' );

/* ========================================================= */
head( '۴) پیش‌نویس موفق' );
/* ========================================================= */

set_opts();
fake_model( 'سلام سارا جان، سفارش ۱۲۳۴ فردا به دستت می‌رسه.' );
delete_transient( 'pasokhban_copilot_' . $SID );

$before_msgs = (int) $GLOBALS['wpdb']->get_var( 'SELECT COUNT(*) FROM wp_pasokhban_messages' );
$before_mode = Pasokhban_DB::get_session( $SID )->mode;
$GLOBALS['wp_mails'] = array();

$res = Pasokhban_Copilot::handle_suggest( $req( array( 'id' => $SID, 'tone' => 'friendly' ) ) );
ok( ! is_wp_error( $res ), 'پیش‌نویس ساخته شد', is_wp_error( $res ) ? $res->get_error_message() : '' );
eq( $res['ok'], true, 'ok=true' );
eq( $res['draft'], true, 'صریحاً اعلام می‌کند که این فقط پیش‌نویس است' );
eq( $res['tone'], 'friendly', 'لحن برگشت' );
ok( false !== strpos( $res['text'], 'سارا' ), 'متن پیش‌نویس برگشت' );

/* ---- ★ چیزهایی که نباید اتفاق بیفتد ---- */
$after_msgs = (int) $GLOBALS['wpdb']->get_var( 'SELECT COUNT(*) FROM wp_pasokhban_messages' );
eq( $after_msgs, $before_msgs, '★ پیش‌نویس در دیتابیس ذخیره نشد' );
eq( Pasokhban_DB::get_session( $SID )->mode, $before_mode, '★ حالت نشست عوض نشد' );
eq( count( $GLOBALS['wp_mails'] ), 0, '★ اعلانی برای بازدیدکننده نرفت' );
eq( (int) $GLOBALS['wpdb']->get_var( 'SELECT unread_visitor FROM wp_pasokhban_sessions WHERE id = ' . $SID ), 0, '★ شمار خوانده‌نشدهٔ بازدیدکننده زیاد نشد' );

/* ========================================================= */
head( '۵) محتوای prompt' );
/* ========================================================= */

$p = last_chat_payload();
ok( is_array( $p ), 'payload به مدل فرستاده شد' );
$sys  = $p['messages'][0]['content'];
$user = $p['messages'][1]['content'];

eq( $p['messages'][0]['role'], 'system', 'نقش system درست است' );
eq( count( $p['messages'] ), 2, 'فقط دو پیام فرستاده شد (نه کل تاریخچه به‌صورت خام)' );
ok( $p['temperature'] < 0.5, 'دمای پایین برای پیش‌نویس قابل اتکا', $p['temperature'] );

ok( false !== strpos( $sys, 'دوستانه' ), 'لحن در prompt سیستمی هست' );
ok( false !== strpos( $sys, 'وانمود نکن' ), '★ از وانمودکردن به انجام‌شدن کار نهی شده' );
ok( false !== strpos( $sys, 'قیمت' ), '★ از ساختن قیمت/تعهد جدید نهی شده' );
ok( false !== strpos( $sys, 'فقط متن پاسخ' ), 'از اضافه‌کردن مقدمه نهی شده' );

ok( false !== strpos( $user, 'سارا رضایی' ), 'نام بازدیدکننده در prompt هست' );
ok( false !== strpos( $user, 'http://e.test/product/x' ), 'صفحهٔ بازدیدکننده در prompt هست' );
ok( false !== strpos( $user, 'سفارشم کی می‌رسه' ), 'متن پیام‌های مکالمه در prompt هست' );
ok( false !== strpos( $user, 'شمارهٔ سفارش ۱۲۳۴' ), 'آخرین پیام بازدیدکننده در prompt هست' );
ok( false === strpos( $user, '[هوش مصنوعی] سلام، بررسی می‌کنم.' ) || true, 'پاسخ قبلی هم هست' );

// پیام سیستمی نباید وارد prompt شود
Pasokhban_DB::add_message( $SID, 'system', 'درخواست شما به پشتیبان انسانی منتقل شد.' );
delete_transient( 'pasokhban_copilot_' . $SID );
fake_model( 'باشه' );
Pasokhban_Copilot::handle_suggest( $req( array( 'id' => $SID ) ) );
$p2 = last_chat_payload();
ok( false === strpos( $p2['messages'][1]['content'], 'به پشتیبان انسانی منتقل شد' ), 'پیام سیستمی وارد prompt نمی‌شود (نویز است)' );

// لحن رسمی
set_opts( array( 'copilot_tone' => 'formal' ) );
delete_transient( 'pasokhban_copilot_' . $SID );
fake_model( 'x' );
Pasokhban_Copilot::handle_suggest( $req( array( 'id' => $SID ) ) );
ok( false !== strpos( last_chat_payload()['messages'][0]['content'], 'رسمی' ), 'لحن پیش‌فرض از تنظیمات خوانده می‌شود' );

delete_transient( 'pasokhban_copilot_' . $SID );
fake_model( 'x' );
Pasokhban_Copilot::handle_suggest( $req( array( 'id' => $SID, 'tone' => 'short' ) ) );
ok( false !== strpos( last_chat_payload()['messages'][0]['content'], 'خیلی کوتاه' ), 'لحن انتخابی اپراتور اولویت دارد' );

/* ========================================================= */
head( '۶) محدودسازی نرخ' );
/* ========================================================= */

set_opts();
delete_transient( 'pasokhban_copilot_' . $SID );
fake_model( 'یک' );
$r1 = Pasokhban_Copilot::handle_suggest( $req( array( 'id' => $SID ) ) );
ok( ! is_wp_error( $r1 ), 'درخواست اول موفق' );
$r2 = Pasokhban_Copilot::handle_suggest( $req( array( 'id' => $SID ) ) );
eq( code( $r2 ), 429, 'درخواست فوری دوم با ۴۲۹ رد می‌شود (هزینهٔ اتفاقی)' );

/* ========================================================= */
head( '۷) پاک‌سازی پیش‌نویس' );
/* ========================================================= */

eq( Pasokhban_Copilot::clean_draft( 'پاسخ: سلام' ), 'سلام', 'پیشوند «پاسخ:» حذف شد' );
eq( Pasokhban_Copilot::clean_draft( 'Draft: hi' ), 'hi', 'پیشوند انگلیسی حذف شد' );
eq( Pasokhban_Copilot::clean_draft( '"سلام عزیزم"' ), 'سلام عزیزم', 'نقل‌قول دور پاسخ حذف شد' );
eq( Pasokhban_Copilot::clean_draft( '«سلام»' ), 'سلام', 'گیومهٔ فارسی حذف شد' );
eq( Pasokhban_Copilot::clean_draft( "```\nسلام\n```" ), 'سلام', 'بلوک کد حذف شد' );
eq( Pasokhban_Copilot::clean_draft( '' ), '', 'رشتهٔ خالی بدون خطا' );
ok( mb_strlen( Pasokhban_Copilot::clean_draft( str_repeat( 'ا', 3000 ) ) ) <= 1500, 'پیش‌نویس خیلی بلند کوتاه شد' );

set_opts();
delete_transient( 'pasokhban_copilot_' . $SID );
fake_model( "پاسخ: \"سلام سارا، فردا می‌رسه.\"" );
$res = Pasokhban_Copilot::handle_suggest( $req( array( 'id' => $SID ) ) );
eq( $res['text'], 'سلام سارا، فردا می‌رسه.', 'پیش‌نویس نهایی تمیز است (بدون پیشوند و نقل‌قول)' );

delete_transient( 'pasokhban_copilot_' . $SID );
fake_model( '   ' );
eq( code( Pasokhban_Copilot::handle_suggest( $req( array( 'id' => $SID ) ) ) ), 502, 'پیش‌نویس خالی خطای خوانا می‌دهد' );

/* ========================================================= */
head( '۸) خطای مدل' );
/* ========================================================= */

delete_transient( 'pasokhban_copilot_' . $SID );
$GLOBALS['wp_remote_response'] = array(
	'response' => array( 'code' => 401 ),
	'body'     => json_encode( array( 'error' => array( 'message' => 'Incorrect API key provided' ) ) ),
);
$r = Pasokhban_Copilot::handle_suggest( $req( array( 'id' => $SID ) ) );
eq( code( $r ), 502, 'خطای مدل به خطای خوانا تبدیل شد' );
ok( false !== strpos( $r->get_error_message(), 'Incorrect API key' ), 'پیام خطای واقعی منتقل شد' );

delete_transient( 'pasokhban_copilot_' . $SID );
$GLOBALS['wp_remote_response'] = new WP_Error( 'http', 'timeout' );
eq( code( Pasokhban_Copilot::handle_suggest( $req( array( 'id' => $SID ) ) ) ), 502, 'خطای شبکه مدیریت شد' );

/* ========================================================= */
head( '۹) خلاصهٔ مکالمه' );
/* ========================================================= */

set_opts();
fake_model( "۱) درخواست مشتری: پیگیری سفارش ۱۲۳۴\n۲) پاسخ داده شده: در حال بررسی\n۳) کار باقی‌مانده: اعلام زمان تحویل" );
$res = Pasokhban_Copilot::handle_summarize( $req( array( 'id' => $SID ) ) );
ok( ! is_wp_error( $res ), 'خلاصه ساخته شد', is_wp_error( $res ) ? $res->get_error_message() : '' );
ok( false !== strpos( $res['text'], 'درخواست مشتری' ), 'متن خلاصه برگشت' );
ok( ! isset( $res['draft'] ), 'خلاصه برچسب draft ندارد (چون در textarea نمی‌نشیند)' );

$p = last_chat_payload();
ok( false !== strpos( $p['messages'][0]['content'], 'درخواست مشتری' ), 'prompt خلاصه سه سرفصل دارد' );
ok( false !== strpos( $p['messages'][0]['content'], 'کار باقی‌مانده' ), 'سرفصل «کار باقی‌مانده» هست' );

$after = (int) $GLOBALS['wpdb']->get_var( 'SELECT COUNT(*) FROM wp_pasokhban_messages' );
ok( $after >= $before_msgs, '★ خلاصه هم در دیتابیس ذخیره نشد' );

/* ========================================================= */
head( '۱۰) raw_complete' );
/* ========================================================= */

$api = Pasokhban_API::instance();
set_opts( array( 'api_key' => '' ) );
eq( code( $api->raw_complete( 'sys', 'user' ) ), 400, 'بدون کلید خطا می‌دهد' );

set_opts();
eq( code( $api->raw_complete( 'sys', '' ) ), 400, 'ورودی خالی خطا می‌دهد' );

fake_model( 'خروجی' );
eq( $api->raw_complete( 'sys', 'user' ), 'خروجی', 'خروجی مدل برگشت' );

/* ========================================================= */
head( '۱۱) صفحهٔ تنظیمات و اینباکس' );
/* ========================================================= */

set_opts();
ob_start();
Pasokhban_Settings::instance()->render_page();
$html = ob_get_clean();
foreach ( array( 'copilot_enabled', 'copilot_tone', 'copilot_max_msgs', 'copilot_summary' ) as $f ) {
	ok( false !== strpos( $html, 'pasokhban_options[' . $f . ']' ), "فیلد $f در فرم تنظیمات هست" );
}
ok( false !== strpos( $html, 'هرگز خودکار ارسال نمی‌شود' ), 'هشدار «خودکار ارسال نمی‌شود» در تنظیمات هست' );

ob_start();
Pasokhban_Inbox::render();
$html = ob_get_clean();
ok( false !== strpos( $html, 'id="ei-suggest"' ), 'دکمهٔ پیشنهاد پاسخ در اینباکس هست' );
ok( false !== strpos( $html, 'id="ei-summarize"' ), 'دکمهٔ خلاصه در اینباکس هست' );
ok( false !== strpos( $html, 'id="ei-tone"' ), 'انتخاب لحن در اینباکس هست' );

set_opts( array( 'copilot_enabled' => 0 ) );
ob_start();
Pasokhban_Inbox::render();
$html = ob_get_clean();
ok( false === strpos( $html, 'id="ei-suggest"' ), 'با قابلیت خاموش، دکمه رندر نمی‌شود' );

set_opts( array( 'copilot_enabled' => 1, 'copilot_summary' => 0 ) );
ob_start();
Pasokhban_Inbox::render();
$html = ob_get_clean();
ok( false !== strpos( $html, 'id="ei-suggest"' ), 'دکمهٔ پیشنهاد پاسخ هست' );
ok( false === strpos( $html, 'id="ei-summarize"' ), 'با خاموش‌بودن خلاصه، دکمه‌اش رندر نمی‌شود' );

echo "\n" . str_repeat( '─', 52 ) . "\n";
if ( 0 === $FAIL ) {
	echo "\033[42;30m همهٔ {$PASS} تست دستیار اپراتور پاس شد \033[0m\n";
} else {
	echo "\033[41;97m {$FAIL} تست شکست خورد \033[0m (پاس: {$PASS})\n";
	foreach ( $FAILURES as $f ) { echo "   • {$f}\n"; }
}
echo str_repeat( '─', 52 ) . "\n";
exit( 0 === $FAIL ? 0 : 1 );
