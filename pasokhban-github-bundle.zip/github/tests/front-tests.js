/**
 * تست فرانت‌اند — فایل واقعی assets/js/pasokhban-chat.js را
 * داخل یک DOM واقعی (jsdom) با fetch شبیه‌سازی‌شده اجرا می‌کند.
 */
const fs = require('fs');
const { JSDOM } = require('jsdom');

const JS = fs.readFileSync(__dirname + '/../plugin/assets/js/pasokhban-chat.js', 'utf8');

let pass = 0, fail = 0; const fails = [];
const ok = (c, l, x) => { if (c) { pass++; console.log(`  \x1b[32m✓\x1b[0m ${l}`); } else { fail++; fails.push(l + (x ? ' — ' + x : '')); console.log(`  \x1b[31m✗\x1b[0m ${l}` + (x ? '  → ' + x : '')); } };
const eq = (a, b, l) => ok(a === b, l, `انتظار ${JSON.stringify(b)} / دریافت ${JSON.stringify(a)}`);
const head = t => console.log(`\n\x1b[1m${t}\x1b[0m`);
const wait = ms => new Promise(r => setTimeout(r, ms));

const SETTINGS = {
  title: 'گفتگوی آنلاین', agentName: 'پشتیبانی', greeting: 'سلام! 👋',
  placeholder: 'بنویس…', accent: '#ff00aa', position: 'end',
  autoOpen: false, autoDelay: 5, starter: ['سؤال یک', 'سؤال دو'],
  humanHandoff: true, sound: false, offlineNote: '',
  offsetBottom: 30, offsetSide: 24, launcherSize: 70,
  panelWidth: 400, panelHeight: 640, radius: 22, blur: 24, glassOpacity: 55,
  launcherLabel: '', teaser: true, teaserText: 'متن سفارشی برچسب',
  mobileSheet: true, maximize: true, showFooter: true, theme: 'auto',
  prechat: false, prechatRequired: true, prechatNote: 'مشخصاتت را وارد کن'
};

function makeDom(over) {
  const S2 = Object.assign({}, SETTINGS, over || {});
  const dom = new JSDOM(
    `<!DOCTYPE html><html dir="rtl"><body><div id="pasokhban-live" data-mode="widget"></div></body></html>`,
    { url: 'http://example.test/', pretendToBeVisual: true, runScripts: 'dangerously' }
  );
  const w = dom.window;

  w.PASOKHBAN_CHAT = { restUrl: '/wp-json/pasokhban/v1', nonce: 'n', lang: 'fa' };
  w.PASOKHBAN_CHAT_SETTINGS = S2;

  const calls = [];
  w.__calls = calls;
  w.__pending = [];
  w.__mode = 'ai';
  w.__fail = false;
  w.__failStart = false;
  w.__echoVisitor = false;
  w.__lastVisitorMsg = null;
  let id = 10;

  w.fetch = (url, opt) => {
    opt = opt || {};
    const path = String(url).replace(/^.*\/pasokhban\/v1/, '');
    const body = opt.body ? JSON.parse(opt.body) : {};
    calls.push({ path, body });
    return Promise.resolve({
      ok: !(w.__failStart && path.startsWith('/live/start')),
      status: (w.__failStart && path.startsWith('/live/start')) ? 503 : 200,
      json: () => {
        if (path.startsWith('/live/start')) {
          if (w.__failStart) return Promise.resolve({ message: 'سرور در دسترس نیست' });
          return Promise.resolve({ key: 'a1b2c3d4e5f60718293a4b5c6d7e8f90', mode: w.__mode, status: 'open', messages: [], agentOnline: false, agentName: 'پشتیبانی', settings: S2 });
        }
        if (path.startsWith('/live/contact')) return Promise.resolve({ ok: true });
      if (path.startsWith('/live/handoff')) {
        w.__mode = 'agent';
        return Promise.resolve({ mode: 'agent', note: 'درخواست شما به پشتیبان انسانی منتقل شد. لطفاً کمی صبر کنید.', agentOnline: false });
      }
      if (path.startsWith('/live/send')) {
        w.__lastVisitorMsg = { id: ++id, sender: 'visitor', content: body.content, meta: {}, time: new Date().toISOString() };
          const m = { id: ++id, sender: 'visitor', content: body.content, meta: {}, time: new Date().toISOString() };
          if (w.__fail) return Promise.resolve({ message: m, mode: w.__mode, error: 'Incorrect API key provided' });
          if (w.__mode === 'agent') return Promise.resolve({ message: m, mode: 'agent', queued: true });
          return Promise.resolve({ message: m, mode: 'ai', reply: { id: ++id, sender: 'agent', content: 'جواب <b>دستیار</b> است. لینک: https://example.ir/x', meta: { via: 'ai', sources: [{ title: 'منبع', url: 'https://example.ir/s' }] }, time: new Date().toISOString() } });
        }
        if (path.startsWith('/live/poll')) {
          const m = w.__pending.splice(0, w.__pending.length);
          if (w.__echoVisitor) { m.unshift(w.__lastVisitorMsg); w.__echoVisitor = false; }
          return Promise.resolve({ messages: m, mode: w.__mode, status: null, typing: false, agentOnline: false, agentName: 'پشتیبانی' });
        }
        return Promise.resolve({ ok: true });
      }
    });
  };

  // اجرای فایل واقعی پلاگین در realm خودِ window
  const s = w.document.createElement('script');
  s.textContent = JS;
  w.document.body.appendChild(s);

  return { dom, w, doc: w.document, id: () => ++id };
}

(async () => {

/* ========================================================= */
head('۱) ساخت رابط کاربری');
/* ========================================================= */
const { w, doc } = makeDom();
await wait(150);

ok(!!doc.querySelector('.psb-launcher'), 'حباب راه‌انداز ساخته شد');
ok(!!doc.querySelector('.psb-panel'), 'پنل ساخته شد');
ok(!!doc.querySelector('.psb-head'), 'هدر ساخته شد');
ok(!!doc.querySelector('.psb-body'), 'بدنهٔ پیام ساخته شد');
ok(!!doc.querySelector('.psb-input'), 'باکس ورودی ساخته شد');
ok(!!doc.querySelector('.psb-send'), 'دکمهٔ ارسال ساخته شد');
ok(!!doc.querySelector('.psb-avatar .psb-brain'), 'مغز در آواتار هدر هست');
ok(!!doc.querySelector('#psb-human'), 'دکمهٔ «گپ با پشتیبان» هست (humanHandoff=true)');
eq(doc.querySelector('.psb-launcher').dataset.pos, 'end', 'موقعیت از تنظیمات خوانده شد');
eq(doc.querySelector('.psb-htitle').textContent, 'گفتگوی آنلاین', 'عنوان از تنظیمات خوانده شد');
eq(doc.querySelector('.psb-input').placeholder, 'بنویس…', 'placeholder از تنظیمات خوانده شد');
eq(w.document.getElementById('pasokhban-live').style.getPropertyValue('--psb-accent'), '#ff00aa', 'رنگ اصلی روی root اعمال شد (باگ ۱.۰.۰ در ویجت مغز)');

// بازدیدکنندهٔ تازه: تا پنل باز نشود هیچ درخواستی به سرور نمی‌رود
eq(w.__calls.length, 0, 'بازدیدکنندهٔ تازه هیچ درخواستی به سرور نمی‌زند (بدون ساخت نشست بیهوده)');

// با باز کردن پنل، نشست ساخته می‌شود
doc.querySelector('.psb-launcher').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
await wait(80);
ok(w.__calls.some(c => c.path.startsWith('/live/start')), '/live/start صدا زده شد');
eq(doc.querySelectorAll('.psb-chip').length, 2, 'دکمه‌های شروع ساخته شدند');
const greet = doc.querySelector('.psb-msg.agent');
ok(!!greet, 'حباب greeting رندر شد');
eq(greet ? greet.textContent.trim() : '', 'سلام! 👋', 'متن greeting درست است');

/* ========================================================= */
head('۲) 🧠 مغزِ در حال تفکر → محو شدن → پاسخ');
/* ========================================================= */

ok(doc.getElementById('pasokhban-live').classList.contains('is-open'), 'پنل باز شد');
eq(doc.querySelector('.psb-launcher').getAttribute('aria-expanded'), 'true', 'aria-expanded به‌روز شد');

// ارسال پیام
const input = doc.querySelector('.psb-input');
input.value = 'قیمت چنده؟';
input.dispatchEvent(new w.Event('input', { bubbles: true }));
doc.querySelector('.psb-send').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));

await wait(20);
const think = doc.querySelector('.psb-think');
ok(!!think, '🧠 اندیکاتور تفکر ظاهر شد');
ok(!!(think && think.querySelector('.psb-brain')), 'شکل مغز (SVG) داخل اندیکاتور هست');
ok(!!(think && think.querySelector('.psb-brain .shell')), 'خط دور مغز هست');
ok(!!(think && think.querySelectorAll('.psb-brain .node').length === 6), '۶ گرهٔ عصبی مغز هست');
ok(!!(think && /در حال تفکر/.test(think.textContent)), 'متن «در حال تفکر» نمایش داده می‌شود');
eq(doc.querySelector('.psb-msg.visitor') ? doc.querySelector('.psb-msg.visitor').textContent : null, 'قیمت چنده؟', 'پیام کاربر رندر شد');

// پاسخ می‌رسد → مغز باید برود
await wait(120);
const leaving = doc.querySelector('.psb-think.leaving');
ok(!!leaving, 'مغز کلاس خروج (leaving) گرفت');
await wait(500);
eq(doc.querySelectorAll('.psb-think').length, 0, '🧠 مغز بعد از رسیدن پاسخ کاملاً حذف شد');

const botMsgs = doc.querySelectorAll('.psb-msg.agent');
const last = botMsgs[botMsgs.length - 1];
ok(!!last, 'حباب پاسخ رندر شد');
ok(last && last.textContent.indexOf('جواب') === 0, 'متن پاسخ درست است', last ? last.textContent.slice(0, 30) : '');
ok(last && !!last.querySelector('.psb-srcbtn'), 'دکمهٔ «مشاهدهٔ منابع» زیر پاسخ هست');
ok(last && last.querySelectorAll(':scope > .psb-srcs a').length === 0, 'منابع به‌صورت فهرست باز زیر پاسخ نیستند');
ok(last && !!last.querySelector('.psb-time'), 'ساعت پیام نمایش داده شد');

/* ========================================================= */
head('۳) امنیت — فرار از HTML و لینک‌سازی');
/* ========================================================= */

input.value = '<img src=x onerror="alert(1)"> سلام';
doc.querySelector('.psb-send').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
await wait(200);

const vMsgs = doc.querySelectorAll('.psb-msg.visitor');
const xss = vMsgs[vMsgs.length - 1];
eq(doc.querySelectorAll('img').length, 0, 'هیچ تگ <img> تزریق نشد');
ok(xss && xss.textContent.indexOf('<img src=x') === 0, 'تگ به‌صورت متن نمایش داده شد (escape شد)');
ok(xss && !xss.innerHTML.includes('<img'), 'innerHTML هم تگ خام ندارد');

// پاسخ AI هم که HTML داشت escape شده
const bots = doc.querySelectorAll('.psb-msg.agent');
const b = bots[bots.length - 1];
const txtNode = b ? b.querySelector('.psb-msg-text').childNodes[0] : null;
eq(txtNode && txtNode.nodeType, 3, 'اولین گرهٔ حباب پاسخ، گرهٔ متن است (نه المان)');
ok(txtNode && txtNode.nodeValue.indexOf('<b>دستیار</b>') >= 0,
   'تگ <b> پاسخ AI به‌صورت متن ماند (تبدیل به المان نشد)',
   txtNode ? JSON.stringify(txtNode.nodeValue.slice(0, 30)) : '');
eq(doc.querySelectorAll('.psb-msg-text b').length, 0, 'هیچ تگ <b> واقعی داخل متن تزریق نشد');
const auto = b ? b.querySelector('a[href="https://example.ir/x"]') : null;
ok(!!auto, 'URL خام خودکار به لینک تبدیل شد');
ok(auto && auto.getAttribute('rel').includes('nofollow'), 'لینک nofollow دارد');

/* ========================================================= */
head('۴) خطای API پنهان نمی‌شود');
/* ========================================================= */

w.__fail = true;
input.value = 'دوباره';
doc.querySelector('.psb-send').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
await wait(60);
ok(!!doc.querySelector('.psb-think'), 'مغز برای درخواست خطایی هم آمد');
await wait(120);
const errEl = doc.querySelector('.psb-err');
ok(!!errEl, 'کادر خطا نمایش داده شد');
eq(errEl ? errEl.textContent : '', 'Incorrect API key provided', 'متن خطای واقعی API نشان داده شد');
await wait(600);
eq(doc.querySelectorAll('.psb-think').length, 0, 'مغز در حالت خطا هم حذف شد');
w.__fail = false;

/* ========================================================= */
head('۵) ورود اپراتور انسانی');
/* ========================================================= */

w.__mode = 'agent';
const callsBeforeHandoff = w.__calls.length;   // فقط درخواست‌های بعد از کلیک را بشمار
doc.querySelector('#psb-human').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
await wait(20);
const callsAfter = w.__calls.slice(callsBeforeHandoff);
ok(!!doc.querySelector('.psb-think'), 'اندیکاتور هنگام درخواست انسانی آمد');
ok(callsAfter.some(c => c.path.startsWith('/live/handoff')), 'دکمهٔ پشتیبان به /live/handoff می‌رود');
ok(!callsAfter.some(c => c.path.startsWith('/live/send')), 'پیام متنی به AI فرستاده نشد');
await wait(200);
const sys = doc.querySelector('.psb-sys');
ok(!!sys && /پشتیبان انسانی/.test(sys.textContent), 'پیام «به پشتیبان انسانی منتقل شد» نمایش داده شد', sys ? sys.textContent : '');

// حالا کلاینت از پاسخ فهمیده mode=agent است؛ پیام بعدی باید «در حال نوشتن» بدهد
input.value = 'ممنون، منتظرم';
doc.querySelector('.psb-send').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
await wait(30);
ok(!!doc.querySelector('.psb-think .psb-dots'), 'به‌جای مغز، «در حال نوشتن» نمایش داده شد');
var thinkNodes = doc.querySelectorAll('.psb-think');
ok(/پشتیبان در حال نوشتن/.test(thinkNodes[thinkNodes.length - 1].textContent), 'متن «پشتیبان در حال نوشتن» درست است', thinkNodes[thinkNodes.length - 1].textContent);
await wait(600);
// پاسخ انسانی از طریق poll
w.__pending.push({ id: 900, sender: 'agent', content: 'سلام، من پشتیبانم.', meta: { via: 'human' }, time: new Date().toISOString() });
await wait(4300);
const all = doc.querySelectorAll('.psb-msg.agent');
ok(Array.from(all).some(n => n.textContent.includes('من پشتیبانم')), 'پاسخ اپراتور از poll رسید و رندر شد');

/* ========================================================= */
head('۶) بستن پنل و badge');
/* ========================================================= */

doc.querySelector('#psb-close').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
await wait(20);
ok(!doc.getElementById('pasokhban-live').classList.contains('is-open'), 'پنل بسته شد');

w.__pending.push({ id: 901, sender: 'agent', content: 'یه پیام دیگه', meta: {}, time: new Date().toISOString() });
await wait(8600);  // poll پنلِ بسته هر ۸ ثانیه
const badge = doc.querySelector('.psb-badge');
ok(badge && badge.classList.contains('on'), 'نشانگر پیام خوانده‌نشده روشن شد');
eq(badge ? badge.textContent : '', '1', 'شمارندهٔ badge = ۱');
ok(w.document.title.startsWith('(1)'), 'عنوان صفحه هم شماره خورد', w.document.title);

doc.querySelector('.psb-launcher').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
await wait(30);
ok(badge && !badge.classList.contains('on'), 'با باز کردن پنل badge خاموش شد');
eq(w.document.title.startsWith('('), false, 'شماره از عنوان صفحه پاک شد');

/* ========================================================= */
head('۷) تم و دسترس‌پذیری');
/* ========================================================= */

const themeBtn = doc.querySelector('#psb-theme');
themeBtn.dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
ok(doc.getElementById('pasokhban-live').classList.contains('psb-dark'), 'با یک کلیک حالت تاریک شد');
themeBtn.dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
ok(doc.getElementById('pasokhban-live').classList.contains('psb-light'), 'با کلیک دوم حالت روشن شد');
themeBtn.dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
ok(doc.getElementById('pasokhban-live').classList.contains('psb-auto'), 'با کلیک سوم حالت خودکار شد');

ok(doc.querySelector('.psb-panel').hasAttribute('role'), 'پنل role دارد');
eq(doc.querySelector('.psb-panel').getAttribute('role'), 'dialog', 'role=dialog');
ok(doc.querySelector('.psb-body').getAttribute('aria-live') === 'polite', 'aria-live روی بدنه هست');

doc.dispatchEvent(new w.KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
await wait(20);
ok(!doc.getElementById('pasokhban-live').classList.contains('is-open'), 'با Escape پنل بسته شد');

w.close();

/* ========================================================= */
head('۸) تنظیمات ظاهر (۱.۲.۰)');
/* ========================================================= */
{
  const t = makeDom();
  const wd = t.w, dd = t.doc;
  await wait(120);
  const R = dd.getElementById('pasokhban-live');
  const gv = v => R.style.getPropertyValue(v).trim();

  eq(gv('--psb-accent'), '#ff00aa', 'رنگ اصلی اعمال شد');
  eq(gv('--psb-off-bottom'), '30px', 'فاصله از پایین اعمال شد');
  eq(gv('--psb-off-side'), '24px', 'فاصله از کنار اعمال شد');
  eq(gv('--psb-launcher'), '70px', 'قطر حباب اعمال شد');
  eq(gv('--psb-panel-w'), '400px', 'عرض پنل اعمال شد');
  eq(gv('--psb-panel-h'), '640px', 'ارتفاع پنل اعمال شد');
  eq(gv('--psb-r-lg'), '22px', 'گردی پنل اعمال شد');
  eq(gv('--psb-blur-px'), '24px', 'شدت شیشه اعمال شد');
  eq(gv('--psb-glass-a'), '0.55', 'شفافیت پنل اعمال شد');
  ok(R.classList.contains('sheet'), 'کلاس sheet برای ورق موبایل هست');

  const mx = dd.querySelector('#psb-max');
  ok(!!mx, 'دکمهٔ بزرگ‌نمایی ساخته شد');
  mx.dispatchEvent(new wd.MouseEvent('click', { bubbles: true }));
  ok(R.classList.contains('is-max'), 'با کلیک پنل بزرگ شد');
  mx.dispatchEvent(new wd.MouseEvent('click', { bubbles: true }));
  ok(!R.classList.contains('is-max'), 'با کلیک دوم به اندازهٔ عادی برگشت');
  wd.close();
}

/* ========================================================= */
head('۹) خاموش‌کردن اجزا و حباب با متن');
/* ========================================================= */
{
  const t = makeDom({ maximize: false, showFooter: false, mobileSheet: false, humanHandoff: false, launcherLabel: 'پشتیبانی', starter: [] });
  const wd = t.w, dd = t.doc;
  await wait(120);
  const R = dd.getElementById('pasokhban-live');

  eq(dd.querySelector('#psb-max'), null, 'دکمهٔ بزرگ‌نمایی ساخته نشد');
  eq(dd.querySelector('.psb-foot'), null, 'پابرگ برند ساخته نشد');
  eq(dd.querySelector('#psb-human'), null, 'دکمهٔ «گپ با پشتیبان» ساخته نشد');
  ok(!R.classList.contains('sheet'), 'کلاس sheet اعمال نشد (ورق موبایل خاموش)');

  const lb = dd.querySelector('.psb-launcher');
  ok(lb.classList.contains('has-label'), 'حباب با متن، کلاس has-label گرفت');
  eq(dd.querySelector('.psb-lbl') ? dd.querySelector('.psb-lbl').textContent : null, 'پشتیبانی', 'متن داخل حباب نمایش داده شد');

  dd.querySelector('.psb-launcher').dispatchEvent(new wd.MouseEvent('click', { bubbles: true }));
  await wait(120);
  eq(dd.querySelectorAll('.psb-chip').length, 0, 'بدون دکمهٔ شروع، چیپی ساخته نمی‌شود');
  wd.close();
}

/* ========================================================= */
head('۱۰) رگرسیون: حلقهٔ بی‌نهایت هنگام خرابی /live/start');
/* ========================================================= */
{
  const t = makeDom({ autoOpen: false });
  const wd = t.w, dd = t.doc;
  wd.__failStart = true;              // سرور /live/start را ۵۰۳ می‌دهد
  await wait(120);

  dd.querySelector('.psb-launcher').dispatchEvent(new wd.MouseEvent('click', { bubbles: true }));
  await wait(120);

  const before = w.__calls.filter(c => c.path.startsWith('/live/start')).length;
  const inp = dd.querySelector('.psb-input');
  inp.value = 'سلام';
  dd.querySelector('.psb-send').dispatchEvent(new wd.MouseEvent('click', { bubbles: true }));

  await wait(4000);   // اگر حلقه بی‌نهایت بود، اینجا صدها درخواست می‌زد

  const starts = w.__calls.filter(c => c.path.startsWith('/live/start')).length;
  ok(starts - before <= 4, '/live/start بیش از ۴ بار تکرار نشد (سقف retry)', 'تکرارها: ' + (starts - before));

  const errs = dd.querySelectorAll('.psb-err');
  eq(errs.length, 1, 'خطای تکراری تلنبار نشد (یک حباب، تازه می‌شود)');

  const greets = Array.from(dd.querySelectorAll('.psb-msg.agent')).filter(x => x.textContent.includes('سلام! 👋'));
  eq(greets.length, 1, 'greeting فقط یک بار چاپ شد');

  // بعد از رفع خطا باید دوباره کار کند
  wd.__failStart = false;
  inp.value = 'دوباره';
  dd.querySelector('.psb-send').dispatchEvent(new wd.MouseEvent('click', { bubbles: true }));
  await wait(2800);
  ok(Array.from(dd.querySelectorAll('.psb-msg.visitor')).some(x => x.textContent === 'دوباره'), 'بعد از رفع خطا پیام ارسال شد');
  wd.close();
}

/* ========================================================= */
head('۱۱) فرم پیش از گفتگو');
/* ========================================================= */
{
  const t = makeDom({ prechat: true });
  const wd = t.w, dd = t.doc;
  await wait(120);

  ok(!!dd.querySelector('#psb-prechat'), 'فرم پیش از گفتگو ساخته شد');
  ok(!!dd.querySelector('#psb-pc-name') && !!dd.querySelector('#psb-pc-family') && !!dd.querySelector('#psb-pc-phone'), 'سه فیلد نام/نام خانوادگی/تلفن هست');
  eq(dd.querySelector('#psb-pc-skip'), null, 'چون فرم اجباری است، دکمهٔ رد کردن نیست');

  dd.querySelector('.psb-launcher').dispatchEvent(new wd.MouseEvent('click', { bubbles: true }));
  await wait(80);
  eq(dd.querySelector('#psb-prechat').hidden, false, 'با باز شدن پنل فرم نمایش داده شد');

  // خالی بفرست → باید خطا بدهد
  dd.querySelector('#psb-pc-go').dispatchEvent(new wd.MouseEvent('click', { bubbles: true }));
  await wait(50);
  eq(dd.querySelector('#psb-pc-err').hidden, false, 'فرم خالی خطا می‌دهد');
  eq(dd.querySelector('#psb-prechat').hidden, false, 'فرم بسته نمی‌شود');

  // شمارهٔ کوتاه → خطا
  dd.querySelector('#psb-pc-name').value = 'سارا';
  dd.querySelector('#psb-pc-family').value = 'احمدی';
  dd.querySelector('#psb-pc-phone').value = '۱۲۳';   // ارقام فارسی هم باید شمرده شوند
  dd.querySelector('#psb-pc-go').dispatchEvent(new wd.MouseEvent('click', { bubbles: true }));
  await wait(50);
  ok(/شماره/.test(dd.querySelector('#psb-pc-err').textContent), 'شمارهٔ کوتاه خطا می‌دهد', dd.querySelector('#psb-pc-err').textContent);

  // درست پر کن — با ارقام فارسی (باید قبول شود، نه رد)
  dd.querySelector('#psb-pc-phone').value = '۰۹۱۲۱۱۱۲۲۳۳';
  dd.querySelector('#psb-pc-go').dispatchEvent(new wd.MouseEvent('click', { bubbles: true }));
  await wait(200);
  eq(dd.querySelector('#psb-prechat').hidden, true, 'فرم بعد از ارسال بسته شد');

  // فرم قبل از start() پر می‌شود، پس اطلاعات تماس از راه /live/start می‌رود
  await wait(250);
  const st = wd.__calls.filter(c => c.path.startsWith('/live/start'));
  ok(st.length >= 1, '/live/start صدا زده شد');
  const body = st[st.length - 1].body;
  eq(body.name, 'سارا', 'نام از راه /live/start فرستاده شد');
  eq(body.family, 'احمدی', 'نام خانوادگی از راه /live/start فرستاده شد');
  eq(body.phone, '09121112233', 'شمارهٔ فارسی به لاتین نرمال و فرستاده شد');

  // گفتگو بعد از فرم کار می‌کند
  const inp = dd.querySelector('.psb-input');
  inp.value = 'سلام';
  dd.querySelector('.psb-send').dispatchEvent(new wd.MouseEvent('click', { bubbles: true }));
  await wait(300);
  ok(!!dd.querySelector('.psb-msg.visitor'), 'بعد از فرم، پیام ارسال شد');

  // بار دوم باز کردن: فرم نباید بیاید
  dd.querySelector('#psb-close').dispatchEvent(new wd.MouseEvent('click', { bubbles: true }));
  await wait(50);
  dd.querySelector('.psb-launcher').dispatchEvent(new wd.MouseEvent('click', { bubbles: true }));
  await wait(80);
  eq(dd.querySelector('#psb-prechat').hidden, true, 'فرم یک‌بار برای هر بازدیدکننده است');
  wd.close();
}

/* ========================================================= */
head('۱۲) رگرسیون: پیام کاربر دوبار نمایش داده نمی‌شود');
/* ========================================================= */
{
  const t = makeDom({ prechat: false });
  const wd = t.w, dd = t.doc;
  await wait(150);
  dd.querySelector('.psb-launcher').dispatchEvent(new wd.MouseEvent('click', { bubbles: true }));
  await wait(400);   // منتظر /live/start

  // (الف) قفل ارسال: دو کلیک پشت‌سرهم و هم‌زمان
  wd.__echoVisitor = true;   // سرور پیام کاربر را در poll هم برمی‌گرداند
  const inp = dd.querySelector('.psb-input');
  inp.value = 'قیمت چنده؟';
  dd.querySelector('.psb-send').dispatchEvent(new wd.MouseEvent('click', { bubbles: true }));
  dd.querySelector('.psb-send').dispatchEvent(new wd.MouseEvent('click', { bubbles: true }));   // بلافاصله، بدون await
  await wait(50);
  const sends = wd.__calls.filter(c => c.path.startsWith('/live/send')).length;
  eq(sends, 1, 'دو کلیک پشت‌سرهم فقط یک درخواست می‌فرستد (قفل busy)', 'تعداد send: ' + sends);

  const mineNow = Array.from(dd.querySelectorAll('.psb-msg.visitor'));
  eq(mineNow.length, 1, 'یک حباب برای پیام کاربر ساخته شد');

  // (ب) dedupe واقعی: poll همان پیام را از سرور برمی‌گرداند
  await wait(4500);   // یک چرخهٔ کامل poll (۴ ثانیه)
  const mineAfter = Array.from(dd.querySelectorAll('.psb-msg.visitor'));
  eq(mineAfter.length, 1, 'بعد از poll هم پیام کاربر دوبار نشده', 'تعداد: ' + mineAfter.length);
  eq(mineAfter[0].textContent, 'قیمت چنده؟', 'متن پیام درست ماند');
  ok(!!mineAfter[0].getAttribute('data-mid'), 'id سرور به حباب موجود چسبید (نه حباب جدید)');

  wd.close();
}

console.log('\n' + '─'.repeat(52));
if (fail === 0) console.log(`\x1b[42;30m همهٔ ${pass} تست فرانت‌اند پاس شد \x1b[0m`);
else { console.log(`\x1b[41;97m ${fail} تست شکست خورد \x1b[0m (پاس: ${pass})`); fails.forEach(f => console.log('   • ' + f)); }
console.log('─'.repeat(52));
process.exit(fail === 0 ? 0 : 1);
})();
