/**
 * تست فرانت‌اندِ استعلام سفارش ووکامرس — فایل واقعی pasokhban-chat.js
 * داخل jsdom.
 */
const fs = require('fs');
const { JSDOM } = require('jsdom');

const JS = fs.readFileSync(__dirname + '/../plugin/assets/js/pasokhban-chat.js', 'utf8');

let pass = 0, fail = 0; const fails = [];
const ok = (c, l, x) => { if (c) { pass++; console.log(`  \x1b[32m✓\x1b[0m ${l}`); } else { fail++; fails.push(l + (x ? ' — ' + x : '')); console.log(`  \x1b[31m✗\x1b[0m ${l}` + (x ? '  → ' + x : '')); } };
const eq = (a, b, l) => ok(a === b, l, `انتظار ${JSON.stringify(b)} / دریافت ${JSON.stringify(a)}`);
const head = t => console.log(`\n\x1b[1m${t}\x1b[0m`);
const wait = ms => new Promise(r => setTimeout(r, ms));

const BASE = {
  title: 'گفتگو', agentName: 'پشتیبانی', greeting: 'سلام', placeholder: 'بنویس…',
  accent: '#22d3ee', position: 'start', autoOpen: false, autoDelay: 5, starter: [],
  humanHandoff: true, sound: false, offlineNote: '', offsetBottom: 18, offsetSide: 18,
  launcherSize: 62, panelWidth: 384, panelHeight: 620, radius: 28, blur: 30, glassOpacity: 62,
  launcherLabel: '', teaser: false, teaserText: '', mobileSheet: true, maximize: true,
  showFooter: true, theme: 'light', prechat: false, prechatRequired: false, prechatNote: '',
  streaming: false, csat: false, upload: false, wooOrder: true
};

const ORDER = {
  number: '۱۰۰۱', status: 'در حال پردازش', date: '2025-01-01', total: '۱٬۴۳۰٬۰۰۰ تومان',
  shipping: 'پست پیشتاز', city: 'کرج',
  items: [{ name: 'هندزفری X200', qty: 1 }, { name: 'کابل type-c', qty: 2 }]
};

function makeDom(over) {
  const S2 = Object.assign({}, BASE, over || {});
  const dom = new JSDOM(
    `<!DOCTYPE html><html dir="rtl"><body><div id="pasokhban-live" data-mode="widget"></div></body></html>`,
    { url: 'http://example.test/', pretendToBeVisual: true, runScripts: 'dangerously' }
  );
  const w = dom.window;
  w.PASOKHBAN_CHAT = { restUrl: '/wp-json/pasokhban/v1', nonce: 'n', lang: 'fa' };
  w.PASOKHBAN_CHAT_SETTINGS = S2;

  const calls = [];
  w.__calls = calls;
  w.__orderFail = false;

  w.fetch = (url, opt) => {
    opt = opt || {};
    const path = String(url).replace(/^.*\/pasokhban\/v1/, '');
    const body = opt.body ? JSON.parse(opt.body) : {};
    calls.push({ path, body });
    return Promise.resolve({
      ok: !(w.__orderFail && path.startsWith('/live/order')),
      status: (w.__orderFail && path.startsWith('/live/order')) ? 403 : 200,
      json: () => {
        if (path.startsWith('/live/start')) {
          return Promise.resolve({ key: 'k1', mode: 'ai', status: 'open', messages: [], agentOnline: false, agentName: 'پ', settings: S2 });
        }
        if (path.startsWith('/live/order')) {
          if (w.__orderFail) return Promise.resolve({ code: 'x', message: 'سفارشی با این شماره و مشخصات پیدا نشد.' });
          return Promise.resolve({ ok: true, order: ORDER });
        }
        if (path.startsWith('/live/send')) {
          const m = { id: 500, sender: 'visitor', content: body.content, time: new Date().toISOString(), meta: {} };
          const reply = { id: 501, sender: 'agent', content: 'باشه', time: new Date().toISOString(), meta: { via: 'ai' } };
          return Promise.resolve({ message: m, reply: reply, mode: 'ai', agentOnline: false });
        }
        if (path.startsWith('/live/poll')) return Promise.resolve({ messages: [], mode: 'ai', status: 'open', agentOnline: false, lastId: 0 });
        return Promise.resolve({ ok: true });
      }
    });
  };

  const s = w.document.createElement('script');
  s.textContent = JS;
  w.document.body.appendChild(s);
  return { w: w, d: w.document };
}

async function openChat(w, d) {
  for (let i = 0; i < 60 && !d.getElementById('psb-launcher'); i++) await wait(10);
  const lb = d.getElementById('psb-launcher');
  if (!lb) return;
  lb.dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
  for (let i = 0; i < 40; i++) {
    await wait(10);
    if (w.__calls.some(c => c.path.startsWith('/live/start'))) return;
  }
  await wait(60);
}

function type(w, d, text) {
  const i = d.getElementById('psb-input');
  i.value = text;
  d.getElementById('psb-send').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
}

(async function () {

  /* ========================================================= */
  head('۱) تشخیص شمارهٔ سفارش در پیام');
  /* ========================================================= */

  let { w, d } = makeDom();
  await openChat(w, d);

  type(w, d, 'سلام، حال شما چطوره؟');
  await wait(80);
  ok(!d.querySelector('.psb-ordask'), 'در پیام معمولی کارت استعلام نمی‌آید');

  type(w, d, 'سفارش ۱۰۰۱ من کجاست؟');
  await wait(80);
  let card = d.querySelector('.psb-ordask');
  ok(!!card, 'با شمارهٔ سفارش فارسی، کارت استعلام آمد');
  ok(card && card.textContent.indexOf('۱۰۰۱') > -1, 'شمارهٔ سفارش در کارت نمایش داده شد');
  ok(!!card.querySelector('.psb-ordask-in'), 'کادر ورودی تأیید هویت هست');
  ok(!!card.querySelector('.psb-ordask-go'), 'دکمهٔ استعلام هست');

  // برای همان شماره دوباره کارت نمی‌آید
  const n1 = d.querySelectorAll('.psb-ordask').length;
  type(w, d, 'سفارش ۱۰۰۱ چی شد؟');
  await wait(80);
  eq(d.querySelectorAll('.psb-ordask').length, n1, 'برای یک شماره، کارت تکراری نمی‌آید');

  /* ========================================================= */
  head('۲) قالب‌های مختلف شمارهٔ سفارش');
  /* ========================================================= */

  ({ w, d } = makeDom());
  await openChat(w, d);
  type(w, d, 'order #1002 please');
  await wait(80);
  ok(!!d.querySelector('.psb-ordask'), 'قالب «order #1002» تشخیص داده شد');

  ({ w, d } = makeDom());
  await openChat(w, d);
  type(w, d, 'شماره ۱۰۰۳ را گرفتم');
  await wait(80);
  ok(!d.querySelector('.psb-ordask'), 'عدد بدون کلمهٔ «سفارش» کارت نمی‌سازد (جلوگیری از تشخیص اشتباه)');

  /* ========================================================= */
  head('۳) استعلام موفق');
  /* ========================================================= */

  ({ w, d } = makeDom());
  await openChat(w, d);
  type(w, d, 'سفارش ۱۰۰۱ کجاست؟');
  await wait(80);
  card = d.querySelector('.psb-ordask');

  card.querySelector('.psb-ordask-in').value = 'sara@example.test';
  card.querySelector('.psb-ordask-go').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
  await wait(100);

  const oc = w.__calls.filter(c => c.path.startsWith('/live/order'));
  eq(oc.length, 1, 'یک درخواست /live/order رفت');
  eq(oc[0].body.order_id, '1001', 'شمارهٔ سفارش لاتین شد و فرستاده شد');
  eq(oc[0].body.verify, 'sara@example.test', 'مقدار تأیید هویت فرستاده شد');
  eq(oc[0].body.key, 'k1', 'کلید نشست فرستاده شد');

  const res = d.querySelector('.psb-order');
  ok(!!res, 'کارت وضعیت سفارش رندر شد');
  ok(!d.querySelector('.psb-ordask'), 'کارت تأیید هویت بعد از موفقیت برداشته شد');
  if (res) {
    const t = res.textContent;
    ok(t.indexOf('۱۰۰۱') > -1, 'شمارهٔ سفارش در کارت هست');
    ok(t.indexOf('در حال پردازش') > -1, 'وضعیت در کارت هست');
    ok(t.indexOf('۱٬۴۳۰٬۰۰۰ تومان') > -1, 'مبلغ در کارت هست');
    ok(t.indexOf('کرج') > -1, 'شهر مقصد در کارت هست');
    ok(t.indexOf('هندزفری X200') > -1 && t.indexOf('کابل type-c') > -1, 'اقلام در کارت هست');
    ok(t.indexOf('×2') > -1, 'تعداد قلم نمایش داده شد');
    // سانسور سمت سرور تست شده؛ اینجا فقط مطمئن می‌شویم چیزی اضافه چاپ نمی‌شود
    ok(res.querySelectorAll('.psb-order-r').length >= 5, 'همهٔ ردیف‌های موجود رندر شدند');
  }

  /* ========================================================= */
  head('۴) استعلام ناموفق');
  /* ========================================================= */

  ({ w, d } = makeDom());
  await openChat(w, d);
  w.__orderFail = true;
  type(w, d, 'سفارش ۱۰۰۱ کجاست؟');
  await wait(80);
  card = d.querySelector('.psb-ordask');
  card.querySelector('.psb-ordask-in').value = 'wrong@evil.test';
  card.querySelector('.psb-ordask-go').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
  await wait(100);

  ok(!!d.querySelector('.psb-ordask'), 'کارت بعد از خطا باقی می‌ماند تا کاربر دوباره تلاش کند');
  ok(!d.querySelector('.psb-order'), 'کارت وضعیت ساخته نشد');
  const errBox = d.querySelector('.psb-ordask-err');
  ok(errBox && !errBox.hidden, 'پیام خطا نمایش داده شد');
  ok(errBox && errBox.textContent.indexOf('پیدا نشد') > -1, 'متن خطای سرور نشان داده شد');
  ok(!card.querySelector('.psb-ordask-go').disabled, 'دکمه دوباره فعال شد');

  /* ========================================================= */
  head('۵) ورودی خالی و Enter');
  /* ========================================================= */

  ({ w, d } = makeDom());
  await openChat(w, d);
  type(w, d, 'سفارش ۱۰۰۱ کجاست؟');
  await wait(80);
  card = d.querySelector('.psb-ordask');
  const before = w.__calls.filter(c => c.path.startsWith('/live/order')).length;
  card.querySelector('.psb-ordask-go').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
  await wait(40);
  eq(w.__calls.filter(c => c.path.startsWith('/live/order')).length, before, 'با ورودی خالی درخواست نمی‌رود');

  card.querySelector('.psb-ordask-in').value = '09121234567';
  card.querySelector('.psb-ordask-in').dispatchEvent(new w.KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
  await wait(100);
  eq(w.__calls.filter(c => c.path.startsWith('/live/order')).length, before + 1, 'با Enter استعلام ارسال شد');

  /* ========================================================= */
  head('۶) با قابلیت خاموش');
  /* ========================================================= */

  ({ w, d } = makeDom({ wooOrder: false }));
  await openChat(w, d);
  type(w, d, 'سفارش ۱۰۰۱ کجاست؟');
  await wait(80);
  ok(!d.querySelector('.psb-ordask'), 'با wooOrder:false کارت استعلام نمی‌آید');

  console.log('\n' + '─'.repeat(52));
  if (!fail) console.log(`\x1b[42;30m همهٔ ${pass} تست استعلام سفارشِ فرانت‌اند پاس شد \x1b[0m`);
  else {
    console.log(`\x1b[41;97m ${fail} تست شکست خورد \x1b[0m (پاس: ${pass})`);
    fails.forEach(f => console.log('   • ' + f));
  }
  console.log('─'.repeat(52));
  process.exit(fail ? 1 : 0);
})();
