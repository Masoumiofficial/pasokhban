<?php
/**
 * ممیزی ایستای کل پلاگین — دسته‌های رایج باگ.
 */

$root = PASOKHBAN_PLUGIN_DIR;
$files = array();
$rii = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $root ) );
foreach ( $rii as $f ) {
	if ( $f->isFile() && preg_match( '/\.(php|js|css)$/', $f->getFilename() ) ) {
		$files[ str_replace( $root . '/', '', $f->getPathname() ) ] = file_get_contents( $f->getPathname() );
	}
}
ksort( $files );

$issues = array();
function add( $sev, $file, $line, $msg ) {
	global $issues;
	$issues[] = array( $sev, $file, $line, $msg );
}

foreach ( $files as $path => $src ) {
	$lines = explode( "\n", $src );
	$is_php = ( '.php' === substr( $path, -4 ) );

	foreach ( $lines as $i => $line ) {
		$n = $i + 1;

		if ( $is_php ) {
			// ۱) خروجی بدون escape
			if ( preg_match( '/echo\s+\$[a-zA-Z_]/', $line ) && ! preg_match( '/esc_html|esc_attr|esc_url|wp_kses|absint|intval|floatval|\(int\)|\(float\)|esc_js/', $line ) ) {
				add( 'HIGH', $path, $n, 'خروجی بدون escape: ' . trim( $line ) );
			}
			// ۲) SQL با الحاق متغیر بدون prepare
			if ( preg_match( '/\$wpdb->(get_|query|prepare)/', $line ) && preg_match( '/\.\s*\$/', $line ) && false === strpos( $line, 'prepare' ) && false === strpos( $line, '_table()' ) ) {
				add( 'HIGH', $path, $n, 'SQL با الحاق متغیر: ' . trim( $line ) );
			}
			// ۳) $_GET/$_POST بدون sanitize
			if ( preg_match( '/\$_(GET|POST|REQUEST)\[/', $line ) && ! preg_match( '/sanitize_|intval|absint|isset|empty|wp_unslash|nonce/', $line ) ) {
				add( 'HIGH', $path, $n, 'ورودی خام: ' . trim( $line ) );
			}
			// ۴) تابع حذف‌شده/خطرناک
			if ( preg_match( '/\b(eval|create_function|assert)\s*\(/', $line ) ) {
				add( 'HIGH', $path, $n, 'تابع خطرناک: ' . trim( $line ) );
			}
			// ۵) کلید API در خروجی
			if ( preg_match( '/api_key/', $line ) && preg_match( '/echo|print|wp_json_encode.*\$opts/', $line ) && ! preg_match( '/esc_attr|password/', $line ) ) {
				add( 'HIGH', $path, $n, 'احتمال نشت کلید API: ' . trim( $line ) );
			}
			// ۶) مقایسهٔ شل
			if ( preg_match( '/[^!=<>]==[^=]/', $line ) && preg_match( '/\$(opts|options)\[/', $line ) ) {
				add( 'LOW', $path, $n, 'مقایسهٔ شل (==): ' . trim( $line ) );
			}
		}

		if ( '.js' === substr( $path, -3 ) ) {
			// ۷) innerHTML با دادهٔ خام
			if ( preg_match( '/innerHTML\s*=\s*[^;]*\+\s*[a-zA-Z]/', $line ) && ! preg_match( '/esc\(|textContent/', $line ) ) {
				add( 'MED', $path, $n, 'innerHTML با الحاق متغیر: ' . trim( $line ) );
			}
			// ۸) console.log باقی‌مانده
			if ( preg_match( '/console\.(log|debug)\(/', $line ) ) {
				add( 'LOW', $path, $n, 'console.log باقی‌مانده: ' . trim( $line ) );
			}
			// ۹) var در حلقه (مشکل closure)
			if ( preg_match( '/for\s*\(\s*var\s+\w+\s*=\s*0/', $line ) ) {
				add( 'INFO', $path, $n, 'حلقه با var (برای ES5 عمدی است)' );
			}
		}
	}
}

// ── بررسی‌های سراسری ──
$all_php = '';
foreach ( $files as $p => $s ) { if ( '.php' === substr( $p, -4 ) ) $all_php .= $s; }

// توابع تعریف‌شده vs صدا زده‌شده
preg_match_all( '/function\s+([a-zA-Z_][a-zA-Z0-9_]*)\s*\(/', $all_php, $m );
$defined = array_unique( $m[1] );

// کلاس‌های ارجاع‌شده
preg_match_all( '/Pasokhban_([A-Za-z]+)/', $all_php, $m2 );
$refs = array_unique( $m2[1] );
$declared = array();
preg_match_all( '/(?:final\s+)?class\s+Pasokhban_([A-Za-z]+)/', $all_php, $m3 );
$declared = array_unique( $m3[1] );
foreach ( $refs as $r ) {
	if ( ! in_array( $r, $declared, true ) && ! in_array( $r, array( 'DB', 'API', 'Settings', 'LiveChat', 'Stream', 'Notify', 'Inbox', 'Contacts', 'Analytics' ), true ) ) {
		add( 'HIGH', '(سراسری)', 0, "کلاس ارجاع‌شده ولی تعریف‌نشده: Pasokhban_$r" );
	}
}

// کلیدهای options خوانده‌شده vs defaults
preg_match_all( "/\\\$opts\['([a-z_]+)'\]/", $all_php, $m4 );
$used = array_unique( $m4[1] );
$settings_src = $files['includes/class-settings.php'];
preg_match( '/public function defaults\(\)\s*\{(.*?)\n\t\}/s', $settings_src, $dm );
$defaults_src = isset( $dm[1] ) ? $dm[1] : '';
foreach ( $used as $k ) {
	if ( false === strpos( $defaults_src, "'$k'" ) ) {
		add( 'MED', '(سراسری)', 0, "کلید \$opts['$k'] استفاده شده ولی در defaults نیست" );
	}
}

// رشته‌های ترجمه بدون text-domain
foreach ( $files as $path => $src ) {
	if ( '.php' !== substr( $path, -4 ) ) continue;
	$lines = explode( "\n", $src );
	foreach ( $lines as $i => $line ) {
		if ( preg_match( '/__\(\s*[\'"][^\'"]+[\'"]\s*\)/', $line ) && false === strpos( $line, 'pasokhban' ) ) {
			add( 'LOW', $path, $i + 1, 'رشتهٔ ترجمه بدون text-domain: ' . trim( $line ) );
		}
	}
}

// ── گزارش ──
$counts = array( 'HIGH' => 0, 'MED' => 0, 'LOW' => 0, 'INFO' => 0 );
foreach ( $issues as $is ) { $counts[ $is[0] ]++; }

echo "══════════════════════════════════════════════\n";
echo " ممیزی پلاگین — " . count( $files ) . " فایل بررسی شد\n";
echo "══════════════════════════════════════════════\n";
printf( " HIGH: %d   MED: %d   LOW: %d   INFO: %d\n\n", $counts['HIGH'], $counts['MED'], $counts['LOW'], $counts['INFO'] );

foreach ( array( 'HIGH', 'MED', 'LOW' ) as $sev ) {
	$group = array_filter( $issues, function ( $x ) use ( $sev ) { return $x[0] === $sev; } );
	if ( ! $group ) continue;
	echo "──── $sev ────\n";
	foreach ( $group as $x ) {
		printf( "  %s:%d  %s\n", $x[1], $x[2], mb_substr( $x[3], 0, 120 ) );
	}
	echo "\n";
}

echo "کلاس‌های تعریف‌شده: " . implode( ', ', $declared ) . "\n";
echo "تعداد توابع: " . count( $defined ) . "\n";
exit( $counts['HIGH'] > 0 ? 1 : 0 );
