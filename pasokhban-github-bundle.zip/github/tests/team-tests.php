<?php
/**
 * تست‌های ۲.۳.۰ — تیم پشتیبانی و ساعت کاری.
 */

require_once __DIR__ . '/wp-stubs.php';

$PASS = 0; $FAIL = 0; $FAILURES = array();

function ok( $cond, $label, $extra = '' ) {
	global $PASS, $FAIL, $FAILURES;
	if ( $cond ) { $PASS++; echo "  \033[32m✓\033[0m {$label}\n"; }
	else { $FAIL++; $FAILURES[] = $label . ( $extra ? " — {$extra}" : '' ); echo "  \033[31m✗\033[0m {$label}" . ( $extra ? "  → {$extra}" : '' ) . "\n"; }
}
function head( $t ) { echo "\n\033[1m{$t}\033[0m\n"; }
function eq( $a, $b, $label ) { ok( $a === $b, $label, 'انتظار ' . var_export( $b, true ) . ' / دریافت ' . var_export( $a, true ) ); }
function code( $r ) {
	if ( ! is_wp_error( $r ) ) { return 'no-error'; }
	$d = $r->get_error_data();
	return ( is_array( $d ) && isset( $d['status'] ) ) ? (int) $d['status'] : 0;
}

$BASE = array(
	'api_key' => 'sk', 'base_url' => 'https://api.example.test/v1',
	'live_enabled' => 1, 'live_human_enabled' => 1, 'rate_limit' => 0, 'live_history' => 20,
	'team_auto_assign' => 1, 'team_restrict' => 0,
	'hours_enabled' => 0, 'hours_days' => '0,1,2,3,4,6',
	'hours_from' => '09:00', 'hours_to' => '18:00', 'hours_ai_outside' => 1,
	'hours_offline_msg' => '',
);
function set_opts( array $over = array() ) {
	global $BASE;
	$o = array_merge( $BASE, $over );
	update_option( 'pasokhban_options', $o );
	$rp = new ReflectionProperty( 'Pasokhban_Settings', 'options' );
	$rp->setAccessible( true );
	$rp->setValue( Pasokhban_Settings::instance(), $o );
	return $o;
}
/** ورود به عنوان کاربری با قابلیت‌های مشخص. */
function login_as( $id, $name, array $caps ) {
	$GLOBALS['wp_current_user'] = (object) array( 'ID' => (int) $id, 'display_name' => $name, 'user_login' => 'u' . $id );
	$GLOBALS['wp_user_caps']    = $caps;
}
function login_admin() { login_as( 1, 'مدیر سایت', array( 'manage_options', 'pasokhban_reply', 'read' ) ); }

set_opts();
Pasokhban_DB::install();
Pasokhban_Team::install();
login_admin();

/* ========================================================= */
head( '۱) نقش و دسترسی' );
/* ========================================================= */

ok( isset( $GLOBALS['wp_roles']['pasokhban_agent'] ), 'نقش «اپراتور پاسخ‌بان» ساخته شد' );
ok( in_array( 'pasokhban_reply', $GLOBALS['wp_roles']['pasokhban_agent']['caps'], true ), 'نقش، قابلیت پاسخ‌گویی دارد' );
ok( ! in_array( 'manage_options', $GLOBALS['wp_roles']['pasokhban_agent']['caps'], true ), '★ نقش اپراتور، manage_options ندارد' );
ok( in_array( 'pasokhban_reply', $GLOBALS['wp_roles']['administrator']['caps'], true ), 'مدیر به‌صورت خودکار قابلیت را دارد' );

eq( Pasokhban_Team::can_access(), true, 'مدیر دسترسی دارد' );
eq( Pasokhban_Team::is_admin(), true, 'مدیر، مدیر است' );

login_as( 7, 'سارا', array( 'pasokhban_reply', 'read' ) );
eq( Pasokhban_Team::can_access(), true, '★ اپراتور به اینباکس دسترسی دارد' );
eq( Pasokhban_Team::is_admin(), false, '★ اپراتور، مدیر نیست' );
eq( Pasokhban_Team::current_id(), 7, 'شناسهٔ کاربر جاری درست است' );
eq( Pasokhban_Team::current_name(), 'سارا', 'نام کاربر جاری درست است' );

login_as( 9, 'غریبه', array( 'read' ) );
eq( Pasokhban_Team::can_access(), false, '★ کاربر بدون قابلیت، دسترسی ندارد' );

// سازندهٔ نقش idempotent است
login_admin();
Pasokhban_Team::install();
Pasokhban_Team::install();
eq( count( $GLOBALS['wp_roles'] ), 2, 'ساخت دوبارهٔ نقش، نقش تکراری نمی‌سازد' );

/* ========================================================= */
head( '۲) فهرست اپراتورها و حضور' );
/* ========================================================= */

$GLOBALS['wp_users'] = array(
	array( 'ID' => 1, 'display_name' => 'مدیر سایت', 'user_login' => 'admin', 'caps' => array( 'manage_options', 'pasokhban_reply' ) ),
	array( 'ID' => 7, 'display_name' => 'سارا', 'user_login' => 'sara', 'caps' => array( 'pasokhban_reply' ) ),
	array( 'ID' => 8, 'display_name' => 'علی', 'user_login' => 'ali', 'caps' => array( 'pasokhban_reply' ) ),
	array( 'ID' => 9, 'display_name' => 'غریبه', 'user_login' => 'x', 'caps' => array( 'read' ) ),
);

$ags = Pasokhban_Team::agents();
eq( count( $ags ), 3, 'سه اپراتور پیدا شد (کاربر بدون قابلیت شمرده نشد)' );
$names = array();
foreach ( $ags as $a ) { $names[] = $a['name']; }
ok( in_array( 'سارا', $names, true ) && in_array( 'علی', $names, true ), 'نام اپراتورها درست است' );
ok( ! in_array( 'غریبه', $names, true ), '★ کاربر بدون قابلیت در فهرست اپراتورها نیست' );

eq( Pasokhban_Team::agent_name( 7 ), 'سارا', 'نام از شناسه خوانده شد' );
eq( Pasokhban_Team::agent_name( 999 ), '', 'شناسهٔ ناموجود → رشتهٔ خالی، نه خطا' );
eq( Pasokhban_Team::agent_name( 0 ), '', 'شناسهٔ صفر → رشتهٔ خالی' );

delete_option( Pasokhban_Team::ONLINE_OPT );
eq( Pasokhban_Team::anyone_online(), false, 'در ابتدا هیچ‌کس آنلاین نیست' );

login_as( 7, 'سارا', array( 'pasokhban_reply' ) );
Pasokhban_Team::heartbeat();
eq( array_keys( Pasokhban_Team::online_ids() ), array( 7 ), 'ضربان قلب سارا ثبت شد' );
eq( Pasokhban_Team::anyone_online(), true, 'یک نفر آنلاین است' );

login_as( 8, 'علی', array( 'pasokhban_reply' ) );
Pasokhban_Team::heartbeat();
eq( count( Pasokhban_Team::online_ids() ), 2, 'هر دو اپراتور آنلاین‌اند' );

// هرس: کاربر قدیمی حذف می‌شود
$map = get_option( Pasokhban_Team::ONLINE_OPT, array() );
$map[7] = time() - 9999;
update_option( Pasokhban_Team::ONLINE_OPT, $map );
eq( array_keys( Pasokhban_Team::online_ids() ), array( 8 ), '★ اپراتوری که از TTL گذشته حذف می‌شود' );

// آرایهٔ خراب باعث خطا نمی‌شود
update_option( Pasokhban_Team::ONLINE_OPT, 'نه-آرایه' );
eq( Pasokhban_Team::online_ids(), array(), 'گزینهٔ خراب → فهرست خالی، نه fatal' );
delete_option( Pasokhban_Team::ONLINE_OPT );

/* ========================================================= */
head( '۳) واگذاری خودکار نوبتی' );
/* ========================================================= */

$lc = Pasokhban_LiveChat::instance();

function new_session() {
	global $lc;
	$r = $lc->handle_start( new WP_REST_Request( array(), array( 'lang' => 'fa', 'name' => 'مشتری' ) ) );
	return (int) Pasokhban_DB::get_session_by_key( $r['key'] )->id;
}

// همه آفلاین → به اولین اپراتور می‌دهد تا بی‌صاحب نماند
delete_option( Pasokhban_Team::RR_OPT );
$s1 = new_session();
$pick1 = Pasokhban_Team::auto_assign( $s1 );
ok( $pick1 > 0, 'با همهٔ آفلاین هم مکالمه بی‌صاحب نمی‌ماند', $pick1 );

// نوبتی بین آنلاین‌ها
update_option( Pasokhban_Team::ONLINE_OPT, array( 7 => time(), 8 => time() ) );
delete_option( Pasokhban_Team::RR_OPT );
$picks = array();
for ( $i = 0; $i < 4; $i++ ) {
	$picks[] = Pasokhban_Team::auto_assign( new_session() );
}
eq( $picks, array( 7, 8, 7, 8 ), '★ واگذاری نوبتی بین دو اپراتور آنلاین می‌چرخد' );

// مکالمهٔ قبلاً واگذارشده دست نمی‌خورد
$sid = new_session();
Pasokhban_DB::assign_session( $sid, 8 );
eq( Pasokhban_Team::auto_assign( $sid ), 8, 'مکالمهٔ واگذارشده دوباره واگذار نمی‌شود' );

// خاموش → واگذار نمی‌کند
set_opts( array( 'team_auto_assign' => 0 ) );
$sid2 = new_session();
eq( Pasokhban_Team::auto_assign( $sid2 ), 0, 'با قابلیت خاموش، واگذاری انجام نمی‌شود' );
eq( (int) Pasokhban_DB::get_session( $sid2 )->assigned_to, 0, 'assigned_to صفر ماند' );
set_opts();

// نشست ناموجود
eq( Pasokhban_Team::auto_assign( 999999 ), 0, 'نشست ناموجود → ۰، نه خطا' );

// هیچ اپراتوری نباشد
$saved = $GLOBALS['wp_users'];
$GLOBALS['wp_users'] = array();
eq( Pasokhban_Team::auto_assign( new_session() ), 0, 'بدون اپراتور → ۰، نه خطا' );
$GLOBALS['wp_users'] = $saved;

/* ========================================================= */
head( '۴) واگذاری دستی و کنترل دسترسی' );
/* ========================================================= */

$sid = new_session();

login_admin();
$res = Pasokhban_Team::handle_assign( new WP_REST_Request( array( 'id' => $sid, 'user_id' => 7 ) ) );
ok( ! is_wp_error( $res ), 'مدیر واگذار می‌کند', is_wp_error( $res ) ? $res->get_error_message() : '' );
eq( (int) Pasokhban_DB::get_session( $sid )->assigned_to, 7, 'واگذاری در دیتابیس ثبت شد' );
eq( $res['assignedName'], 'سارا', 'نام اپراتور برگشت' );

// پیام سیستمی ثبت شد
$msgs = Pasokhban_DB::get_messages( $sid );
$found = false;
foreach ( $msgs as $m ) {
	if ( isset( $m->meta['note'] ) && 'assign' === $m->meta['note'] ) { $found = true; }
}
ok( $found, 'واگذاری به‌صورت پیام سیستمی ثبت شد' );

// لغو واگذاری
$res = Pasokhban_Team::handle_assign( new WP_REST_Request( array( 'id' => $sid, 'user_id' => 0 ) ) );
eq( (int) Pasokhban_DB::get_session( $sid )->assigned_to, 0, 'واگذاری لغو شد' );

// ★ واگذاری به کاربر نامعتبر
eq( code( Pasokhban_Team::handle_assign( new WP_REST_Request( array( 'id' => $sid, 'user_id' => 9 ) ) ) ), 400, '★ واگذاری به کاربر بدون قابلیت رد شد' );
eq( code( Pasokhban_Team::handle_assign( new WP_REST_Request( array( 'id' => $sid, 'user_id' => 999 ) ) ) ), 400, '★ واگذاری به کاربر ناموجود رد شد' );
eq( (int) Pasokhban_DB::get_session( $sid )->assigned_to, 0, '★ واگذاری ناموفق، assigned_to را خراب نکرد' );

// نشست ناموجود
eq( code( Pasokhban_Team::handle_assign( new WP_REST_Request( array( 'id' => 999999, 'user_id' => 7 ) ) ) ), 404, 'نشست ناموجود، ۴۰۴' );

// ★ کنترل دسترسی اپراتور
set_opts( array( 'team_restrict' => 1 ) );
Pasokhban_DB::assign_session( $sid, 7 );
$other = new_session();
Pasokhban_DB::assign_session( $other, 8 );
$free  = new_session();

login_as( 7, 'سارا', array( 'pasokhban_reply' ) );
eq( Pasokhban_Team::can_touch( Pasokhban_DB::get_session( $sid ) ), true, 'اپراتور به مکالمهٔ خودش دسترسی دارد' );
eq( Pasokhban_Team::can_touch( Pasokhban_DB::get_session( $other ) ), false, '★ اپراتور به مکالمهٔ دیگری دسترسی ندارد' );
eq( Pasokhban_Team::can_touch( Pasokhban_DB::get_session( $free ) ), true, 'اپراتور به مکالمهٔ واگذارنشده دسترسی دارد' );

eq( code( Pasokhban_Team::handle_assign( new WP_REST_Request( array( 'id' => $other, 'user_id' => 7 ) ) ) ), 403, '★ واگذاری مکالمهٔ دیگری با ۴۰۳ رد شد' );

login_admin();
eq( Pasokhban_Team::can_touch( Pasokhban_DB::get_session( $other ) ), true, 'مدیر به همه دسترسی دارد' );

// با محدودسازی خاموش، اپراتور هم به همه دسترسی دارد
set_opts( array( 'team_restrict' => 0 ) );
login_as( 7, 'سارا', array( 'pasokhban_reply' ) );
eq( Pasokhban_Team::can_touch( Pasokhban_DB::get_session( $other ) ), true, 'با محدودسازی خاموش، اپراتور همه را می‌بیند' );

/* ========================================================= */
head( '۵) محدودسازی لیست — سمت سرور' );
/* ========================================================= */

set_opts( array( 'team_restrict' => 1 ) );

login_as( 7, 'سارا', array( 'pasokhban_reply' ) );
$args = Pasokhban_Team::scope_list_args( array( 'assigned' => 'all' ) );
eq( $args['assigned'], 'me', '★ اپراتور محدود، حتی اگر «همه» بخواهد، «مکالمات من» می‌گیرد' );
eq( $args['agent_id'], 7, 'شناسهٔ اپراتور با آرگومان رفت' );

login_admin();
$args = Pasokhban_Team::scope_list_args( array( 'assigned' => 'all' ) );
eq( $args['assigned'], 'all', 'مدیر می‌تواند «همه» را ببیند' );

// واقعاً در کوئری اعمال می‌شود
set_opts( array( 'team_restrict' => 1 ) );
login_admin();
$all = $lc->admin_sessions( new WP_REST_Request( array( 'status' => 'all', 'per_page' => 50 ) ) );
login_as( 7, 'سارا', array( 'pasokhban_reply' ) );
$mine = $lc->admin_sessions( new WP_REST_Request( array( 'status' => 'all', 'per_page' => 50, 'assigned' => 'all' ) ) );
ok( count( $mine['items'] ) < count( $all['items'] ), '★ لیست اپراتور کوتاه‌تر از لیست مدیر است', count( $mine['items'] ) . ' < ' . count( $all['items'] ) );
foreach ( $mine['items'] as $it ) {
	ok( 0 === (int) $it['assignedTo'] || 7 === (int) $it['assignedTo'], '★ هیچ مکالمهٔ دیگری در لیست اپراتور نیست', $it['assignedTo'] );
	break; // یک نمونه کافی است، بقیه در حلقهٔ بالا شمرده شدند
}

// shape_session اطلاعات واگذاری را برمی‌گرداند
login_admin();
$one = $lc->admin_sessions( new WP_REST_Request( array( 'status' => 'all', 'per_page' => 50 ) ) );
$has = false;
foreach ( $one['items'] as $it ) {
	if ( isset( $it['assignedTo'], $it['assignedName'] ) ) { $has = true; break; }
}
ok( $has, 'shape_session فیلدهای assignedTo و assignedName را دارد' );

/* ========================================================= */
head( '۶) حذف مکالمه فقط برای مدیر' );
/* ========================================================= */

$del = new_session();
login_as( 7, 'سارا', array( 'pasokhban_reply' ) );
eq( code( $lc->admin_delete( new WP_REST_Request( array( 'id' => $del ) ) ) ), 403, '★ اپراتور نمی‌تواند مکالمه حذف کند' );
ok( null !== Pasokhban_DB::get_session( $del ), 'مکالمه سر جایش است' );

login_admin();
$res = $lc->admin_delete( new WP_REST_Request( array( 'id' => $del ) ) );
ok( ! is_wp_error( $res ), 'مدیر می‌تواند حذف کند' );
eq( Pasokhban_DB::get_session( $del ), null, 'مکالمه حذف شد' );

/* ========================================================= */
head( '۷) ساعت کاری' );
/* ========================================================= */

// بدون فعال‌سازی → همیشه باز
set_opts( array( 'hours_enabled' => 0 ) );
eq( Pasokhban_Hours::is_open( strtotime( '2026-01-02 03:00:00' ) ), true, '★ بدون ساعت کاری، همیشه باز (جمعه ساعت ۳ هم)' );

set_opts( array( 'hours_enabled' => 1, 'hours_days' => '0,1,2,3,4,6', 'hours_from' => '09:00', 'hours_to' => '18:00' ) );
update_option( 'gmt_offset', 0 );

// ۲۰۲۶-۰۱-۰۵ دوشنبه است (w=1)
$mon_10 = strtotime( '2026-01-05 10:00:00' );
$mon_08 = strtotime( '2026-01-05 08:00:00' );
$mon_18 = strtotime( '2026-01-05 18:00:00' );
$mon_1759 = strtotime( '2026-01-05 17:59:00' );
// ۲۰۲۶-۰۱-۰۹ جمعه است (w=5)
$fri_10 = strtotime( '2026-01-09 10:00:00' );

eq( Pasokhban_Hours::is_open( $mon_10 ), true, 'دوشنبه ساعت ۱۰ باز است' );
eq( Pasokhban_Hours::is_open( $mon_08 ), false, 'دوشنبه ساعت ۸ بسته است' );
eq( Pasokhban_Hours::is_open( $mon_1759 ), true, 'دوشنبه ۱۷:۵۹ باز است' );
eq( Pasokhban_Hours::is_open( $mon_18 ), false, '★ ساعت پایان، خودِ آن لحظه بسته است (نیمه‌باز [from,to) )' );
eq( Pasokhban_Hours::is_open( $fri_10 ), false, '★ جمعه که در فهرست روزها نیست، بسته است' );

// ★ بازهٔ شبانه
set_opts( array( 'hours_enabled' => 1, 'hours_days' => '0,1,2,3,4,5,6', 'hours_from' => '22:00', 'hours_to' => '02:00' ) );
eq( Pasokhban_Hours::is_open( strtotime( '2026-01-05 23:30:00' ) ), true, '★ بازهٔ شبانه: ۲۳:۳۰ باز است' );
eq( Pasokhban_Hours::is_open( strtotime( '2026-01-05 01:00:00' ) ), true, '★ بازهٔ شبانه: ۰۱:۰۰ باز است' );
eq( Pasokhban_Hours::is_open( strtotime( '2026-01-05 12:00:00' ) ), false, '★ بازهٔ شبانه: ظهر بسته است' );

// ورودی نامعتبر
eq( Pasokhban_Hours::to_minutes( '09:30' ), 570, 'HH:MM به دقیقه تبدیل شد' );
eq( Pasokhban_Hours::to_minutes( '9:05' ), 545, 'ساعت تک‌رقمی قبول است' );
eq( Pasokhban_Hours::to_minutes( '24:00' ), null, 'ساعت ۲۴ نامعتبر است' );
eq( Pasokhban_Hours::to_minutes( '12:60' ), null, 'دقیقهٔ ۶۰ نامعتبر است' );
eq( Pasokhban_Hours::to_minutes( 'abc' ), null, 'رشتهٔ بی‌ربط → null' );
eq( Pasokhban_Hours::to_minutes( '' ), null, 'خالی → null' );

eq( Pasokhban_Hours::parse_days( '1,2,3' ), array( 1, 2, 3 ), 'فهرست روزها تجزیه شد' );
eq( Pasokhban_Hours::parse_days( '3,1,1,9,-2' ), array( 1, 3 ), 'تکراری و نامعتبر حذف شد' );
eq( Pasokhban_Hours::parse_days( '' ), array( 0, 1, 2, 3, 4, 5, 6 ), '★ فهرست خالی → هر روز باز' );

// منطقهٔ زمانی
update_option( 'gmt_offset', 3.5 );   // تهران
$utc_0730 = strtotime( '2026-01-05 07:30:00' );  // = ۱۱:۰۰ تهران
set_opts( array( 'hours_enabled' => 1, 'hours_days' => '0,1,2,3,4,5,6', 'hours_from' => '09:00', 'hours_to' => '18:00' ) );
eq( Pasokhban_Hours::is_open( $utc_0730 ), true, '★ با gmt_offset=+3:30، ساعت ۰۷:۳۰ UTC یعنی ۱۱:۰۰ تهران → باز' );
$utc_0430 = strtotime( '2026-01-05 04:30:00' );  // = ۰۸:۰۰ تهران
eq( Pasokhban_Hours::is_open( $utc_0430 ), false, '★ ساعت ۰۴:۳۰ UTC یعنی ۰۸:۰۰ تهران → بسته' );
update_option( 'gmt_offset', 0 );

/* ========================================================= */
head( '۸) پیام بیرون از ساعت کاری' );
/* ========================================================= */

set_opts( array( 'hours_enabled' => 1, 'hours_days' => '0,1,2,3,4,6', 'hours_from' => '09:00', 'hours_to' => '18:00', 'hours_offline_msg' => '' ) );
$msg = Pasokhban_Hours::offline_message();
ok( false !== strpos( $msg, 'بیرون از ساعت کاری' ), 'پیام پیش‌فرض مناسب است', $msg );
ok( (bool) preg_match( '/\d{2}:\d{2}/', $msg ), 'زمان بازگشایی در پیام هست', $msg );

$lbl = Pasokhban_Hours::next_open_label( strtotime( '2026-01-05 07:00:00' ) );
ok( false !== strpos( $lbl, '09:00' ), 'بازگشایی امروز', $lbl );
$lbl2 = Pasokhban_Hours::next_open_label( strtotime( '2026-01-05 20:00:00' ) );
ok( false !== strpos( $lbl2, '09:00' ), 'بازگشایی روز بعد', $lbl2 );

set_opts( array( 'hours_enabled' => 1, 'hours_offline_msg' => 'الان نیستیم، فردا جواب می‌دهیم.' ) );
$custom = Pasokhban_Hours::offline_message();
ok( 0 === strpos( $custom, 'الان نیستیم، فردا جواب می‌دهیم.' ), 'پیام سفارشی عیناً استفاده می‌شود', $custom );
ok( (bool) preg_match( '/\d{2}:\d{2}/', $custom ), 'زمان بازگشایی به پیام سفارشی هم اضافه می‌شود', $custom );

/* ========================================================= */
head( '۹) اثر ساعت کاری روی چت' );
/* ========================================================= */

$meth = new ReflectionMethod( 'Pasokhban_LiveChat', 'agent_online' );
$meth->setAccessible( true );

// اپراتور آنلاین + ساعت باز
set_opts( array( 'hours_enabled' => 1, 'hours_days' => '0,1,2,3,4,5,6', 'hours_from' => '00:00', 'hours_to' => '23:59' ) );
update_option( Pasokhban_Team::ONLINE_OPT, array( 7 => time() ) );
set_transient( Pasokhban_LiveChat::HEARTBEAT, 1, 25 );
eq( $meth->invoke( $lc ), true, 'ساعت باز + اپراتور آنلاین → در دسترس' );

// ساعت بسته
set_opts( array( 'hours_enabled' => 1, 'hours_days' => '', 'hours_from' => '03:00', 'hours_to' => '03:01' ) );
eq( $meth->invoke( $lc ), false, '★ بیرون از ساعت کاری → آفلاین، حتی با اپراتور آنلاین' );

// ساعت باز ولی کسی آنلاین نیست
set_opts( array( 'hours_enabled' => 1, 'hours_days' => '0,1,2,3,4,5,6', 'hours_from' => '00:00', 'hours_to' => '23:59' ) );
delete_transient( Pasokhban_LiveChat::HEARTBEAT );
eq( $meth->invoke( $lc ), false, 'بدون اپراتور آنلاین → آفلاین' );
set_transient( Pasokhban_LiveChat::HEARTBEAT, 1, 25 );

// handoff بیرون از ساعت کاری
set_opts( array( 'hours_enabled' => 1, 'hours_days' => '', 'hours_from' => '03:00', 'hours_to' => '03:01' ) );
$key = $lc->handle_start( new WP_REST_Request( array(), array( 'lang' => 'fa', 'name' => 'مشتری' ) ) )['key'];
$ho  = $lc->handle_handoff( new WP_REST_Request( array(), array( 'key' => $key, 'lang' => 'fa' ) ) );
$msgs = Pasokhban_DB::get_messages( (int) Pasokhban_DB::get_session_by_key( $key )->id );
$last = end( $msgs );
ok( false !== strpos( $last->content, 'بیرون از ساعت کاری' ), '★ بیرون از ساعت، پیام درست به مشتری می‌رسد', $last->content );
ok( false === strpos( $last->content, 'کمی صبر کنید' ), '★ وعدهٔ دروغ «کمی صبر کن» داده نمی‌شود' );
eq( $ho['agentOnline'], false, 'agentOnline=false برگشت' );

// public_settings ساعت کاری را می‌دهد
set_opts( array( 'hours_enabled' => 1, 'hours_days' => '0,1,2,3,4,5,6', 'hours_from' => '00:00', 'hours_to' => '23:59' ) );
$pub = $lc->public_settings( 'fa' );
eq( $pub['hoursEnabled'], true, 'hoursEnabled به کلاینت می‌رسد' );
eq( $pub['hoursOpen'], true, 'hoursOpen به کلاینت می‌رسد' );
ok( isset( $pub['hoursMsg'] ), 'hoursMsg به کلاینت می‌رسد' );

set_opts( array( 'hours_enabled' => 0 ) );
$pub2 = $lc->public_settings( 'fa' );
eq( $pub2['hoursOpen'], true, '★ بدون ساعت کاری، همیشه باز گزارش می‌شود' );

/* ========================================================= */
head( '۱۰) تنظیمات — sanitize' );
/* ========================================================= */

$s = Pasokhban_Settings::instance();
$d = $s->defaults();
eq( $d['team_auto_assign'], 1, 'واگذاری خودکار پیش‌فرض روشن' );
eq( $d['team_restrict'], 0, 'محدودسازی پیش‌فرض خاموش' );
eq( $d['hours_enabled'], 0, 'ساعت کاری پیش‌فرض خاموش' );
eq( $d['hours_days'], '0,1,2,3,4,6', 'پیش‌فرض روزها: همه جز جمعه' );
eq( $d['hours_ai_outside'], 1, 'AI بیرون ساعت پیش‌فرض روشن' );

$out = $s->sanitize( array( 'hours_from' => '99:99', 'hours_to' => 'abc' ) );
eq( $out['hours_from'], '09:00', 'ساعت نامعتبر به پیش‌فرض برمی‌گردد' );
eq( $out['hours_to'], '18:00', 'ساعت نامعتبر (۲) به پیش‌فرض برمی‌گردد' );

$out = $s->sanitize( array( 'hours_from' => '22:30' ) );
eq( $out['hours_from'], '22:30', 'ساعت معتبر پذیرفته شد' );

$out = $s->sanitize( array( 'hours_days_list' => array( '1', '3', '3', '99', '-1' ) ) );
eq( $out['hours_days'], '1,3', 'چک‌باکس روزها پاک‌سازی شد' );

$out = $s->sanitize( array( 'hours_days_list' => array() ) );
eq( $out['hours_days'], '0,1,2,3,4,6', '★ هیچ روزی انتخاب نشد → همهٔ روزها (پشتیبانی هیچ‌وقت کور نمی‌شود)' );

$out = $s->sanitize( array( 'hours_days' => '1,2,99,abc' ) );
eq( $out['hours_days'], '1,2', 'فیلد پنهان روزها پاک‌سازی شد' );

$out = $s->sanitize( array( 'team_restrict' => 1, 'hours_enabled' => 1 ) );
eq( $out['team_restrict'], 1, 'کلید boolean محدودسازی ذخیره شد' );
eq( $out['hours_enabled'], 1, 'کلید boolean ساعت کاری ذخیره شد' );

/* ========================================================= */
head( '۱۱) صفحهٔ تنظیمات و اینباکس' );
/* ========================================================= */

login_admin();
set_opts();
ob_start();
Pasokhban_Settings::instance()->render_page();
$html = ob_get_clean();
foreach ( array( 'team_auto_assign', 'team_restrict', 'hours_enabled', 'hours_ai_outside', 'hours_days', 'hours_from', 'hours_to', 'hours_offline_msg' ) as $f ) {
	ok( false !== strpos( $html, 'pasokhban_options[' . $f ), "فیلد $f در فرم تنظیمات هست" );
}
ok( false !== strpos( $html, 'data-panel="team"' ), 'تب «تیم و ساعت کاری» وجود دارد' );
ok( false !== strpos( $html, 'psb-day' ), 'چک‌باکس روزهای هفته رندر شد' );

ob_start();
Pasokhban_Inbox::render();
$html = ob_get_clean();
ok( false !== strpos( $html, 'id="ei-assign"' ), 'select واگذاری در اینباکس هست' );
ok( false !== strpos( $html, 'id="ei-owner"' ), 'فیلتر «مکالمات من» در اینباکس هست' );
ok( false !== strpos( $html, 'سارا' ), 'نام اپراتور در select واگذاری هست' );

// اپراتور هم اینباکس را می‌بیند
login_as( 7, 'سارا', array( 'pasokhban_reply' ) );
ob_start();
Pasokhban_Inbox::render();
$html = ob_get_clean();
ok( false !== strpos( $html, 'ei-app' ), '★ اپراتور (نه مدیر) هم اینباکس را می‌بیند' );

// کاربر بدون قابلیت، wp_die
login_as( 9, 'غریبه', array( 'read' ) );
$died = false;
try {
	ob_start();
	Pasokhban_Inbox::render();
	ob_end_clean();
} catch ( Exception $e ) {
	$died = true;
	ob_end_clean();
}
ok( $died, '★ کاربر بدون قابلیت با wp_die رد می‌شود' );

/* ========================================================= */
head( '۱۲) ساختار دیتابیس' );
/* ========================================================= */

ok( version_compare( Pasokhban_DB::SCHEMA_VERSION, '1.6.0', '>=' ), 'نسخهٔ ساختار حداقل ۱.۶.۰ است', Pasokhban_DB::SCHEMA_VERSION );
// PRAGMA ستون اول را cid می‌دهد، پس باید ستون name (ایندکس ۱) خوانده شود
$rows = $GLOBALS['wpdb']->get_results( "PRAGMA table_info(wp_pasokhban_sessions)" );
$cols = array();
foreach ( (array) $rows as $r ) { $cols[] = is_object( $r ) ? $r->name : $r; }
ok( in_array( 'assigned_to', $cols, true ), 'ستون assigned_to به جدول نشست‌ها اضافه شد', implode( ',', $cols ) );

$un = file_get_contents( PASOKHBAN_PATH . 'uninstall.php' );
ok( false !== strpos( $un, 'remove_role' ), 'uninstall نقش اپراتور را حذف می‌کند' );
ok( false !== strpos( $un, 'pasokhban_agents_online' ), 'uninstall گزینهٔ حضور را پاک می‌کند' );

echo "\n" . str_repeat( '─', 52 ) . "\n";
if ( 0 === $FAIL ) {
	echo "\033[42;30m همهٔ {$PASS} تست تیم و ساعت کاری پاس شد \033[0m\n";
} else {
	echo "\033[41;97m {$FAIL} تست شکست خورد \033[0m (پاس: {$PASS})\n";
	foreach ( $FAILURES as $f ) { echo "   • {$f}\n"; }
}
echo str_repeat( '─', 52 ) . "\n";
exit( 0 === $FAIL ? 0 : 1 );
