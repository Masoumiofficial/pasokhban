/**
 * تست اینباکس — فایل واقعی assets/js/pasokhban-inbox.js (بدون jQuery)
 * روی HTML واقعیِ رندرشده توسط PHP.
 */
const fs = require('fs');
const { execFileSync } = require('child_process');
const { JSDOM } = require('jsdom');

const JS = fs.readFileSync(__dirname + '/../plugin/assets/js/pasokhban-inbox.js', 'utf8');
const CSS = fs.readFileSync(__dirname + '/../plugin/assets/css/pasokhban-inbox.css', 'utf8');

let pass = 0, fail = 0; const fails = [];
const ok = (c, l, x) => { if (c) { pass++; console.log(`  \x1b[32m✓\x1b[0m ${l}`); } else { fail++; fails.push(l + (x ? ' — ' + x : '')); console.log(`  \x1b[31m✗\x1b[0m ${l}` + (x ? '  → ' + x : '')); } };
const eq = (a, b, l) => ok(a === b, l, `انتظار ${JSON.stringify(b)} / دریافت ${JSON.stringify(a)}`);
const head = t => console.log(`\n\x1b[1m${t}\x1b[0m`);
const wait = ms => new Promise(r => setTimeout(r, ms));

/* ---- HTML واقعی از PHP ---- */
const HTML = execFileSync((process.env.PASOKHBAN_PHP || 'php'), ['-r', `
  require_once __DIR__ . '/wp-stubs.php';
  update_option("pasokhban_options", array("api_key"=>"sk","live_enabled"=>1,"rate_limit"=>0,"live_history"=>20));
  $rp=new ReflectionProperty("Pasokhban_Settings","options"); $rp->setAccessible(true);
  $rp->setValue(Pasokhban_Settings::instance(), get_option("pasokhban_options"));
  Pasokhban_DB::install();
  $GLOBALS["wp_remote_response"]=array("response"=>array("code"=>200),"body"=>json_encode(array("choices"=>array(array("message"=>array("content"=>"پاسخ دستیار"))))));
  $l=Pasokhban_LiveChat::instance();
  for($i=1;$i<=2;$i++){
    $r=$l->handle_start(new WP_REST_Request(array(),array("lang"=>"fa","name"=>"مشتری $i","current_url"=>"http://e.test/p$i")));
    $l->handle_send(new WP_REST_Request(array(),array("key"=>$r["key"],"content"=>"سؤال $i","lang"=>"fa")));
  }
  ob_start(); Pasokhban_Inbox::render(); echo ob_get_clean();
`], { encoding: 'utf8' });

console.log(`\x1b[2mHTML از PHP: ${HTML.length} بایت، ${ (HTML.match(/class="ei-item"/g) || []).length } آیتم\x1b[0m`);

const MESSAGES = [
  { id: 1, sender: 'visitor', content: 'سلام', meta: {}, time: new Date().toISOString(), ago: '۲ دقیقه پیش' },
  { id: 2, sender: 'agent', content: 'درود! در خدمتم.', meta: { via: 'ai' }, time: new Date().toISOString(), ago: '۱ دقیقه پیش' },
  { id: 3, sender: 'visitor', content: 'این فاکتور و عکسش', time: new Date().toISOString(), ago: 'همین حالا',
    meta: { attachments: [
      { name: 'فاکتور.pdf', url: 'http://e.test/wp-content/uploads/pasokhban/a1.pdf', mime: 'application/pdf', size: 30720 },
      { name: 'عکس.png',   url: 'http://e.test/wp-content/uploads/pasokhban/a2.png', mime: 'image/png', size: 2048, w: 80, h: 60 },
      { name: 'x',         url: 'http://evil.test/x.php', mime: 'image/png' }
    ] } }
];

(async () => {

const dom = new JSDOM('<!DOCTYPE html><html dir="rtl"><head><meta charset="utf-8"></head><body>' + HTML + '</body></html>',
  { url: 'http://e.test/wp-admin/admin.php?page=pasokhban-inbox', pretendToBeVisual: true, runScripts: 'dangerously' });
const w = dom.window;

w.PASOKHBAN_INBOX = {
  restUrl: 'http://e.test/wp-json/pasokhban/v1', nonce: 'n', agent: 'Admin',
  i18n: { reply: 'پاسخ بده…', sending: '…', send: 'ارسال', noSession: 'خالی', errLoad: 'خطای بار', errSend: 'خطای ارسال',
          errOpen: 'خطای باز', you: 'شما', visitor: 'بازدیدکننده', ai: 'هوش مصنوعی', system: 'سیستم',
          sources: 'منابع:', confirm: 'حذف؟', openChat: 'بستن گفتگو', reopen: 'بازکردن گفتگو',
          suggest: '✨ پیشنهاد پاسخ', thinking: 'در حال نوشتن پیش‌نویس…', summarize: '📋 خلاصهٔ مکالمه',
          summarizing: 'در حال خلاصه‌کردن…', errCopilot: 'ساخت پیش‌نویس ناموفق بود.',
          inserted: 'پیش‌نویس در کادر ورودی قرار گرفت — ویرایشش کن و ارسال کن.' },
};

const calls = [];
w.__calls = calls;
let extraMsg = null;

// idهای واقعیِ رندرشده توسط PHP — mock باید همان‌ها را برگرداند
const IDS = Array.from(HTML.matchAll(/data-id="(\d+)"/g)).map(m => parseInt(m[1], 10));
console.log('\x1b[2midهای لیست سمت سرور: ' + JSON.stringify(IDS) + '\x1b[0m');

w.fetch = (url, opt) => {
  opt = opt || {};
  const path = String(url).replace(/^.*\/pasokhban\/v1/, '');
  const body = opt.body ? JSON.parse(opt.body) : {};
  calls.push({ path, body, method: opt.method || 'GET' });
  return Promise.resolve({
    ok: true, status: 200,
    json: () => {
      // توجه: /admin/sessions باید قبل از /admin/session بررسی شود (prefix collision)
      if (path.startsWith('/admin/sessions')) {
        const items = IDS.map(id => ({ id: id, name: 'مشتری ' + id, email: '', ip: '', lang: 'fa', mode: 'ai', status: 'open', unreadAgent: 0, unreadVisitor: 0, lastMessage: 'پاسخ دستیار', lastSender: 'agent', updatedAt: '2026-08-26 10:00:00' }));
        return Promise.resolve({ items: items, total: items.length, pages: 1 });
      }
      if (path.startsWith('/admin/session')) {
        const all = extraMsg ? MESSAGES.concat([extraMsg]) : MESSAGES;
        return Promise.resolve({
          session: { id: IDS[0], name: 'مشتری ' + IDS[0], email: '', ip: '1.2.3.4', mode: 'ai', status: 'open', currentUrl: 'http://e.test/p1', entryUrl: 'http://e.test/', unreadAgent: 1, unreadVisitor: 0 },
          messages: all
        });
      }
      if (path.startsWith('/admin/reply')) {
        return Promise.resolve({ message: { id: 200, sender: 'agent', content: body.content, meta: { via: 'human' }, ago: 'هم‌اکنون' } });
      }
      if (path.startsWith('/admin/suggest')) {
        w.__lastTone = body.tone;
        return Promise.resolve({ ok: true, draft: true, tone: body.tone, text: 'پیش‌نویس پیشنهادی مدل' });
      }
      if (path.startsWith('/admin/summarize')) {
        return Promise.resolve({ ok: true, text: '۱) درخواست مشتری: …\n۲) پاسخ داده شده: …\n۳) کار باقی‌مانده: …' });
      }
      return Promise.resolve({ ok: true });
    }
  });
};

const s = w.document.createElement('script');
s.textContent = JS;
w.document.body.appendChild(s);
await wait(120);

const d = w.document;
const $ = sel => d.querySelector(sel);

/* ========================================================= */
head('۱) کار بدون jQuery');
/* ========================================================= */
eq(typeof w.jQuery, 'undefined', 'jQuery در صفحه نیست');
ok(calls.some(c => c.path.startsWith('/admin/heartbeat')), 'ضربان قلب اپراتور ارسال شد (پس JS اجرا شده)');

/* ========================================================= */
head('۲) لیست رندرشدهٔ سمت سرور');
/* ========================================================= */
const items = d.querySelectorAll('.ei-item');
ok(items.length >= 2, 'آیتم‌های سمت سرور در DOM هستند', String(items.length));
ok(!d.querySelector('#ei-items').innerHTML.includes('ei-empty-list'), 'لیست خالی نیست');

/* ========================================================= */
head('۳) بازکردن مکالمه');
/* ========================================================= */
items[0].dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
await wait(150);

ok(items[0].classList.contains('active'), 'آیتم انتخاب‌شده فعال شد');
eq($('#ei-thead').hidden, false, 'هدر مکالمه نمایان شد');
eq($('#ei-composer').hidden, false, 'کادر پاسخ نمایان شد');
ok($('#ei-tname').textContent.length > 0, 'نام مشتری در هدر', $('#ei-tname').textContent);
ok($('#ei-tsub').textContent.includes('e.test/p1'), 'آدرس صفحهٔ مشتری در هدر', $('#ei-tsub').textContent);

const bubbles = d.querySelectorAll('#ei-msgs .ei-m');
eq(bubbles.length, 3, 'هر ۳ پیام رندر شد');
eq(bubbles[0].className, 'ei-m visitor', 'پیام بازدیدکننده کلاس درست دارد');
eq(bubbles[1].className, 'ei-m agent', 'پاسخ دستیار کلاس درست دارد');

/* ---- ضمیمه‌ها در اینباکس (۲.۰.۰) ---- */
const attBox = bubbles[2] ? bubbles[2].querySelector('.ei-atts') : null;
ok(!!attBox, 'پیام دارای ضمیمه، جعبهٔ ضمیمه دارد');
if (attBox) {
  const links = attBox.querySelectorAll('.ei-att');
  eq(links.length, 3, 'هر سه ضمیمه رندر شدند');
  ok(links[0].textContent.indexOf('فاکتور.pdf') > -1, 'نام فایل نمایش داده می‌شود');
  ok(/KB/.test(links[0].textContent), 'حجم فایل نمایش داده می‌شود');
  ok(!links[0].querySelector('img'), 'فایل غیرتصویری بندانگشتی ندارد');
  ok(!!links[1].querySelector('img'), 'تصویر بندانگشتی دارد');
  eq(links[1].querySelector('img').getAttribute('loading'), 'lazy', 'تصویر lazy بارگذاری می‌شود');
  eq(links[0].getAttribute('rel'), 'noopener noreferrer', 'لینک با noopener باز می‌شود');
  eq(links[0].getAttribute('target'), '_blank', 'در تب تازه باز می‌شود');
  ok(attBox.textContent.indexOf('<') === -1, 'نام فایل escape شده (تزریق HTML ممکن نیست)');
}
ok(!bubbles[0].querySelector('.ei-atts'), 'پیام بدون ضمیمه، جعبهٔ ضمیمه نمی‌گیرد');
ok(bubbles[1].textContent.includes('هوش مصنوعی'), 'برچسب «هوش مصنوعی» روی پاسخ AI');

/* ========================================================= */
head('۴) پاسخ اپراتور');
/* ========================================================= */
const inp = $('#ei-input');
inp.value = 'سلام، من پشتیبانم';
inp.dispatchEvent(new w.Event('input', { bubbles: true }));
ok(calls.some(c => c.path.startsWith('/admin/typing')), 'سیگنال «در حال نوشتن» رفت');

$('#ei-send').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
await wait(120);
eq(inp.value, '', 'کادر ورودی خالی شد');
const after = d.querySelectorAll('#ei-msgs .ei-m');
eq(after.length, 4, 'پاسخ اپراتور اضافه شد');
ok(after[3].textContent.includes('من پشتیبانم'), 'متن پاسخ درست است');
eq($('#ei-mode').checked, true, 'حالت به «پاسخ دستی» رفت');

/* ========================================================= */
head('۵) پیام تازه از polling');
/* ========================================================= */
extraMsg = { id: 201, sender: 'visitor', content: 'ممنون از پاسخت', meta: {}, ago: 'هم‌اکنون' };
await wait(4300);
const polled = d.querySelectorAll('#ei-msgs .ei-m');
ok(Array.from(polled).some(n => n.textContent.includes('ممنون از پاسخت')), 'پیام تازهٔ بازدیدکننده از poll رسید');

/* ========================================================= */
head('۶) ابزارها');
/* ========================================================= */
const before = calls.length;
$('#ei-refresh').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
await wait(80);
ok(calls.length > before && calls.some(c => c.path.startsWith('/admin/sessions')), 'دکمهٔ تازه‌سازی لیست را reload کرد');

$('#ei-filter').value = 'all';
$('#ei-filter').dispatchEvent(new w.Event('change', { bubbles: true }));
await wait(80);
ok(calls.some(c => c.path.includes('status=all')), 'فیلتر «همه» اعمال شد');

$('#ei-mode').checked = false;
$('#ei-mode').dispatchEvent(new w.Event('change', { bubbles: true }));
await wait(80);
ok(calls.some(c => c.path.startsWith('/admin/mode') && c.body.mode === 'ai'), 'تغییر حالت به AI فرستاده شد');

$('#ei-close').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
await wait(80);
ok(calls.some(c => c.path.startsWith('/admin/status')), 'بستن گفتگو فرستاده شد');

/* ========================================================= */
head('۷) دستیار اپراتور (۲.۱.۰)');
/* ========================================================= */

// یک مکالمه باز کن تا نوار دستیار نمایان شود
items[0].dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
await wait(150);

const copBox = d.getElementById('ei-copilot');
ok(!!copBox, 'نوار دستیار اپراتور رندر شده');
ok(copBox && !copBox.hidden, 'با باز شدن مکالمه، نوار نمایان شد');
ok(!!d.getElementById('ei-suggest'), 'دکمهٔ پیشنهاد پاسخ هست');
ok(!!d.getElementById('ei-summarize'), 'دکمهٔ خلاصه هست');
ok(!!d.getElementById('ei-tone'), 'انتخاب لحن هست');

// ---- پیش‌نویس داخل کادر ورودی می‌نشیند، ارسال نمی‌شود ----
const callsBefore = calls.length;
const inputBox = $('#ei-input');
inputBox.value = '';

d.getElementById('ei-tone').value = 'formal';
d.getElementById('ei-suggest').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
await wait(120);

const sugCall = calls.filter(c => c.path.startsWith('/admin/suggest')).pop();
ok(!!sugCall, 'درخواست /admin/suggest رفت');
if (sugCall) {
  eq(sugCall.body.tone, 'formal', 'لحن انتخابی با درخواست رفت');
  ok(sugCall.body.id > 0, 'شناسهٔ مکالمه با درخواست رفت');
}
ok(inputBox.value.length > 0, 'پیش‌نویس داخل کادر ورودی نشست');
ok(!calls.some(c => c.path.startsWith('/admin/reply') && c.__after), 'پیش‌نویس خودکار ارسال نشد');
const outBox = d.getElementById('ei-copilot-out');
ok(outBox && !outBox.hidden, 'پیام راهنما نمایش داده شد');
ok(outBox && outBox.classList.contains('is-ok'), 'پیام موفقیت سبز است');

// ---- متن موجود اپراتور پاک نمی‌شود ----
inputBox.value = 'متن خودم';
d.getElementById('ei-suggest').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
await wait(120);
ok(inputBox.value.indexOf('متن خودم') === 0, 'متنی که اپراتور تایپ کرده بود پاک نشد');
ok(inputBox.value.length > 'متن خودم'.length, 'پیش‌نویس به آن اضافه شد');

// ---- خلاصه در کادر ورودی نمی‌نشیند ----
inputBox.value = '';
d.getElementById('ei-summarize').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
await wait(120);
ok(calls.some(c => c.path.startsWith('/admin/summarize')), 'درخواست /admin/summarize رفت');
eq(inputBox.value, '', '★ خلاصه داخل کادر ورودی نرفت (برای خود اپراتور است)');
ok(d.getElementById('ei-copilot-out').classList.contains('is-sum'), 'خلاصه در جعبهٔ خروجی نمایش داده شد');

// ---- بستن مکالمه، نوار را پنهان می‌کند ----
$('#ei-close-thread') && $('#ei-close-thread').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
await wait(60);
if (d.getElementById('ei-thead').hidden) {
  ok(copBox.hidden, 'با بستن مکالمه، نوار دستیار پنهان شد');
}


/* ========================================================= */
head('۸) طراحی تازهٔ اینباکس (۲.۷.۰)');
/* ========================================================= */

// اول لیست را تازه کن (تست‌های قبلی ممکن است خالی‌اش کرده باشند)
d.getElementById('ei-refresh').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
await wait(300);

// آواتار با حروف اول نام
const itemsNow = d.querySelectorAll('.ei-item');
ok(itemsNow.length > 0, 'آیتمی برای آزمون هست', String(itemsNow.length));
const ava = itemsNow[0] ? itemsNow[0].querySelector('.ei-ava') : null;
ok(!!ava, '★ آواتار به آیتم اضافه شد');
ok(ava && ava.textContent.trim().length > 0 && ava.textContent.trim().length <= 2,
   'حروف اول نام در آواتار است', ava ? ava.textContent : '');
ok(ava && /hsl\(/.test(ava.getAttribute('style') || ''), '★ رنگ آواتار از نام مشتق شد');

// رنگ پایدار: دو بار رندر، همان رنگ
const tint1 = ava ? (ava.getAttribute('style') || '') : '';
d.getElementById('ei-refresh').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
await wait(300);
const ava2 = d.querySelector('.ei-item .ei-ava');
eq(ava2 ? (ava2.getAttribute('style') || '') : '', tint1, '★ رنگ آواتار با رندر دوباره عوض نمی‌شود');

// آیتم خوانده‌نشده کلاس می‌گیرد و badge دارد
ok(CSS.indexOf('.ei-item.is-unread') > -1, 'CSS آیتم خوانده‌نشده هست');
ok(CSS.indexOf('.ei-badge') > -1, 'CSS نشانگر تعداد هست');
ok(CSS.indexOf('.ei-daysep') > -1, 'CSS جداکنندهٔ روز هست');
ok(CSS.indexOf('.ei-hero') > -1, 'CSS هدر شیشه‌ای هست');
ok(CSS.indexOf('.ei-stats') > -1, 'CSS نوار آمار هست');
ok(CSS.indexOf('.ei-stat.is-hot') > -1, 'CSS آمار خوانده‌نشدهٔ داغ هست');
ok(CSS.indexOf('@media (max-width: 860px)') > -1, '★ واکنش‌گرایی موبایل هست');
ok(CSS.indexOf('.ei-app.is-thread-open') > -1, '★ سوییچ لیست/مکالمه در موبایل هست');
ok(CSS.indexOf('prefers-color-scheme: dark') > -1, 'حالت تاریک هست');
ok(CSS.indexOf('focus-visible') > -1, 'دسترسی‌پذیری کیبورد هست');

// جداکنندهٔ روز در مکالمه
const firstItem = d.querySelector('.ei-item');
ok(!!firstItem, 'آیتمی برای باز کردن مکالمه هست');
if (firstItem) firstItem.dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
await wait(300);
ok(d.querySelectorAll('#ei-msgs .ei-daysep').length > 0, '★ جداکنندهٔ روز در مکالمه رندر شد');
const sepTxt = d.querySelector('#ei-msgs .ei-daysep');
ok(sepTxt && sepTxt.textContent.trim().length > 0, 'جداکننده متن دارد', sepTxt ? sepTxt.textContent : '');

// دو پیام هم‌روز → فقط یک جداکننده
eq(d.querySelectorAll('#ei-msgs .ei-daysep').length, 1, '★ برای پیام‌های هم‌روز جداکنندهٔ تکراری نمی‌آید');

// دکمهٔ بازگشت (موبایل)
const backBtn = d.querySelector('.ei-back');
ok(!!backBtn, 'دکمهٔ بازگشت به لیست ساخته شد');

// سوییچ موبایل
const app = d.getElementById('ei-app');
ok(app && app.classList.contains('is-thread-open'), '★ با باز کردن مکالمه، کلاس موبایل اضافه شد');
backBtn.dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
await wait(50);
ok(!app.classList.contains('is-thread-open'), '★ با دکمهٔ بازگشت، به لیست برگشت');

/* ========================================================= */
head('۹) آمار و آواتار سمت PHP');
/* ========================================================= */

ok(HTML.indexOf('ei-hero') > -1, 'هدر تازه در HTML سمت PHP هست');
ok(HTML.indexOf('ei-stats') > -1, 'نوار آمار در HTML سمت PHP هست');
ok(HTML.indexOf('ei-ava') > -1, '★ آواتار در HTML سمت PHP هست');
ok(/--ei-ava: hsl\(/.test(HTML), '★ رنگ آواتار سمت PHP هم hsl است');
ok(HTML.indexOf('خوانده‌نشده') > -1, 'آمار خوانده‌نشده هست');
ok(HTML.indexOf('دست اپراتور') > -1, 'آمار مکالمات اپراتور هست');
ok(HTML.indexOf('کل مکالمات') > -1, 'آمار کل هست');

w.close();
console.log('\n' + '─'.repeat(52));
if (fail === 0) console.log(`\x1b[42;30m همهٔ ${pass} تست اینباکس پاس شد \x1b[0m`);
else { console.log(`\x1b[41;97m ${fail} تست شکست خورد \x1b[0m (پاس: ${pass})`); fails.forEach(f => console.log('   • ' + f)); }
console.log('─'.repeat(52));
process.exit(fail === 0 ? 0 : 1);
})();
