/**
 * تست فرانت‌اندِ ارسال فایل — فایل واقعی assets/js/pasokhban-chat.js
 * داخل jsdom با fetch و XMLHttpRequest شبیه‌سازی‌شده.
 *
 * نکته: همهٔ توابع پلاگین داخل یک IIFE هستند، پس هیچ‌چیز global نیست.
 * همه‌چیز از راه DOM (رویداد change روی input فایل) و پاسخ /live/start
 * رانده می‌شود — یعنی دقیقاً همان مسیری که کاربر واقعی طی می‌کند.
 */
const fs = require('fs');
const { JSDOM } = require('jsdom');

const JS  = fs.readFileSync(__dirname + '/../plugin/assets/js/pasokhban-chat.js', 'utf8');
const CSS = fs.readFileSync(__dirname + '/../plugin/assets/css/pasokhban-chat.css', 'utf8');

let pass = 0, fail = 0; const fails = [];
const ok = (c, l, x) => { if (c) { pass++; console.log(`  \x1b[32m✓\x1b[0m ${l}`); } else { fail++; fails.push(l + (x ? ' — ' + x : '')); console.log(`  \x1b[31m✗\x1b[0m ${l}` + (x ? '  → ' + x : '')); } };
const eq = (a, b, l) => ok(a === b, l, `انتظار ${JSON.stringify(b)} / دریافت ${JSON.stringify(a)}`);
const head = t => console.log(`\n\x1b[1m${t}\x1b[0m`);
const wait = ms => new Promise(r => setTimeout(r, ms));

const SETTINGS = {
  title: 'گفتگو', agentName: 'پشتیبانی', greeting: 'سلام', placeholder: 'بنویس…',
  accent: '#22d3ee', position: 'start', autoOpen: false, autoDelay: 5, starter: [],
  humanHandoff: true, sound: false, offlineNote: '', offsetBottom: 18, offsetSide: 18,
  launcherSize: 62, panelWidth: 384, panelHeight: 620, radius: 28, blur: 30, glassOpacity: 62,
  launcherLabel: '', teaser: false, teaserText: '', mobileSheet: true, maximize: true,
  showFooter: true, theme: 'light', prechat: false, prechatRequired: false, prechatNote: '',
  streaming: false, csat: false,
  upload: true, uploadMax: 5, uploadTypes: ['jpg', 'jpeg', 'png', 'pdf'], uploadMaxPer: 4
};

/**
 * فایل واقعی jsdom.
 *
 * چرا شیء ساده نه: FormData مقدار غیر-Blob را به رشته تبدیل می‌کند، پس
 * fd.get('file') نام و حجم را از دست می‌داد. با File واقعی دقیقاً همان
 * چیزی می‌رود که در مرورگر کاربر می‌رود.
 */
let W0 = null;
function F(name, size) {
  return new W0.File([new Uint8Array(Math.min(size, 64))], name, { type: 'application/octet-stream' });
}
/** حجم دقیق را روی فایل ست می‌کند (jsdom اندازه را از محتوا می‌گیرد). */
function sized(name, size) {
  const f = new W0.File([new Uint8Array(1)], name, { type: 'application/octet-stream' });
  Object.defineProperty(f, 'size', { value: size, configurable: true });
  return f;
}

function makeDom(over) {
  const S2 = Object.assign({}, SETTINGS, over || {});
  const dom = new JSDOM(
    `<!DOCTYPE html><html dir="rtl"><body><div id="pasokhban-live" data-mode="widget"></div></body></html>`,
    { url: 'http://example.test/', pretendToBeVisual: true, runScripts: 'dangerously' }
  );
  const w = dom.window;
  w.PASOKHBAN_CHAT = { restUrl: '/wp-json/pasokhban/v1', nonce: 'n', lang: 'fa' };
  w.PASOKHBAN_CHAT_SETTINGS = S2;

  const calls = [];
  w.__calls = calls;
  w.__uploads = [];
  w.__uploadFail = false;
  w.__uploadMsg = '';
  w.__history = [];
  w.__tokenMap = {};
  let id = 100, n = 0;

  w.fetch = (url, opt) => {
    opt = opt || {};
    const path = String(url).replace(/^.*\/pasokhban\/v1/, '');
    const body = opt.body ? JSON.parse(opt.body) : {};
    calls.push({ path, body });
    return Promise.resolve({
      ok: true, status: 200,
      json: () => {
        if (path.startsWith('/live/start')) {
          return Promise.resolve({
            key: 'k1', mode: 'ai', status: 'open', messages: w.__history,
            agentOnline: false, agentName: 'پشتیبانی', settings: S2
          });
        }
        if (path.startsWith('/live/send')) {
          const m = {
            id: ++id, sender: 'visitor', content: body.content, time: new Date().toISOString(),
            meta: (body.attachments && body.attachments.length)
              ? { attachments: body.attachments.map(t => w.__tokenMap[t]).filter(Boolean) }
              : {}
          };
          const reply = { id: ++id, sender: 'agent', content: 'باشه', time: new Date().toISOString(), meta: { via: 'ai' } };
          return Promise.resolve({ message: m, reply: reply, mode: 'ai', agentOnline: false });
        }
        if (path.startsWith('/live/poll')) {
          return Promise.resolve({ messages: [], mode: 'ai', status: 'open', agentOnline: false, lastId: 0 });
        }
        return Promise.resolve({ ok: true });
      }
    });
  };

  w.XMLHttpRequest = function () {
    const self = this;
    this.upload = {};
    this.status = 0;
    this.responseText = '';
    this.__headers = {};
    this.open = function (m, u) { self.__url = u; self.__method = m; };
    this.setRequestHeader = function (k, v) { self.__headers[k] = v; };
    this.send = function (fd) {
      const file = fd.get ? fd.get('file') : null;
      const key = fd.get ? fd.get('key') : '';
      w.__uploads.push({
        name: file && file.name, size: file && file.size, key: key,
        url: self.__url, nonce: self.__headers['X-WP-Nonce']
      });
      setTimeout(function () {
        if (self.upload.onprogress) self.upload.onprogress({ lengthComputable: true, loaded: 10, total: 20 });
        if (w.__uploadFail) {
          self.status = 415;
          self.responseText = JSON.stringify({ code: 'x', message: w.__uploadMsg || 'نوع فایل مجاز نیست' });
        } else {
          n++;
          const token = 'tok' + n;
          const att = {
            token: token, name: file ? file.name : 'f',
            url: 'http://example.test/wp-content/uploads/pasokhban/rnd' + n + '.jpg',
            file: 'rnd' + n + '.jpg', mime: 'image/jpeg', size: file ? file.size : 10, w: 48, h: 32
          };
          w.__tokenMap[token] = att;
          self.status = 200;
          self.responseText = JSON.stringify({ ok: true, token: token, attachment: att });
        }
        if (self.onload) self.onload();
      }, 1);
    };
  };

  const s = w.document.createElement('script');
  s.textContent = JS;
  w.document.body.appendChild(s);
  W0 = w;
  return { w: w, d: w.document };
}

/**
 * ویجت را باز می‌کند و صبر می‌کند تا /live/start کامل شود.
 * در حالت ویجت، start() تنبل است و فقط با باز شدن پنل اجرا می‌شود.
 */
async function openChat(w, d) {
  // ویجت روی DOMContentLoaded ساخته می‌شود، پس اول صبر کن تا حباب بیاید
  for (let i = 0; i < 60 && !d.getElementById('psb-launcher'); i++) await wait(10);
  const lb = d.getElementById('psb-launcher');
  if (!lb) return;
  lb.dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
  for (let i = 0; i < 40; i++) {
    await wait(10);
    if (w.__calls.some(c => c.path.startsWith('/live/start'))) {
      const inp = d.getElementById('psb-send');
      if (inp && !inp.disabled) return;
    }
  }
  await wait(60);
}

/** انتخاب فایل از راه input — همان کاری که کاربر با دکمهٔ گیره می‌کند. */
function pick(w, d, files) {
  const fi = d.getElementById('psb-file');
  Object.defineProperty(fi, 'files', { value: files, configurable: true });
  fi.dispatchEvent(new w.Event('change', { bubbles: true }));
}

function lastErr(d) {
  const all = d.querySelectorAll('.psb-err');
  return all.length ? all[all.length - 1].textContent : '';
}

(async function () {

  /* ========================================================= */
  head('۱) رابط کاربری');
  /* ========================================================= */

  let { w, d } = makeDom();
  await openChat(w, d);

  ok(!!d.getElementById('psb-clip'), 'دکمهٔ گیرهٔ کاغذ در کامپوزر هست');
  const fi = d.getElementById('psb-file');
  ok(!!fi, 'input فایل هست');
  eq(fi.type, 'file', 'نوع input فایل است');
  ok(fi.hasAttribute('multiple'), 'چندفایلی است');
  ok(fi.hidden, 'input پنهان است (با دکمه باز می‌شود)');
  eq(fi.getAttribute('accept'), '.jpg,.jpeg,.png,.pdf', 'فهرست accept از تنظیمات سرور ساخته شد');
  ok(!!d.getElementById('psb-atts'), 'جعبهٔ چیپ‌های ضمیمه هست');
  ok(d.getElementById('psb-atts').hidden, 'جعبهٔ چیپ‌ها در ابتدا پنهان است');

  const off = makeDom({ upload: false });
  await wait(60);
  ok(!off.d.getElementById('psb-clip'), 'با upload:false دکمهٔ گیره رندر نمی‌شود');

  /* ========================================================= */
  head('۲) اعتبارسنجی سمت کاربر');
  /* ========================================================= */

  ({ w, d } = makeDom());
  await openChat(w, d);

  pick(w, d, [sized('bad.exe', 1000)]);
  await wait(20);
  ok(/مجاز نیست/.test(lastErr(d)), 'پسوند نامجاز پیام خطا می‌دهد', lastErr(d));
  eq(w.__uploads.length, 0, 'فایل نامجاز اصلاً آپلود نمی‌شود');

  pick(w, d, [sized('big.jpg', 9 * 1024 * 1024)]);
  await wait(20);
  ok(/بزرگ‌تر/.test(lastErr(d)), 'فایل بزرگ پیام خطا می‌دهد', lastErr(d));
  eq(w.__uploads.length, 0, 'فایل بزرگ آپلود نمی‌شود');

  /* ========================================================= */
  head('۳) آپلود موفق');
  /* ========================================================= */

  ({ w, d } = makeDom());
  await openChat(w, d);

  pick(w, d, [sized('عکس من.jpg', 20480)]);
  await wait(50);

  eq(w.__uploads.length, 1, 'یک درخواست آپلود رفت');
  eq(w.__uploads[0].url, '/wp-json/pasokhban/v1/live/upload', 'به مسیر درست رفت');
  eq(w.__uploads[0].nonce, 'n', 'nonce با درخواست رفت');
  eq(w.__uploads[0].key, 'k1', 'کلید نشست با درخواست رفت');
  eq(w.__uploads[0].name, 'عکس من.jpg', 'نام فایل درست فرستاده شد');

  const box = d.getElementById('psb-atts');
  ok(!box.hidden, 'جعبهٔ چیپ‌ها نمایان شد');
  eq(box.querySelectorAll('.psb-chip').length, 1, 'یک چیپ ساخته شد');
  const chip = box.querySelector('.psb-chip');
  ok(chip.classList.contains('is-done'), 'چیپ به حالت آماده رفت');
  ok(!!chip.querySelector('.psb-chip-x'), 'دکمهٔ حذف دارد');
  ok(!!chip.querySelector('.psb-chip-ico img'), 'برای تصویر، بندانگشتی نمایش داده می‌شود');
  ok(/KB/.test(chip.textContent), 'حجم فایل نمایش داده می‌شود', chip.textContent);
  ok(!chip.querySelector('.psb-chip-bar'), 'نوار پیشرفت بعد از پایان برداشته شد');

  chip.querySelector('.psb-chip-x').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
  await wait(20);
  eq(d.getElementById('psb-atts').querySelectorAll('.psb-chip').length, 0, 'با دکمهٔ حذف، چیپ برداشته شد');
  ok(d.getElementById('psb-atts').hidden, 'جعبهٔ چیپ‌ها دوباره پنهان شد');

  /* ========================================================= */
  head('۴) خطای سرور');
  /* ========================================================= */

  ({ w, d } = makeDom());
  await openChat(w, d);
  w.__uploadFail = true;
  w.__uploadMsg = 'محتوای فایل با پسوندش نمی‌خواند';
  pick(w, d, [sized('evil.jpg', 1000)]);
  await wait(50);
  ok(/نمی‌خواند/.test(lastErr(d)), 'پیام خطای سرور به کاربر نشان داده می‌شود', lastErr(d));
  eq(d.getElementById('psb-atts').querySelectorAll('.psb-chip').length, 0, 'چیپِ ناموفق برداشته شد');

  /* ========================================================= */
  head('۵) سقف تعداد ضمیمه');
  /* ========================================================= */

  ({ w, d } = makeDom());
  await openChat(w, d);
  pick(w, d, [sized('a.jpg', 100), sized('b.jpg', 100), sized('c.jpg', 100), sized('d.jpg', 100), sized('e.jpg', 100)]);
  await wait(80);
  ok(w.__uploads.length <= 4, 'بیش از سقف، آپلود نمی‌شود', String(w.__uploads.length));
  ok(/حداکثر/.test(lastErr(d)), 'پیام سقف تعداد نمایش داده می‌شود', lastErr(d));

  /* ========================================================= */
  head('۶) ارسال پیام با ضمیمه');
  /* ========================================================= */

  ({ w, d } = makeDom());
  await openChat(w, d);

  pick(w, d, [sized('invoice.jpg', 4096)]);
  await wait(50);
  d.getElementById('psb-input').value = 'این فاکتور را ببین';
  d.getElementById('psb-send').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
  await wait(100);

  const sent = w.__calls.filter(c => c.path.startsWith('/live/send'));
  eq(sent.length, 1, 'یک درخواست ارسال رفت');
  eq(sent[0].body.content, 'این فاکتور را ببین', 'متن پیام درست رفت');
  ok(Array.isArray(sent[0].body.attachments) && sent[0].body.attachments.length === 1, 'توکن ضمیمه با درخواست رفت');
  eq(sent[0].body.attachments[0], 'tok1', 'خودِ توکن رفت، نه URL');

  const bubbles = d.querySelectorAll('.psb-msg.visitor');
  ok(bubbles.length >= 1, 'حباب پیام کاربر ساخته شد');
  ok(!!bubbles[0].querySelector('.psb-att'), 'ضمیمه داخل حباب نمایش داده می‌شود');
  const img = bubbles[0].querySelector('.psb-att.is-img img');
  ok(!!img, 'تصویر به‌صورت بندانگشتی رندر شد');
  eq(img.getAttribute('loading'), 'lazy', 'تصویر lazy بارگذاری می‌شود');
  eq(bubbles[0].querySelector('.psb-att').getAttribute('rel'), 'noopener noreferrer', 'لینک با noopener باز می‌شود');

  eq(d.getElementById('psb-atts').querySelectorAll('.psb-chip').length, 0, 'چیپ‌ها بعد از ارسال پاک شدند');
  eq(d.querySelectorAll('.psb-msg.visitor').length, 1, 'پیام کاربر دوبار رندر نشد');

  /* ========================================================= */
  head('۷) ارسال فقط فایل، بدون متن');
  /* ========================================================= */

  ({ w, d } = makeDom());
  await openChat(w, d);
  pick(w, d, [sized('shot.png', 2048)]);
  await wait(50);
  eq(d.getElementById('psb-input').value, '', 'کادر متن خالی است');
  d.getElementById('psb-send').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
  await wait(100);
  const sent2 = w.__calls.filter(c => c.path.startsWith('/live/send'));
  eq(sent2.length, 1, 'پیام بدون متن ولی با فایل ارسال شد');
  eq(sent2[0].body.content, '', 'متن خالی رفت');
  ok(!!d.querySelector('.psb-msg.is-filesonly'), 'حباب فقط-فایل کلاس مخصوص دارد');

  /* ========================================================= */
  head('۸) رندر ضمیمه از تاریخچهٔ سرور');
  /* ========================================================= */

  ({ w, d } = makeDom());
  w.__history = [{
    id: 900, sender: 'agent', content: 'فایلت رسید', time: new Date().toISOString(),
    meta: { attachments: [
      { name: 'گزارش.pdf', url: 'http://example.test/wp-content/uploads/pasokhban/abc.pdf', mime: 'application/pdf', size: 20480 },
      { name: 'عکس.png',  url: 'http://example.test/wp-content/uploads/pasokhban/xyz.png', mime: 'image/png', size: 1024, w: 100, h: 80 }
    ] }
  }];
  const h2 = makeDom();
  h2.w.__history = w.__history;
  await openChat(h2.w, h2.d);
  await wait(60);

  const m = h2.d.querySelector('.psb-msg.agent');
  ok(!!m, 'پیام اپراتور از تاریخچه رندر شد');
  if (m) {
    const atts = m.querySelectorAll('.psb-att');
    eq(atts.length, 2, 'هر دو ضمیمه رندر شدند');
    ok(!!atts[0].querySelector('.psb-att-ico'), 'برای فایل غیرتصویری، آیکون فایل هست');
    ok(atts[0].textContent.indexOf('گزارش.pdf') > -1, 'نام فایل نمایش داده می‌شود');
    ok(/KB/.test(atts[0].textContent), 'حجم فایل نمایش داده می‌شود');
    ok(!!atts[1].querySelector('img'), 'تصویر رندر شد');
  }

  /* ========================================================= */
  head('۹) دفاع در برابر URL خارجی');
  /* ========================================================= */

  const h3 = makeDom();
  h3.w.__history = [{
    id: 901, sender: 'agent', content: 'سلام', time: new Date().toISOString(),
    meta: { attachments: [
      { name: 'x', url: 'http://evil.test/x.php', mime: 'image/png' },
      { name: 'y', url: 'javascript:alert(1)', mime: 'image/png' },
      { name: 'z', url: 'http://example.test/wp-content/uploads/pasokhban/ok.png', mime: 'image/png' }
    ] }
  }];
  await openChat(h3.w, h3.d);
  await wait(60);
  const links = h3.d.querySelectorAll('.psb-msg.agent .psb-att');
  eq(links.length, 1, 'فقط URL هم‌دامنه رندر شد');
  if (links.length) eq(links[0].href, 'http://example.test/wp-content/uploads/pasokhban/ok.png', 'لینک سالم باقی ماند');

  /* ========================================================= */
  head('۱۰) CSS');
  /* ========================================================= */

  ({ w, d } = makeDom());
  await openChat(w, d);
  const st = d.createElement('style');
  st.textContent = CSS;
  d.head.appendChild(st);
  await wait(40);

  const cs = el => w.getComputedStyle(el);
  ok(CSS.indexOf('.psb-clip') > -1, 'قلمرو دکمهٔ گیره در CSS هست');
  ok(CSS.indexOf('.psb-chip') > -1, 'قلمرو چیپ ضمیمه در CSS هست');
  ok(CSS.indexOf('.psb-att') > -1, 'قلمرو ضمیمهٔ داخل حباب در CSS هست');
  ok(CSS.indexOf('.is-drop') > -1, 'حالت کشیدن فایل در CSS هست');
  eq(cs(d.getElementById('psb-clip')).borderRadius, '50%', 'دکمهٔ گیره گرد است');
  eq(cs(d.getElementById('psb-clip')).cursor, 'pointer', 'نشانگر ماوس روی دکمه دست است');

  console.log('\n' + '─'.repeat(52));
  if (!fail) console.log(`\x1b[42;30m همهٔ ${pass} تست آپلودِ فرانت‌اند پاس شد \x1b[0m`);
  else {
    console.log(`\x1b[41;97m ${fail} تست شکست خورد \x1b[0m (پاس: ${pass})`);
    fails.forEach(f => console.log('   • ' + f));
  }
  console.log('─'.repeat(52));
  process.exit(fail ? 1 : 0);
})();
