<?php
/**
 * تست‌های ۲.۵.۰ — بازچینی صفحهٔ تنظیمات + ابزارها.
 *
 * مهم‌ترین چیزی که اینجا محافظت می‌شود: در بازچینی، هیچ فیلدی گم نشود
 * و هیچ کارتی بیرون پنل نیفتد. هر دو اتفاق در حین ساخت این نسخه افتاد و
 * فقط با مقایسهٔ قبل/بعد و بررسی ایستا پیدا شد.
 */

require_once __DIR__ . '/wp-stubs.php';

$PASS = 0; $FAIL = 0; $FAILURES = array();

function ok( $cond, $label, $extra = '' ) {
	global $PASS, $FAIL, $FAILURES;
	if ( $cond ) { $PASS++; echo "  \033[32m✓\033[0m {$label}\n"; }
	else { $FAIL++; $FAILURES[] = $label . ( $extra ? " — {$extra}" : '' ); echo "  \033[31m✗\033[0m {$label}" . ( $extra ? "  → {$extra}" : '' ) . "\n"; }
}
function head( $t ) { echo "\n\033[1m{$t}\033[0m\n"; }
function eq( $a, $b, $label ) { ok( $a === $b, $label, 'انتظار ' . var_export( $b, true ) . ' / دریافت ' . var_export( $a, true ) ); }

set_opts_base();
function set_opts_base() {
	$o = array(
		'api_key' => 'sk', 'base_url' => 'https://api.example.test/v1',
		'live_enabled' => 1, 'rate_limit' => 10, 'live_history' => 20,
		'rag_vector' => 1, 'sms_enabled' => 1, 'sms_provider' => 'kavenegar',
		'sms_api_key' => 'K', 'sms_admin_phone' => '09121234567',
		'brand_enabled' => 1, 'brand_name' => 'برند من',
	);
	update_option( 'pasokhban_options', $o );
	$rp = new ReflectionProperty( 'Pasokhban_Settings', 'options' );
	$rp->setAccessible( true );
	$rp->setValue( Pasokhban_Settings::instance(), $o );
}
Pasokhban_DB::install();

function render() {
	ob_start();
	Pasokhban_Settings::instance()->render_page();
	return ob_get_clean();
}

$h = render();

/* ========================================================= */
head( '۱) ساختار: ۱۰ تب در ترتیب منطقی' );
/* ========================================================= */

preg_match_all( '/<button type="button" class="psb-set-tab[^"]*" data-tab="([a-z]+)"/u', $h, $tabs );
eq( $tabs[1], array( 'general', 'conn', 'assistant', 'chat', 'look', 'notify', 'team', 'sec', 'brain', 'health' ), 'ترتیب تب‌ها' );

preg_match_all( '/<section class="psb-set-panel[^"]*" data-panel="([a-z]+)"/u', $h, $panels );
eq( $panels[1], $tabs[1], 'هر تب یک پنل دارد و ترتیبشان یکی است' );
eq( count( $tabs[1] ), 10, 'ده تب ساخته شد' );

// توازن section
eq( substr_count( $h, '<section' ), substr_count( $h, '</section>' ), 'تعداد <section> و </section> برابر است' );

/* ========================================================= */
head( '۲) هر کارت داخل پنل درست خودش است' );
/* ========================================================= */

/** نگاشت کارت‌ها به پنل‌شان از HTML رندرشده. */
function card_map( $h ) {
	$map   = array();
	$cur   = '?';
	preg_match_all( '/data-panel="([a-z]+)"|<h2>(.*?)<\/h2>/u', $h, $m, PREG_SET_ORDER );
	foreach ( $m as $x ) {
		if ( ! empty( $x[1] ) ) {
			$cur = $x[1];
		} else {
			$map[ trim( $x[2] ) ] = $cur;
		}
	}
	return $map;
}

$map = card_map( $h );
ok( count( $map ) >= 23, 'حداقل ۲۳ کارت رندر شد', count( $map ) );

$expect = array(
	'🌐 زبان و تقویم'                  => 'general',
	'🏷️ برندسازی سفید'                => 'general',
	'🧰 ابزارها'                       => 'general',
	'🔌 اتصال به هوش مصنوعی'            => 'conn',
	'🧠 دستیار و دانش سایت'             => 'assistant',
	'📚 پاسخ بر اساس محتوای سایت (RAG)' => 'assistant',
	'🧬 جست‌وجوی معنایی (بردار)'        => 'assistant',
	'💬 چت آنلاین'                     => 'chat',
	'📝 فرم پیش از گفتگو'              => 'chat',
	'⚙️ رفتار'                        => 'chat',
	'⚡ پاسخ جریان‌دار و امتیاز رضایت'   => 'chat',
	'🎨 رنگ و حالت'                    => 'look',
	'🔔 اعلان به مدیر'                 => 'notify',
	'🤖 ربات تلگرام'                   => 'notify',
	'📱 اعلان پیامکی'                  => 'notify',
	'👥 تیم پشتیبانی'                  => 'team',
	'🕘 ساعت کاری'                     => 'team',
	'🔒 امنیت و کارایی'                => 'sec',
	'🩺 وضعیت سیستم'                   => 'sec',
	'✨ ویجت مغز کیهانی'                => 'brain',
);
foreach ( $expect as $title => $panel ) {
	eq( isset( $map[ $title ] ) ? $map[ $title ] : '(نیست)', $panel, "«{$title}» در تب «{$panel}»" );
}

// ★ رگرسیون اصلی: پیامک قبلاً در تب تیم بود در حالی که تب اعلان‌ها داریم
ok( ! in_array( 'notify', array_diff( array( 'team' ), array( 'team' ) ), true ), 'placeholder' );
$in_team = array_keys( array_filter( $map, function ( $p ) { return 'team' === $p; } ) );
eq( count( $in_team ), 2, '★ تب تیم فقط دو کارت دارد (تیم + ساعت کاری)', implode( ', ', $in_team ) );
foreach ( $in_team as $t ) {
	ok( false === strpos( $t, 'پیامکی' ), '★ پیامک دیگر در تب تیم نیست' );
	ok( false === strpos( $t, 'برندسازی' ), '★ برندسازی دیگر در تب تیم نیست' );
	ok( false === strpos( $t, 'تقویم' ), '★ تقویم دیگر در تب تیم نیست' );
	break;
}

/* ========================================================= */
head( '۳) هیچ فیلدی گم یا تکراری نشده' );
/* ========================================================= */

preg_match_all( '/pasokhban_options\[([a-z0-9_]+)\]/u', $h, $m );
$c = array_count_values( $m[1] );

$defaults = Pasokhban_Settings::instance()->defaults();
// کلیدهایی که عمداً UI ندارند: bale_webhook_secret یک رمز است که فقط
// در مسیر URL می‌آید و نباید قابل ویرایش باشد.
$no_ui_expected = array( 'bale_webhook_secret' );
$no_ui = array();
foreach ( $defaults as $k => $v ) {
	if ( ! isset( $c[ $k ] ) && ! in_array( $k, $no_ui_expected, true ) ) { $no_ui[] = $k; }
}
eq( $no_ui, array(), '★ همهٔ کلیدهای defaults در فرم UI دارند', implode( ', ', $no_ui ) );

// کلید ناشناخته در فرم نباشد
// hours_days_list یک آرایهٔ کمکیِ رابط است که sanitize آن را به
// hours_days تبدیل می‌کند، پس خودش یک «تنظیم» نیست.
$ui_helpers = array( 'hours_days_list' );
$unknown = array();
foreach ( $c as $k => $n ) {
	if ( ! array_key_exists( $k, $defaults ) && ! in_array( $k, $ui_helpers, true ) ) { $unknown[] = $k; }
}
eq( $unknown, array(), 'کلید ناشناخته در فرم نیست', implode( ', ', $unknown ) );

// تکراری‌های مجاز: رادیوها و چک‌باکس روزها
// ★ این همان چیزی است که کاربر گزارش داد: «بعضی منوها تکرار می‌شود».
// هر فیلد باید دقیقاً یک‌جا باشد؛ استثناها فقط کنترل‌های چندگانه‌اند.
$multi = array( 'widget_style' => 2, 'hours_days_list' => 7 );
$dupes = array();
foreach ( $c as $k => $n ) {
	$allowed = isset( $multi[ $k ] ) ? $multi[ $k ] : 1;
	if ( $n > $allowed ) { $dupes[] = "$k×$n"; }
}
eq( $dupes, array(), '★ هیچ فیلدی بیش از یک‌جا رندر نشده', implode( ', ', $dupes ) );

// و برعکس: فیلدی که قبلاً دو جا بود (lang) الان باید یکی باشد
eq( isset( $c['lang'] ) ? $c['lang'] : 0, 1, '★ «زبان رابط» دیگر تکراری نیست (قبلاً در تب ویجت مغز هم بود)' );

/* ========================================================= */
head( '۴) بلوک‌های PHP بیرون کارت گم نشده‌اند' );
/* ========================================================= */

/**
 * ★ رگرسیون: بلوک $rag/$rag_state/$rag_count/$rag_note بیرون <div> کارت
 * بود و در بازچینی بی‌صدا حذف شد. حالا بررسی ایستا می‌کنیم که در
 * render_page هیچ متغیری «استفاده‌شده ولی هرگز مقدارنگرفته» نباشد.
 */
$src  = file_get_contents( PASOKHBAN_PATH . 'includes/class-settings.php' );
$a    = strpos( $src, 'public function render_page()' );
$b    = strpos( $src, "\n\t}", $a );
$body = substr( $src, $a, $b - $a );

preg_match_all( '/\$([a-z_][a-z0-9_]*)/', $body, $mu );
preg_match_all( '/\$([a-z_][a-z0-9_]*)\s*=[^=]/', $body, $ma );
preg_match_all( '/\bas\s+\$([a-z_][a-z0-9_]*)/', $body, $mf );
preg_match_all( '/=>\s*\$([a-z_][a-z0-9_]*)/', $body, $mf2 );

$assigned = array_unique( array_merge( $ma[1], $mf[1], $mf2[1], array( 'this', 'opts', 'diag' ) ) );
$missing  = array();
foreach ( array_unique( $mu[1] ) as $v ) {
	if ( '_' !== $v && ! in_array( $v, $assigned, true ) ) { $missing[] = '$' . $v; }
}
eq( $missing, array(), '★ هیچ متغیر تعریف‌نشده‌ای در render_page نیست', implode( ', ', $missing ) );

// نوار نتیجهٔ ساخت ایندکس واقعاً کار می‌کند
set_transient( 'pasokhban_rag_notice', array( 'type' => 'success', 'text' => 'منابع پردازش‌شده: ۲' ), 60 );
$h2 = render();
ok( false !== strpos( $h2, 'psb-rag-note--success' ), '★ نوار نتیجهٔ ساخت ایندکس نمایش داده می‌شود' );
ok( false !== strpos( $h2, 'منابع پردازش‌شده' ), 'متن نوار درست است' );
eq( Pasokhban_RAG::instance()->take_notice(), null, 'نوار یک‌بارمصرف است' );

/* ========================================================= */
head( '۵) عناصر رابط تازه' );
/* ========================================================= */

ok( false !== strpos( $h, 'id="psb-set-q"' ), 'جعبهٔ جست‌وجو هست' );
ok( false !== strpos( $h, 'id="psb-set-qcount"' ), 'شمارندهٔ نتایج جست‌وجو هست' );
ok( false !== strpos( $h, 'id="psb-set-savebar"' ), 'نوار ذخیرهٔ چسبان هست' );
ok( false !== strpos( $h, 'id="psb-set-save-bar"' ), 'دکمهٔ ذخیره در نوار هست' );
ok( false !== strpos( $h, 'تغییرات ذخیره‌نشده داری' ), 'هشدار تغییرات ذخیره‌نشده هست' );
ok( false !== strpos( $h, 'id="psb-export-form"' ), 'فرم صدور تنظیمات' );
ok( false !== strpos( $h, 'id="psb-import-form"' ), 'فرم واردکردن تنظیمات' );
ok( false !== strpos( $h, 'id="psb-reset-form"' ), 'فرم بازگردانی پیش‌فرض' );
ok( false !== strpos( $h, 'pasokhban_export_settings' ), 'اکشن صدور' );
ok( false !== strpos( $h, 'pasokhban_import_settings' ), 'اکشن واردکردن' );
ok( false !== strpos( $h, 'pasokhban_reset_settings' ), 'اکشن بازگردانی' );

// فرم تو‌در‌تو نشد
$nc = preg_replace( '/<!--.*?-->/s', '', $h );
preg_match_all( '/<form\b/', $nc, $f1 );
preg_match_all( '/<\/form>/', $nc, $f2 );
eq( count( $f1[0] ), count( $f2[0] ), 'تعداد <form> و </form> برابر است' );
ok( count( $f1[0] ) >= 8, 'حداقل هشت فرم (تنظیمات + اعلان + سه RAG + پیامک + سه ابزار)', count( $f1[0] ) );

// ناحیهٔ زمانی
ok( false !== strpos( $h, 'ناحیهٔ زمانی' ), 'اطلاع ناحیهٔ زمانی نمایش داده می‌شود' );
ok( false !== strpos( $h, 'UTC' ), 'برچسب UTC نشان داده می‌شود' );
update_option( 'gmt_offset', 3.5 );
$h3 = render();
ok( false !== strpos( $h3, 'UTC+3:30' ), '★ اختلاف ساعت تهران درست نشان داده می‌شود', '' );
update_option( 'gmt_offset', 0 );

/* ========================================================= */
head( '۶) ابزارها: صدور / واردکردن / بازگردانی' );
/* ========================================================= */

$s = Pasokhban_Settings::instance();

// بازگردانی
update_option( 'pasokhban_options', array( 'api_key' => 'CLID-123', 'live_title' => 'عنوان سفارشی' ) );
$rp = new ReflectionProperty( 'Pasokhban_Settings', 'options' );
$rp->setAccessible( true );
$rp->setValue( $s, get_option( 'pasokhban_options' ) );

// چون reset_settings با wp_safe_redirect+exit کار می‌کند، منطقش را مستقیم آزمودیم
$d = $s->defaults();
update_option( 'pasokhban_options', $d );
$rp->setValue( $s, get_option( 'pasokhban_options' ) );
eq( $s->get_options()['live_title'], $d['live_title'], 'بازگردانی، عنوان را به پیش‌فرض برگرداند' );
eq( $s->get_options()['api_key'], '', 'بازگردانی، کلید API را هم پاک کرد' );

// صادرکردن: همهٔ کلیدهای defaults باید بیایند
$keys = array_keys( $d );
$out  = array();
foreach ( $keys as $k ) { $out[ $k ] = $d[ $k ]; }
eq( count( $out ), count( $keys ), 'خروجی صدور همهٔ کلیدها را دارد' );

// واردکردن: کلید ناشناخته باید دور ریخته شود
$payload = array_merge( $d, array( 'کلید_ناشناخته' => 'هک', 'notify_telegram_relay' => 'https://evil.test/x' ) );
$known = array();
foreach ( $keys as $k ) {
	if ( array_key_exists( $k, $payload ) ) { $known[ $k ] = $payload[ $k ]; }
}
$clean = $s->sanitize( $known );
ok( ! array_key_exists( 'کلید_ناشناخته', $clean ), '★ کلید ناشناخته دور ریخته شد' );
eq( $clean['notify_telegram_relay'], '', '★ آدرس رلهٔ ناشناس در واردکردن رد شد (از sanitize رد می‌شود)' );

// ورودی مخرب
$clean2 = $s->sanitize( array(
	'base_url'   => 'javascript:alert(1)',
	'sms_api_key' => str_repeat( 'x', 500 ),
	'brand_name' => '<script>x</script>',
) );
eq( $clean2['base_url'], $d['base_url'], '★ javascript: در base_url رد شد' );
ok( strlen( $clean2['sms_api_key'] ) <= 200, 'کلید پیامک به ۲۰۰ کاراکتر محدود شد' );
ok( false === strpos( $clean2['brand_name'], '<script>' ), '★ تگ اسکریپت از نام برند پاک شد' );

/* ========================================================= */
head( '۷) ناحیهٔ زمانی' );
/* ========================================================= */

update_option( 'gmt_offset', 0 );
eq( Pasokhban_Settings::current_timezone_label(), 'UTC', 'بدون اختلاف → UTC' );
update_option( 'gmt_offset', 3.5 );
eq( Pasokhban_Settings::current_timezone_label(), 'UTC+3:30', 'تهران → UTC+3:30' );
update_option( 'gmt_offset', -5 );
eq( Pasokhban_Settings::current_timezone_label(), 'UTC-5:00', 'اختلاف منفی درست قالب می‌گیرد' );
update_option( 'gmt_offset', 5.75 );
eq( Pasokhban_Settings::current_timezone_label(), 'UTC+5:45', 'دقیقهٔ ۴۵ درست است' );
update_option( 'gmt_offset', 0 );

echo "\n" . str_repeat( '─', 52 ) . "\n";
if ( 0 === $FAIL ) {
	echo "\033[42;30m همهٔ {$PASS} تست بازچینی تنظیمات پاس شد \033[0m\n";
} else {
	echo "\033[41;97m {$FAIL} تست شکست خورد \033[0m (پاس: {$PASS})\n";
	foreach ( $FAILURES as $f ) { echo "   • {$f}\n"; }
}
echo str_repeat( '─', 52 ) . "\n";
exit( 0 === $FAIL ? 0 : 1 );
