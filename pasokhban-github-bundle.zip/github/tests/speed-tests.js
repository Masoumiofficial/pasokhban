/**
 * تست رفع‌های سرعت: تایمر سپری‌شده · fallback زودهنگام
 */
const fs = require('fs');
const { JSDOM } = require('jsdom');
const { ReadableStream } = require('stream/web');
const { TextEncoder, TextDecoder } = require('util');

const JS = fs.readFileSync(__dirname + '/../plugin/assets/js/pasokhban-chat.js', 'utf8');

let pass = 0, fail = 0; const fails = [];
const ok = (c, l, x) => { if (c) { pass++; console.log(`  \x1b[32m✓\x1b[0m ${l}`); } else { fail++; fails.push(l + (x ? ' — ' + x : '')); console.log(`  \x1b[31m✗\x1b[0m ${l}` + (x ? '  → ' + x : '')); } };
const eq = (a, b, l) => ok(JSON.stringify(a) === JSON.stringify(b), l, `انتظار ${JSON.stringify(b)} / دریافت ${JSON.stringify(a)}`);
const head = t => console.log(`\n\x1b[1m${t}\x1b[0m`);
const wait = ms => new Promise(r => setTimeout(r, ms));

const SETTINGS = {
  title: 'چت', agentName: 'پشتیبانی', greeting: 'سلام', placeholder: 'بنویس',
  accent: '#22d3ee', position: 'start', autoOpen: false, autoDelay: 5, starter: [],
  humanHandoff: true, sound: false, offlineNote: '',
  offsetBottom: 18, offsetSide: 18, launcherSize: 62, panelWidth: 384, panelHeight: 620,
  radius: 28, blur: 30, glassOpacity: 62, launcherLabel: '', teaser: false, teaserText: '',
  mobileSheet: true, maximize: true, showFooter: true, theme: 'auto',
  prechat: false, streaming: true, csat: true,
  streamUrl: 'http://e.test/wp-json/pasokhban/v1/live/stream'
};

/**
 * @param mode 'slow'   = جریان کار می‌کند ولی اولین توکن ۲.۲ ثانیه طول می‌کشد
 *             'broken' = سرور پیام کاربر را ذخیره می‌کند و {visitor} می‌فرستد، بعد جریان قطع می‌شود
 *             'fast'   = جریان سریع و سالم
 */
function makeDom(mode) {
  const dom = new JSDOM('<!DOCTYPE html><html><body><div id="pasokhban-live" data-mode="widget"></div></body></html>',
    { url: 'http://e.test/', pretendToBeVisual: true, runScripts: 'dangerously' });
  const w = dom.window, d = w.document;
  w.ReadableStream = ReadableStream;
  w.TextEncoder = TextEncoder;
  w.TextDecoder = TextDecoder;
  w.Response = class {
    constructor(b, o) { o = o || {}; this.body = b; this.status = o.status || 200; this.ok = true;
      const raw = o.headers || {}, lower = {}; Object.keys(raw).forEach(k => lower[k.toLowerCase()] = raw[k]);
      this.headers = { get: k => lower[String(k).toLowerCase()] || null }; }
    json() { return Promise.resolve(JSON.parse(this.body)); }
  };
  w.PASOKHBAN_CHAT = { restUrl: '/wp-json/pasokhban/v1', nonce: 'n', lang: 'fa' };
  w.PASOKHBAN_CHAT_SETTINGS = SETTINGS;

  const calls = [];
  w.__calls = calls;
  let vid = 700;

  w.fetch = (url, opt) => {
    const path = String(url).replace(/^.*\/v1/, '');
    const body = opt.body ? JSON.parse(opt.body) : {};
    calls.push(path);

    if (path.indexOf('/live/stream') === 0) {
      const enc = new w.TextEncoder();

      if (mode === 'broken') {
        // سرور پیام کاربر را ذخیره می‌کند و شناسه‌اش را می‌فرستد، بعد قطع می‌شود
        const v = ++vid;
        const stream = new w.ReadableStream({
          start(c) {
            c.enqueue(enc.encode('data: ' + JSON.stringify({ visitor: v }) + '\n\n'));
            c.close();
          }
        });
        return Promise.resolve(new w.Response(stream, { status: 200, headers: { 'Content-Type': 'text/event-stream' } }));
      }

      let i = 0;
      const toks = ['پاسخ ', 'سریع'];
      const firstDelay = (mode === 'slow') ? 2200 : 20;
      const stream = new w.ReadableStream({
        pull(c) {
          if (i < toks.length) {
            const delay = (i === 0) ? firstDelay : 20;
            const idx = i;
            return new Promise(r => setTimeout(() => {
              c.enqueue(enc.encode('data: ' + JSON.stringify({ t: toks[idx] }) + '\n\n'));
              i++;
              r();
            }, delay));
          }
          c.enqueue(enc.encode('data: ' + JSON.stringify({ done: true, id: 900 + i, ms: 100, sources: [] }) + '\n\n'));
          c.close();
        }
      });
      return Promise.resolve(new w.Response(stream, { status: 200, headers: { 'Content-Type': 'text/event-stream' } }));
    }

    if (path.indexOf('/live/answer') === 0) {
      return Promise.resolve(new w.Response(JSON.stringify({ id: 999, content: 'پاسخ بازیابی', sources: [], ms: 50 }),
        { status: 200, headers: { 'Content-Type': 'application/json' } }));
    }
    if (path.indexOf('/live/send') === 0) {
      return Promise.resolve(new w.Response(JSON.stringify({
        message: { id: 800, sender: 'visitor', content: body.content, meta: {} },
        mode: 'ai', reply: { id: 801, sender: 'agent', content: 'پاسخ معمولی', meta: {} }
      }), { status: 200, headers: { 'Content-Type': 'application/json' } }));
    }

    let data = { ok: true };
    if (path.indexOf('/live/start') === 0) data = { key: 'a1b2c3d4e5f60718293a4b5c6d7e8f90', mode: 'ai', status: 'open', messages: [], agentOnline: false, settings: SETTINGS };
    if (path.indexOf('/live/poll') === 0) data = { messages: [], mode: 'ai', status: null, typing: false, agentOnline: false };
    return Promise.resolve(new w.Response(JSON.stringify(data), { status: 200, headers: { 'Content-Type': 'application/json' } }));
  };

  const s = d.createElement('script');
  s.textContent = JS;
  d.body.appendChild(s);
  return { w, d };
}

async function openPanel(t) {
  await wait(250);
  t.d.querySelector('.psb-launcher').dispatchEvent(new t.w.MouseEvent('click', { bubbles: true }));
  await wait(300);
}

(async () => {
  head('۱) تایمر سپری‌شده (جریان سالم ولی آهسته)');
  let t = makeDom('slow');
  await openPanel(t);

  const inp = t.d.querySelector('.psb-input');
  inp.value = 'سؤال';
  t.d.querySelector('.psb-send').dispatchEvent(new t.w.MouseEvent('click', { bubbles: true }));
  await wait(150);

  const think = t.d.querySelector('.psb-think');
  ok(!!think, 'اندیکاتور تفکر نمایش داده شد');
  ok(!!think.querySelector('.psb-think-t'), 'جای تایمر در اندیکاتور هست');

  await wait(1600);   // مجموع ~۱.۷۵ ثانیه
  const tEl = t.d.querySelector('.psb-think .psb-think-t');
  const txt = tEl ? tEl.textContent : '';
  ok(/^\d+s/.test(txt), 'تایمر سپری‌شده نمایش داده می‌شود', JSON.stringify(txt));

  await wait(1400);
  ok(!t.d.querySelector('.psb-think'), 'اندیکاتور بعد از رسیدن پاسخ حذف شد');

  head('۲) fallback زودهنگام (یک شکست کافی است)');
  t = makeDom('broken');
  await openPanel(t);

  const inp2 = t.d.querySelector('.psb-input');
  inp2.value = 'پیام اول';
  t.d.querySelector('.psb-send').dispatchEvent(new t.w.MouseEvent('click', { bubbles: true }));
  await wait(700);

  eq(t.w.__calls.filter(p => p.indexOf('/live/stream') === 0).length, 1, 'پیام اول یک تلاش stream کرد');
  ok(t.w.__calls.some(p => p.indexOf('/live/answer') === 0), 'مسیر بازیابی استفاده شد');

  inp2.value = 'پیام دوم';
  t.d.querySelector('.psb-send').dispatchEvent(new t.w.MouseEvent('click', { bubbles: true }));
  await wait(700);

  eq(t.w.__calls.filter(p => p.indexOf('/live/stream') === 0).length, 1, 'پیام دوم stream را امتحان نکرد');
  ok(t.w.__calls.filter(p => p.indexOf('/live/send') === 0).length >= 1, 'مسیر معمولی استفاده شد');

  const agents = Array.from(t.d.querySelectorAll('.psb-msg.agent')).filter(b => !b.textContent.startsWith('سلام'));
  ok(agents.length >= 2, 'هر دو پیام پاسخ گرفتند', 'تعداد: ' + agents.length);

  head('۳) وقتی stream کار می‌کند، بازیابی لازم نمی‌شود');
  t = makeDom('fast');
  await openPanel(t);

  const inp3 = t.d.querySelector('.psb-input');
  inp3.value = 'سؤال سریع';
  t.d.querySelector('.psb-send').dispatchEvent(new t.w.MouseEvent('click', { bubbles: true }));
  await wait(900);

  eq(t.w.__calls.filter(p => p.indexOf('/live/answer') === 0).length, 0, 'بازیابی صدا زده نشد');
  eq(t.w.__calls.filter(p => p.indexOf('/live/send') === 0).length, 0, 'مسیر معمولی هم لازم نشد');
  const a = Array.from(t.d.querySelectorAll('.psb-msg.agent')).filter(b => !b.textContent.startsWith('سلام'));
  ok(a.length >= 1 && /پاسخ سریع/.test(a[a.length - 1].textContent), 'پاسخ جریان‌دار رسید');

  console.log('\n' + '─'.repeat(52));
  if (fail === 0) console.log(`\x1b[42;30m همهٔ ${pass} تست سرعت پاس شد \x1b[0m`);
  else { console.log(`\x1b[41;97m ${fail} تست شکست خورد \x1b[0m (پاس: ${pass})`); fails.forEach(f => console.log('   • ' + f)); }
  console.log('─'.repeat(52));
  process.exit(fail === 0 ? 0 : 1);
})();
