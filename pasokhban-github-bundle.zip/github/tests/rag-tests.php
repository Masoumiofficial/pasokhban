<?php
/**
 * تست‌های ۱.۹.۰ — جست‌وجوی معنایی (RAG برداری).
 *
 * کد واقعی Pasokhban_RAG روی هارنس SQLite اجرا می‌شود. embedding با یک
 * Closure ساختگی شبیه‌سازی می‌شود که متن را به یک «فضای موضوعی» نگاشت
 * می‌کند — یعنی آزمون واقعاً بررسی می‌کند نزدیک‌ترین تکه انتخاب می‌شود،
 * نه فقط اینکه کد اجرا شد.
 */

require_once __DIR__ . '/wp-stubs.php';

$PASS = 0; $FAIL = 0; $FAILURES = array();

function ok( $cond, $label, $extra = '' ) {
	global $PASS, $FAIL, $FAILURES;
	if ( $cond ) { $PASS++; echo "  \033[32m✓\033[0m {$label}\n"; }
	else { $FAIL++; $FAILURES[] = $label . ( $extra ? " — {$extra}" : '' ); echo "  \033[31m✗\033[0m {$label}" . ( $extra ? "  → {$extra}" : '' ) . "\n"; }
}
function head( $t ) { echo "\n\033[1m{$t}\033[0m\n"; }
function eq( $a, $b, $label ) { ok( $a === $b, $label, 'انتظار ' . var_export( $b, true ) . ' / دریافت ' . var_export( $a, true ) ); }
function near( $a, $b, $label, $eps = 0.001 ) { ok( abs( $a - $b ) < $eps, $label, 'انتظار ~' . $b . ' / دریافت ' . $a ); }
function errcode( $r ) { return is_wp_error( $r ) ? $r->get_error_code() : false; }

/* =========================================================
 * فضای معنایی ساختگی برای embedding
 * =======================================================*/
$GLOBALS['FAKE_TOPICS'] = array(
	'refund'   => array( 'بازگشت', 'استرداد', 'پول', 'برمی‌گردد', 'پس بگیر', 'وجه', 'مرجوع', 'ناراضی' ),
	'shipping' => array( 'ارسال', 'پست', 'حمل', 'بسته', 'مرسوله', 'تحویل' ),
	'pricing'  => array( 'قیمت', 'هزینه', 'تخفیف', 'تعرفه' ),
	'about'    => array( 'درباره', 'تیم', 'شرکت', 'تاریخچه' ),
);

function fake_vector( $text ) {
	$v = array( 0.35 ); // بعد بایاس — شبیه رفتار واقعی embedding
	foreach ( $GLOBALS['FAKE_TOPICS'] as $words ) {
		$c = 0;
		foreach ( $words as $w ) {
			$c += substr_count( $text, $w );
		}
		$v[] = (float) $c;
	}
	return Pasokhban_RAG::normalize( $v );
}

/** پاسخ ساختگی /embeddings — با index به‌هم‌ریخته برمی‌گردد تا بازچینی هم آزموده شود. */
$GLOBALS['wp_remote_response'] = function ( $url, $args ) {
	if ( ! empty( $GLOBALS['fake_embed_fail'] ) ) {
		return array( 'response' => array( 'code' => $GLOBALS['fake_embed_fail'] ), 'body' => $GLOBALS['fake_embed_body'] );
	}
	$payload = json_decode( isset( $args['body'] ) ? $args['body'] : '{}', true );
	$inputs  = isset( $payload['input'] ) ? (array) $payload['input'] : array();
	$dims    = isset( $payload['dimensions'] ) ? (int) $payload['dimensions'] : 0;
	if ( $dims > 0 ) {
		$GLOBALS['fake_dims_requested'] = $dims;
	}

	$data = array();
	foreach ( $inputs as $i => $t ) {
		$data[] = array( 'object' => 'embedding', 'index' => $i, 'embedding' => fake_vector( $t ) );
	}
	// ترتیب را عمداً برعکس کن
	$data = array_reverse( $data );

	return array(
		'response' => array( 'code' => 200 ),
		'body'     => json_encode( array( 'object' => 'list', 'data' => $data, 'model' => $payload['model'] ) ),
	);
};

/* =========================================================
 * دادهٔ آزمایشی
 * =======================================================*/
function mkpost( $id, $title, $content, $type = 'post', $status = 'publish' ) {
	return (object) array(
		'ID'           => $id,
		'post_title'   => $title,
		'post_content' => $content,
		'post_type'    => $type,
		'post_status'  => $status,
	);
}

$GLOBALS['wp_posts'] = array(
	mkpost( 11, 'ضمانت‌نامهٔ محصول', 'اگر از خرید خود ناراضی بودی، تمام پولت به حساب بانکی‌ات برمی‌گردد. برای استرداد وجه کافی است شمارهٔ سفارش را برای ما بفرستی. بازگشت مبلغ بین سه تا پنج روز کاری انجام می‌شود و هیچ کارمزدی از تو گرفته نمی‌شود.' ),
	mkpost( 12, 'روش‌های ارسال', 'بسته‌ها با پست پیشتاز ارسال می‌شوند و تحویل معمولاً سه روز کاری طول می‌کشد. مرسوله‌های سنگین با باربری حمل می‌شوند و هزینهٔ حمل بر عهدهٔ مشتری است.' ),
	mkpost( 13, 'دربارهٔ ما', 'شرکت ما از سال ۱۳۹۰ کار خود را آغاز کرد. تیم ما از بیست نفر تشکیل شده و تاریخچهٔ بلندی در تولید محصول باکیفیت دارد. ما به مشتری‌های خود احترام می‌گذاریم.' ),
);

update_option( 'pasokhban_options', array(
	'api_key'      => 'sk-test-123',
	'base_url'     => 'https://api.example.test/v1',
	'rag_vector'   => 1,
	'rag_dims'     => 0,
	'rag_top_k'    => 3,
	'rag_min_score' => 0.30,
) );

Pasokhban_Settings::instance();
Pasokhban_DB::install();
$rag = Pasokhban_RAG::instance();

/* ========================================================= */
head( '۱) جدول ایندکس ساخته می‌شود' );
/* ========================================================= */

eq( Pasokhban_DB::chunks_table(), 'wp_pasokhban_chunks', 'نام جدول ایندکس' );
$exists = $GLOBALS['wpdb']->get_var( "SELECT name FROM sqlite_master WHERE type='table' AND name='wp_pasokhban_chunks'" );
ok( 'wp_pasokhban_chunks' === $exists, 'جدول pasokhban_chunks واقعاً ساخته شد' );
ok( version_compare( Pasokhban_DB::SCHEMA_VERSION, '1.5.0', '>=' ), 'نسخهٔ ساختار حداقل ۱.۵.۰ است', Pasokhban_DB::SCHEMA_VERSION );

/* ========================================================= */
head( '۲) تنظیمات جدید — مقدار پیش‌فرض و sanitize' );
/* ========================================================= */

$d = Pasokhban_Settings::instance()->defaults();
eq( $d['rag_vector'], 0, 'جست‌وجوی برداری به‌صورت پیش‌فرض خاموش است (رفتار ۱.۸ حفظ می‌شود)' );
eq( $d['rag_model'], 'text-embedding-3-small', 'مدل پیش‌فرض embedding' );
eq( $d['rag_dims'], 512, 'ابعاد پیش‌فرض ۵۱۲' );
eq( $d['rag_top_k'], 4, 'top_k پیش‌فرض ۴' );
eq( $d['rag_auto_sync'], 1, 'همگام‌سازی خودکار پیش‌فرض روشن' );

$st = Pasokhban_Settings::instance();
$out = $st->sanitize( array(
	'api_key'           => 'sk',
	'rag_vector'        => 1,
	'rag_model'         => '  text-embedding-3-large  ',
	'rag_dims'          => '999',            // نامعتبر
	'rag_top_k'         => 99,               // بیرون از محدوده
	'rag_min_score'     => 5,                // بیرون از محدوده
	'rag_chunk_size'    => 100000,
	'rag_chunk_overlap' => 900,
	'rag_post_types'    => 'post, page , product, foo, bar, baz, qux',
	'rag_auto_sync'     => 0,
) );
eq( $out['rag_vector'], 1, 'کلید boolean ذخیره شد' );
eq( $out['rag_model'], 'text-embedding-3-large', 'فاصلهٔ اضافهٔ مدل گرفته شد' );
eq( $out['rag_dims'], 512, 'ابعاد نامعتبر به پیش‌فرض برمی‌گردد' );
eq( $out['rag_top_k'], 8, 'top_k به سقف چسبید' );
eq( $out['rag_min_score'], 0.95, 'آستانه به سقف چسبید' );
eq( $out['rag_chunk_size'], 4000, 'اندازهٔ تکه به سقف چسبید' );
ok( $out['rag_chunk_overlap'] <= $out['rag_chunk_size'] - 100, 'هم‌پوشانی از اندازهٔ تکه بزرگ‌تر نمی‌شود', 'overlap=' . $out['rag_chunk_overlap'] );
eq( $out['rag_auto_sync'], 0, 'همگام‌سازی خودکار خاموش شد' );
eq( $out['rag_post_types'], 'post,page,product,foo,bar,baz', 'فقط ۶ نوع اول پذیرفته شد' );

$out2 = $st->sanitize( array( 'rag_post_types' => '!!!' ) );
eq( $out2['rag_post_types'], 'post,page', 'ورودی نامعتبر نوع محتوا به پیش‌فرض برمی‌گردد' );
$out3 = $st->sanitize( array( 'rag_dims' => '256' ) );
eq( $out3['rag_dims'], 256, 'ابعاد معتبر ۲۵۶ پذیرفته شد' );

/* ========================================================= */
head( '۳) تکه‌کردن متن' );
/* ========================================================= */

eq( Pasokhban_RAG::chunk_text( '' ), array(), 'متن خالی → بدون تکه' );
eq( Pasokhban_RAG::chunk_text( '   ' ), array(), 'متن فقط فاصله → بدون تکه' );
eq( Pasokhban_RAG::chunk_text( 'متن کوتاه' ), array( 'متن کوتاه' ), 'متن کوتاه دست‌نخورده برمی‌گردد' );

$para1 = str_repeat( 'جملهٔ اول پاراگراف. ', 30 );   // ~۶۰۰ کاراکتر
$para2 = str_repeat( 'جملهٔ دوم پاراگراف. ', 30 );
$long  = $para1 . "\n\n" . $para2;
$pieces = Pasokhban_RAG::chunk_text( $long, 700, 150 );
ok( count( $pieces ) >= 2, 'متن بلند به چند تکه تقسیم شد', count( $pieces ) . ' تکه' );
$too_big = 0;
foreach ( $pieces as $pc ) {
	if ( mb_strlen( $pc ) > 700 ) { $too_big++; }
}
eq( $too_big, 0, 'هیچ تکه‌ای از اندازهٔ هدف بزرگ‌تر نیست' );

// هم‌پوشانی: دنبالهٔ تکهٔ اول باید ابتدای تکهٔ دوم باشد
$tail = mb_substr( $pieces[0], -100 );
ok( false !== mb_strpos( $pieces[1], $tail ), 'هم‌پوشانی بین تکه‌ها وجود دارد' );

$noov = Pasokhban_RAG::chunk_text( $long, 700, 0 );
ok( count( $noov ) >= 2, 'با هم‌پوشانی صفر هم تکه‌بندی کار می‌کند' );

// سقف تکه برای هر منبع
$huge = str_repeat( str_repeat( 'پاراگراف بلند. ', 200 ) . "\n\n", 60 );
$capped = Pasokhban_RAG::chunk_text( $huge, 600, 0 );
ok( count( $capped ) <= Pasokhban_RAG::MAX_PER_SOURCE, 'تکه‌ها به سقف هر منبع محدود شدند', count( $capped ) . ' <= ' . Pasokhban_RAG::MAX_PER_SOURCE );

// پاراگراف نباید وسطش بریده شود اگر جا می‌شود
$two_short = "پاراگراف کوتاه اول.\n\nپاراگراف کوتاه دوم.";
eq( count( Pasokhban_RAG::chunk_text( $two_short, 500, 0 ) ), 1, 'دو پاراگراف کوتاه در یک تکه جا می‌شوند' );

/* ========================================================= */
head( '۴) ریاضیات بردار' );
/* ========================================================= */

$n = Pasokhban_RAG::normalize( array( 3, 4 ) );
near( sqrt( $n[0] * $n[0] + $n[1] * $n[1] ), 1.0, 'بردار واحد شد (طول = ۱)' );
near( $n[0], 0.6, 'مؤلفهٔ اول درست است' );
eq( Pasokhban_RAG::normalize( array( 0, 0, 0 ) ), array(), 'بردار صفر → آرایهٔ خالی (تقسیم بر صفر نمی‌شود)' );

near( Pasokhban_RAG::dot( $n, $n ), 1.0, 'ضرب داخلی بردار با خودش = ۱' );
near( Pasokhban_RAG::dot( array( 1.0, 0.0 ), array( 0.0, 1.0 ) ), 0.0, 'بردارهای عمود → ۰' );
ok( Pasokhban_RAG::dot( array( 1.0, 0.0 ), array( 0.0, 1.0 ) ) < Pasokhban_RAG::dot( $n, $n ), 'ترتیب شباهت درست است' );

// encode/decode
$enc = Pasokhban_RAG::encode( $n );
ok( is_string( $enc ) && '' !== $enc, 'بردار به رشته تبدیل شد' );
$dec = Pasokhban_RAG::decode( $enc );
near( $dec[0], $n[0], 'round-trip: مؤلفهٔ اول حفظ شد' );
near( $dec[1], $n[1], 'round-trip: مؤلفهٔ دوم حفظ شد' );
eq( Pasokhban_RAG::decode( 'not-json' ), array(), 'رشتهٔ خراب → آرایهٔ خالی، نه fatal' );
eq( Pasokhban_RAG::decode( '' ), array(), 'رشتهٔ خالی → آرایهٔ خالی' );
eq( Pasokhban_RAG::encode( array() ), '', 'بردار خالی → رشتهٔ خالی' );

// قالب ذخیره‌سازی: base64 از float32 big-endian
ok( false === strpos( $enc, '[' ), 'قالب ذخیره JSON نیست (فشرده‌تر است)' );
ok( (bool) preg_match( '#^[A-Za-z0-9+/=]+$#', $enc ), 'قالب base64 است' );
eq( strlen( base64_decode( $enc, true ) ), 8, 'دو مؤلفهٔ float32 = ۸ بایت' );
// big-endian یعنی قابل انتقال بین ماشین‌ها: بایت اول باید 0x3F باشد (0.6 ≈ 0x3F19999A)
$raw = base64_decode( $enc, true );
eq( dechex( ord( $raw[0] ) ), '3f', 'بایت‌ها big-endian نوشته شده‌اند (با جابه‌جایی هاست خراب نمی‌شود)' );

// سازگاری با ایندکس قدیمیِ JSON
$legacy = json_encode( array( 0.1, 0.2, 0.3 ) );
$ld     = Pasokhban_RAG::decode( $legacy );
eq( count( $ld ), 3, 'قالب JSON قدیمی هم خوانده می‌شود (ایندکس قبلی بی‌اعتبار نمی‌شود)' );
near( $ld[1], 0.2, 'مقدار قالب قدیمی درست خوانده شد' );

/* ========================================================= */
head( '۵) تشخیص پاسخ HTML به‌جای JSON' );
/* ========================================================= */
ok( Pasokhban_RAG::looks_like_html( "<!DOCTYPE html><html>" ), 'doctype تشخیص داده شد' );
ok( Pasokhban_RAG::looks_like_html( "  \n <HTML><head>" ), 'تگ html با فاصله تشخیص داده شد' );
ok( Pasokhban_RAG::looks_like_html( "window['ppConfig'] = {productName:" ), 'صفحهٔ لاگین گوگل تشخیص داده شد' );
ok( ! Pasokhban_RAG::looks_like_html( '{"data":[]}' ), 'JSON سالم HTML تشخیص داده نمی‌شود' );
ok( ! Pasokhban_RAG::looks_like_html( '' ), 'بدنهٔ خالی HTML نیست' );

/* ========================================================= */
head( '۶) فراخوانی /embeddings' );
/* ========================================================= */

$api = Pasokhban_API::instance();

// بدون کلید
update_option( 'pasokhban_options', array( 'api_key' => '' ) );
$rp = new ReflectionProperty( 'Pasokhban_Settings', 'options' ); $rp->setAccessible( true );
$rp->setValue( Pasokhban_Settings::instance(), get_option( 'pasokhban_options' ) );
$r = $rag->embed( array( 'سلام' ) );
eq( errcode( $r ), 'pasokhban_no_key', 'بدون کلید API خطای مشخص می‌دهد' );

update_option( 'pasokhban_options', array(
	'api_key' => 'sk-test-123', 'base_url' => 'https://api.example.test/v1',
	'rag_vector' => 1, 'rag_dims' => 0, 'rag_top_k' => 3, 'rag_min_score' => 0.30,
) );
$rp->setValue( Pasokhban_Settings::instance(), get_option( 'pasokhban_options' ) );

$GLOBALS['wp_remote_calls'] = array();
$r = $rag->embed( array( 'بازگشت وجه', 'ارسال بسته' ) );
ok( is_array( $r ) && ! is_wp_error( $r ), 'embedding موفق برگشت', is_wp_error( $r ) ? $r->get_error_message() : '' );
eq( count( $r ), 2, 'دو بردار برگشت' );

// ترتیب: پاسخ ساختگی عمداً array_reverse شده بود
$v_refund   = fake_vector( 'بازگشت وجه' );
$v_shipping = fake_vector( 'ارسال بسته' );
near( $r[0][1], $v_refund[1], 'ترتیب بازچینی شد: بردار اول مال متن اول است' );
near( $r[1][2], $v_shipping[2], 'ترتیب بازچینی شد: بردار دوم مال متن دوم است' );
ok( Pasokhban_RAG::dot( $r[0], $v_refund ) > 0.999, 'بردار اول دقیقاً همان است که انتظار داریم' );

$calls = $GLOBALS['wp_remote_calls'];
$last  = end( $calls );
ok( false !== strpos( $last['url'], '/embeddings' ), 'به مسیر /embeddings درخواست رفت', $last['url'] );
ok( ! isset( $last['body']['dimensions'] ), 'با ابعاد=۰ پارامتر dimensions فرستاده نمی‌شود' );

// متن‌های خالی حذف می‌شوند
$GLOBALS['wp_remote_calls'] = array();
$r = $rag->embed( array( '', '  ', 'بازگشت وجه' ) );
eq( count( $r ), 1, 'متن‌های خالی قبل از درخواست حذف شدند' );
eq( $rag->embed( array( '', '  ' ) ), array(), 'همه خالی → آرایهٔ خالی بدون درخواست شبکه' );

// خطای ۴۰۰
$GLOBALS['fake_embed_fail'] = 400;
$GLOBALS['fake_embed_body'] = json_encode( array( 'error' => array( 'message' => 'model not found' ) ) );
$r = $rag->embed( array( 'سلام' ) );
eq( errcode( $r ), 'pasokhban_embed', 'خطای ۴۰۰ به WP_Error تبدیل شد' );
ok( false !== strpos( $r->get_error_message(), 'model not found' ), 'پیام خطای سرور به کاربر منتقل شد' );

// پاسخ HTML
$GLOBALS['fake_embed_body'] = "<!DOCTYPE html><html><body>Not found</body></html>";
$r = $rag->embed( array( 'سلام' ) );
eq( errcode( $r ), 'pasokhban_embed', 'پاسخ HTML خطا می‌دهد' );
ok( false !== mb_strpos( $r->get_error_message(), 'HTML' ), 'پیام خطا راهنما دارد' );

// پاسخ ۲۰۰ ولی data خالی
$GLOBALS['fake_embed_fail'] = 200;
$GLOBALS['fake_embed_body'] = '{"data":[]}';
$r = $rag->embed( array( 'سلام' ) );
eq( errcode( $r ), 'pasokhban_embed', 'پاسخ خالی خطا می‌دهد' );

// پاسخ ۲۰۰ با تعداد بردار کمتر از متن‌ها
$GLOBALS['fake_embed_body'] = '{"data":[{"index":0,"embedding":[0.5,0.5]}]}';
$GLOBALS['wp_remote_response_bak'] = null;
$orig = $GLOBALS['wp_remote_response'];
$GLOBALS['wp_remote_response'] = array( 'response' => array( 'code' => 200 ), 'body' => $GLOBALS['fake_embed_body'] );
$r = $rag->embed( array( 'یک', 'دو' ) );
eq( errcode( $r ), 'pasokhban_embed', 'عدم تطابق تعداد بردارها خطا می‌دهد' );
$GLOBALS['wp_remote_response'] = $orig;

// خطای شبکه
$GLOBALS['wp_remote_response'] = new WP_Error( 'http_error', 'timeout' );
$r = $rag->embed( array( 'سلام' ) );
eq( errcode( $r ), 'pasokhban_remote', 'خطای شبکه به WP_Error تبدیل شد' );
$GLOBALS['wp_remote_response'] = $orig;
unset( $GLOBALS['fake_embed_fail'], $GLOBALS['fake_embed_body'] );

// dimensions نامعتبر → یک بار بدون آن تلاش دوباره
$GLOBALS['wp_remote_response'] = $orig;
update_option( 'pasokhban_options', array(
	'api_key' => 'sk-test-123', 'base_url' => 'https://api.example.test/v1',
	'rag_vector' => 1, 'rag_dims' => 512, 'rag_top_k' => 3, 'rag_min_score' => 0.30,
) );
$rp->setValue( Pasokhban_Settings::instance(), get_option( 'pasokhban_options' ) );

$GLOBALS['dims_attempts'] = 0;
$GLOBALS['wp_remote_response'] = function ( $url, $args ) {
	$payload = json_decode( $args['body'], true );
	$GLOBALS['dims_attempts']++;
	if ( isset( $payload['dimensions'] ) ) {
		return array(
			'response' => array( 'code' => 400 ),
			'body'     => json_encode( array( 'error' => array( 'message' => 'Unsupported parameter: dimensions' ) ) ),
		);
	}
	$data = array();
	foreach ( (array) $payload['input'] as $i => $t ) {
		$data[] = array( 'index' => $i, 'embedding' => fake_vector( $t ) );
	}
	return array( 'response' => array( 'code' => 200 ), 'body' => json_encode( array( 'data' => $data ) ) );
};
$r = $rag->embed( array( 'بازگشت وجه' ) );
ok( ! is_wp_error( $r ), 'با خطای dimensions، یک بار بدون آن تلاش شد و موفق بود', is_wp_error( $r ) ? $r->get_error_message() : '' );
eq( $GLOBALS['dims_attempts'], 2, 'دقیقاً دو درخواست زده شد (نه بیشتر)' );

// ابعاد معتبر واقعاً فرستاده می‌شود
$GLOBALS['wp_remote_response'] = $orig;
$GLOBALS['wp_remote_calls'] = array();
$r = $rag->embed( array( 'بازگشت وجه' ) );
$last = end( $GLOBALS['wp_remote_calls'] );
eq( isset( $last['body']['dimensions'] ) ? (int) $last['body']['dimensions'] : null, 512, 'پارامتر dimensions=512 فرستاده شد' );

/* ========================================================= */
head( '۷) ساخت ایندکس' );
/* ========================================================= */

update_option( 'pasokhban_options', array(
	'api_key' => 'sk-test-123', 'base_url' => 'https://api.example.test/v1',
	'rag_vector' => 1, 'rag_dims' => 0, 'rag_top_k' => 3, 'rag_min_score' => 0.30,
	'rag_chunk_size' => 1200, 'rag_chunk_overlap' => 200, 'rag_post_types' => 'post,page',
	'rag_auto_sync' => 1,
) );
$rp->setValue( Pasokhban_Settings::instance(), get_option( 'pasokhban_options' ) );

$GLOBALS['wpdb']->query( 'DELETE FROM wp_pasokhban_chunks' );
$res = $rag->build( array( 'reset' => true ) );
ok( $res['ok'], 'ایندکس بدون خطا ساخته شد', implode( ' | ', $res['errors'] ) );
eq( $res['sources'], 3, 'هر سه نوشته پردازش شد' );
ok( $res['chunks'] >= 3, 'برای هر نوشته حداقل یک تکه ساخته شد', $res['chunks'] . ' تکه' );
eq( $rag->count_chunks(), $res['chunks'], 'شمارش جدول با خلاصهٔ اجرا یکی است' );

$stt = $rag->state();
eq( $stt['chunks'], $res['chunks'], 'وضعیت ذخیره شد' );
eq( $stt['sources'], 3, 'تعداد منابع در وضعیت' );
ok( $stt['built_at'] > 0, 'زمان ساخت ثبت شد' );
eq( $stt['error'], '', 'خطایی در وضعیت ثبت نشد' );

// هر تکه بردار دارد و عنوان/آدرس پر است
$rows = $GLOBALS['wpdb']->get_results( 'SELECT * FROM wp_pasokhban_chunks' );
$bad  = 0;
foreach ( $rows as $row ) {
	if ( '' === $row->vector || count( Pasokhban_RAG::decode( $row->vector ) ) < 2 ) { $bad++; }
	if ( (int) $row->dims !== count( Pasokhban_RAG::decode( $row->vector ) ) ) { $bad++; }
	if ( '' === $row->title || '' === $row->url || '' === $row->content ) { $bad++; }
}
eq( $bad, 0, 'همهٔ تکه‌ها بردار، عنوان، آدرس و محتوا دارند' );
ok( false !== strpos( $rows[0]->url, 'example.test' ), 'آدرس تکه permalink است', $rows[0]->url );

// اجرای دوباره: هیچ‌چیز عوض نشده، پس نباید embedding بگیرد
$GLOBALS['wp_remote_calls'] = array();
$res2 = $rag->build( array() );
eq( $res2['sources'], 0, 'اجرای دوباره هیچ منبعی را پردازش نکرد' );
eq( $res2['skipped'], 3, 'هر سه منبع «بدون تغییر» شناخته شدند' );
eq( $res2['chunks'], 0, 'تکهٔ تازه‌ای ساخته نشد' );
$emb_calls = 0;
foreach ( $GLOBALS['wp_remote_calls'] as $c ) {
	if ( false !== strpos( $c['url'], '/embeddings' ) ) { $emb_calls++; }
}
eq( $emb_calls, 0, 'بدون تغییر محتوا، هیچ درخواست embedding زده نمی‌شود (هزینهٔ تکراری صفر)' );

// ویرایش یک نوشته → فقط همان دوباره ایندکس می‌شود
$GLOBALS['wp_posts'][0]->post_content .= ' این جمله تازه اضافه شده است.';
$res3 = $rag->build( array() );
eq( $res3['sources'], 1, 'فقط نوشتهٔ تغییریافته پردازش شد' );
eq( $res3['skipped'], 2, 'دو نوشتهٔ دیگر رد شدند' );
ok( $res3['chunks'] >= 1, 'تکهٔ تازه ساخته شد' );

// حذف یک نوشته از منابع → تکه‌هایش پاک می‌شوند
$before = $rag->count_chunks();
unset( $GLOBALS['wp_posts'][2] );
$GLOBALS['wp_posts'] = array_values( $GLOBALS['wp_posts'] );
$res4 = $rag->build( array() );
eq( $res4['removed'], 1, 'منبع حذف‌شده شناسایی شد' );
ok( $rag->count_chunks() < $before, 'تکه‌های منبع حذف‌شده از جدول پاک شدند' );
$left = $GLOBALS['wpdb']->get_var( "SELECT COUNT(*) FROM wp_pasokhban_chunks WHERE source_id = '13'" );
eq( (int) $left, 0, 'هیچ تکه‌ای از نوشتهٔ حذف‌شده نماند' );

// پارامتر only
$GLOBALS['wp_remote_calls'] = array();
$GLOBALS['wp_posts'][0]->post_content .= ' یک جملهٔ دیگر.';
$GLOBALS['wp_posts'][1]->post_content .= ' یک جملهٔ دیگر.';
$res5 = $rag->build( array( 'only' => array( 'post:11' ) ) );
eq( $res5['sources'], 1, 'فقط منبع خواسته‌شده ایندکس شد' );
eq( $res5['skipped'], 0, 'منابع دیگر حتی شمرده نشدند' );

// limit و remaining
$GLOBALS['wp_posts'][1]->post_content .= ' باز هم.';
$res6 = $rag->build( array( 'limit' => 0 ) );
ok( isset( $res6['total'] ), 'تعداد کل تکه‌ها در خلاصه هست' );

// بدون کلید API
update_option( 'pasokhban_options', array( 'api_key' => '', 'rag_vector' => 1 ) );
$rp->setValue( Pasokhban_Settings::instance(), get_option( 'pasokhban_options' ) );
$res7 = $rag->build( array() );
eq( $res7['ok'], false, 'بدون کلید API ساخت ایندکس شکست می‌خورد' );
ok( ! empty( $res7['errors'] ), 'دلیل شکست گزارش شد' );

update_option( 'pasokhban_options', array(
	'api_key' => 'sk-test-123', 'base_url' => 'https://api.example.test/v1',
	'rag_vector' => 1, 'rag_dims' => 0, 'rag_top_k' => 3, 'rag_min_score' => 0.30,
	'rag_chunk_size' => 1200, 'rag_chunk_overlap' => 200, 'rag_post_types' => 'post,page',
	'rag_auto_sync' => 1,
) );
$rp->setValue( Pasokhban_Settings::instance(), get_option( 'pasokhban_options' ) );

/* ========================================================= */
head( '۸) خطای embedding موقع ساخت ایندکس' );
/* ========================================================= */

$GLOBALS['wpdb']->query( 'DELETE FROM wp_pasokhban_chunks' );
$GLOBALS['wp_remote_response'] = array(
	'response' => array( 'code' => 401 ),
	'body'     => json_encode( array( 'error' => array( 'message' => 'invalid api key' ) ) ),
);
$res8 = $rag->build( array( 'reset' => true ) );
eq( $res8['ok'], false, 'با خطای API، ساخت ایندکس ناموفق گزارش می‌شود' );
eq( $res8['chunks'], 0, 'هیچ تکهٔ بی‌بردار ذخیره نشد' );
ok( false !== strpos( $rag->state()['error'], 'invalid api key' ), 'خطا در وضعیت ثبت شد تا در پیشخوان دیده شود' );
$GLOBALS['wp_remote_response'] = $orig;

/* ========================================================= */
head( '۹) جست‌وجوی معنایی' );
/* ========================================================= */

$GLOBALS['wpdb']->query( 'DELETE FROM wp_pasokhban_chunks' );
delete_option( Pasokhban_RAG::OPT_STATE );
$GLOBALS['wp_transients'] = array();
$built = $rag->build( array( 'reset' => true ) );
ok( $built['ok'], 'ایندکس برای آزمون جست‌وجو ساخته شد', implode( ' | ', $built['errors'] ) );

// خاموش → null
update_option( 'pasokhban_options', array( 'api_key' => 'sk', 'rag_vector' => 0 ) );
$rp->setValue( Pasokhban_Settings::instance(), get_option( 'pasokhban_options' ) );
eq( $rag->retrieve( 'چطور پولم را پس بگیرم؟' ), null, 'با قابلیت خاموش، null برمی‌گردد' );
eq( $rag->enabled(), false, 'enabled() خاموش است' );

update_option( 'pasokhban_options', array(
	'api_key' => 'sk-test-123', 'base_url' => 'https://api.example.test/v1',
	'rag_vector' => 1, 'rag_dims' => 0, 'rag_top_k' => 3, 'rag_min_score' => 0.30,
) );
$rp->setValue( Pasokhban_Settings::instance(), get_option( 'pasokhban_options' ) );
eq( $rag->enabled(), true, 'enabled() روشن است' );

eq( $rag->retrieve( '   ' ), null, 'پرس‌وجوی خالی → null' );

// ایندکس خالی → null (نه خطا)
$GLOBALS['wpdb']->query( 'DELETE FROM wp_pasokhban_chunks' );
eq( $rag->retrieve( 'چطور پولم را پس بگیرم؟' ), null, 'با ایندکس خالی null برمی‌گردد تا مسیر قدیمی کار کند' );
$rag->build( array( 'reset' => true ) );
$GLOBALS['wp_transients'] = array();

// ★ آزمون اصلی: سؤالی که هیچ کلمهٔ مشترکی با عنوان ندارد
$GLOBALS['wp_remote_calls'] = array();
$hit = $rag->retrieve( 'چطور پولم را پس بگیرم؟' );
ok( is_array( $hit ), 'نتیجهٔ جست‌وجو آرایه است' );
ok( ! empty( $hit['context'] ), 'زمینهٔ متنی ساخته شد' );
ok( ! empty( $hit['sources'] ), 'منبع برگشت' );
eq( $hit['sources'][0]['title'], 'ضمانت‌نامهٔ محصول', 'نوشتهٔ «ضمانت‌نامه» برای سؤال «پس گرفتن پول» پیدا شد' );
ok( $hit['hits'][0]['score'] > 0.6, 'امتیاز شباهت بالاست', $hit['hits'][0]['score'] );
ok( false === strpos( $hit['context'], 'روش‌های ارسال' ) || $hit['hits'][0]['title'] !== 'روش‌های ارسال', 'نوشتهٔ نامرتبط اول نیست' );

// کش: بار دوم بدون درخواست شبکه
$GLOBALS['wp_remote_calls'] = array();
$hit2 = $rag->retrieve( 'چطور پولم را پس بگیرم؟' );
eq( $hit2['sources'][0]['title'], 'ضمانت‌نامهٔ محصول', 'نتیجهٔ کش‌شده همان است' );
eq( count( $GLOBALS['wp_remote_calls'] ), 0, 'بار دوم هیچ درخواست embedding زده نشد (کش)' );

// سؤال دربارهٔ ارسال
$GLOBALS['wp_transients'] = array();
$hit3 = $rag->retrieve( 'بسته‌ام چطور ارسال می‌شود؟' );
eq( $hit3['sources'][0]['title'], 'روش‌های ارسال', 'سؤال ارسال به نوشتهٔ ارسال رسید' );

// آستانهٔ بالا → نتیجهٔ خالی ولی بدون خطا
update_option( 'pasokhban_options', array(
	'api_key' => 'sk-test-123', 'base_url' => 'https://api.example.test/v1',
	'rag_vector' => 1, 'rag_dims' => 0, 'rag_top_k' => 3, 'rag_min_score' => 0.99,
) );
$rp->setValue( Pasokhban_Settings::instance(), get_option( 'pasokhban_options' ) );
$GLOBALS['wp_transients'] = array();
$hit4 = $rag->retrieve( 'تاریخچهٔ شرکت' );
eq( $hit4['context'], '', 'با آستانهٔ خیلی بالا، زمینه خالی است' );
eq( $hit4['sources'], array(), 'منبعی برنگشت' );

// خطای embedding موقع جست‌وجو → WP_Error (چت نمی‌افتد)
update_option( 'pasokhban_options', array(
	'api_key' => 'sk-test-123', 'base_url' => 'https://api.example.test/v1',
	'rag_vector' => 1, 'rag_dims' => 0, 'rag_top_k' => 3, 'rag_min_score' => 0.30,
) );
$rp->setValue( Pasokhban_Settings::instance(), get_option( 'pasokhban_options' ) );
$GLOBALS['wp_transients'] = array();
$GLOBALS['wp_remote_response'] = new WP_Error( 'http_error', 'timeout' );
$hit5 = $rag->retrieve( 'چطور پولم را پس بگیرم؟' );
ok( is_wp_error( $hit5 ), 'خطای embedding به‌صورت WP_Error برمی‌گردد' );
$GLOBALS['wp_remote_response'] = $orig;

// بردار با ابعاد ناهمخوان → سطر نادیده گرفته می‌شود، fatal نمی‌شود
$GLOBALS['wpdb']->query( "UPDATE wp_pasokhban_chunks SET vector = '[0.1, 0.2, 0.3]' WHERE id = (SELECT MIN(id) FROM wp_pasokhban_chunks)" );
$GLOBALS['wp_transients'] = array();
$hit6 = $rag->retrieve( 'چطور پولم را پس بگیرم؟' );
ok( is_array( $hit6 ), 'سطر با ابعاد ناهمخوان باعث fatal نشد' );
$rag->build( array( 'reset' => true ) );

/* ========================================================= */
head( '۱۰) یکپارچگی با get_site_docs' );
/* ========================================================= */

$GLOBALS['wp_transients'] = array();
$docs = $api->get_site_docs( 'چطور پولم را پس بگیرم؟' );
eq( isset( $docs['engine'] ) ? $docs['engine'] : '', 'vector', 'موتور برداری استفاده شد' );
ok( ! empty( $docs['context'] ), 'زمینه برگشت' );
eq( $docs['sources'][0]['title'], 'ضمانت‌نامهٔ محصول', 'منبع درست به مدل می‌رسد' );

// خاموش → مسیر کلیدواژه‌ای
update_option( 'pasokhban_options', array( 'api_key' => 'sk', 'rag_vector' => 0 ) );
$rp->setValue( Pasokhban_Settings::instance(), get_option( 'pasokhban_options' ) );
$GLOBALS['wp_transients'] = array();
$GLOBALS['wp_remote_calls'] = array();
$docs2 = $api->get_site_docs( 'چطور پولم را پس بگیرم؟' );
eq( $docs2['engine'], 'keyword', 'با خاموش‌بودن، مسیر کلیدواژه‌ای کار می‌کند' );
eq( count( $GLOBALS['wp_remote_calls'] ), 0, 'در حالت خاموش هیچ درخواست embedding زده نمی‌شود' );

// روشن ولی API خراب → باید بی‌سروصدا به کلیدواژه‌ای برگردد
update_option( 'pasokhban_options', array( 'api_key' => 'sk-test-123', 'base_url' => 'https://api.example.test/v1', 'rag_vector' => 1, 'rag_dims' => 0, 'rag_top_k' => 3, 'rag_min_score' => 0.30 ) );
$rp->setValue( Pasokhban_Settings::instance(), get_option( 'pasokhban_options' ) );
$GLOBALS['wp_transients'] = array();
$GLOBALS['wp_remote_response'] = new WP_Error( 'http_error', 'timeout' );
$docs3 = $api->get_site_docs( 'چطور پولم را پس بگیرم؟' );
eq( $docs3['engine'], 'keyword', 'با خرابی API، جست‌وجوی کلیدواژه‌ای جایگزین می‌شود' );
ok( true, 'چت با وجود خرابی embedding از کار نمی‌افتد' );
$GLOBALS['wp_remote_response'] = $orig;

/* ========================================================= */
head( '۱۰٫۵) پاسخ کامل با RAG برداری (generate_reply)' );
/* ========================================================= */

// حالا دو endpoint متفاوت صدا زده می‌شود: /embeddings و /chat/completions
$GLOBALS['wp_remote_calls'] = array();
$GLOBALS['wp_transients']   = array();
$chat_payload_seen          = null;
$GLOBALS['wp_remote_response'] = function ( $url, $args ) use ( &$chat_payload_seen ) {
	if ( false !== strpos( $url, '/embeddings' ) ) {
		$p    = json_decode( $args['body'], true );
		$data = array();
		foreach ( (array) $p['input'] as $i => $t ) {
			$data[] = array( 'index' => $i, 'embedding' => fake_vector( $t ) );
		}
		return array( 'response' => array( 'code' => 200 ), 'body' => json_encode( array( 'data' => $data ) ) );
	}
	$chat_payload_seen = json_decode( $args['body'], true );
	return array(
		'response' => array( 'code' => 200 ),
		'body'     => json_encode( array(
			'choices' => array( array( 'message' => array( 'role' => 'assistant', 'content' => 'برای بازگشت وجه شمارهٔ سفارش را بفرست.' ) ) ),
		) ),
	);
};

$rag->build( array( 'reset' => true ) );
// شمارنده را بعد از ایندکس‌سازی صفر کن؛ خودِ build هم embedding می‌زند
// و اینجا فقط درخواست‌های مسیر پاسخ را می‌خواهیم.
$GLOBALS['wp_remote_calls'] = array();
$GLOBALS['wp_transients']   = array();

$reply = $api->generate_reply(
	array( array( 'role' => 'user', 'content' => 'چطور پولم را پس بگیرم؟' ) ),
	'fa',
	array( 'mode' => 'live' )
);

ok( is_array( $reply ) && ! is_wp_error( $reply ), 'generate_reply موفق بود', is_wp_error( $reply ) ? $reply->get_error_message() : '' );
eq( $reply['sources'][0]['title'], 'ضمانت‌نامهٔ محصول', 'منبع برداری در پاسخ نهایی برگشت' );

// زمینهٔ برداری واقعاً به مدل رسیده باشد
$sys = '';
foreach ( $chat_payload_seen['messages'] as $m ) {
	if ( 'system' === $m['role'] && false !== strpos( $m['content'], 'جست‌وجوی معنایی' ) ) {
		$sys = $m['content'];
	}
}
ok( '' !== $sys, 'زمینهٔ برداری به‌عنوان پیام system به مدل فرستاده شد' );
ok( false !== strpos( $sys, 'ضمانت‌نامهٔ محصول' ), 'متن تکهٔ برنده داخل زمینه هست' );
ok( false !== strpos( $sys, 'example.test' ), 'لینک منبع داخل زمینه هست تا مدل ارجاع بدهد' );

$emb_calls = 0;
$chat_calls = 0;
foreach ( $GLOBALS['wp_remote_calls'] as $c ) {
	if ( false !== strpos( $c['url'], '/embeddings' ) ) { $emb_calls++; }
	if ( false !== strpos( $c['url'], '/chat/completions' ) ) { $chat_calls++; }
}
eq( $emb_calls, 1, 'دقیقاً یک درخواست embedding (برای خودِ سؤال)' );
eq( $chat_calls, 1, 'دقیقاً یک درخواست chat' );

$GLOBALS['wp_remote_response'] = $orig;

/* ========================================================= */
head( '۱۱) صف تغییر و کرون' );
/* ========================================================= */

delete_option( Pasokhban_RAG::OPT_DIRTY );
$GLOBALS['wp_cron'] = array();
$rag->on_save_post( 11, $GLOBALS['wp_posts'][0] );
eq( get_option( Pasokhban_RAG::OPT_DIRTY, array() ), array( 'post:11' ), 'ذخیرهٔ نوشته در صف تغییر رفت' );
$rag->on_save_post( 11, $GLOBALS['wp_posts'][0] );
eq( count( get_option( Pasokhban_RAG::OPT_DIRTY, array() ) ), 1, 'تکراری در صف نمی‌رود' );
ok( isset( $GLOBALS['wp_cron'][ Pasokhban_RAG::CRON_HOOK ] ), 'کرون ساعتی زمان‌بندی شد' );
eq( $GLOBALS['wp_cron'][ Pasokhban_RAG::CRON_HOOK ], 'hourly', 'بازهٔ کرون ساعتی است' );

$rag->on_save_post( 12, $GLOBALS['wp_posts'][1] );
eq( count( get_option( Pasokhban_RAG::OPT_DIRTY, array() ) ), 2, 'نوشتهٔ دوم هم در صف رفت' );

$synced = $rag->sync_dirty();
ok( is_array( $synced ) && ! empty( $synced['ok'] ), 'همگام‌سازی کرون اجرا شد' );
eq( get_option( Pasokhban_RAG::OPT_DIRTY, array() ), array(), 'بعد از همگام‌سازی، صف خالی شد' );

// خاموش → صف پر نمی‌شود
update_option( 'pasokhban_options', array( 'api_key' => 'sk', 'rag_vector' => 0, 'rag_auto_sync' => 1 ) );
$rp->setValue( Pasokhban_Settings::instance(), get_option( 'pasokhban_options' ) );
delete_option( Pasokhban_RAG::OPT_DIRTY );
$rag->on_save_post( 11, $GLOBALS['wp_posts'][0] );
eq( get_option( Pasokhban_RAG::OPT_DIRTY, array() ), array(), 'با قابلیت خاموش، صف پر نمی‌شود' );

update_option( 'pasokhban_options', array( 'api_key' => 'sk-test-123', 'base_url' => 'https://api.example.test/v1', 'rag_vector' => 1, 'rag_dims' => 0, 'rag_top_k' => 3, 'rag_min_score' => 0.30, 'rag_auto_sync' => 0 ) );
$rp->setValue( Pasokhban_Settings::instance(), get_option( 'pasokhban_options' ) );
delete_option( Pasokhban_RAG::OPT_DIRTY );
$rag->on_save_post( 11, $GLOBALS['wp_posts'][0] );
eq( get_option( Pasokhban_RAG::OPT_DIRTY, array() ), array(), 'با همگام‌سازی خودکار خاموش، صف پر نمی‌شود' );

// حذف نوشته → تکه‌ها بی‌درنگ پاک می‌شوند
update_option( 'pasokhban_options', array( 'api_key' => 'sk-test-123', 'base_url' => 'https://api.example.test/v1', 'rag_vector' => 1, 'rag_dims' => 0, 'rag_top_k' => 3, 'rag_min_score' => 0.30 ) );
$rp->setValue( Pasokhban_Settings::instance(), get_option( 'pasokhban_options' ) );
$rag->build( array( 'reset' => true ) );
ok( (int) $GLOBALS['wpdb']->get_var( "SELECT COUNT(*) FROM wp_pasokhban_chunks WHERE source_id = '12'" ) > 0, 'تکه‌های نوشتهٔ ۱۲ در ایندکس هست' );
$rag->on_delete_post( 12 );
eq( (int) $GLOBALS['wpdb']->get_var( "SELECT COUNT(*) FROM wp_pasokhban_chunks WHERE source_id = '12'" ), 0, 'با حذف نوشته، تکه‌هایش فوراً پاک شدند' );

/* ========================================================= */
head( '۱۲) پاک‌کردن و حذف پلاگین' );
/* ========================================================= */

$rag->build( array( 'reset' => true ) );
ok( $rag->count_chunks() > 0, 'ایندکس پر است' );
$rag->clear();
eq( $rag->count_chunks(), 0, 'clear() جدول را خالی کرد' );
eq( get_option( Pasokhban_RAG::OPT_STATE, null ), null, 'clear() وضعیت را پاک کرد' );
eq( $rag->retrieve( 'چطور پولم را پس بگیرم؟' ), null, 'بعد از پاک‌کردن، جست‌وجو null می‌دهد' );

$un = file_get_contents( PASOKHBAN_PATH . 'uninstall.php' );
ok( false !== strpos( $un, 'pasokhban_chunks' ), 'uninstall.php جدول ایندکس را حذف می‌کند' );
ok( false !== strpos( $un, 'pasokhban_rag_state' ), 'uninstall.php وضعیت ایندکس را پاک می‌کند' );

/* ========================================================= */
head( '۱۳) صفحهٔ تنظیمات' );
/* ========================================================= */

$rag->build( array( 'reset' => true ) );
set_transient( 'pasokhban_rag_notice', array( 'type' => 'success', 'text' => 'منابع پردازش‌شده: ۲' ), 60 );
ob_start();
Pasokhban_Settings::instance()->render_page();
$html = ob_get_clean();

foreach ( array( 'rag_vector', 'rag_model', 'rag_dims', 'rag_top_k', 'rag_chunk_size', 'rag_chunk_overlap', 'rag_min_score', 'rag_post_types', 'rag_auto_sync' ) as $f ) {
	ok( false !== strpos( $html, 'pasokhban_options[' . $f . ']' ), 'فیلد ' . $f . ' در فرم تنظیمات هست' );
}
ok( false !== strpos( $html, 'id="psb-rag-build-form"' ), 'فرم ساخت ایندکس هست' );
ok( false !== strpos( $html, 'id="psb-rag-test-form"' ), 'فرم آزمایش اتصال هست' );
ok( false !== strpos( $html, 'id="psb-rag-clear-form"' ), 'فرم پاک‌کردن ایندکس هست' );
ok( false !== strpos( $html, 'form="psb-rag-build-form"' ), 'دکمهٔ ساخت ایندکس به فرم بیرونی وصل است' );
ok( false !== strpos( $html, 'psb-rag-note--success' ), 'نوار نتیجهٔ عملیات نمایش داده می‌شود' );
ok( false !== strpos( $html, 'id="pasokhban-rag"' ), 'لنگر کارت RAG هست' );

// ★ رگرسیون باگ فرم تو‌در‌تو: دکمه‌های RAG نباید داخل فرم تنظیمات باشند
$main_pos = strpos( $html, 'id="psb-set-form"' );
$main_end = strpos( $html, '</form>', $main_pos );
$build_pos = strpos( $html, 'id="psb-rag-build-form"' );
ok( $build_pos > $main_end, 'فرم ساخت ایندکس بیرون فرم تنظیمات است (باگ فرم تو‌در‌تو تکرار نشد)' );
// نکته: توضیح HTML داخل class-settings.php خودش یک </form> دارد، پس
// قبل از شمارش، commentها را برمی‌داریم.
$html_nocomment = preg_replace( '/<!--.*?-->/s', '', $html );
preg_match_all( '/<form\b/', $html_nocomment, $m );
preg_match_all( '/<\/form>/', $html_nocomment, $m2 );
eq( count( $m[0] ), count( $m2[0] ), 'تعداد <form> و </form> برابر است' );
ok( count( $m[0] ) >= 5, 'حداقل پنج فرم (تنظیمات + آزمایش اعلان + سه فرم RAG + پیامک)', count( $m[0] ) );
$depth = 0; $maxdepth = 0;
foreach ( preg_split( '/(<form\b|<\/form>)/', $html_nocomment, -1, PREG_SPLIT_DELIM_CAPTURE ) as $tok ) {
	if ( '<form' === substr( $tok, 0, 5 ) ) { $depth++; $maxdepth = max( $maxdepth, $depth ); }
	if ( '</form>' === $tok ) { $depth--; }
}
eq( $maxdepth, 1, 'هیچ‌جا فرم تو‌در‌تو نمی‌شود' );
eq( $depth, 0, 'همهٔ فرم‌ها بسته شده‌اند' );

// take_notice یک‌بار مصرف است
eq( $rag->take_notice(), null, 'نوار نتیجه یک‌بار مصرف است' );

/* ========================================================= */
head( '۱۴) نسخه و بارگذاری' );
/* ========================================================= */

$main = file_get_contents( PASOKHBAN_PATH . 'pasokhban.php' );
ok( (bool) preg_match( "/define\\( 'PASOKHBAN_VERSION', '([0-9.]+)' \\)/", $main, $mv ), 'نسخهٔ پلاگین تعریف شده' );
ok( version_compare( $mv[1], '1.9.0', '>=' ), 'نسخهٔ پلاگین حداقل ۱.۹.۰ است', $mv[1] );
ok( false !== strpos( $main, 'includes/class-rag.php' ), 'class-rag.php بارگذاری می‌شود' );
ok( false !== strpos( $main, 'Pasokhban_RAG::instance()' ), 'کلاس RAG راه‌اندازی می‌شود' );
ok( false !== strpos( $main, "array( 'Pasokhban_RAG', 'bootstrap' )" ), 'bootstrap به admin_init وصل است' );

/* ========================================================= */
echo "\n────────────────────────────────────────────────────\n";
if ( 0 === $FAIL ) {
	echo "\033[42;30m همهٔ {$PASS} تست RAG پاس شد \033[0m\n";
} else {
	echo "\033[41;97m {$FAIL} تست شکست خورد \033[0m (پاس: {$PASS})\n";
	foreach ( $FAILURES as $f ) {
		echo "   • {$f}\n";
	}
}
echo "────────────────────────────────────────────────────\n";
exit( $FAIL > 0 ? 1 : 0 );
