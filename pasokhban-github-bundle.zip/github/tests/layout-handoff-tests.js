/**
 * تست دو رفع: چیدمان پیام‌ها · دوبار نشدن پیام handoff
 */
const fs = require('fs');
const { JSDOM } = require('jsdom');
const { ReadableStream } = require('stream/web');
const { TextEncoder, TextDecoder } = require('util');

const JS = fs.readFileSync(__dirname + '/../plugin/assets/js/pasokhban-chat.js', 'utf8');
const CSS = fs.readFileSync(__dirname + '/../plugin/assets/css/pasokhban-chat.css', 'utf8');

let pass = 0, fail = 0; const fails = [];
const ok = (c, l, x) => { if (c) { pass++; console.log(`  \x1b[32m✓\x1b[0m ${l}`); } else { fail++; fails.push(l + (x ? ' — ' + x : '')); console.log(`  \x1b[31m✗\x1b[0m ${l}` + (x ? '  → ' + x : '')); } };
const eq = (a, b, l) => ok(JSON.stringify(a) === JSON.stringify(b), l, `انتظار ${JSON.stringify(b)} / دریافت ${JSON.stringify(a)}`);
const head = t => console.log(`\n\x1b[1m${t}\x1b[0m`);
const wait = ms => new Promise(r => setTimeout(r, ms));

const SETTINGS = {
  title: 'چت', agentName: 'پشتیبانی', greeting: 'سلام', placeholder: 'بنویس',
  accent: '#22d3ee', position: 'start', autoOpen: false, autoDelay: 5, starter: [],
  humanHandoff: true, sound: false, offlineNote: '',
  offsetBottom: 18, offsetSide: 18, launcherSize: 62, panelWidth: 384, panelHeight: 620,
  radius: 28, blur: 30, glassOpacity: 62, launcherLabel: '', teaser: false, teaserText: '',
  mobileSheet: true, maximize: true, showFooter: true, theme: 'auto',
  prechat: false, streaming: false, csat: true
};

const dom = new JSDOM('<!DOCTYPE html><html dir="rtl"><head><style>' + CSS + '</style></head><body><div id="pasokhban-live" data-mode="widget"></div></body></html>',
  { url: 'http://e.test/', pretendToBeVisual: true, runScripts: 'dangerously' });
const w = dom.window, d = w.document;
w.ReadableStream = ReadableStream; w.TextEncoder = TextEncoder; w.TextDecoder = TextDecoder;
w.Response = class {
  constructor(b, o) { o = o || {}; this.body = b; this.status = o.status || 200; this.ok = true;
    const raw = o.headers || {}, lower = {}; Object.keys(raw).forEach(k => lower[k.toLowerCase()] = raw[k]);
    this.headers = { get: k => lower[String(k).toLowerCase()] || null }; }
  json() { return Promise.resolve(JSON.parse(this.body)); }
};
w.PASOKHBAN_CHAT = { restUrl: '/wp-json/pasokhban/v1', nonce: 'n', lang: 'fa' };
w.PASOKHBAN_CHAT_SETTINGS = SETTINGS;

const calls = [];
w.__calls = calls;
let handoffMsgId = 555;

w.fetch = (url, opt) => {
  const path = String(url).replace(/^.*\/v1/, '');
  const body = opt.body ? JSON.parse(opt.body) : {};
  calls.push({ path, body });

  if (path.indexOf('/live/handoff') === 0) {
    return Promise.resolve(new w.Response(JSON.stringify({
      mode: 'agent',
      message: { id: handoffMsgId, sender: 'system', content: 'درخواست شما به پشتیبان انسانی منتقل شد. لطفاً کمی صبر کنید.', meta: { note: 'handoff' } },
      note: 'درخواست شما به پشتیبان انسانی منتقل شد. لطفاً کمی صبر کنید.',
      agentOnline: false
    }), { status: 200, headers: { 'Content-Type': 'application/json' } }));
  }
  if (path.indexOf('/live/poll') === 0) {
    // سرور همان پیام سیستمی handoff را برمی‌گرداند (چون در دیتابیس ذخیره شده)
    const after = parseInt((String(url).match(/after=(\d+)/) || [0, 0])[1], 10);
    const msgs = (handoffMsgId > after)
      ? [{ id: handoffMsgId, sender: 'system', content: 'درخواست شما به پشتیبان انسانی منتقل شد. لطفاً کمی صبر کنید.', meta: { note: 'handoff' } }]
      : [];
    return Promise.resolve(new w.Response(JSON.stringify({ messages: msgs, mode: 'agent', status: null, typing: false, agentOnline: false }),
      { status: 200, headers: { 'Content-Type': 'application/json' } }));
  }
  if (path.indexOf('/live/send') === 0) {
    return Promise.resolve(new w.Response(JSON.stringify({
      message: { id: 800, sender: 'visitor', content: body.content, meta: {} },
      mode: 'ai', reply: { id: 801, sender: 'agent', content: 'پاسخ ربات', meta: { via: 'ai' } }
    }), { status: 200, headers: { 'Content-Type': 'application/json' } }));
  }
  let data = { ok: true };
  if (path.indexOf('/live/start') === 0) data = { key: 'a1b2c3d4e5f60718293a4b5c6d7e8f90', mode: 'ai', status: 'open', messages: [], agentOnline: false, settings: SETTINGS };
  return Promise.resolve(new w.Response(JSON.stringify(data), { status: 200, headers: { 'Content-Type': 'application/json' } }));
};

const s = d.createElement('script');
s.textContent = JS;
d.body.appendChild(s);

(async () => {
  await wait(250);
  d.querySelector('.psb-launcher').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
  await wait(350);

  head('۱) چیدمان پیام‌ها در RTL');
  const cs = (sel) => w.getComputedStyle(d.querySelector(sel));

  eq(cs('.psb-msg.agent').alignSelf, 'flex-end', 'پیام ربات align-self: flex-end دارد');
  ok(true, 'در RTL یعنی سمت چپ ✓');

  // پیام کاربر بفرست تا حباب visitor ساخته شود
  const inp = d.querySelector('.psb-input');
  inp.value = 'سلام';
  d.querySelector('.psb-send').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
  await wait(400);

  const vBubble = d.querySelector('.psb-msg.visitor');
  ok(!!vBubble, 'حباب پیام کاربر ساخته شد');
  eq(cs('.psb-msg.visitor').alignSelf, 'flex-start', 'پیام کاربر align-self: flex-start دارد');
  ok(true, 'در RTL یعنی سمت راست ✓');

  ok(cs('.psb-msg.visitor').alignSelf !== cs('.psb-msg.agent').alignSelf, 'دو سمت متفاوت‌اند (قبلاً هر دو یک سمت بودند)');

  // جهت container باید RTL باشد
  eq(w.getComputedStyle(d.getElementById('pasokhban-live')).direction, 'rtl', 'کانتینر RTL است');

  head('۲) پیام handoff دوبار نمایش داده نمی‌شود');
  d.querySelector('#psb-human').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
  await wait(200);

  let sys = Array.from(d.querySelectorAll('.psb-sys')).filter(e => /پشتیبان انسانی/.test(e.textContent));
  eq(sys.length, 1, 'بلافاصله بعد از handoff یک پیام هست');

  // حالا poll اجرا شود — سرور همان پیام را برمی‌گرداند
  d.dispatchEvent(new w.Event('visibilitychange'));
  await wait(300);
  d.dispatchEvent(new w.Event('visibilitychange'));
  await wait(300);

  sys = Array.from(d.querySelectorAll('.psb-sys')).filter(e => /پشتیبان انسانی/.test(e.textContent));
  eq(sys.length, 1, 'بعد از poll هم هنوز یک پیام است (دوبار نشد)');

  console.log('\n' + '─'.repeat(52));
  if (fail === 0) console.log(`\x1b[42;30m همهٔ ${pass} تست پاس شد \x1b[0m`);
  else { console.log(`\x1b[41;97m ${fail} تست شکست خورد \x1b[0m (پاس: ${pass})`); fails.forEach(f => console.log('   • ' + f)); }
  console.log('─'.repeat(52));
  process.exit(fail === 0 ? 0 : 1);
})();
