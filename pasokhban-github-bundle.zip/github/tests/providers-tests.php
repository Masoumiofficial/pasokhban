<?php
/**
 * تست‌های ۲.۹.۰ — پشتیبانی از چند سرویس هوش مصنوعی.
 *
 * هر سرویس قالب درخواست، هدر، قالب پاسخ و قالب استریم متفاوتی دارد. اگر
 * یکی از این چهار مورد برای سرویسی غلط باشد، آن سرویس بی‌صدا کار نمی‌کند
 * و کاربر فقط «پاسخ دریافت نشد» می‌بیند — پس هر چهار مورد جدا سنجیده
 * می‌شود.
 */

require_once __DIR__ . '/wp-stubs.php';

$PASS = 0; $FAIL = 0; $FAILURES = array();

function ok( $cond, $label, $extra = '' ) {
	global $PASS, $FAIL, $FAILURES;
	if ( $cond ) { $PASS++; echo "  \033[32m✓\033[0m {$label}\n"; }
	else { $FAIL++; $FAILURES[] = $label . ( $extra ? " — {$extra}" : '' ); echo "  \033[31m✗\033[0m {$label}" . ( $extra ? "  → {$extra}" : '' ) . "\n"; }
}
function head( $t ) { echo "\n\033[1m{$t}\033[0m\n"; }
function eq( $a, $b, $label ) { ok( $a === $b, $label, 'انتظار ' . var_export( $b, true ) . ' / دریافت ' . var_export( $a, true ) ); }

$BASE = array(
	'ai_provider' => 'gapgpt', 'api_key' => 'sk-TEST',
	'base_url'    => 'https://api.gapgpt.app/v1', 'model' => 'gpt-4o',
	'max_tokens'  => 800, 'temperature' => 0.7,
);
function opts_for( $provider, array $over = array() ) {
	global $BASE;
	$presets = Pasokhban_Providers::presets();
	$base    = isset( $presets[ $provider ]['base_url'] ) ? $presets[ $provider ]['base_url'] : '';
	return array_merge( $BASE, array( 'ai_provider' => $provider, 'base_url' => $base ), $over );
}

$P = 'Pasokhban_Providers';

$msgs = array(
	array( 'role' => 'system',    'content' => 'تو دستیار سایت هستی.' ),
	array( 'role' => 'user',      'content' => 'سلام' ),
	array( 'role' => 'assistant', 'content' => 'در خدمتم' ),
	array( 'role' => 'user',      'content' => 'سفارشم کجاست؟' ),
);

/* ========================================================= */
head( '۱) فهرست سرویس‌ها' );
/* ========================================================= */

$presets = $P::presets();
foreach ( array( 'gapgpt', 'openai', 'gemini', 'anthropic', 'custom' ) as $k ) {
	ok( isset( $presets[ $k ] ), "سرویس «{$k}» ثبت شده" );
	ok( ! empty( $presets[ $k ]['api'] ), "«{$k}» قالب API دارد" );
	ok( ! empty( $presets[ $k ]['label'] ), "«{$k}» برچسب دارد" );
}
eq( $presets['gemini']['api'], 'gemini', 'جمینای قالب مخصوص خودش را دارد' );
eq( $presets['anthropic']['api'], 'anthropic', 'آنتروپیک قالب مخصوص خودش را دارد' );
eq( $presets['openai']['api'], 'openai', 'OpenAI قالب openai دارد' );
eq( $presets['custom']['api'], 'openai', '«دلخواه» هم قالب openai دارد (سازگار)' );
eq( $presets['custom']['base_url'], '', '«دلخواه» آدرس پیش‌فرض ندارد (کاربر باید بگذارد)' );

// سرویس ناشناخته به پیش‌فرض برمی‌گردد
$c = $P::current( array( 'ai_provider' => 'evil-provider', 'base_url' => 'https://x.test' ) );
eq( $c['key'], 'gapgpt', '★ سرویس ناشناخته به پیش‌فرض برمی‌گردد (نه fatal)' );

// آدرس دلخواه کاربر اولویت دارد (مثلاً پروکسی شخصی)
$c = $P::current( array( 'ai_provider' => 'openai', 'base_url' => 'https://my-proxy.test/v1' ) );
eq( $c['base_url'], 'https://my-proxy.test/v1', '★ آدرس دلخواه کاربر بر پیش‌فرض سرویس اولویت دارد' );

$c = $P::current( array( 'ai_provider' => 'gemini', 'base_url' => '' ) );
eq( $c['base_url'], 'https://generativelanguage.googleapis.com/v1beta', 'آدرس خالی → پیش‌فرض سرویس' );

/* ========================================================= */
head( '۲) ساخت درخواست — OpenAI' );
/* ========================================================= */

$o = opts_for( 'openai' );
$r = $P::request( $msgs, $o, false );
ok( ! is_wp_error( $r ), 'درخواست ساخته شد' );
eq( $r['url'], 'https://api.openai.com/v1/chat/completions', 'آدرس OpenAI' );
eq( $r['headers']['Authorization'], 'Bearer sk-TEST', '★ احراز هویت با Bearer' );
$b = json_decode( $r['body'], true );
eq( $b['model'], 'gpt-4o', 'مدل در بدنه' );
eq( count( $b['messages'] ), 4, 'هر ۴ پیام فرستاده شد' );
eq( $b['messages'][0]['role'], 'system', 'نقش system سر جایش است' );
ok( ! isset( $b['stream'] ), 'در حالت غیرجریانی stream فرستاده نمی‌شود' );

$r = $P::request( $msgs, $o, true );
$b = json_decode( $r['body'], true );
eq( $b['stream'], true, 'در حالت جریان stream=true' );
eq( $r['headers']['Accept'], 'text/event-stream', 'Accept درست' );

// gapgpt هم همان قالب است
$r = $P::request( $msgs, opts_for( 'gapgpt' ), false );
eq( $r['url'], 'https://api.gapgpt.app/v1/chat/completions', 'آدرس gapgpt' );

/* ========================================================= */
head( '۳) ساخت درخواست — Gemini' );
/* ========================================================= */

$o = opts_for( 'gemini', array( 'model' => 'gemini-2.5-flash' ) );
$r = $P::request( $msgs, $o, false );
ok( ! is_wp_error( $r ), 'درخواست جمینای ساخته شد', is_wp_error( $r ) ? $r->get_error_message() : '' );
ok( false !== strpos( $r['url'], '/models/gemini-2.5-flash:generateContent' ), '★ مسیر :generateContent با نام مدل', $r['url'] );
ok( false !== strpos( $r['url'], 'key=sk-TEST' ), '★ کلید در query string' );
eq( $r['headers']['x-goog-api-key'], 'sk-TEST', '★ کلید در هدر هم هست (بعضی پروکسی‌ها query را دور می‌اندازند)' );
ok( false === strpos( $r['url'], '/chat/completions' ), '★ مسیر OpenAI استفاده نشده' );

$b = json_decode( $r['body'], true );
ok( ! isset( $b['messages'] ), '★ فیلد messages ندارد (قالب جمینای contents است)' );
ok( isset( $b['contents'] ), 'فیلد contents هست' );
eq( $b['systemInstruction']['parts'][0]['text'], 'تو دستیار سایت هستی.', '★ نقش system به systemInstruction رفت' );
eq( count( $b['contents'] ), 3, 'سه پیام غیرسیستم در contents' );
eq( $b['contents'][0]['role'], 'user', 'نقش user حفظ شد' );
eq( $b['contents'][1]['role'], 'model', '★ نقش assistant به model تبدیل شد' );
eq( $b['contents'][0]['parts'][0]['text'], 'سلام', 'متن داخل parts پیچیده شد' );
eq( $b['generationConfig']['maxOutputTokens'], 800, 'maxOutputTokens به‌جای max_tokens' );
ok( isset( $b['generationConfig']['temperature'] ), 'temperature در generationConfig' );

// حالت جریان
$r = $P::request( $msgs, $o, true );
ok( false !== strpos( $r['url'], ':streamGenerateContent?alt=sse' ), '★ مسیر استریم جمینای :streamGenerateContent?alt=sse' );

// تاریخچهٔ خالی
$r = $P::request( array( array( 'role' => 'system', 'content' => 'x' ) ), $o, false );
ok( is_wp_error( $r ), '★ جمینای با تاریخچهٔ خالی خطا می‌دهد (نه درخواست بی‌محتوا)' );

/* ========================================================= */
head( '۴) ساخت درخواست — Anthropic' );
/* ========================================================= */

$o = opts_for( 'anthropic', array( 'model' => 'claude-sonnet-4-5' ) );
$r = $P::request( $msgs, $o, false );
ok( ! is_wp_error( $r ), 'درخواست آنتروپیک ساخته شد' );
eq( $r['url'], 'https://api.anthropic.com/v1/messages', '★ مسیر /messages' );
eq( $r['headers']['x-api-key'], 'sk-TEST', '★ احراز هویت با x-api-key (نه Bearer)' );
ok( ! isset( $r['headers']['Authorization'] ), '★ هدر Authorization ندارد' );
eq( $r['headers']['anthropic-version'], '2023-06-01', 'هدر anthropic-version' );

$b = json_decode( $r['body'], true );
eq( $b['system'], 'تو دستیار سایت هستی.', '★ system یک رشتهٔ سطح‌بالاست، نه پیام' );
ok( ! isset( $b['systemInstruction'] ), 'فیلد جمینای استفاده نشده' );
eq( count( $b['messages'] ), 3, 'سه پیام غیرسیستم' );
foreach ( $b['messages'] as $m ) {
	ok( 'system' !== $m['role'], '★ نقش system داخل messages نیست (آنتروپیک رد می‌کند)' );
}
eq( $b['model'], 'claude-sonnet-4-5', 'مدل در بدنه' );
eq( $b['max_tokens'], 800, '★ max_tokens فرستاده شد (آنتروپیک اجباری می‌داند)' );
eq( $b['stream'], false, 'stream=false در حالت غیرجریانی' );

$r = $P::request( $msgs, $o, true );
$b = json_decode( $r['body'], true );
eq( $b['stream'], true, 'stream=true در حالت جریان' );

// max_tokens صفر نباید برود
$r = $P::request( $msgs, opts_for( 'anthropic', array( 'max_tokens' => 0 ) ), false );
$b = json_decode( $r['body'], true );
ok( $b['max_tokens'] >= 1, '★ max_tokens صفر به حداقل ۱ تبدیل شد (وگرنه آنتروپیک ۴۰۰ می‌دهد)' );

/* ========================================================= */
head( '۵) خطاهای ورودی' );
/* ========================================================= */

ok( is_wp_error( $P::request( $msgs, array( 'ai_provider' => 'openai', 'api_key' => '', 'model' => 'gpt-4o' ), false ) ), '★ بدون کلید خطا می‌دهد' );
ok( is_wp_error( $P::request( $msgs, array( 'ai_provider' => 'openai', 'api_key' => 'sk', 'model' => '' ), false ) ), '★ بدون مدل خطا می‌دهد' );

/* ========================================================= */
head( '۶) تجزیهٔ پاسخ' );
/* ========================================================= */

// OpenAI
$resp = array( 'choices' => array( array( 'message' => array( 'content' => 'سلام دوست من' ) ) ) );
eq( $P::parse( opts_for( 'openai' ), $resp ), 'سلام دوست من', 'پاسخ OpenAI' );

// Gemini — چند part
$resp = array( 'candidates' => array( array( 'content' => array( 'parts' => array(
	array( 'text' => 'سلام ' ), array( 'text' => 'دوست من' ),
) ) ) ) );
eq( $P::parse( opts_for( 'gemini' ), $resp ), 'سلام دوست من', '★ پاسخ جمینای از چند part به هم چسبید' );
eq( $P::parse( opts_for( 'gemini' ), array( 'candidates' => array() ) ), '', 'پاسخ خالی جمینای → رشتهٔ خالی' );
eq( $P::parse( opts_for( 'gemini' ), array() ), '', 'پاسخ بدون candidates → رشتهٔ خالی' );

// Anthropic
$resp = array( 'content' => array( array( 'type' => 'text', 'text' => 'سلام ' ), array( 'type' => 'text', 'text' => 'دوست من' ) ) );
eq( $P::parse( opts_for( 'anthropic' ), $resp ), 'سلام دوست من', '★ پاسخ آنتروپیک از چند بلوک به هم چسبید' );

// ★ قالب اشتباه نباید fatal بدهد
eq( $P::parse( opts_for( 'gemini' ), array( 'choices' => array() ) ), '', 'پاسخ با قالب OpenAI در جمینای → خالی، نه fatal' );
eq( $P::parse( opts_for( 'anthropic' ), array( 'choices' => array() ) ), '', 'پاسخ با قالب OpenAI در آنتروپیک → خالی، نه fatal' );

// خطاها
eq( $P::parse_error( opts_for( 'openai' ), array( 'error' => array( 'message' => 'bad key' ) ) ), 'bad key', 'خطای OpenAI' );
eq( $P::parse_error( opts_for( 'gemini' ), array( 'error' => array( 'message' => 'API key not valid' ) ) ), 'API key not valid', 'خطای جمینای' );
eq( $P::parse_error( opts_for( 'anthropic' ), array( 'error' => array( 'message' => 'invalid x-api-key' ) ) ), 'invalid x-api-key', 'خطای آنتروپیک' );
eq( $P::parse_error( opts_for( 'openai' ), array( 'error' => 'string error' ) ), 'string error', 'خطای رشته‌ای' );
eq( $P::parse_error( opts_for( 'openai' ), array( 'ok' => true ) ), '', 'بدون خطا → رشتهٔ خالی' );

/* ========================================================= */
head( '۷) توکن استریم' );
/* ========================================================= */

// OpenAI
eq( $P::stream_token( opts_for( 'openai' ), array( 'choices' => array( array( 'delta' => array( 'content' => 'سل' ) ) ) ) ), 'سل', 'توکن OpenAI از delta.content' );
eq( $P::stream_token( opts_for( 'openai' ), array( 'choices' => array( array( 'message' => array( 'content' => 'کل' ) ) ) ) ), 'کل', 'fallback به message.content' );

// Gemini
eq( $P::stream_token( opts_for( 'gemini' ), array( 'candidates' => array( array( 'content' => array( 'parts' => array( array( 'text' => 'سل' ) ) ) ) ) ) ), 'سل', '★ توکن جمینای از candidates.parts' );
eq( $P::stream_token( opts_for( 'gemini' ), array( 'candidates' => array() ) ), '', 'بدون candidates → خالی' );

// Anthropic
eq( $P::stream_token( opts_for( 'anthropic' ), array( 'delta' => array( 'text' => 'سل' ) ) ), 'سل', '★ توکن آنتروپیک از delta.text' );
eq( $P::stream_token( opts_for( 'anthropic' ), array( 'content_block' => array( 'text' => 'کل' ) ) ), 'کل', 'fallback به content_block' );

// پایان جریان
eq( $P::stream_done( opts_for( 'openai' ), '[DONE]' ), true, '★ پایان OpenAI با [DONE]' );
eq( $P::stream_done( opts_for( 'openai' ), '{"choices":[]}' ), false, 'رویداد معمولی پایان نیست' );
eq( $P::stream_done( opts_for( 'anthropic' ), 'event: message_stop' ), true, '★ پایان آنتروپیک با message_stop' );
eq( $P::stream_done( opts_for( 'gemini' ), '{"candidates":[{"finishReason":"STOP"}]}' ), true, '★ پایان جمینای با finishReason' );
eq( $P::stream_done( opts_for( 'gemini' ), '{"candidates":[{"content":{"parts":[]}}]}' ), false, 'رویداد معمولی جمینای پایان نیست' );

/* ========================================================= */
head( '۸) تولید پاسخ end-to-end با هر سرویس' );
/* ========================================================= */

$api = Pasokhban_API::instance();
$rp  = new ReflectionProperty( 'Pasokhban_Settings', 'options' );
$rp->setAccessible( true );

// پاسخ ساختگی OpenAI
update_option( 'pasokhban_options', opts_for( 'openai', array( 'live_history' => 20, 'knowledge' => 0 ) ) );
$rp->setValue( Pasokhban_Settings::instance(), get_option( 'pasokhban_options' ) );

$GLOBALS['wp_remote_response'] = array(
	'response' => array( 'code' => 200 ),
	'body'     => json_encode( array( 'choices' => array( array( 'message' => array( 'content' => 'پاسخ اوپن‌ای‌آی' ) ) ) ) ),
);
$res = $api->generate_reply( array( array( 'role' => 'user', 'content' => 'سلام' ) ), 'fa', array() );
ok( ! is_wp_error( $res ), 'OpenAI پاسخ داد', is_wp_error( $res ) ? $res->get_error_message() : '' );
eq( $res['content'], 'پاسخ اوپن‌ای‌آی', 'متن درست' );
eq( $res['provider'], 'openai', 'نام سرویس در پاسخ هست' );

// پاسخ ساختگی Gemini
update_option( 'pasokhban_options', opts_for( 'gemini', array( 'model' => 'gemini-2.5-flash', 'live_history' => 20, 'knowledge' => 0 ) ) );
$rp->setValue( Pasokhban_Settings::instance(), get_option( 'pasokhban_options' ) );

$GLOBALS['wp_remote_response'] = array(
	'response' => array( 'code' => 200 ),
	'body'     => json_encode( array( 'candidates' => array( array( 'content' => array( 'parts' => array( array( 'text' => 'پاسخ جمینای' ) ) ) ) ) ) ),
);
$res = $api->generate_reply( array( array( 'role' => 'user', 'content' => 'سلام' ) ), 'fa', array() );
ok( ! is_wp_error( $res ), '★ Gemini پاسخ داد', is_wp_error( $res ) ? $res->get_error_message() : '' );
eq( $res['content'], 'پاسخ جمینای', 'متن جمینای درست تجزیه شد' );
eq( $res['provider'], 'gemini', 'نام سرویس جمینای' );
$last = end( $GLOBALS['wp_remote_calls'] );
ok( false !== strpos( $last['url'], 'generativelanguage.googleapis.com' ), '★ درخواست واقعاً به جمینای رفت', $last['url'] );

// پاسخ ساختگی Anthropic
update_option( 'pasokhban_options', opts_for( 'anthropic', array( 'model' => 'claude-sonnet-4-5', 'live_history' => 20, 'knowledge' => 0 ) ) );
$rp->setValue( Pasokhban_Settings::instance(), get_option( 'pasokhban_options' ) );

$GLOBALS['wp_remote_response'] = array(
	'response' => array( 'code' => 200 ),
	'body'     => json_encode( array( 'content' => array( array( 'type' => 'text', 'text' => 'پاسخ آنتروپیک' ) ) ) ),
);
$res = $api->generate_reply( array( array( 'role' => 'user', 'content' => 'سلام' ) ), 'fa', array() );
ok( ! is_wp_error( $res ), '★ Anthropic پاسخ داد', is_wp_error( $res ) ? $res->get_error_message() : '' );
eq( $res['content'], 'پاسخ آنتروپیک', 'متن آنتروپیک درست تجزیه شد' );
$last = end( $GLOBALS['wp_remote_calls'] );
ok( false !== strpos( $last['url'], 'api.anthropic.com/v1/messages' ), '★ درخواست واقعاً به آنتروپیک رفت', $last['url'] );

// خطای سرویس باید پیام سرویس را بدهد، نه پیام کلی
$GLOBALS['wp_remote_response'] = array(
	'response' => array( 'code' => 401 ),
	'body'     => json_encode( array( 'error' => array( 'message' => 'authentication_error: invalid x-api-key' ) ) ),
);
$res = $api->generate_reply( array( array( 'role' => 'user', 'content' => 'سلام' ) ), 'fa', array() );
ok( is_wp_error( $res ), 'خطای آنتروپیک WP_Error می‌دهد' );
ok( false !== strpos( $res->get_error_message(), 'invalid x-api-key' ), '★ پیام خطای خودِ سرویس به کاربر می‌رسد', $res->get_error_message() );

// پاسخ غیر JSON
$GLOBALS['wp_remote_response'] = array( 'response' => array( 'code' => 502 ), 'body' => '<html>Bad Gateway</html>' );
$res = $api->generate_reply( array( array( 'role' => 'user', 'content' => 'سلام' ) ), 'fa', array() );
ok( is_wp_error( $res ), 'پاسخ غیر JSON خطا می‌دهد' );
ok( false !== strpos( $res->get_error_message(), 'JSON نبود' ), 'پیام روشن است', $res->get_error_message() );

/* ========================================================= */
head( '۹) تنظیمات' );
/* ========================================================= */

$s = Pasokhban_Settings::instance();
$d = $s->defaults();
eq( $d['ai_provider'], 'gapgpt', '★ سرویس پیش‌فرض gapgpt است (رفتار قبلی حفظ می‌شود)' );

$out = $s->sanitize( array( 'ai_provider' => 'gemini' ) );
eq( $out['ai_provider'], 'gemini', 'سرویس معتبر پذیرفته شد' );
$out = $s->sanitize( array( 'ai_provider' => 'evil' ) );
eq( $out['ai_provider'], 'gapgpt', '★ سرویس ناشناخته به پیش‌فرض برمی‌گردد' );

// صفحهٔ تنظیمات
update_option( 'pasokhban_options', opts_for( 'gemini', array( 'model' => 'gemini-2.5-flash' ) ) );
$rp->setValue( $s, get_option( 'pasokhban_options' ) );
Pasokhban_DB::install();
ob_start();
$s->render_page();
$h = ob_get_clean();

ok( false !== strpos( $h, 'pasokhban_options[ai_provider]' ), '★ انتخاب سرویس در فرم هست' );
foreach ( array( 'gapgpt', 'openai', 'gemini', 'anthropic', 'custom' ) as $k ) {
	ok( false !== strpos( $h, 'value="' . $k . '"' ), "گزینهٔ «{$k}» در سلکت هست" );
}
ok( false !== strpos( $h, 'value="gemini" ' ) || false !== strpos( $h, 'value="gemini"' ), 'سرویس انتخاب‌شده رندر شد' );
ok( false !== strpos( $h, 'pasokhban_test_provider' ), 'اکشن آزمایش اتصال هست' );
ok( false !== strpos( $h, 'psb-prov-test-form' ), 'فرم آزمایش اتصال هست' );
ok( false !== strpos( $h, 'gemini-2.5-flash' ), 'مدل جمینای در datalist هست' );
ok( false !== strpos( $h, 'claude-sonnet-4-5' ), 'مدل آنتروپیک در datalist هست' );
ok( false !== strpos( $h, 'آدرس پایهٔ API' ), 'هشدار تغییر آدرس پایه هست' );

// فرم تو‌در‌تو نشد
$nc = preg_replace( '/<!--.*?-->/s', '', $h );
eq( substr_count( $nc, '<section' ), substr_count( $nc, '</section>' ), '<section> balanced است' );
eq( preg_match_all( '/<form\b/', $nc ), preg_match_all( '/<\/form>/', $nc ), '<form> balanced است' );

/* ========================================================= */
head( '۱۰) مدل‌های پیشنهادی' );
/* ========================================================= */

$models = $P::models_for( opts_for( 'gemini' ) );
ok( in_array( 'gemini-2.5-flash', $models, true ), 'مدل جمینای در فهرست پیشنهادی' );
$models = $P::models_for( opts_for( 'anthropic' ) );
ok( in_array( 'claude-sonnet-4-5', $models, true ), 'مدل آنتروپیک در فهرست پیشنهادی' );
eq( $P::models_for( opts_for( 'custom' ) ), array(), '«دلخواه» فهرست مدل ندارد' );

echo "\n" . str_repeat( '─', 52 ) . "\n";
if ( 0 === $FAIL ) {
	echo "\033[42;30m همهٔ {$PASS} تست چندسرویسی پاس شد \033[0m\n";
} else {
	echo "\033[41;97m {$FAIL} تست شکست خورد \033[0m (پاس: {$PASS})\n";
	foreach ( $FAILURES as $f ) { echo "   • {$f}\n"; }
}
echo str_repeat( '─', 52 ) . "\n";
exit( 0 === $FAIL ? 0 : 1 );
