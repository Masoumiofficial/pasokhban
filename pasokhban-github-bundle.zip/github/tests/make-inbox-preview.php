<?php
/**
 * ساخت پیش‌نمایش اینباکس از کد واقعی PHP پلاگین.
 *
 * با دادهٔ نمونهٔ متنوع (خوانده‌نشده، اپراتور، بسته، واگذارشده، ضمیمه،
 * پیام در روزهای مختلف) تا همهٔ حالت‌های بصری دیده شوند.
 */

require_once __DIR__ . '/wp-stubs.php';

update_option( 'pasokhban_options', array(
	'api_key'       => 'sk-demo',
	'live_enabled'  => 1,
	'rate_limit'    => 10,
	'live_history'  => 20,
	'canned'        => "سلام! خوش آمدید 👋|خوش‌آمد\nبله، همکاران ما به‌زودی تماس می‌گیرند.|اطلاع‌رسانی تماس",
	'copilot_enabled' => 1,
	'copilot_summary' => 1,
	'copilot_tone'  => 'friendly',
	'sms_enabled'   => 0,
	'bale_enabled'  => 0,
) );
$rp = new ReflectionProperty( 'Pasokhban_Settings', 'options' );
$rp->setAccessible( true );
$rp->setValue( Pasokhban_Settings::instance(), get_option( 'pasokhban_options' ) );

Pasokhban_DB::install();
Pasokhban_Team::install();

// اپراتورهای نمونه برای select واگذاری
$GLOBALS['wp_users'] = array(
	array( 'ID' => 1, 'display_name' => 'مدیر سایت', 'user_login' => 'admin', 'caps' => array( 'manage_options', 'pasokhban_reply' ) ),
	array( 'ID' => 7, 'display_name' => 'سارا احمدی', 'user_login' => 'sara', 'caps' => array( 'pasokhban_reply' ) ),
	array( 'ID' => 8, 'display_name' => 'علی رضایی', 'user_login' => 'ali', 'caps' => array( 'pasokhban_reply' ) ),
);
$GLOBALS['wp_current_user'] = (object) array( 'ID' => 1, 'display_name' => 'مدیر سایت', 'user_login' => 'admin' );

$GLOBALS['wp_remote_response'] = array(
	'response' => array( 'code' => 200 ),
	'body'     => json_encode( array( 'choices' => array( array( 'message' => array( 'content' => 'پاسخ دستیار هوشمند' ) ) ) ) ),
);

$lc = Pasokhban_LiveChat::instance();

$people = array(
	array( 'name' => 'مریم', 'family' => 'کریمی', 'phone' => '09121234567', 'email' => 'maryam@example.test', 'q' => 'سلام، سفارش شمارهٔ ۱۰۰۱ من کی می‌رسه؟' ),
	array( 'name' => 'حسن', 'family' => 'موسوی', 'phone' => '', 'email' => 'hasan@example.test', 'q' => 'آیا این محصول گارانتی دارد؟' ),
	array( 'name' => 'نگار', 'family' => 'شریفی', 'phone' => '09351112233', 'email' => '', 'q' => 'می‌خواستم با یک پشتیبان صحبت کنم' ),
	array( 'name' => 'رضا', 'family' => 'نوری', 'phone' => '', 'email' => 'reza@example.test', 'q' => 'قیمت عمده‌فروشی چطور محاسبه می‌شود؟' ),
	array( 'name' => 'سپیده', 'family' => 'صادقی', 'phone' => '09199876543', 'email' => 'sepideh@example.test', 'q' => 'مشکل پرداخت داشتم، تراکنش ناموفق بود' ),
);

$ids = array();
foreach ( $people as $i => $p ) {
	$r   = $lc->handle_start( new WP_REST_Request( array(), array(
		'lang' => 'fa', 'name' => $p['name'], 'family' => $p['family'],
		'phone' => $p['phone'], 'email' => $p['email'],
		'current_url' => 'https://example.test/product/sample-' . ( $i + 1 ),
	) ) );
	$ids[] = (int) Pasokhban_DB::get_session_by_key( $r['key'] )->id;
	$lc->handle_send( new WP_REST_Request( array(), array( 'key' => $r['key'], 'content' => $p['q'], 'lang' => 'fa' ) ) );
}

// حالت‌های متنوع
Pasokhban_DB::update_session( $ids[0], array( 'unread_agent' => 3, 'mode' => 'agent' ) );
Pasokhban_DB::assign_session( $ids[0], 7 );
Pasokhban_DB::update_session( $ids[1], array( 'unread_agent' => 1 ) );
Pasokhban_DB::update_session( $ids[2], array( 'mode' => 'agent', 'status' => 'closed' ) );
Pasokhban_DB::assign_session( $ids[2], 8 );

// پیام‌های چندروزه برای جداکنندهٔ روز
Pasokhban_DB::add_message( $ids[0], 'visitor', 'سلام، وقتتون بخیر' );
Pasokhban_DB::add_message( $ids[0], 'agent', 'سلام مریم جان، در خدمتم 🌸', array( 'via' => 'ai' ) );
Pasokhban_DB::add_message( $ids[0], 'visitor', 'سفارشم رو دیروز ثبت کردم ولی هنوز وضعیتش تغییر نکرده' );
Pasokhban_DB::add_message( $ids[0], 'system', 'درخواست شما به پشتیبان انسانی منتقل شد.', array( 'note' => 'handoff' ) );
Pasokhban_DB::add_message( $ids[0], 'agent', 'بررسی کردم؛ سفارش شما امروز ارسال می‌شود و کد رهگیری پیامک خواهد شد.', array(
	'via'       => 'bale',
	'bale_from' => 'سارا احمدی',
) );
Pasokhban_DB::add_message( $ids[0], 'visitor', 'ممنون از پیگیریتون 🙏' );

// پیام دارای ضمیمه
Pasokhban_DB::add_message( $ids[0], 'visitor', 'این هم فاکتور خریدم', array(
	'attachments' => array(
		array( 'name' => 'فاکتور-۱۰۰۱.pdf', 'url' => '#', 'mime' => 'application/pdf', 'size' => 245760 ),
		array( 'name' => 'اسکرین‌شات.png', 'url' => 'data:image/svg+xml;utf8,' . rawurlencode( '<svg xmlns="http://www.w3.org/2000/svg" width="200" height="140"><rect width="200" height="140" fill="#22d3ee"/><text x="100" y="75" font-size="14" text-anchor="middle" fill="#06283a">اسکرین‌شات</text></svg>' ), 'mime' => 'image/png', 'size' => 88432 ),
	),
) );

ob_start();
Pasokhban_Inbox::render();
$body = ob_get_clean();

$css  = file_get_contents( PASOKHBAN_PLUGIN_DIR . '/assets/css/pasokhban-inbox.css' );
$js   = file_get_contents( PASOKHBAN_PLUGIN_DIR . '/assets/js/pasokhban-inbox.js' );
$boot = 'window.PASOKHBAN_INBOX = ' . json_encode( array(
	'restUrl' => '/wp-json/pasokhban/v1',
	'nonce'   => 'demo',
	'agent'   => 'مدیر سایت',
	'i18n'    => array(
		'reply' => 'پاسخ بده…', 'sending' => '…', 'send' => 'ارسال',
		'noSession' => 'مکالمه‌ای نیست', 'errLoad' => 'خطا', 'errSend' => 'خطا', 'errOpen' => 'خطا',
		'you' => 'شما', 'visitor' => 'بازدیدکننده', 'ai' => 'هوش مصنوعی', 'system' => 'سیستم',
		'sources' => 'منابع:', 'confirm' => 'حذف؟', 'openChat' => 'بستن گفتگو', 'reopen' => 'بازکردن گفتگو',
		'today' => 'امروز', 'yesterday' => 'دیروز', 'back' => 'بازگشت به لیست',
	),
), JSON_UNESCAPED_UNICODE ) . ';';

$shell = '
body{margin:0;background:#eef1f6;font-family:"Vazirmatn",-apple-system,BlinkMacSystemFont,"Segoe UI",Tahoma,sans-serif}
.demo-note{max-width:1400px;margin:0 auto;padding:12px 20px;color:#64748b;font-size:12px;line-height:1.9}
.wrap{margin:0 auto;padding:16px 20px}
';

$html = '<!DOCTYPE html><html dir="rtl" lang="fa"><head><meta charset="utf-8">'
	. '<meta name="viewport" content="width=device-width, initial-scale=1">'
	. '<title>پیش‌نمایش اینباکس — پاسخ‌بان ۲.۷.۰</title>'
	. '<style>' . $css . $shell . '</style></head><body>'
	. '<div class="demo-note">پیش‌نمایش با دادهٔ نمونه — طراحی ۲.۷.۰. پنجره را باریک کن تا حالت موبایل را ببینی.</div>'
	. $body
	. '<script>' . $boot . $js . '</script>'
	. '</body></html>';

file_put_contents( PASOKHBAN_TESTS_DIR . '/../preview/inbox.html', $html );
echo 'preview/inbox.html نوشته شد — ' . strlen( $html ) . " بایت\n";
