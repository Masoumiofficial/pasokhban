/**
 * تست منابع: دکمهٔ جمع‌شونده + پاپ‌آپ، و نوتیفیکیشن.
 */
const fs = require('fs');
const { JSDOM } = require('jsdom');

const JS = fs.readFileSync(__dirname + '/../plugin/assets/js/pasokhban-chat.js', 'utf8');

let pass = 0, fail = 0; const fails = [];
const ok = (c, l, x) => { if (c) { pass++; console.log(`  \x1b[32m✓\x1b[0m ${l}`); } else { fail++; fails.push(l + (x ? ' — ' + x : '')); console.log(`  \x1b[31m✗\x1b[0m ${l}` + (x ? '  → ' + x : '')); } };
const eq = (a, b, l) => ok(JSON.stringify(a) === JSON.stringify(b), l, `انتظار ${JSON.stringify(b)} / دریافت ${JSON.stringify(a)}`);
const head = t => console.log(`\n\x1b[1m${t}\x1b[0m`);
const wait = ms => new Promise(r => setTimeout(r, ms));

const SRCS = [
  { title: 'خدمات طراحی سایت وردپرس', url: 'https://example.ir/services' },
  { title: 'تعرفهٔ طراحی', url: 'https://example.ir/pricing' },
  { title: 'دربارهٔ ما', url: 'https://www.example.ir/about' }
];

const SETTINGS = {
  title: 'چت', agentName: 'پشتیبانی', greeting: 'سلام', placeholder: 'بنویس',
  accent: '#22d3ee', position: 'start', autoOpen: false, autoDelay: 5, starter: [],
  humanHandoff: true, sound: false, offlineNote: '',
  offsetBottom: 18, offsetSide: 18, launcherSize: 62, panelWidth: 384, panelHeight: 620,
  radius: 28, blur: 30, glassOpacity: 62, launcherLabel: '', teaser: false, teaserText: '',
  mobileSheet: true, maximize: true, showFooter: true, theme: 'auto',
  prechat: false, streaming: false, csat: true
};

const dom = new JSDOM('<!DOCTYPE html><html><body><div id="pasokhban-live" data-mode="widget"></div></body></html>',
  { url: 'http://e.test/', pretendToBeVisual: true, runScripts: 'dangerously' });
const w = dom.window, d = w.document;

w.Response = class {
  constructor(b, o) { o = o || {}; this.body = b; this.status = o.status || 200; this.ok = true;
    const raw = o.headers || {}, lower = {}; Object.keys(raw).forEach(k => lower[k.toLowerCase()] = raw[k]);
    this.headers = { get: k => lower[String(k).toLowerCase()] || null }; }
  json() { return Promise.resolve(JSON.parse(this.body)); }
};
w.PASOKHBAN_CHAT = { restUrl: '/wp-json/pasokhban/v1', nonce: 'n', lang: 'fa' };
w.PASOKHBAN_CHAT_SETTINGS = SETTINGS;

// شمارندهٔ پخش صدا
let pingCount = 0;
const RealAC = w.AudioContext;

w.fetch = (url, opt) => {
  const path = String(url).replace(/^.*\/v1/, '');
  const body = opt.body ? JSON.parse(opt.body) : {};
  let data = { ok: true };
  if (path.indexOf('/live/start') === 0) data = { key: 'a1b2c3d4e5f60718293a4b5c6d7e8f90', mode: 'ai', status: 'open', messages: [], agentOnline: false, settings: SETTINGS };
  if (path.indexOf('/live/poll') === 0) data = { messages: [], mode: 'ai', status: null, typing: false, agentOnline: false };
  if (path.indexOf('/live/send') === 0) {
    data = {
      message: { id: 800, sender: 'visitor', content: body.content, meta: {}, time: new Date().toISOString() },
      mode: 'ai',
      reply: { id: 801, sender: 'agent', content: 'پاسخ با منابع', meta: { via: 'ai', sources: SRCS }, time: new Date().toISOString() }
    };
  }
  return Promise.resolve(new w.Response(JSON.stringify(data), { status: 200, headers: { 'Content-Type': 'application/json' } }));
};

const s = d.createElement('script');
s.textContent = JS;
d.body.appendChild(s);

(async () => {
  await wait(250);
  d.querySelector('.psb-launcher').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
  await wait(300);

  head('۱) منابع پشت دکمه جمع می‌شوند');
  const inp = d.querySelector('.psb-input');
  inp.value = 'قیمت چنده؟';
  d.querySelector('.psb-send').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
  await wait(300);

  const bubble = Array.from(d.querySelectorAll('.psb-msg.agent')).filter(b => b.textContent.indexOf('پاسخ با منابع') >= 0)[0];
  ok(!!bubble, 'حباب پاسخ رندر شد');

  const btn = bubble.querySelector('.psb-srcbtn');
  ok(!!btn, 'دکمهٔ «مشاهدهٔ منابع» هست');
  ok(!!btn && /مشاهدهٔ منابع/.test(btn.textContent), 'برچسب دکمه درست است', btn ? btn.textContent : '');
  eq(btn ? btn.querySelector('.psb-srcbtn-n').textContent : null, '3', 'تعداد منابع روی دکمه');

  const pop = bubble.querySelector('.psb-srcpop');
  ok(!!pop, 'پاپ‌آپ وجود دارد');
  eq(pop ? pop.hidden : null, true, 'پاپ‌آپ در ابتدا بسته است');

  // منابع به‌صورت فهرست بلند زیر پاسخ نیستند
  const inlineLinks = bubble.querySelectorAll(':scope > .psb-srcs a');
  eq(inlineLinks.length, 0, 'منابع به‌صورت فهرست باز زیر پاسخ نیستند');

  head('۲) پاپ‌آپ باز و بسته می‌شود');
  btn.dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
  await wait(50);
  eq(pop.hidden, false, 'با کلیک باز شد');
  eq(btn.getAttribute('aria-expanded'), 'true', 'aria-expanded درست است');
  eq(pop.querySelectorAll('.psb-srcpop-list a').length, 3, 'هر سه منبع در پاپ‌آپ هست');

  const first = pop.querySelector('.psb-srcpop-list a');
  eq(first.getAttribute('href'), 'https://example.ir/services', 'لینک منبع درست است');
  eq(first.getAttribute('rel'), 'noopener nofollow', 'rel درست است');
  ok(/خدمات طراحی/.test(first.querySelector('.psb-srcpop-t').textContent), 'عنوان منبع نمایش داده شد');
  eq(first.querySelector('.psb-srcpop-u').textContent, 'example.ir', 'نام دامنه بدون www نمایش داده شد');

  pop.querySelector('.psb-srcpop-x').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
  await wait(50);
  eq(pop.hidden, true, 'با دکمهٔ بستن، پاپ‌آپ بسته شد');

  btn.dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
  await wait(30);
  eq(pop.hidden, false, 'دوباره باز شد');
  d.dispatchEvent(new w.KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
  await wait(30);
  eq(pop.hidden, true, 'با Escape بسته شد');
  ok(d.getElementById('pasokhban-live').classList.contains('is-open'), 'Escape اول پاپ‌آپ را بست، نه کل پنل را');

  head('۳) نوتیفیکیشن: پاسخ AI به سؤال خودت صدا نمی‌دهد');
  // صدا باید غیرفعال باشد چون settings.sound === false؛ برای آزمون واقعی
  // آن را روشن می‌کنیم و AudioContext را می‌شماریم
  SETTINGS.sound = true;
  let acCreated = 0;
  w.AudioContext = function () {
    acCreated++;
    return {
      currentTime: 0, destination: {},
      createOscillator: () => ({ type: '', frequency: { setValueAtTime() {}, exponentialRampToValueAtTime() {} }, connect() {}, start() {}, stop() {} }),
      createGain: () => ({ gain: { setValueAtTime() {}, exponentialRampToValueAtTime() {} }, connect() {} })
    };
  };
  try { localStorage.setItem('pasokhban_live_muted', '0'); } catch (e) {}

  inp.value = 'سؤال دوم';
  d.querySelector('.psb-send').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
  await wait(300);
  eq(acCreated, 0, 'برای پاسخ AI (پنل باز) صدا پخش نشد');

  console.log('\n' + '─'.repeat(52));
  if (fail === 0) console.log(`\x1b[42;30m همهٔ ${pass} تست منابع/نوتیفیکیشن پاس شد \x1b[0m`);
  else { console.log(`\x1b[41;97m ${fail} تست شکست خورد \x1b[0m (پاس: ${pass})`); fails.forEach(f => console.log('   • ' + f)); }
  console.log('─'.repeat(52));
  process.exit(fail === 0 ? 0 : 1);
})();
