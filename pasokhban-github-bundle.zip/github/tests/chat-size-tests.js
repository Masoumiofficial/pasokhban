/**
 * تست اندازه و چیدمان پنل چت از سمت کاربر.
 *
 * رگرسیون ۲.۹.۱: در ۲.۸.۰ یک بلوک @supports بدون media query اضافه شد که
 * ارتفاع پنل را روی ۹۲dvh می‌گذاشت. چون JS کلاس .sheet را بر اساس
 * «تنظیم» اضافه می‌کند نه «عرض صفحه»، آن بلوک در دسکتاپ هم اعمال می‌شد
 * و پنل تقریباً تمام‌صفحه می‌شد.
 *
 * این تست دو کار می‌کند:
 *   ۱) تحلیل ایستا: هیچ بلوک @supports یا قانون .sheet که بعدِ پنل را
 *      تعیین می‌کند نباید بیرون media query باشد.
 *   ۲) اندازه‌گیری واقعی در jsdom در عرض دسکتاپ و موبایل.
 */
const fs = require('fs');
const { JSDOM } = require('jsdom');

const CSS = fs.readFileSync(__dirname + '/../plugin/assets/css/pasokhban-chat.css', 'utf8');
const JS  = fs.readFileSync(__dirname + '/../plugin/assets/js/pasokhban-chat.js', 'utf8');

let pass = 0, fail = 0; const fails = [];
const ok = (c, l, x) => { if (c) { pass++; console.log(`  \x1b[32m✓\x1b[0m ${l}`); } else { fail++; fails.push(l + (x ? ' — ' + x : '')); console.log(`  \x1b[31m✗\x1b[0m ${l}` + (x ? '  → ' + x : '')); } };
const eq = (a, b, l) => ok(a === b, l, `انتظار ${JSON.stringify(b)} / دریافت ${JSON.stringify(a)}`);
const head = t => console.log(`\n\x1b[1m${t}\x1b[0m`);

/* ========================================================= */
head('۱) تحلیل ایستا: نشت قوانین به دسکتاپ');
/* ========================================================= */

/**
 * پیمایش CSS و برگرداندن اینکه هر قانون داخل کدام media/supports است.
 * یک پیمایش سادهٔ آکولادی — برای CSS دست‌نویس خودمان کافی است.
 */
function walkRules(css) {
  const out = [];
  let depth = 0;
  const stack = [];
  let buf = '';
  for (let i = 0; i < css.length; i++) {
    const ch = css[i];
    if (ch === '{') {
      const sel = buf.trim();
      buf = '';
      stack.push(sel);
      depth++;
    } else if (ch === '}') {
      buf = '';
      stack.pop();
      depth--;
    } else if (ch === ';') {
      buf = '';
    } else {
      buf += ch;
    }
    if (ch === '{') {
      out.push({ path: stack.slice(), i });
    }
  }
  return out;
}

/** آیا این قانون داخل یک @media با max-width است؟ */
function insideWidthMedia(path) {
  return path.some(p => /@media/.test(p) && /max-width/.test(p));
}
function insideAnySupports(path) {
  return path.some(p => /@supports/.test(p));
}

const rules = walkRules(CSS);

// ۱) هیچ بلوک @supports که بعد/اندازهٔ پنل را تعیین می‌کند نباید
//    بیرون یک media query باشد
const leaking = rules.filter(r => {
  const sel = r.path[r.path.length - 1] || '';
  const parent = r.path.slice(0, -1);
  const touchesPanel = /\.psb-panel\b/.test(sel);
  const inSupports = insideAnySupports(parent);
  const inWidth = insideWidthMedia(parent);
  return touchesPanel && inSupports && !inWidth;
});
eq(leaking.length, 0, '★ هیچ قانون پنلی داخل @supportsِ بدون media query نیست',
   leaking.map(r => r.path.join(' > ')).join(' | '));

// ۲) هیچ قانون .sheet که height/max-height می‌گذارد نباید بیرون media باشد
//    (چون .sheet در دسکتاپ هم روی ریشه هست)
const sheetRules = rules.filter(r => {
  const sel = r.path[r.path.length - 1] || '';
  if (!/\.sheet/.test(sel) || !/\.psb-panel\b/.test(sel)) return false;
  // آیا داخل media query هست؟
  return !insideWidthMedia(r.path.slice(0, -1));
});
// باید صفر باشد، مگر اینکه height/max-height تعیین نکند
const withHeight = [];
for (const r of sheetRules) {
  // بدنهٔ قانون را از CSS استخراج کن
  const sel = r.path[r.path.length - 1];
  const idx = CSS.indexOf(sel, r.i - sel.length - 5);
  if (idx < 0) continue;
  const bodyEnd = CSS.indexOf('}', idx);
  const body = CSS.slice(idx, bodyEnd);
  if (/^\s*(max-)?height\s*:/m.test(body.split('{')[1] || '')) withHeight.push(sel);
}
eq(withHeight.length, 0, '★ هیچ قانون .sheet بیرون media query ارتفاع پنل را تعیین نمی‌کند',
   withHeight.join(' | '));

// ۳) قید «منهای حباب و فاصلهٔ پایین» باید در ارتفاع موبایل هم باشد
const mobileBlock = CSS.slice(CSS.indexOf('@media (max-width: 480px)'));
const floatRule = mobileBlock.slice(mobileBlock.indexOf('#pasokhban-live:not(.sheet):not(.is-inline) .psb-panel'));
const floatBody = floatRule.slice(0, floatRule.indexOf('}'));
ok(/height:\s*min\(/.test(floatBody), 'ارتفاع موبایل با min() است');
ok(/--psb-off-bottom/.test(floatBody) && /--psb-launcher/.test(floatBody),
   '★ قید «منهای حباب و فاصلهٔ پایین» در ارتفاع موبایل هست (وگرنه پنل روی حباب می‌افتد)');
ok(/max-height/.test(floatBody), 'max-height هم قید دارد');

// ۴) dvh فقط داخل media query
const dvhLines = CSS.split('\n').map((l, i) => ({ l, i })).filter(x => /dvh/.test(x.l) && !/^\s*\*/.test(x.l) && !/\/\*/.test(x.l));
ok(dvhLines.length > 0, 'dvh استفاده شده');
// همهٔ خطوط dvh باید داخل یک media query باشند
let depthAt = [];
let d = 0, inMedia = [];
CSS.split('\n').forEach(line => {
  if (/@media|@supports/.test(line)) inMedia.push(line);
  (line.match(/\{/g) || []).forEach(() => d++);
  (line.match(/\}/g) || []).forEach(() => { d--; if (d === 0) inMedia = []; });
  depthAt.push(inMedia.slice());
});
const badDvh = dvhLines.filter(x => !(depthAt[x.i] || []).some(m => /max-width/.test(m)));
eq(badDvh.length, 0, '★ همهٔ کاربردهای dvh داخل media query با max-width هستند',
   badDvh.map(x => `خط ${x.i + 1}: ${x.l.trim()}`).join(' | '));

/* ========================================================= */
head('۲) متغیرهای CSS که JS از تنظیمات می‌گذارد');
/*
  نکتهٔ صادقانه: jsdom قوانین @media را ارزیابی نمی‌کند (در عرض ۳۷۵px هم
  --psb-off-side همان ۱۸px می‌ماند) و مقدار var()/calc()/min() را هم
  resolve نمی‌کند. پس «اندازه‌گیری پیکسلی» در jsdom ممکن نیست و بخش ۱
  (تحلیل ایستا) همان چیزی است که واقعاً این رگرسیون را می‌گیرد.
  این بخش فقط چیزهایی را می‌سنجد که jsdom واقعاً می‌تواند: متغیرهایی که
  JS به‌صورت inline روی ریشه می‌گذارد.
*/

const SETTINGS = {
  title: 'چت', agentName: 'پشتیبانی', greeting: 'سلام', placeholder: 'بنویس',
  accent: '#22d3ee', position: 'start', autoOpen: false, autoDelay: 5, starter: [],
  humanHandoff: true, sound: false, offlineNote: '', offsetBottom: 18, offsetSide: 18,
  launcherSize: 62, panelWidth: 384, panelHeight: 620, radius: 28, blur: 30, glassOpacity: 62,
  launcherLabel: '', teaser: true, teaserText: '', mobileSheet: true, maximize: true,
  showFooter: true, theme: 'light', prechat: false, prechatRequired: false, prechatNote: '',
  streaming: false, csat: false, upload: false
};

function makeDom(width, height) {
  const dom = new JSDOM(
    `<!DOCTYPE html><html dir="rtl"><head><style>${CSS}</style></head>` +
    `<body><div id="pasokhban-live" data-mode="widget"></div></body></html>`,
    { url: 'http://example.test/', pretendToBeVisual: true, runScripts: 'dangerously' }
  );
  const w = dom.window;
  Object.defineProperty(w, 'innerWidth',  { value: width,  configurable: true });
  Object.defineProperty(w, 'innerHeight', { value: height, configurable: true });
  w.PASOKHBAN_CHAT = { restUrl: '/wp-json/pasokhban/v1', nonce: 'n', lang: 'fa' };
  w.PASOKHBAN_CHAT_SETTINGS = SETTINGS;
  w.fetch = () => Promise.resolve({ ok: true, status: 200, json: () => Promise.resolve({
    key: 'k1', mode: 'ai', status: 'open', messages: [], agentOnline: false, agentName: 'پ', settings: SETTINGS
  }) });
  const s = w.document.createElement('script');
  s.textContent = JS;
  w.document.body.appendChild(s);
  return { w, d: w.document };
}

const wait = ms => new Promise(r => setTimeout(r, ms));

(async () => {

  let { w, d } = makeDom(1440, 900);
  await wait(80);
  const root = d.getElementById('pasokhban-live');
  ok(!!root, 'ویجت رندر شد');
  const rs = w.getComputedStyle(root);

  eq(rs.getPropertyValue('--psb-panel-w').trim(), '384px', '★ عرض پنل از تنظیمات روی ریشه نشست');
  eq(rs.getPropertyValue('--psb-panel-h').trim(), '620px', '★ ارتفاع پنل از تنظیمات روی ریشه نشست');
  eq(rs.getPropertyValue('--psb-off-side').trim(), '18px', 'فاصلهٔ کنار از تنظیمات نشست');
  eq(rs.getPropertyValue('--psb-off-bottom').trim(), '18px', 'فاصلهٔ پایین از تنظیمات نشست');
  eq(rs.getPropertyValue('--psb-launcher').trim(), '62px', 'اندازهٔ حباب از تنظیمات نشست');
  ok(root.classList.contains('sheet'), 'کلاس sheet روی ریشه هست (چون mobileSheet روشن است)');

  const panel = d.querySelector('.psb-panel');
  ok(!!panel, 'پنل رندر شد');

  // ★ رگرسیون اصلی: قانون پایه باید min() با قید حباب باشد، نه dvh خالص
  const ps = w.getComputedStyle(panel);
  ok(/^min\(/.test(ps.height), '★ ارتفاع پنل با min() است (نه یک مقدار ثابت یا dvh خالص)', ps.height);
  ok(/--psb-off-bottom/.test(ps.height) && /--psb-launcher/.test(ps.height),
     '★ قید «منهای حباب و فاصلهٔ پایین» در ارتفاع پنل هست', ps.height);
  ok(/--psb-panel-w/.test(ps.width), 'عرض پنل از متغیر تنظیمات می‌آید', ps.width);

  // عرض پنل در هر عرضی از viewport بزرگ‌تر نمی‌شود (max-width دارد)
  ok(/calc\(100vw/.test(ps.maxWidth), '★ max-width با قید viewport هست', ps.maxWidth);

console.log('\n' + '─'.repeat(52));
  if (!fail) console.log(`\x1b[42;30m همهٔ ${pass} تست اندازهٔ پنل پاس شد \x1b[0m`);
  else {
    console.log(`\x1b[41;97m ${fail} تست شکست خورد \x1b[0m (پاس: ${pass})`);
    fails.forEach(f => console.log('   • ' + f));
  }
  console.log('─'.repeat(52));
  process.exit(fail ? 1 : 0);
})();
