/**
 * تست پاسخ جریان‌دار (SSE) + امتیاز رضایت در کلاینت.
 * فایل واقعی pasokhban-chat.js با یک ReadableStream ساختگی.
 */
const fs = require('fs');
const { JSDOM } = require('jsdom');
const { ReadableStream } = require('stream/web');
const { TextEncoder, TextDecoder } = require('util');

const JS = fs.readFileSync(__dirname + '/../plugin/assets/js/pasokhban-chat.js', 'utf8');

let pass = 0, fail = 0; const fails = [];
const ok = (c, l, x) => { if (c) { pass++; console.log(`  \x1b[32m✓\x1b[0m ${l}`); } else { fail++; fails.push(l + (x ? ' — ' + x : '')); console.log(`  \x1b[31m✗\x1b[0m ${l}` + (x ? '  → ' + x : '')); } };
const eq = (a, b, l) => ok(JSON.stringify(a) === JSON.stringify(b), l, `انتظار ${JSON.stringify(b)} / دریافت ${JSON.stringify(a)}`);
const head = t => console.log(`\n\x1b[1m${t}\x1b[0m`);
const wait = ms => new Promise(r => setTimeout(r, ms));

const SETTINGS = {
  title: 'چت', agentName: 'پشتیبانی', greeting: 'سلام', placeholder: 'بنویس',
  accent: '#22d3ee', position: 'start', autoOpen: false, autoDelay: 5, starter: [],
  humanHandoff: true, sound: false, offlineNote: '',
  offsetBottom: 18, offsetSide: 18, launcherSize: 62, panelWidth: 384, panelHeight: 620,
  radius: 28, blur: 30, glassOpacity: 62, launcherLabel: '', teaser: false, teaserText: '',
  mobileSheet: true, maximize: true, showFooter: true, theme: 'auto',
  prechat: false, streaming: true, csat: true,
  streamUrl: 'http://e.test/wp-json/pasokhban/v1/live/stream'
};

const dom = new JSDOM('<!DOCTYPE html><html><body><div id="pasokhban-live" data-mode="widget"></div></body></html>',
  { url: 'http://e.test/', pretendToBeVisual: true, runScripts: 'dangerously' });
const w = dom.window;
const d = w.document;

// APIهای جریان که jsdom ندارد
w.ReadableStream = ReadableStream;
w.TextDecoder = TextDecoder;
if (!w.Response) {
  w.Response = class {
    constructor(b, o) { this._b = b; o = o || {}; this.status = o.status || 200; this.ok = this.status >= 200 && this.status < 300; this.headers = { get: (k) => (o.headers || {})[k.toLowerCase()] || null }; }
    json() { return Promise.resolve(JSON.parse(this._b)); }
  };
}

w.PASOKHBAN_CHAT = { restUrl: '/wp-json/pasokhban/v1', nonce: 'n', lang: 'fa' };
w.PASOKHBAN_CHAT_SETTINGS = SETTINGS;

const calls = [];
const TOKENS = ['پاسخ ', 'جریان‌دار ', 'کار ', 'می‌کند.'];

w.fetch = (url, opt) => {
  opt = opt || {};
  const path = String(url).replace(/^.*\/v1/, '');
  const body = opt.body ? JSON.parse(opt.body) : {};
  calls.push({ path, body });

  // مسیر جریان
  if (path.indexOf('/live/stream') === 0) {
    if (w.__streamMode === 'json') {
      return Promise.resolve(new w.Response(JSON.stringify({ error: 'no stream' }), { status: 200, headers: { 'content-type': 'application/json' } }));
    }
    if (w.__streamMode === 'error') {
      const stream = new ReadableStream({
        start(c) {
          c.enqueue(new TextEncoder().encode('data: ' + JSON.stringify({ error: 'کلید نامعتبر' }) + '\n\n'));
          c.close();
        }
      });
      return Promise.resolve(Object.assign(new w.Response('', { status: 200, headers: { 'content-type': 'text/event-stream' } }), { body: stream }));
    }

    const enc = new TextEncoder();
    let i = 0;
    const stream = new ReadableStream({
      pull(c) {
        if (i < TOKENS.length) {
          c.enqueue(enc.encode('data: ' + JSON.stringify({ t: TOKENS[i] }) + '\n\n'));
          i++;
          return new Promise(r => setTimeout(r, 130));
        }
        c.enqueue(enc.encode('data: ' + JSON.stringify({ done: true, id: 777, ms: 1200, sources: [{ title: 'منبع تست', url: 'http://e.test/s' }] }) + '\n\n'));
        c.close();
      }
    });
    return Promise.resolve(Object.assign(new w.Response('', { status: 200, headers: { 'content-type': 'text/event-stream' } }), { body: stream }));
  }

  return Promise.resolve(new w.Response(JSON.stringify({
    ok: path.indexOf('/live/feedback') === 0 ? true : undefined,
    ...(path.indexOf('/live/start') === 0 ? { key: 'a1b2c3d4e5f60718293a4b5c6d7e8f90', mode: 'ai', status: 'open', messages: [], agentOnline: false, settings: SETTINGS } : {}),
    ...(path.indexOf('/live/send') === 0 ? { message: { id: 55, sender: 'visitor', content: body.content, meta: {} }, mode: 'ai', reply: { id: 56, sender: 'agent', content: 'پاسخ معمولی', meta: {} } } : {}),
    ...(path.indexOf('/live/poll') === 0 ? { messages: [], mode: 'ai', status: null, typing: false, agentOnline: false } : {})
  }), { status: 200, headers: { 'content-type': 'application/json' } }));
};

const s = d.createElement('script');
s.textContent = JS;
d.body.appendChild(s);

(async () => {
  await wait(250);

  head('۱) مسیر جریان‌دار انتخاب می‌شود');
  d.querySelector('.psb-launcher').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
  await wait(300);

  const inp = d.querySelector('.psb-input');
  inp.value = 'تست جریان';
  d.querySelector('.psb-send').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
  await wait(40);

  ok(calls.some(c => c.path.indexOf('/live/stream') === 0), 'به /live/stream درخواست رفت');
  ok(!calls.some(c => c.path.indexOf('/live/send') === 0), 'به /live/send نرفت (مسیر جریان انتخاب شد)');

  head('۲) متن تدریجی تایپ می‌شود');
  await wait(180);   // بعد از اولین تکه، قبل از پایان
  const streamBubble = d.querySelector('.psb-msg.agent.is-streaming');
  ok(!!streamBubble, 'حباب در حال جریان با کلاس is-streaming ساخته شد');
  const mid = streamBubble ? streamBubble.querySelector('.psb-msg-text').textContent : '';
  ok(mid.length > 0 && mid.length < TOKENS.join('').length, 'در میانهٔ جریان، متن هنوز ناقص است', JSON.stringify(mid));
  ok(streamBubble && !streamBubble.querySelector('.psb-think'), 'مغزِ فکری داخل حباب جریان نیست');

  head('۳) پایان جریان');
  await wait(900);
  const agents = d.querySelectorAll('.psb-msg.agent');
  const last = agents[agents.length - 1];
  eq(last.querySelector('.psb-msg-text').textContent, TOKENS.join(''), 'کل متن از تکه‌ها ساخته شد');
  ok(!last.classList.contains('is-streaming'), 'کلاس is-streaming بعد از پایان برداشته شد');
  eq(last.getAttribute('data-mid'), '777', 'شناسهٔ پیام به حباب چسبید');
  ok(!!last.querySelector('.psb-srcbtn'), 'دکمهٔ «مشاهدهٔ منابع» زیر پاسخ هست');
  // greeting هم .psb-msg.agent است، پس ۲ = greeting + پاسخ جریان‌دار
  eq(d.querySelectorAll('.psb-msg.agent').length, 2, 'حباب پاسخ تکراری ساخته نشد (greeting + یکی)');

  head('۴) امتیاز رضایت (CSAT)');
  const csat = last.querySelector('.psb-csat');
  ok(!!csat, 'دکمه‌های 👍/👎 زیر پاسخ ظاهر شد');
  eq(csat.querySelectorAll('.psb-csat-b').length, 2, 'دو دکمه هست');
  ok(!!csat.querySelector('.psb-csat-q'), 'برچسب پرسش هست');

  const up = csat.querySelector('.psb-csat-b[data-r="1"]');
  up.dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
  await wait(80);

  const fb = calls.filter(c => c.path.indexOf('/live/feedback') === 0);
  eq(fb.length, 1, 'یک درخواست امتیاز فرستاده شد');
  eq(fb[0] && fb[0].body.rating, 1, 'امتیاز ۱ فرستاده شد');
  eq(fb[0] && fb[0].body.message_id, 777, 'شناسهٔ پیام درست فرستاده شد');
  ok(csat.classList.contains('done'), 'بعد از رأی، کلاس done گرفت');
  ok(csat.classList.contains('voted-up'), 'رأی مثبت علامت خورد');
  ok(/ممنون/.test(csat.querySelector('.psb-csat-q').textContent), 'پیام تشکر نمایش داده شد');

  // رأی دوباره نباید برود
  csat.querySelector('.psb-csat-b[data-r="-1"]').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
  await wait(50);
  eq(calls.filter(c => c.path.indexOf('/live/feedback') === 0).length, 1, 'رأی دوباره فرستاده نشد');

  head('۵) fallback وقتی جریان نیست');
  w.__streamMode = 'json';
  inp.value = 'تست fallback';
  d.querySelector('.psb-send').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
  await wait(400);

  ok(calls.some(c => c.path.indexOf('/live/send') === 0), 'وقتی سرور جریان نداد، به /live/send برگشت');
  const agents2 = d.querySelectorAll('.psb-msg.agent');
  const last2 = agents2[agents2.length - 1];
  ok(/پاسخ معمولی/.test(last2.textContent), 'پاسخ از مسیر معمولی نمایش داده شد');
  ok(!d.querySelector('.psb-msg.agent.is-streaming'), 'حباب نیمه‌کارهٔ جریان پاک شد');

  head('۶) fallback وقتی جریان خطا می‌دهد');
  w.__streamMode = 'error';
  inp.value = 'تست خطای جریان';
  d.querySelector('.psb-send').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
  await wait(400);
  const agents3 = d.querySelectorAll('.psb-msg.agent');
  ok(agents3.length >= 3, 'بعد از خطای جریان هم پاسخ رسید (fallback)', 'تعداد: ' + agents3.length);

  console.log('\n' + '─'.repeat(52));
  if (fail === 0) console.log(`\x1b[42;30m همهٔ ${pass} تست جریان و CSAT پاس شد \x1b[0m`);
  else { console.log(`\x1b[41;97m ${fail} تست شکست خورد \x1b[0m (پاس: ${pass})`); fails.forEach(f => console.log('   • ' + f)); }
  console.log('─'.repeat(52));
  process.exit(fail === 0 ? 0 : 1);
})();
