<?php
/**
 * ساخت پیش‌نمایش HTML صفحهٔ تنظیمات از کد واقعی PHP پلاگین.
 *
 * این یک ابزار توسعه است، نه بخشی از پلاگین. همان render_page() واقعی را
 * صدا می‌زند و دورش یک پوستهٔ شبه‌وردپرس می‌گذارد تا در مرورگر دیده شود.
 *
 * استفاده: php tests/make-preview.php
 */

require_once __DIR__ . '/wp-stubs.php';

update_option( 'pasokhban_options', array(
	'api_key'            => 'sk-demo-1234',
	'model'              => 'gpt-4o',
	'widget_style'       => 'chat',
	'rag_vector'         => 1,
	'rag_dims'           => 512,
	'rag_top_k'          => 4,
	'rag_min_score'      => 0.30,
	'rag_chunk_size'     => 1200,
	'rag_chunk_overlap'  => 200,
	'rag_post_types'     => 'post,page',
	'rag_auto_sync'      => 1,
	'notify_email'       => 1,
	'notify_telegram'    => 1,
) );
Pasokhban_Settings::instance();
Pasokhban_DB::install();

// یک ایندکس نمونه تا کارت RAG با عدد واقعی رندر شود
$GLOBALS['wp_posts'] = array(
	(object) array( 'ID' => 1, 'post_title' => 'ضمانت‌نامهٔ محصول', 'post_content' => str_repeat( 'شرایط بازگشت وجه. ', 40 ), 'post_type' => 'post', 'post_status' => 'publish' ),
	(object) array( 'ID' => 2, 'post_title' => 'روش‌های ارسال', 'post_content' => str_repeat( 'ارسال با پست پیشتاز. ', 40 ), 'post_type' => 'post', 'post_status' => 'publish' ),
);
$GLOBALS['wp_remote_response'] = function ( $url, $args ) {
	$p    = json_decode( $args['body'], true );
	$data = array();
	foreach ( (array) $p['input'] as $i => $t ) {
		mt_srand( crc32( $t ) );
		$v = array();
		for ( $k = 0; $k < 8; $k++ ) { $v[] = ( mt_rand() / mt_getrandmax() ) - 0.5; }
		$data[] = array( 'index' => $i, 'embedding' => Pasokhban_RAG::normalize( $v ) );
	}
	return array( 'response' => array( 'code' => 200 ), 'body' => json_encode( array( 'data' => $data ) ) );
};
Pasokhban_RAG::instance()->build( array( 'reset' => true ) );

set_transient( 'pasokhban_rag_notice', array(
	'type' => 'success',
	'text' => "منابع پردازش‌شده: ۲ · تکهٔ تازه: ۲ · بدون تغییر: ۰ · زمان: ۰٫۴ ثانیه",
), 60 );

ob_start();
Pasokhban_Settings::instance()->render_page();
$body = ob_get_clean();

$css = file_get_contents( PASOKHBAN_PLUGIN_DIR . '/assets/css/pasokhban-admin.css' );
$js  = file_get_contents( PASOKHBAN_PLUGIN_DIR . '/assets/js/pasokhban-settings.js' );

$nav = '<nav id="adminmenu">'
	. '<a class="m on" href="settings.html">⚙️ تنظیمات</a>'
	. '<a class="m" href="inbox.html">💬 گفتگوها</a>'
	. '<a class="m" href="contacts.html">👥 مخاطبین</a>'
	. '<a class="m" href="analytics.html">📊 آمار</a>'
	. '</nav>';

$shell_css = '
#wpwrap{display:flex;gap:0;background:#f1f5f9;min-height:100vh}
#adminmenu{flex:none;width:190px;background:#0b1120;padding:16px 10px;display:flex;flex-direction:column;gap:4px}
#adminmenu a.m{color:#cbd5e1;text-decoration:none;padding:9px 12px;border-radius:9px;font-size:13px}
#adminmenu a.m.on{background:rgba(34,211,238,.16);color:#22d3ee}
#wpbody{flex:1;min-width:0;padding:20px}
body{margin:0;background:#f1f5f9}
';

$html = '<!DOCTYPE html><html dir="rtl" lang="fa"><head><meta charset="utf-8">'
	. '<meta name="viewport" content="width=device-width, initial-scale=1">'
	. '<title>پیش‌نمایش تنظیمات — پاسخ‌بان ۱.۹.۰</title>'
	. '<style>' . $css . $shell_css . '</style>'
	. '</head><body><div id="wpwrap">' . $nav . '<div id="wpbody">' . $body . '</div></div>'
	. '<script>' . $js . '</script>'
	. '</body></html>';

file_put_contents( PASOKHBAN_TESTS_DIR . '/../preview/settings.html', $html );
echo 'preview/settings.html نوشته شد — ' . strlen( $html ) . " بایت\n";
