<?php
/**
 * تست‌های واقعی پاسخ‌بان ۱.۱.۰
 * کد واقعی پلاگین را روی هارنس وردپرس/SQLite اجرا می‌کند.
 */

require_once __DIR__ . '/wp-stubs.php';

$PASS = 0; $FAIL = 0; $FAILURES = array();

function ok( $cond, $label, $extra = '' ) {
	global $PASS, $FAIL, $FAILURES;
	if ( $cond ) { $PASS++; echo "  \033[32m✓\033[0m {$label}\n"; }
	else { $FAIL++; $FAILURES[] = $label . ( $extra ? " — {$extra}" : '' ); echo "  \033[31m✗\033[0m {$label}" . ( $extra ? "  → {$extra}" : '' ) . "\n"; }
}
function head( $t ) { echo "\n\033[1m{$t}\033[0m\n"; }
function eq( $a, $b, $label ) { ok( $a === $b, $label, 'انتظار ' . var_export( $b, true ) . ' / دریافت ' . var_export( $a, true ) ); }

/** دسترسی امن به فیلد — تا WP_Error باعث fatal نشود و خطا خوانا بماند. */
function fld( $r, $k ) { return ( is_array( $r ) && array_key_exists( $k, $r ) ) ? $r[ $k ] : null; }
function errcode( $r ) { return is_wp_error( $r ) ? $r->get_error_code() : false; }
/** فیلد یک مقدار که ممکن است array یا stdClass باشد (پیام‌ها stdClass هستند). */
function getf( $o, $k ) {
	if ( is_array( $o ) ) return array_key_exists( $k, $o ) ? $o[ $k ] : null;
	if ( is_object( $o ) ) return isset( $o->{$k} ) ? $o->{$k} : null;
	return null;
}
function why( $r ) {
	if ( is_wp_error( $r ) ) return 'WP_Error: ' . $r->get_error_code() . ' (' . $r->get_error_message() . ')';
	if ( is_array( $r ) && ! empty( $r['error'] ) ) return 'error: ' . $r['error'];
	return '—';
}

/* ========================================================= */
head( '۱) تنظیمات — sanitize' );
/* ========================================================= */

// گزینه‌ها را قبل از ساخت singleton می‌گذاریم
update_option( 'pasokhban_options', array( 'api_key' => 'sk-test-123' ) );
$settings = Pasokhban_Settings::instance();
$d = $settings->defaults();

ok( count( $d ) >= 32, 'defaults حداقل ۳۲ کلید دارد', 'تعداد: ' . count( $d ) );
eq( $d['widget_style'], 'chat', 'سبک پیش‌فرض ویجت = chat' );
eq( $d['live_enabled'], 1, 'چت آنلاین به‌صورت پیش‌فرض فعال' );

$clean = $settings->sanitize( array(
	'api_key'          => 'sk-abc',
	'max_tokens'       => 5000,
	'temperature'      => 9,
	'rate_limit'       => -5,
	'knowledge_posts'  => 0,
	'accent'           => 'javascript:alert(1)',
	'widget_style'     => 'brain',
	'live_position'    => 'end',
	'live_theme'       => 'dark',
	'live_auto_delay'  => 9999,
	'live_history'     => 9999,
	'live_enabled'     => 1,
	'knowledge'        => 1,
	'tts'              => 0,
	'lang'             => 'de',
	'live_starters'    => "<script>x</script>\nخط دوم",
	'live_title'       => '<b>عنوان</b>',
) );

eq( $clean['max_tokens'], 5000, 'max_tokens بدون سقف بالا نمی‌شکند' );
eq( $clean['temperature'], 2.0, 'temperature به ۲ محدود می‌شود' );
eq( $clean['rate_limit'], 0, 'rate_limit منفی به ۰ تبدیل می‌شود' );
eq( $clean['knowledge_posts'], 1, 'knowledge_posts صفر به ۱ می‌رسد' );
eq( $clean['accent'], '#22d3ee', 'رنگ نامعتبر به پیش‌فرض برمی‌گردد (XSS خنثی)' );
eq( $clean['widget_style'], 'brain', 'سبک brain پذیرفته می‌شود' );
eq( $clean['live_position'], 'end', 'موقعیت end پذیرفته می‌شود' );
eq( $clean['live_theme'], 'dark', 'تم dark پذیرفته می‌شود' );
eq( $clean['live_auto_delay'], 120, 'تأخیر باز شدن به ۱۲۰ محدود می‌شود' );
eq( $clean['live_history'], 60, 'حافظهٔ مکالمه به ۶۰ محدود می‌شود' );
eq( $clean['lang'], 'fa', 'زبان ناشناخته به fa برمی‌گردد' );
eq( $clean['tts'], 0, 'کلید غیرفعال = ۰' );
ok( strpos( $clean['live_starters'], '<script>' ) === false, 'تگ script از دکمه‌های شروع حذف می‌شود', $clean['live_starters'] );
eq( $clean['live_title'], 'عنوان', 'تگ‌ها از عنوان پاک می‌شوند' );

$bad_style = $settings->sanitize( array( 'widget_style' => 'DROP TABLE' ) );
eq( $bad_style['widget_style'], 'chat', 'سبک نامعتبر به chat برمی‌گردد' );
$bad_theme = $settings->sanitize( array( 'live_theme' => 'neon' ) );
eq( $bad_theme['live_theme'], 'auto', 'تم نامعتبر به auto برمی‌گردد' );

// همهٔ کلیدهای defaults باید بعد از sanitize هم موجود باشند (تا get_options نقص نداشته باشد)
$missing = array_diff( array_keys( $d ), array_keys( $clean ) );
eq( $missing, array(), 'sanitize همهٔ کلیدهای defaults را پوشش می‌دهد' );

/* ========================================================= */
head( '۲) دیتابیس — ساخت جدول و نشست' );
/* ========================================================= */

Pasokhban_DB::install();
ok( Pasokhban_DB::installed(), 'install() نسخهٔ ساختار را ثبت کرد' );

$sess_tbl = Pasokhban_DB::sessions_table();
$msg_tbl  = Pasokhban_DB::messages_table();
ok( $GLOBALS['wpdb']->get_var( "SELECT name FROM sqlite_master WHERE type='table' AND name='{$sess_tbl}'" ), 'جدول نشست‌ها ساخته شد: ' . $sess_tbl );
ok( $GLOBALS['wpdb']->get_var( "SELECT name FROM sqlite_master WHERE type='table' AND name='{$msg_tbl}'" ), 'جدول پیام‌ها ساخته شد: ' . $msg_tbl );

eq( Pasokhban_DB::sanitize_key( 'abc' ), '', 'کلید کوتاه رد می‌شود' );
eq( Pasokhban_DB::sanitize_key( 'DROP TABLE; --' ), '', 'کلید با کاراکتر غیرمجاز رد می‌شود' );
$u = wp_generate_uuid4();
ok( strlen( Pasokhban_DB::sanitize_key( $u ) ) === 32, 'uuid به کلید ۳۲ کاراکتری نرمال می‌شود', Pasokhban_DB::sanitize_key( $u ) );
eq( Pasokhban_DB::get_session_by_key( '' ), null, 'کلید خالی نشست برنمی‌گرداند' );
eq( Pasokhban_DB::get_session_by_key( 'nonexistent' ), null, 'کلید ناموجود null می‌دهد' );

$s1 = Pasokhban_DB::create_session( array( 'lang' => 'fa', 'current_url' => 'http://example.test/page-1' ) );
ok( $s1 && $s1->id > 0, 'ساخت نشست موفق', $s1 ? 'id=' . $s1->id : 'null' );
ok( strlen( $s1->session_key ) === 32, 'کلید نشست ۳۲ کاراکتر hex است', $s1->session_key );
eq( $s1->mode, 'ai', 'حالت پیش‌فرض نشست = ai' );
eq( $s1->status, 'open', 'وضعیت پیش‌فرض = open' );
eq( $s1->current_url, 'http://example.test/page-1', 'آدرس صفحه ذخیره شد' );

// همان کلید دوباره → همان نشست (تکراری ساخته نمی‌شود)
$again = Pasokhban_DB::get_or_create_session( $s1->session_key, array( 'current_url' => 'http://example.test/page-2' ) );
eq( (int) $again->id, (int) $s1->id, 'کلید تکراری نشست جدید نمی‌سازد' );
eq( $again->current_url, 'http://example.test/page-2', 'آدرس صفحهٔ فعلی به‌روز شد' );
eq( Pasokhban_DB::get_or_create_session( 'garbage!!', array() )->session_key !== $s1->session_key, true, 'کلید خراب → نشست تازه' );

/* ========================================================= */
head( '۳) پیام‌ها' );
/* ========================================================= */

$m1 = Pasokhban_DB::add_message( $s1->id, 'visitor', 'سلام' );
$m2 = Pasokhban_DB::add_message( $s1->id, 'agent', 'درود!', array( 'via' => 'ai', 'sources' => array( array( 'title' => 'صفحه', 'url' => 'http://example.test/x' ) ) ) );
$m3 = Pasokhban_DB::add_message( $s1->id, 'hacker', 'نقش نامعتبر' );

ok( $m1 && $m2 && $m3, 'سه پیام ثبت شد' );
eq( $m3->sender, 'visitor', 'نقش نامعتبر به visitor نرمال می‌شود' );
eq( count( Pasokhban_DB::get_messages( $s1->id ) ), 3, 'خواندن هر ۳ پیام' );
eq( count( Pasokhban_DB::get_messages( $s1->id, $m1->id ) ), 2, 'فیلتر after فقط پیام‌های تازه‌تر را می‌دهد' );
eq( Pasokhban_DB::get_messages( $s1->id, 0, 2 )[0]->id, $m2->id, 'سقف limit آخرین پیام‌ها را می‌دهد ولی ترتیب زمانی درست است' );
ok( is_array( $m2->meta ) && 'ai' === $m2->meta['via'], 'meta به‌صورت آرایه بازیابی می‌شود' );
eq( $m1->meta, array(), 'meta خالی = آرایهٔ خالی (نه null)' );
ok( preg_match( '/^\d{2}:\d{2}$/', substr( $m1->time, 11, 5 ) ) === 1 || strlen( $m1->time ) > 10, 'فیلد time پر شده', $m1->time );

/* ========================================================= */
head( '۴) چت آنلاین — مسیر عمومی' );
/* ========================================================= */

update_option( 'pasokhban_options', array(
	'api_key'      => 'sk-test',
	'base_url'     => 'https://api.example.test/v1',
	'model'        => 'gpt-4o',
	'knowledge'    => 0,
	'live_enabled' => 1,
	'rate_limit'   => 0,
	'live_history' => 20,
	'accent'       => '#22d3ee',
) );
// singleton گزینه‌ها را کش کرده — با reflection تازه‌سازی می‌کنیم
$rp = new ReflectionProperty( 'Pasokhban_Settings', 'options' );
$rp->setAccessible( true );
$rp->setValue( $settings, get_option( 'pasokhban_options' ) );

$live = Pasokhban_LiveChat::instance();
$live->register_routes();

ok( isset( $GLOBALS['wp_rest_routes']['pasokhban/v1/live/start'] ), 'مسیر /live/start ثبت شد' );
ok( isset( $GLOBALS['wp_rest_routes']['pasokhban/v1/live/send'] ), 'مسیر /live/send ثبت شد' );
ok( isset( $GLOBALS['wp_rest_routes']['pasokhban/v1/live/poll'] ), 'مسیر /live/poll ثبت شد' );
ok( isset( $GLOBALS['wp_rest_routes']['pasokhban/v1/admin/reply'] ), 'مسیر /admin/reply ثبت شد' );
ok( count( $GLOBALS['wp_rest_routes'] ) >= 11, 'حداقل ۱۱ مسیر REST ثبت شد', count( $GLOBALS['wp_rest_routes'] ) );

// شروع مکالمه
$res = $live->handle_start( new WP_REST_Request( array(), array( 'lang' => 'fa', 'current_url' => 'http://example.test/shop' ) ) );
ok( is_array( $res ) && ! empty( $res['key'] ), 'handle_start کلید نشست برمی‌گرداند' );
eq( $res['mode'], 'ai', 'حالت اولیه ai است' );
eq( $res['messages'], array(), 'مکالمهٔ تازه خالی است' );
ok( ! empty( $res['settings']['title'] ), 'settings به کلاینت داده می‌شود' );
ok( is_array( $res['settings']['starter'] ) && count( $res['settings']['starter'] ) > 0, 'دکمه‌های شروع پر شده' );
$key = $res['key'];

// پاسخ ساختگی مدل
$GLOBALS['wp_remote_response'] = array(
	'response' => array( 'code' => 200 ),
	'body'     => json_encode( array( 'choices' => array( array( 'message' => array( 'content' => 'سلام! در خدمتم.' ) ) ) ) ),
);

$send = $live->handle_send( new WP_REST_Request( array(), array( 'key' => $key, 'content' => 'قیمت چنده؟', 'lang' => 'fa' ) ) );
ok( is_array( $send ) && ! fld( $send, 'error' ), 'ارسال پیام بدون خطا', why( $send ) );
$replyMsg = fld( $send, 'reply' );
ok( $replyMsg && 'سلام! در خدمتم.' === getf( $replyMsg, 'content' ), 'پاسخ AI برگشت و ذخیره شد', $replyMsg ? getf( $replyMsg, 'content' ) : why( $send ) );
eq( $replyMsg ? getf( $replyMsg, 'sender' ) : null, 'agent', 'پاسخ AI با نقش agent ذخیره می‌شود' );
$replyMeta = $replyMsg ? getf( $replyMsg, 'meta' ) : null;
eq( is_array( $replyMeta ) && isset( $replyMeta['via'] ) ? $replyMeta['via'] : null, 'ai', 'متادیتای via=ai ثبت شد' );
ok( $replyMsg && ! empty( getf( $replyMsg, 'time' ) ), 'پاسخ تازه فیلد time دارد (باگ رفع شد)', $replyMsg ? (string) getf( $replyMsg, 'time' ) : '—' );

// آنچه واقعاً به مدل فرستاده شد
$call = end( $GLOBALS['wp_remote_calls'] );
$call = $call ? $call : array( 'url' => null, 'body' => array( 'messages' => array(), 'model' => null ) );
eq( $call['url'], 'https://api.example.test/v1/chat/completions', 'آدرس فراخوانی مدل درست ساخته شد' );
eq( $call['body']['model'], 'gpt-4o', 'مدل درست ارسال شد' );
$roles = array_column( (array) $call['body']['messages'], 'role' );
eq( $roles ? $roles[0] : null, 'system', 'اولین پیام system است' );
eq( $roles ? end( $roles ) : null, 'user', 'آخرین پیام user است' );
ok( in_array( 'قیمت چنده؟', array_column( (array) $call['body']['messages'], 'content' ), true ), 'سؤال کاربر به مدل رسید' );

// polling
$poll = $live->handle_poll( new WP_REST_Request( array( 'key' => $key, 'after' => 0 ) ) );
eq( count( $poll['messages'] ), 2, 'poll هر دو پیام را برمی‌گرداند' );
$poll2 = $live->handle_poll( new WP_REST_Request( array( 'key' => $key, 'after' => $replyMsg ? (int) getf( $replyMsg, 'id' ) : 0 ) ) );
eq( count( $poll2['messages'] ), 0, 'poll با after پیام تکراری نمی‌دهد' );
ok( ! isset( $poll['expired'] ), 'poll برای کلید معتبر expired نمی‌دهد' );
$pollBad = $live->handle_poll( new WP_REST_Request( array( 'key' => 'nope', 'after' => 0 ) ) );
ok( ! empty( $pollBad['expired'] ), 'poll برای کلید نامعتبر expired می‌دهد' );

// نشست در دیتابیس به‌روز شده
$row = Pasokhban_DB::get_session_by_key( $key );
eq( (int) $row->unread_agent, 1, 'شمارندهٔ خوانده‌نشدهٔ اپراتور = ۱' );
eq( (int) $row->unread_visitor, 0, 'بعد از poll شمارندهٔ بازدیدکننده صفر شد' );
eq( $row->last_sender, 'agent', 'آخرین فرستنده روی نشست ثبت شد' );

// پیام خالی
$empty = $live->handle_send( new WP_REST_Request( array(), array( 'key' => $key, 'content' => '   ' ) ) );
ok( is_wp_error( $empty ) && 'pasokhban_empty' === $empty->get_error_code(), 'پیام خالی رد می‌شود' );

// نشست ناموجود
$noSess = $live->handle_send( new WP_REST_Request( array(), array( 'key' => 'deadbeefdeadbeefdeadbeefdeadbeef', 'content' => 'سلام' ) ) );
ok( is_wp_error( $noSess ) && 'pasokhban_nosession' === $noSess->get_error_code(), 'نشست ناموجود خطا می‌دهد' );

/* ========================================================= */
head( '۵) خطای واقعی API پنهان نمی‌شود' );
/* ========================================================= */

$GLOBALS['wp_remote_response'] = array(
	'response' => array( 'code' => 401 ),
	'body'     => json_encode( array( 'error' => array( 'message' => 'Incorrect API key provided' ) ) ),
);
$bad = $live->handle_send( new WP_REST_Request( array(), array( 'key' => $key, 'content' => 'دوباره؟' ) ) );
ok( is_array( $bad ) && ! empty( $bad['error'] ), 'خطای مدل به کلاینت می‌رسد (نه پاسخ جعلی)' );
eq( fld( $bad, 'error' ), 'Incorrect API key provided', 'متن خطای واقعی API بازگردانده شد' );
ok( ! fld( $bad, 'reply' ), 'در حالت خطا پاسخ جعلی ساخته نمی‌شود' );

// بدون کلید API
$opts_nokey = get_option( 'pasokhban_options' );
$opts_nokey['api_key'] = '';
update_option( 'pasokhban_options', $opts_nokey );
$rp->setValue( $settings, $opts_nokey );
$noKey = $live->handle_send( new WP_REST_Request( array(), array( 'key' => $key, 'content' => 'سلام' ) ) );
ok( ! empty( $noKey['error'] ), 'بدون کلید API خطای واضح برمی‌گردد' );

// بازیابی
$opts_nokey['api_key'] = 'sk-test';
update_option( 'pasokhban_options', $opts_nokey );
$rp->setValue( $settings, $opts_nokey );

/* ========================================================= */
head( '۶) ورود اپراتور انسانی' );
/* ========================================================= */

ok( false === $live->admin_permission() || true === $live->admin_permission(), 'admin_permission قابل صدا زدن است' );
$GLOBALS['wp_current_user_can'] = false;
eq( $live->admin_permission(), false, 'کاربر غیرمدیر دسترسی به اینباکس ندارد' );
$GLOBALS['wp_current_user_can'] = true;
eq( $live->admin_permission(), true, 'مدیر دسترسی دارد' );

$sessRow = Pasokhban_DB::get_session_by_key( $key );
$sid = (int) $sessRow->id;

// تغییر حالت به agent
$live->admin_mode( new WP_REST_Request( array(), array( 'id' => $sid, 'mode' => 'agent' ) ) );
eq( Pasokhban_DB::get_session( $sid )->mode, 'agent', 'حالت نشست به agent تغییر کرد' );

// در حالت agent، هوش مصنوعی دخالت نمی‌کند
$callsBefore = count( $GLOBALS['wp_remote_calls'] );
$queued = $live->handle_send( new WP_REST_Request( array(), array( 'key' => $key, 'content' => 'آدم هستی؟' ) ) );
eq( count( $GLOBALS['wp_remote_calls'] ), $callsBefore, 'در حالت agent هیچ فراخوانی AI انجام نمی‌شود' );
ok( ! empty( $queued['queued'] ), 'پیام در صف اپراتور قرار گرفت' );
ok( ! isset( $queued['reply'] ), 'در حالت agent پاسخ AI ساخته نمی‌شود' );

// پاسخ دستی اپراتور
$reply = $live->admin_reply( new WP_REST_Request( array(), array( 'id' => $sid, 'content' => 'بله، من پشتیبانم.' ) ) );
$agentMsg = fld( $reply, 'message' );
ok( $agentMsg && getf( $agentMsg, 'id' ), 'پاسخ اپراتور ذخیره شد', why( $reply ) );
eq( $agentMsg ? getf( $agentMsg, 'sender' ) : null, 'agent', 'نقش پاسخ اپراتور = agent' );
$agentMeta = $agentMsg ? getf( $agentMsg, 'meta' ) : null;
eq( is_array( $agentMeta ) && isset( $agentMeta['via'] ) ? $agentMeta['via'] : null, 'human', 'متادیتای via=human' );

// بازدیدکننده پاسخ اپراتور را در poll می‌بیند
$pollAgent = $live->handle_poll( new WP_REST_Request( array( 'key' => $key, 'after' => fld( $queued, 'message' ) ? (int) getf( $queued['message'], 'id' ) : 0 ) ) );
eq( count( $pollAgent['messages'] ), 1, 'poll پاسخ اپراتور را رساند' );
eq( $pollAgent['messages'][0]->content, 'بله، من پشتیبانم.', 'محتوای پاسخ اپراتور درست است' );

// بازگرداندن به AI
$live->admin_mode( new WP_REST_Request( array(), array( 'id' => $sid, 'mode' => 'ai' ) ) );
eq( Pasokhban_DB::get_session( $sid )->mode, 'ai', 'بازگشت به حالت ai' );
$sysMsgs = array_filter( Pasokhban_DB::get_messages( $sid ), function ( $m ) { return 'system' === $m->sender; } );
ok( count( $sysMsgs ) >= 2, 'پیام سیستمی تغییر حالت ثبت شد', count( $sysMsgs ) );

// بستن مکالمه
$live->admin_status( new WP_REST_Request( array(), array( 'id' => $sid, 'status' => 'closed' ) ) );
eq( Pasokhban_DB::get_session( $sid )->status, 'closed', 'گفتگو بسته شد' );
$live->admin_status( new WP_REST_Request( array(), array( 'id' => $sid, 'status' => 'open' ) ) );
eq( Pasokhban_DB::get_session( $sid )->status, 'open', 'گفتگو باز شد' );

// اینباکس
$list = $live->admin_sessions( new WP_REST_Request( array( 'status' => 'open', 'per_page' => 10, 'page' => 1 ) ) );
ok( $list['total'] >= 1, 'لیست نشست‌ها آیتم دارد', 'total=' . $list['total'] );
ok( isset( $list['items'][0]['name'] ), 'آیتم لیست فیلد name دارد' );
ok( ! isset( $list['items'][0]['session_key'] ), 'کلید خام نشست در خروجی اینباکس نشت نمی‌کند (به‌جایش id هست)' );

$one = $live->admin_session( new WP_REST_Request( array( 'id' => $sid ) ) );
ok( count( $one['messages'] ) >= 4, 'جزئیات مکالمه پیام‌ها را برمی‌گرداند', count( $one['messages'] ) );

$live->admin_read( new WP_REST_Request( array(), array( 'id' => $sid ) ) );
eq( (int) Pasokhban_DB::get_session( $sid )->unread_agent, 0, 'خوانده‌شده标记 شد' );

// حذف
$live->admin_delete( new WP_REST_Request( array(), array( 'id' => $sid ) ) );
eq( Pasokhban_DB::get_session( $sid ), null, 'مکالمه حذف شد' );
eq( count( Pasokhban_DB::get_messages( $sid ) ), 0, 'پیام‌هایش هم حذف شدند' );

/* ========================================================= */
head( '۷) «در حال نوشتن» و «اپراتور آنلاین»' );
/* ========================================================= */

$s2 = Pasokhban_DB::create_session( array( 'lang' => 'fa' ) );
$sid2 = (int) $s2->id;
$live->admin_typing( new WP_REST_Request( array(), array( 'id' => $sid2, 'typing' => 1 ) ) );
$pt = $live->handle_poll( new WP_REST_Request( array( 'key' => $s2->session_key, 'after' => 0 ) ) );
eq( $pt['typing'], true, 'typing به بازدیدکننده می‌رسد' );
$live->admin_typing( new WP_REST_Request( array(), array( 'id' => $sid2, 'typing' => 0 ) ) );
$pt2 = $live->handle_poll( new WP_REST_Request( array( 'key' => $s2->session_key, 'after' => 0 ) ) );
eq( $pt2['typing'], false, 'typing خاموش شد' );

eq( $pt['agentOnline'], false, 'قبل از heartbeat اپراتور آفلاین است' );
$live->admin_heartbeat();
$pt3 = $live->handle_poll( new WP_REST_Request( array( 'key' => $s2->session_key, 'after' => 0 ) ) );
eq( $pt3['agentOnline'], true, 'بعد از heartbeat اپراتور آنلاین است' );

/* ========================================================= */
head( '۸) محدودسازی نرخ و غیرفعال‌بودن چت' );
/* ========================================================= */

$o = get_option( 'pasokhban_options' );
$o['rate_limit'] = 2;
update_option( 'pasokhban_options', $o );
$rp->setValue( $settings, $o );

$GLOBALS['wp_remote_response'] = array( 'response' => array( 'code' => 200 ), 'body' => json_encode( array( 'choices' => array( array( 'message' => array( 'content' => 'ok' ) ) ) ) ) );
$s3 = Pasokhban_DB::create_session( array() );
$r1 = $live->handle_send( new WP_REST_Request( array(), array( 'key' => $s3->session_key, 'content' => '۱' ) ) );
$r2 = $live->handle_send( new WP_REST_Request( array(), array( 'key' => $s3->session_key, 'content' => '۲' ) ) );
$r3 = $live->handle_send( new WP_REST_Request( array(), array( 'key' => $s3->session_key, 'content' => '۳' ) ) );
ok( ! is_wp_error( $r1 ) && ! is_wp_error( $r2 ), 'دو درخواست اول رد می‌شوند' );
ok( is_wp_error( $r3 ) && 'pasokhban_rate' === $r3->get_error_code(), 'درخواست سوم با ۴۲۹ رد می‌شود', is_wp_error( $r3 ) ? $r3->get_error_code() : 'no error' );

$o['rate_limit']   = 0;
$o['live_enabled'] = 0;
update_option( 'pasokhban_options', $o );
$rp->setValue( $settings, $o );
$dis = $live->handle_send( new WP_REST_Request( array(), array( 'key' => $s3->session_key, 'content' => 'سلام' ) ) );
ok( is_wp_error( $dis ) && 'pasokhban_disabled' === $dis->get_error_code(), 'وقتی چت غیرفعال است ۴۰۳ برمی‌گردد' );

/* ========================================================= */
head( '۹) ویجت مغز — اندپوینت /chat' );
/* ========================================================= */

$o['live_enabled'] = 1;
update_option( 'pasokhban_options', $o );
$rp->setValue( $settings, $o );

$api = Pasokhban_API::instance();
$api->register_routes();
ok( isset( $GLOBALS['wp_rest_routes']['pasokhban/v1/chat'] ), 'مسیر /chat ثبت شد' );
ok( isset( $GLOBALS['wp_rest_routes']['pasokhban/v1/config'] ), 'مسیر /config ثبت شد' );

$chat = $api->handle_chat( new WP_REST_Request( array(), array(
	'lang'     => 'fa',
	'messages' => array(
		array( 'role' => 'user', 'content' => 'سلام' ),
		array( 'role' => 'assistant', 'content' => 'درود' ),
		array( 'role' => 'user', 'content' => 'چطوری؟' ),
	),
) ) );
ok( is_array( $chat ) && 'ok' === $chat['content'], 'اندپوینت /chat پاسخ می‌دهد', is_array( $chat ) ? $chat['content'] : ( is_wp_error( $chat ) ? $chat->get_error_message() : '?' ) );
ok( array_key_exists( 'sources', $chat ), 'کلید sources در پاسخ هست (باگ ۱.۰.۰ رفع شد)' );

// باگ ۱.۰.۰: پیام بدون content → جابه‌جایی نقش‌ها / undefined offset
set_error_handler( function ( $n, $s ) { throw new Exception( $s ); } );
$broken = null;
try {
	$broken = $api->handle_chat( new WP_REST_Request( array(), array(
		'lang'     => 'fa',
		'messages' => array(
			array( 'role' => 'user' ),                        // بدون content
			array( 'role' => 'assistant', 'content' => 'الف' ),
			array( 'role' => 'user', 'content' => 'ب' ),
			array( 'junk' => 1 ),
		),
	) ) );
	$thrown = false;
} catch ( Exception $e ) {
	$thrown = true;
}
restore_error_handler();
ok( ! $thrown, 'پیام ناقص باعث خطای PHP نمی‌شود' );
ok( is_array( $broken ) && 'ok' === $broken['content'], 'با پیام ناقص هم درست کار می‌کند', is_array( $broken ) ? 'ok' : '—' );

$chatEmpty = $api->handle_chat( new WP_REST_Request( array(), array( 'lang' => 'fa', 'messages' => array() ) ) );
ok( is_wp_error( $chatEmpty ), 'آرایهٔ خالی خطا می‌دهد' );

$chatGarbage = $api->handle_chat( new WP_REST_Request( array(), array( 'lang' => 'fa' ) ) );
ok( is_wp_error( $chatGarbage ), 'بدون messages خطا می‌دهد' );

// پیکربندی
$cfg = $api->handle_config( new WP_REST_Request( array( 'lang' => 'fa' ) ) );
ok( array_key_exists( 'launcherText', $cfg ), 'config فیلد launcherText را می‌فرستد (باگ ۱.۰.۰ رفع شد)' );
ok( array_key_exists( 'greeting', $cfg ), 'config فیلد greeting را می‌فرستد' );
ok( array_key_exists( 'placeholder', $cfg ), 'config فیلد placeholder را می‌فرستد' );

/* ========================================================= */
head( '۱۰) سقف تاریخچهٔ ارسالی به مدل' );
/* ========================================================= */

$o['live_history'] = 6;
update_option( 'pasokhban_options', $o );
$rp->setValue( $settings, $o );

$s4 = Pasokhban_DB::create_session( array() );
$GLOBALS['wp_remote_calls'] = array();
for ( $i = 1; $i <= 12; $i++ ) {
	$live->handle_send( new WP_REST_Request( array(), array( 'key' => $s4->session_key, 'content' => 'سؤال ' . $i ) ) );
}
$lastCall = end( $GLOBALS['wp_remote_calls'] );
$nonSystem = array_filter( $lastCall['body']['messages'], function ( $m ) { return 'system' !== $m['role']; } );
ok( count( $nonSystem ) <= 6, 'تعداد پیام غیرسیستمی از سقف بیشتر نمی‌شود', count( $nonSystem ) );
eq( end( array_values( $nonSystem ) )['role'], 'user', 'آخرین پیام ارسالی user است' );
ok( count( Pasokhban_DB::get_messages( (int) $s4->id ) ) === 24, 'اما همهٔ ۲۴ پیام در دیتابیس محفوظ است', count( Pasokhban_DB::get_messages( (int) $s4->id ) ) );

/* ========================================================= */
head( '۱۱) قلاب‌ها و اینباکس' );
/* ========================================================= */

$fired = isset( $GLOBALS['wp_actions']['fired'] ) ? $GLOBALS['wp_actions']['fired'] : array();
ok( in_array( 'pasokhban_visitor_message', $fired, true ), 'قلاب pasokhban_visitor_message اجرا شد' );

ob_start();
Pasokhban_Inbox::render();
$html = ob_get_clean();
ok( strpos( $html, 'ei-app' ) !== false, 'صفحهٔ اینباکس رندر می‌شود' );
ok( strpos( $html, 'ei-msgs' ) !== false, 'بخش پیام‌های اینباکس هست' );
ok( strpos( $html, 'ei-composer' ) !== false, 'بخش پاسخ‌دادن اینباکس هست' );

$GLOBALS['wp_current_user_can'] = false;
$died = false;
try { Pasokhban_Inbox::render(); } catch ( Exception $e ) { $died = true; }
ok( $died, 'غیرمدیر از اینباکس بیرون انداخته می‌شود' );
$GLOBALS['wp_current_user_can'] = true;

Pasokhban_Inbox::assets( 'pasokhban_page_pasokhban-inbox' );
Pasokhban_Inbox::assets( 'index.php' );
ok( true, 'بارگذاری دارایی اینباکس بدون خطا' );

/* ========================================================= */
head( '۱۲) تنظیمات ظاهر و جای‌گیری (۱.۲.۰)' );
/* ========================================================= */

$o = get_option( 'pasokhban_options' );
$o['live_enabled'] = 1;
update_option( 'pasokhban_options', $o );
$rp->setValue( $settings, $o );

// مقادیر خارج از محدوده باید محدود شوند
$app = $settings->sanitize( array(
	'live_offset_bottom' => 9999,
	'live_offset_side'   => -50,
	'live_launcher_size' => 500,
	'live_panel_width'   => 100,
	'live_panel_height'  => 9999,
	'live_radius'        => -10,
	'live_blur'          => 999,
	'live_glass_opacity' => 0,
	'live_launcher_label' => '<script>طولانی‌تر از هجده نویسه باشد</script>',
	'live_teaser_text'   => '<b>سلام</b>',
	'live_mobile_sheet'  => 0,
	'live_maximize'      => 1,
	'live_show_footer'   => 0,
	'live_teaser'        => 1,
) );

eq( $app['live_offset_bottom'], 200, 'فاصله از پایین به ۲۰۰ محدود می‌شود' );
eq( $app['live_offset_side'], 0, 'فاصلهٔ منفی از کنار به ۰ می‌رسد' );
eq( $app['live_launcher_size'], 96, 'قطر حباب به ۹۶ محدود می‌شود' );
eq( $app['live_panel_width'], 280, 'عرض پنل کمتر از ۲۸۰ به ۲۸۰ می‌رسد' );
eq( $app['live_panel_height'], 900, 'ارتفاع پنل به ۹۰۰ محدود می‌شود' );
eq( $app['live_radius'], 0, 'گردی منفی به ۰ می‌رسد' );
eq( $app['live_blur'], 80, 'شدت شیشه به ۸۰ محدود می‌شود' );
eq( $app['live_glass_opacity'], 5, 'شفافیت صفر به ۵ می‌رسد' );
eq( mb_strlen( $app['live_launcher_label'], 'UTF-8' ) <= 18, true, 'متن حباب به ۱۸ نویسه محدود می‌شود', $app['live_launcher_label'] );
ok( strpos( $app['live_launcher_label'], '<script>' ) === false, 'تگ از متن حباب پاک می‌شود' );
eq( $app['live_teaser_text'], 'سلام', 'تگ از متن برچسب پاک می‌شود' );
eq( $app['live_mobile_sheet'], 0, 'ورق موبایل قابل خاموش‌کردن است' );
eq( $app['live_maximize'], 1, 'دکمهٔ بزرگ‌نمایی قابل فعال‌کردن است' );
eq( $app['live_show_footer'], 0, 'پابرگ قابل خاموش‌کردن است' );

// همهٔ اینها باید به کلاینت برسند
update_option( 'pasokhban_options', $app );
$rp->setValue( $settings, $app );
$pub = Pasokhban_LiveChat::instance()->public_settings( 'fa' );
foreach ( array( 'offsetBottom', 'offsetSide', 'launcherSize', 'panelWidth', 'panelHeight', 'radius', 'blur', 'glassOpacity', 'launcherLabel', 'teaser', 'teaserText', 'mobileSheet', 'maximize', 'showFooter', 'theme', 'position' ) as $k ) {
	ok( array_key_exists( $k, $pub ), "public_settings فیلد {$k} را می‌فرستد" );
}
eq( $pub['panelWidth'], 280, 'عرض پنل درست به کلاینت می‌رسد' );
eq( $pub['maximize'], true, 'maximize به‌صورت bool می‌رسد' );
eq( $pub['showFooter'], false, 'showFooter خاموش می‌رسد' );

/* ========================================================= */
head( '۱۳) اینباکس — رندر سمت سرور' );
/* ========================================================= */

// چند مکالمهٔ واقعی
$GLOBALS['wp_remote_response'] = array( 'response' => array( 'code' => 200 ), 'body' => json_encode( array( 'choices' => array( array( 'message' => array( 'content' => 'پاسخ' ) ) ) ) ) );
$o = get_option( 'pasokhban_options' );
$o['live_enabled'] = 1; $o['api_key'] = 'sk-test'; $o['rate_limit'] = 0;
update_option( 'pasokhban_options', $o );
$rp->setValue( $settings, $o );

$live2 = Pasokhban_LiveChat::instance();
$created = array();
for ( $i = 1; $i <= 3; $i++ ) {
	$r = $live2->handle_start( new WP_REST_Request( array(), array( 'lang' => 'fa', 'name' => 'بازدیدکننده ' . $i, 'current_url' => 'http://example.test/p' . $i ) ) );
	$live2->handle_send( new WP_REST_Request( array(), array( 'key' => $r['key'], 'content' => 'سؤال شماره ' . $i, 'lang' => 'fa' ) ) );
	$created[] = $r['key'];
}

ob_start();
Pasokhban_Inbox::render();
$html = ob_get_clean();

$n_items = substr_count( $html, 'class="ei-item"' );
ok( $n_items >= 3, 'مکالمات سمت سرور رندر شد (بدون نیاز به JS)', 'تعداد: ' . $n_items );
ok( strpos( $html, 'بازدیدکننده 1' ) !== false
 && strpos( $html, 'بازدیدکننده 2' ) !== false
 && strpos( $html, 'بازدیدکننده 3' ) !== false, 'هر ۳ مکالمهٔ تازه در لیست هستند' );
// آخرین پیام، پاسخ AI است (mock همیشه «پاسخ» می‌دهد) — نه سؤال کاربر
ok( strpos( $html, 'ei-item-msg' ) !== false, 'خلاصهٔ آخرین پیام در لیست نمایش داده می‌شود' );
$row = Pasokhban_DB::get_session_by_key( $created[0] );
eq( $row->last_message, 'پاسخ', 'last_message آخرین پیام مکالمه است (پاسخ AI)' );
eq( $row->last_sender, 'agent', 'last_sender درست ثبت شده' );
ok( strpos( $html, 'ei-diag ok' ) !== false, 'نوار تشخیصی سالم است' );
ok( strpos( $html, 'ei-diag bad' ) === false, 'نوار تشخیصی خطا ندارد' );
preg_match( '/(\d+) مکالمه \((\d+) باز \/ (\d+) بسته\) • (\d+) پیام/u', $html, $dm );
ok( isset( $dm[1] ) && (int) $dm[1] >= 3, 'شمارش تشخیصی درست است', isset( $dm[1] ) ? "total={$dm[1]} open={$dm[2]} msgs={$dm[4]}" : '—' );
ok( strpos( $html, 'id="ei-items"' ) !== false && strpos( $html, 'ei-item-name' ) !== false, 'لیست داخل #ei-items قرار دارد' );

// وقتی جدول خالی است باید پیام راهنما بدهد
$wpdb->query( 'DELETE FROM ' . Pasokhban_DB::sessions_table() );
$wpdb->query( 'DELETE FROM ' . Pasokhban_DB::messages_table() );
ob_start();
Pasokhban_Inbox::render();
$html2 = ob_get_clean();
ok( strpos( $html2, 'مکالمه‌ای در این وضعیت نیست' ) !== false, 'حالت خالی پیام مناسب می‌دهد' );
ok( strpos( $html2, 'هنوز مکالمه‌ای ثبت نشده' ) !== false, 'راهنمای «چطور مکالمه بسازیم» نمایش داده می‌شود' );

/* ========================================================= */
head( '۱۴) رگرسیون: install() بی‌صدا شکست نمی‌خورد' );
/* ========================================================= */

global $wpdb;

// جدول‌ها را بینداز و وانمود کن dbDelta حق CREATE TABLE ندارد
$wpdb->query( 'DROP TABLE IF EXISTS ' . Pasokhban_DB::sessions_table() );
$wpdb->query( 'DROP TABLE IF EXISTS ' . Pasokhban_DB::messages_table() );
Pasokhban_DB::flush_cache();
delete_option( 'pasokhban_db_version' );
delete_option( 'pasokhban_db_error' );

// flag تا پایان این بخش روشن می‌ماند، چون render() خودش هم install() صدا می‌زند
$GLOBALS['wp_dbdelta_fail'] = true;
$res = Pasokhban_DB::install();

ok( is_wp_error( $res ), 'install() وقتی جدول ساخته نشود WP_Error برمی‌گرداند (نه true)' );
ok( is_wp_error( $res ) && false !== strpos( $res->get_error_message(), 'CREATE command denied' ), 'علت واقعی MySQL در خطا هست (قبل از پاک‌شدن last_error گرفته شد)', is_wp_error( $res ) ? $res->get_error_message() : '—' );
eq( get_option( 'pasokhban_db_version' ), false, 'نسخهٔ ساختار ثبت نمی‌شود (تا installed() دروغ نگوید)' );
ok( false !== strpos( (string) get_option( 'pasokhban_db_error', '' ), 'CREATE command denied' ), 'خطا در option ذخیره شد تا اینباکس نشان بدهد' );
eq( Pasokhban_DB::installed(), false, 'installed() درست false می‌دهد' );
eq( Pasokhban_DB::tables_exist(), false, 'tables_exist() درست false می‌دهد' );

// آزمون خودکار باید قبل از render چک شود (render ممکن است تعمیر کند)
$st = Pasokhban_Inbox::self_test();
eq( $st['ok'], false, 'self_test شکست را تشخیص می‌دهد' );

// اینباکس باید خطا را نشان بدهد
ob_start();
Pasokhban_Inbox::render();
$broken = ob_get_clean();
$GLOBALS['wp_dbdelta_fail'] = false;
ok( strpos( $broken, 'ei-diag bad' ) !== false, 'نوار تشخیصی قرمز شد' );
ok( strpos( $broken, 'گفتگوها ذخیره نمی‌شوند' ) !== false, 'هشدار واضح به مدیر نشان داده می‌شود' );
ok( strpos( $broken, 'CREATE command denied' ) !== false, 'متن خطای MySQL در صفحه هست' );
ok( strpos( $broken, 'pasokhban_repair' ) !== false, 'دکمهٔ تعمیر جدول‌ها هست' );
ok( strpos( $broken, '❌' ) !== false, 'وضعیت جدول‌ها ❌ نشان داده می‌شود' );

// حالا تعمیر واقعی
Pasokhban_DB::flush_cache();
$fixed = Pasokhban_DB::install();
eq( $fixed, true, 'install() بعد از رفع مشکل true می‌دهد' );
eq( Pasokhban_DB::installed(), true, 'installed() بعد از تعمیر true شد' );
eq( Pasokhban_DB::tables_exist(), true, 'tables_exist() بعد از تعمیر true شد' );
eq( get_option( 'pasokhban_db_error' ), false, 'خطای ذخیره‌شده پاک شد' );

$st2 = Pasokhban_Inbox::self_test();
eq( $st2['ok'], true, 'self_test بعد از تعمیر پاس می‌شود' );

// fیلتر پیش‌فرض باید «همه» باشد تا چیزی پنهان نماند
$all = Pasokhban_DB::list_sessions( array( 'status' => 'all', 'per_page' => 40, 'page' => 1 ) );
ok( $all['total'] >= 0, 'فیلتر all کار می‌کند' );

/* ========================================================= */
head( '۱۵) تشخیص hook صفحه‌ها (باگ کلیک‌نشدن اینباکس)' );
/* ========================================================= */

// شبیه‌سازی رفتار وردپرس با عنوان منوی فارسی
Pasokhban_Settings::$hooks = array(
	'settings' => 'toplevel_page_pasokhban',
	'inbox'    => '_page_pasokhban-inbox',      // همان چیزی که WP واقعاً می‌سازد
	'contacts' => '_page_pasokhban-contacts',
);

ok( Pasokhban_Settings::is_page( '_page_pasokhban-inbox', 'inbox' ), 'hook واقعی (با عنوان فارسی) شناخته می‌شود' );
ok( Pasokhban_Settings::is_page( 'pasokhban_page_pasokhban-inbox', 'inbox' ), 'hook استاندارد هم به‌عنوان پشتیبان پذیرفته می‌شود' );
ok( Pasokhban_Settings::is_page( 'toplevel_page_pasokhban', 'settings' ), 'صفحهٔ تنظیمات شناخته می‌شود' );
ok( Pasokhban_Settings::is_page( '_page_pasokhban-contacts', 'contacts' ), 'صفحهٔ مخاطبین شناخته می‌شود' );
eq( Pasokhban_Settings::is_page( 'index.php', 'inbox' ), false, 'صفحهٔ بی‌ربط رد می‌شود' );
eq( Pasokhban_Settings::is_page( '_page_pasokhban-contacts', 'inbox' ), false, 'صفحهٔ مخاطبین به‌جای اینباکس پذیرفته نمی‌شود' );

// assets باید با hook واقعی اجرا شود (بدون fatal)
Pasokhban_Inbox::assets( '_page_pasokhban-inbox' );
Pasokhban_Contacts::assets( '_page_pasokhban-contacts' );
Pasokhban_Contacts::assets( 'index.php' );
ok( true, 'بارگذاری دارایی‌ها با hook واقعی بدون خطا' );

/* ========================================================= */
head( '۱۶) فرم پیش از گفتگو (نام/نام خانوادگی/تلفن)' );
/* ========================================================= */

$o = get_option( 'pasokhban_options' );
$o['live_enabled'] = 1; $o['api_key'] = 'sk-test'; $o['rate_limit'] = 0;
$o['live_prechat'] = 1; $o['live_prechat_required'] = 1;
update_option( 'pasokhban_options', $o );
$rp->setValue( $settings, $o );

// پاک‌سازی شمارهٔ تماس
eq( Pasokhban_DB::sanitize_phone( '۰۹۱۲۳۴۵۶۷۸۹' ), '09123456789', 'ارقام فارسی به لاتین تبدیل می‌شود' );
eq( Pasokhban_DB::sanitize_phone( '+98 912-345-6789' ), '+98 912-345-6789', '+ و خط تیره و فاصله مجاز است' );
eq( Pasokhban_DB::sanitize_phone( '<script>0912</script>' ), '0912', 'تگ از شماره پاک می‌شود' );
eq( Pasokhban_DB::sanitize_phone( str_repeat( '9', 60 ) ), str_repeat( '9', 40 ), 'شماره به ۴۰ کاراکتر محدود می‌شود' );

$live3 = Pasokhban_LiveChat::instance();

// شروع با اطلاعات تماس
$r = $live3->handle_start( new WP_REST_Request( array(), array(
	'lang' => 'fa', 'name' => 'سارا', 'family' => 'احمدی', 'phone' => '۰۹۱۲۱۱۱۲۲۳۳', 'current_url' => 'http://example.test/shop',
) ) );
$sid3 = Pasokhban_DB::get_session_by_key( $r['key'] );
eq( $sid3->visitor_name, 'سارا', 'نام ذخیره شد' );
eq( $sid3->visitor_family, 'احمدی', 'نام خانوادگی ذخیره شد' );
eq( $sid3->visitor_phone, '09121112233', 'شمارهٔ تماس نرمال‌سازی و ذخیره شد' );

// ثبت تماس از راه /live/contact
$cr = $live3->handle_contact( new WP_REST_Request( array(), array( 'key' => $r['key'], 'name' => 'مریم', 'family' => 'رضایی', 'phone' => '09351234567' ) ) );
ok( is_array( $cr ) && ! empty( $cr['ok'] ), '/live/contact موفق بود' );
$sid3b = Pasokhban_DB::get_session_by_key( $r['key'] );
eq( $sid3b->visitor_name, 'مریم', 'نام به‌روز شد' );
eq( $sid3b->visitor_family, 'رضایی', 'نام خانوادگی به‌روز شد' );
eq( $sid3b->visitor_phone, '09351234567', 'شماره به‌روز شد' );

// فرم اجباری: فیلد ناقص باید رد شود
$bad = $live3->handle_contact( new WP_REST_Request( array(), array( 'key' => $r['key'], 'name' => '', 'family' => '', 'phone' => '' ) ) );
// چون فیلدها خالی‌اند چیزی به‌روز نمی‌شود ولی اجبار هم بررسی می‌شود
ok( is_wp_error( $bad ) && 'pasokhban_incomplete' === $bad->get_error_code(), 'فرم اجباری با فیلد خالی رد می‌شود', is_wp_error( $bad ) ? $bad->get_error_code() : 'بدون خطا' );

// نشست ناموجود
$noS = $live3->handle_contact( new WP_REST_Request( array(), array( 'key' => 'deadbeefdeadbeefdeadbeefdeadbeef', 'name' => 'x', 'family' => 'y', 'phone' => '0912' ) ) );
ok( is_wp_error( $noS ), '/live/contact با نشست ناموجود خطا می‌دهد' );

// prechat باید در تنظیمات عمومی به کلاینت برود
$pub2 = $live3->public_settings( 'fa' );
eq( $pub2['prechat'], true, 'prechat به کلاینت می‌رسد' );
eq( $pub2['prechatRequired'], true, 'prechatRequired به کلاینت می‌رسد' );

// shape_session باید family/phone داشته باشد
$sh = $live3->admin_sessions( new WP_REST_Request( array( 'status' => 'all', 'per_page' => 50, 'page' => 1 ) ) );
$found = null;
foreach ( $sh['items'] as $it ) { if ( (int) $it['id'] === (int) $sid3b->id ) { $found = $it; break; } }
ok( null !== $found, 'مکالمه در لیست اینباکس هست' );
eq( $found ? $found['family'] : null, 'رضایی', 'نام خانوادگی به اینباکس می‌رسد' );
eq( $found ? $found['phone'] : null, '09351234567', 'شمارهٔ تماس به اینباکس می‌رسد' );

/* ========================================================= */
head( '۱۷) صفحهٔ مخاطبین و خروجی CSV' );
/* ========================================================= */

// چند مکالمهٔ دیگر با مشخصات
foreach ( array( array( 'name' => 'علی', 'family' => 'کریمی', 'phone' => '09121234567' ),
                 array( 'name' => 'نگار', 'family' => 'موسوی', 'phone' => '09359876543' ) ) as $c ) {
	$rr = $live3->handle_start( new WP_REST_Request( array(), array( 'lang' => 'fa', 'name' => $c['name'], 'family' => $c['family'], 'phone' => $c['phone'] ) ) );
	$live3->handle_send( new WP_REST_Request( array(), array( 'key' => $rr['key'], 'content' => 'سلام ' . $c['name'], 'lang' => 'fa' ) ) );
}

$contacts = Pasokhban_DB::list_contacts( array( 'per_page' => 50, 'page' => 1 ) );
ok( $contacts['total'] >= 3, 'لیست مخاطبین آیتم دارد', 'total=' . $contacts['total'] );
ok( isset( $contacts['items'][0]->msg_count ), 'تعداد پیام برای هر مخاطب محاسبه می‌شود' );
ok( isset( $contacts['items'][0]->visitor_msgs ), 'تعداد پیام کاربر جداگانه محاسبه می‌شود' );

// جستجو
$srch = Pasokhban_DB::list_contacts( array( 'search' => 'کریمی', 'per_page' => 50, 'page' => 1 ) );
eq( $srch['total'], 1, 'جستجو با نام خانوادگی کار می‌کند' );
eq( $srch['items'][0]->visitor_name, 'علی', 'مخاطب درست پیدا شد' );

// جستجو با شماره
$srch2 = Pasokhban_DB::list_contacts( array( 'search' => '09359876543', 'per_page' => 50, 'page' => 1 ) );
eq( $srch2['total'], 1, 'جستجو با شمارهٔ تماس کار می‌کند' );

// فقط دارای مشخصات
$only = Pasokhban_DB::list_contacts( array( 'per_page' => 50, 'page' => 1, 'only_with_contact' => true ) );
ok( $only['total'] >= 3, 'فیلتر «فقط دارای مشخصات» کار می‌کند' );

// رندر صفحهٔ مخاطبین
ob_start();
Pasokhban_Contacts::render();
$chtml = ob_get_clean();
ok( strpos( $chtml, 'psb-admin' ) !== false, 'پوستهٔ شیشه‌ای اعمال شده' );
ok( strpos( $chtml, 'pasokhban_export_csv' ) !== false, 'دکمهٔ خروجی CSV هست' );
ok( strpos( $chtml, 'سارا' ) !== false || strpos( $chtml, 'مریم' ) !== false || strpos( $chtml, 'علی' ) !== false, 'نام مخاطبین در جدول هست' );
ok( strpos( $chtml, '09351234567' ) !== false || strpos( $chtml, '09121234567' ) !== false, 'شمارهٔ تماس در جدول هست' );
ok( strpos( $chtml, 'psb-adm-stats' ) !== false, 'کارت‌های آمار رندر شد' );
ok( substr_count( $chtml, '<tr>' ) >= 4, 'ردیف‌های جدول ساخته شد' );

// nonce روی لینک CSV
ok( strpos( $chtml, '_wpnonce' ) !== false, 'لینک CSV nonce دارد' );

/* ========================================================= */
echo "\n" . str_repeat( '─', 52 ) . "\n";
if ( $FAIL === 0 ) {
	echo "\033[42;30m همهٔ {$PASS} تست پاس شد \033[0m\n";
} else {
	echo "\033[41;97m {$FAIL} تست شکست خورد \033[0m (پاس: {$PASS})\n";
	foreach ( $FAILURES as $f ) echo "   • {$f}\n";
}
echo str_repeat( '─', 52 ) . "\n";
exit( $FAIL === 0 ? 0 : 1 );
