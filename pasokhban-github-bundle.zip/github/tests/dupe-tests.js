/**
 * تست رگرسیون: دوبار نمایش داده‌شدن پیام‌ها.
 *
 * باگ ۱.۵.۳: در حالت جریان‌دار، رویداد {visitor:id} از سرور هندل نمی‌شد،
 * پس S.lastId عقب می‌ماند و poll (هر ۴ ثانیه) همان پیام‌ها را دوباره
 * می‌آورد. یعنی «دیر جواب دادن» و «دوبار ارسال شدن» یک علت داشتند.
 *
 * mock این تست سرور را faithful شبیه‌سازی می‌کند: poll فقط پیام‌هایی را
 * برمی‌گرداند که واقعاً ذخیره شده‌اند (نه هر id بزرگ‌تر از after).
 */
const fs = require('fs');
const { JSDOM } = require('jsdom');
const { ReadableStream } = require('stream/web');
const { TextDecoder } = require('util');

const JS = fs.readFileSync(__dirname + '/../plugin/assets/js/pasokhban-chat.js', 'utf8');

let pass = 0, fail = 0; const fails = [];
const ok = (c, l, x) => { if (c) { pass++; console.log(`  \x1b[32m✓\x1b[0m ${l}`); } else { fail++; fails.push(l + (x ? ' — ' + x : '')); console.log(`  \x1b[31m✗\x1b[0m ${l}` + (x ? '  → ' + x : '')); } };
const eq = (a, b, l) => ok(JSON.stringify(a) === JSON.stringify(b), l, `انتظار ${JSON.stringify(b)} / دریافت ${JSON.stringify(a)}`);
const head = t => console.log(`\n\x1b[1m${t}\x1b[0m`);
const wait = ms => new Promise(r => setTimeout(r, ms));

const SETTINGS = {
  title: 'چت', agentName: 'پشتیبانی', greeting: 'سلام', placeholder: 'بنویس',
  accent: '#22d3ee', position: 'start', autoOpen: false, autoDelay: 5, starter: [],
  humanHandoff: true, sound: false, offlineNote: '',
  offsetBottom: 18, offsetSide: 18, launcherSize: 62, panelWidth: 384, panelHeight: 620,
  radius: 28, blur: 30, glassOpacity: 62, launcherLabel: '', teaser: false, teaserText: '',
  mobileSheet: true, maximize: true, showFooter: true, theme: 'auto',
  prechat: false, streaming: true, csat: true,
  streamUrl: 'http://e.test/wp-json/pasokhban/v1/live/stream'
};

const dom = new JSDOM('<!DOCTYPE html><html><body><div id="pasokhban-live" data-mode="widget"></div></body></html>',
  { url: 'http://e.test/', pretendToBeVisual: true, runScripts: 'dangerously' });
const w = dom.window, d = w.document;

w.ReadableStream = ReadableStream;
w.TextDecoder = TextDecoder;
w.Response = class {
  constructor(body, o) {
    o = o || {}; this.body = body; this.status = o.status || 200;
    this.ok = this.status >= 200 && this.status < 300;
    const raw = o.headers || {}, lower = {};
    Object.keys(raw).forEach(k => { lower[k.toLowerCase()] = raw[k]; });
    this.headers = { get: (k) => (lower[String(k).toLowerCase()] || null) };
  }
  json() { return Promise.resolve(JSON.parse(this.body)); }
};

w.PASOKHBAN_CHAT = { restUrl: '/wp-json/pasokhban/v1', nonce: 'n', lang: 'fa' };
w.PASOKHBAN_CHAT_SETTINGS = SETTINGS;

// ── شبیه‌سازی سرور: فقط پیام‌های واقعاً ذخیره‌شده برگردانده می‌شوند ──
const DB = [];              // پیام‌های ذخیره‌شده
let nextId = 500;
const calls = [];
const TOKENS = ['پاسخ ', 'آهسته ', 'برای ', 'آزمون ', 'race.'];

w.fetch = (url, opt) => {
  opt = opt || {};
  const path = String(url).replace(/^.*\/v1/, '');
  const body = opt.body ? JSON.parse(opt.body) : {};
  calls.push({ path });

  if (path.indexOf('/live/stream') === 0) {
    const enc = new TextEncoder();
    let i = 0, visitorMsg = null, agentMsg = null;

    // سرور اول پیام کاربر را ذخیره می‌کند
    visitorMsg = { id: nextId++, sender: 'visitor', content: body.content, meta: {}, time: new Date().toISOString() };
    DB.push(visitorMsg);

    const stream = new ReadableStream({
      pull(c) {
        if (i === 0) {
          c.enqueue(enc.encode('data: ' + JSON.stringify({ visitor: visitorMsg.id }) + '\n\n'));
          i++;
          return new Promise(r => setTimeout(r, 30));
        }
        if (i <= TOKENS.length) {
          c.enqueue(enc.encode('data: ' + JSON.stringify({ t: TOKENS[i - 1] }) + '\n\n'));
          i++;
          return new Promise(r => setTimeout(r, 40));
        }
        // در پایان، پاسخ کامل ذخیره می‌شود
        agentMsg = { id: nextId++, sender: 'agent', content: TOKENS.join(''), meta: { via: 'ai' }, time: new Date().toISOString() };
        DB.push(agentMsg);
        c.enqueue(enc.encode('data: ' + JSON.stringify({ done: true, id: agentMsg.id, ms: 2000, sources: [] }) + '\n\n'));
        c.close();
      }
    });
    return Promise.resolve(new Response(stream, { status: 200, headers: { 'Content-Type': 'text/event-stream' } }));
  }

  if (path.indexOf('/live/poll') === 0) {
    const after = parseInt((String(url).match(/after=(\d+)/) || [0, 0])[1], 10);
    // فقط پیام‌های واقعاً ذخیره‌شده با id بزرگ‌تر از after
    const msgs = DB.filter(m => m.id > after);
    return Promise.resolve(new Response(JSON.stringify({ messages: msgs, mode: 'ai', status: null, typing: false, agentOnline: false }),
      { status: 200, headers: { 'Content-Type': 'application/json' } }));
  }

  if (path.indexOf('/live/start') === 0) {
    return Promise.resolve(new Response(JSON.stringify({ key: 'a1b2c3d4e5f60718293a4b5c6d7e8f90', mode: 'ai', status: 'open', messages: [], agentOnline: false, settings: SETTINGS }),
      { status: 200, headers: { 'Content-Type': 'application/json' } }));
  }

  return Promise.resolve(new Response(JSON.stringify({ ok: true }), { status: 200, headers: { 'Content-Type': 'application/json' } }));
};

const s = d.createElement('script');
s.textContent = JS;
d.body.appendChild(s);

(async () => {
  await wait(250);
  d.querySelector('.psb-launcher').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
  await wait(300);

  head('۱) race: poll وسط جریان اجرا می‌شود');
  const inp = d.querySelector('.psb-input');
  inp.value = 'سؤال من';
  d.querySelector('.psb-send').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
  await wait(60);

  ok(!!d.querySelector('.psb-msg.agent.is-streaming'), 'جریان شروع شد');
  eq(d.querySelectorAll('.psb-msg.visitor').length, 1, 'در شروع، یک حباب پیام کاربر هست');

  // poll وسط جریان (دقیقاً همان حالتی که باگ می‌داد)
  d.dispatchEvent(new w.Event('visibilitychange'));
  await wait(80);
  eq(d.querySelectorAll('.psb-msg.visitor').length, 1, 'poll وسط جریان، پیام کاربر را دوباره نساخت');
  // greeting هم .psb-msg.agent است، پس فقط حباب‌های غیرخوش‌آمد را می‌شماریم
  const nonGreet = () => Array.from(d.querySelectorAll('.psb-msg.agent')).filter(b => !b.textContent.startsWith('سلام'));
  eq(nonGreet().length, 1, 'poll وسط جریان، پاسخ AI را دوباره نساخت');

  head('۲) پایان جریان');
  await wait(600);
  const vb = d.querySelectorAll('.psb-msg.visitor');
  eq(vb.length, 1, 'فقط یک حباب پیام کاربر وجود دارد');
  eq(vb[0].querySelector('.psb-msg-text').textContent, 'سؤال من', 'متن پیام کاربر درست است');
  ok(vb[0].getAttribute('data-mid') !== null, 'شناسهٔ سرور به حباب کاربر چسبید', String(vb[0].getAttribute('data-mid')));

  const ab = Array.from(d.querySelectorAll('.psb-msg.agent')).filter(b => !b.textContent.startsWith('سلام'));
  eq(ab.length, 1, 'فقط یک حباب پاسخ AI وجود دارد (دوبار نشده)');
  eq(ab[0].querySelector('.psb-msg-text').textContent, TOKENS.join(''), 'متن پاسخ کامل و یک‌بار است');
  ok(ab[0].getAttribute('data-mid') !== null, 'شناسهٔ پاسخ به حباب چسبید', String(ab[0].getAttribute('data-mid')));

  head('۳) poll بعد از جریان هم تکراری نمی‌سازد');
  const cnt = d.querySelectorAll('.psb-msg').length;
  d.dispatchEvent(new w.Event('visibilitychange'));
  await wait(150);
  eq(d.querySelectorAll('.psb-msg').length, cnt, 'poll بعد از پایان جریان هیچ حباب تکراری نساخت');

  head('۴) پیام دوم هم دوبار نمی‌شود');
  inp.value = 'سؤال دوم';
  d.querySelector('.psb-send').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
  await wait(800);
  const v2 = Array.from(d.querySelectorAll('.psb-msg.visitor')).filter(b => b.textContent.indexOf('سؤال دوم') >= 0);
  eq(v2.length, 1, 'پیام دوم هم فقط یک بار نمایش داده شد');
  const a2 = Array.from(d.querySelectorAll('.psb-msg.agent')).filter(b => b.textContent.indexOf(TOKENS.join('')) >= 0);
  eq(a2.length, 2, 'دو پاسخ AI برای دو سؤال (نه بیشتر)');

  console.log('\n' + '─'.repeat(52));
  if (fail === 0) console.log(`\x1b[42;30m همهٔ ${pass} تست دوبارارسال پاس شد \x1b[0m`);
  else { console.log(`\x1b[41;97m ${fail} تست شکست خورد \x1b[0m (پاس: ${pass})`); fails.forEach(f => console.log('   • ' + f)); }
  console.log('─'.repeat(52));
  process.exit(fail === 0 ? 0 : 1);
})();
