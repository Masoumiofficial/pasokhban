<?php
/**
 * تست رفع نقاط ضعف: نگهداری داده · فونت شرطی · fallback هوشمند
 */

require_once __DIR__ . '/wp-stubs.php';

$PASS = 0; $FAIL = 0; $FAILURES = array();

function ok( $cond, $label, $extra = '' ) {
	global $PASS, $FAIL, $FAILURES;
	if ( $cond ) { $PASS++; echo "  \033[32m✓\033[0m {$label}\n"; }
	else { $FAIL++; $FAILURES[] = $label . ( $extra ? " — {$extra}" : '' ); echo "  \033[31m✗\033[0m {$label}" . ( $extra ? "  → {$extra}" : '' ) . "\n"; }
}
function head( $t ) { echo "\n\033[1m{$t}\033[0m\n"; }
function eq( $a, $b, $label ) { ok( $a === $b, $label, 'انتظار ' . var_export( $b, true ) . ' / دریافت ' . var_export( $a, true ) ); }

update_option( 'pasokhban_options', array( 'retention_days' => 30, 'cdn_font' => 1 ) );
$settings = Pasokhban_Settings::instance();
$rp = new ReflectionProperty( 'Pasokhban_Settings', 'options' );
$rp->setAccessible( true );
$rp->setValue( $settings, get_option( 'pasokhban_options' ) );

Pasokhban_DB::install();

/* ========================================================= */
head( '۱) نگهداری داده (retention)' );
/* ========================================================= */

global $wpdb;

// سه نشست: یکی قدیمی و بسته (باید برود)، یکی قدیمی ولی باز (بماند)،
// یکی قدیمی و بسته ولی با شمارهٔ تماس (بماند — سرنخ فروش)
$old = gmdate( 'Y-m-d H:i:s', time() - ( 100 * DAY_IN_SECONDS ) );

$wpdb->insert( Pasokhban_DB::sessions_table(), array(
	'session_key' => 'oldclosed0000000000000000000001', 'visitor_phone' => '',
	'status' => 'closed', 'created_at' => $old, 'updated_at' => $old,
), array( '%s', '%s', '%s', '%s', '%s' ) );

$wpdb->insert( Pasokhban_DB::sessions_table(), array(
	'session_key' => 'oldopen00000000000000000000002', 'visitor_phone' => '',
	'status' => 'open', 'created_at' => $old, 'updated_at' => $old,
), array( '%s', '%s', '%s', '%s', '%s' ) );

$wpdb->insert( Pasokhban_DB::sessions_table(), array(
	'session_key' => 'oldphone00000000000000000000003', 'visitor_phone' => '09121112233',
	'status' => 'closed', 'created_at' => $old, 'updated_at' => $old,
), array( '%s', '%s', '%s', '%s', '%s' ) );

// پیام و امتیاز برای نشست قدیمیِ بسته
$sid = (int) $wpdb->get_var( "SELECT id FROM " . Pasokhban_DB::sessions_table() . " WHERE session_key='oldclosed0000000000000000000001'" );
Pasokhban_DB::add_message( $sid, 'visitor', 'سلام قدیمی' );
Pasokhban_DB::add_message( $sid, 'agent', 'پاسخ قدیمی' );
Pasokhban_DB::save_feedback( $sid, 1, 1 );

$msg_before = (int) $wpdb->get_var( "SELECT COUNT(*) FROM " . Pasokhban_DB::messages_table() . " WHERE session_id = $sid" );
eq( $msg_before, 2, 'دو پیام برای نشست قدیمی ثبت شد' );

$removed = Pasokhban_DB::cleanup_old( 30 );
eq( $removed, 1, 'فقط یک نشست حذف شد' );

ok( ! $wpdb->get_var( "SELECT id FROM " . Pasokhban_DB::sessions_table() . " WHERE session_key='oldclosed0000000000000000000001'" ), 'نشست قدیمیِ بسته حذف شد' );
ok( $wpdb->get_var( "SELECT id FROM " . Pasokhban_DB::sessions_table() . " WHERE session_key='oldopen00000000000000000000002'" ), 'نشست قدیمیِ باز نگه داشته شد' );
ok( $wpdb->get_var( "SELECT id FROM " . Pasokhban_DB::sessions_table() . " WHERE session_key='oldphone00000000000000000000003'" ), 'نشست دارای شمارهٔ تماس نگه داشته شد (سرنخ فروش)' );

$msg_after = (int) $wpdb->get_var( "SELECT COUNT(*) FROM " . Pasokhban_DB::messages_table() . " WHERE session_id = $sid" );
eq( $msg_after, 0, 'پیام‌هایش هم پاک شدند' );
$fb_after = (int) $wpdb->get_var( "SELECT COUNT(*) FROM " . Pasokhban_DB::feedback_table() . " WHERE session_id = $sid" );
eq( $fb_after, 0, 'امتیازهایش هم پاک شدند' );

// retention = 0 یعنی هیچ‌کاری نکن
$before_all = (int) $wpdb->get_var( "SELECT COUNT(*) FROM " . Pasokhban_DB::sessions_table() );
eq( Pasokhban_DB::cleanup_old( 0 ), 0, 'با retention=0 هیچ چیز حذف نمی‌شود' );
eq( (int) $wpdb->get_var( "SELECT COUNT(*) FROM " . Pasokhban_DB::sessions_table() ), $before_all, 'تعداد نشست‌ها عوض نشد' );

// زمان‌بندی
Pasokhban_DB::schedule_cleanup();
ok( false !== $GLOBALS['wp_cron']['pasokhban_daily_cleanup'], 'پاک‌سازی روزانه زمان‌بندی شد' );
eq( $GLOBALS['wp_cron']['pasokhban_daily_cleanup'], 'daily', 'بازهٔ زمان‌بندی daily است' );
Pasokhban_DB::unschedule_cleanup();
ok( ! isset( $GLOBALS['wp_cron']['pasokhban_daily_cleanup'] ), 'لغو زمان‌بندی کار می‌کند' );

// محدودسازی retention
$san = $settings->sanitize( array( 'retention_days' => 999999 ) );
eq( $san['retention_days'], 3650, 'retention به ۳۶۵۰ روز محدود می‌شود' );
$san2 = $settings->sanitize( array( 'retention_days' => -5 ) );
eq( $san2['retention_days'], 0, 'retention منفی به صفر می‌رسد' );

/* ========================================================= */
head( '۲) فونت شرطی' );
/* ========================================================= */

$src = file_get_contents( PASOKHBAN_FILE );
ok( false !== strpos( $src, "if ( ! empty( \$opts['cdn_font'] ) )" ), 'بارگذاری فونت شرطی است' );
ok( false !== strpos( $src, '$font_dep' ), 'وابستگی فونت متغیر است' );
eq( substr_count( $src, "array( 'vazirmatn' )," ), 0, 'هیچ وابستگی سخت‌کدشده به vazirmatn نمانده' );

// cdn_font در sanitize
$san3 = $settings->sanitize( array( 'cdn_font' => 0 ) );
eq( $san3['cdn_font'], 0, 'cdn_font قابل خاموش‌کردن است' );
$san4 = $settings->sanitize( array( 'cdn_font' => 1 ) );
eq( $san4['cdn_font'], 1, 'cdn_font قابل روشن‌کردن است' );

/* ========================================================= */
head( '۳) همهٔ کلیدهای جدید در فرم هستند' );
/* ========================================================= */

ob_start();
$settings->render_page();
$html = ob_get_clean();

foreach ( array( 'cdn_font', 'retention_days' ) as $k ) {
	ok( false !== strpos( $html, "pasokhban_options[$k]" ), "فیلد $k در فرم تنظیمات هست" );
}

echo "\n" . str_repeat( '─', 52 ) . "\n";
if ( 0 === $FAIL ) {
	echo "\033[42;30m همهٔ {$PASS} تست نقاط‌ضعف پاس شد \033[0m\n";
} else {
	echo "\033[41;97m {$FAIL} تست شکست خورد \033[0m (پاس: {$PASS})\n";
	foreach ( $FAILURES as $f ) {
		echo "   • {$f}\n";
	}
}
echo str_repeat( '─', 52 ) . "\n";
exit( 0 === $FAIL ? 0 : 1 );
