<?php
/**
 * تست انتقال به پشتیبان انسانی (handoff).
 */

require_once __DIR__ . '/wp-stubs.php';

$PASS = 0; $FAIL = 0; $FAILURES = array();

function ok( $cond, $label, $extra = '' ) {
	global $PASS, $FAIL, $FAILURES;
	if ( $cond ) { $PASS++; echo "  \033[32m✓\033[0m {$label}\n"; }
	else { $FAIL++; $FAILURES[] = $label . ( $extra ? " — {$extra}" : '' ); echo "  \033[31m✗\033[0m {$label}" . ( $extra ? "  → {$extra}" : '' ) . "\n"; }
}
function head( $t ) { echo "\n\033[1m{$t}\033[0m\n"; }
function eq( $a, $b, $label ) { ok( $a === $b, $label, 'انتظار ' . var_export( $b, true ) . ' / دریافت ' . var_export( $a, true ) ); }

$opts = array(
	'live_enabled'       => 1,
	'live_human_enabled' => 1,
	'api_key'            => 'sk-test',
	'rate_limit'         => 0,
	'live_history'       => 20,
	'knowledge'          => 0,
	'notify_email'       => 1,
	'notify_telegram'    => 0,
);
update_option( 'pasokhban_options', $opts );
$settings = Pasokhban_Settings::instance();
$rp = new ReflectionProperty( 'Pasokhban_Settings', 'options' );
$rp->setAccessible( true );
$rp->setValue( $settings, $opts );

Pasokhban_DB::install();
$live = Pasokhban_LiveChat::instance();
$live->register_routes();

/* ========================================================= */
head( '۱) مسیر handoff ثبت شده' );
/* ========================================================= */

ok( isset( $GLOBALS['wp_rest_routes']['pasokhban/v1/live/handoff'] ), 'مسیر /live/handoff ثبت شد' );

/* ========================================================= */
head( '۲) انتقال به پشتیبان انسانی' );
/* ========================================================= */

$r   = $live->handle_start( new WP_REST_Request( array(), array( 'lang' => 'fa', 'name' => 'سارا', 'family' => 'احمدی', 'phone' => '09121112233' ) ) );
$key = $r['key'];
$sid = Pasokhban_DB::get_session_by_key( $key );

eq( $sid->mode, 'ai', 'قبل از handoff حالت ai است' );

$ho = $live->handle_handoff( new WP_REST_Request( array(), array( 'key' => $key, 'lang' => 'fa' ) ) );

ok( is_array( $ho ) && ! is_wp_error( $ho ), 'handoff موفق بود', is_wp_error( $ho ) ? $ho->get_error_message() : '' );
eq( isset( $ho['mode'] ) ? $ho['mode'] : null, 'agent', 'حالت به agent تغییر کرد' );
ok( ! empty( $ho['note'] ), 'پیام «منتقل شد» برگشت' );
ok( false !== strpos( $ho['note'], 'پشتیبان انسانی' ), 'متن پیام درست است', $ho['note'] );

$after = Pasokhban_DB::get_session_by_key( $key );
eq( $after->mode, 'agent', 'در دیتابیس هم mode=agent ذخیره شد' );

$msgs = Pasokhban_DB::get_messages( (int) $sid->id );
$last = $msgs[ count( $msgs ) - 1 ];
eq( $last->sender, 'system', 'پیام اطلاع‌رسانی نقش system دارد' );
eq( isset( $last->meta['note'] ) ? $last->meta['note'] : null, 'handoff', 'علامت handoff ثبت شد' );

// اعلان به مدیر رفته باشد
ok( ! empty( $GLOBALS['wp_mails'] ), 'اعلان به مدیر ارسال شد' );
$mail = end( $GLOBALS['wp_mails'] );
ok( false !== strpos( $mail['subject'], 'پشتیبان انسانی' ), 'موضوع ایمیل درست است', $mail['subject'] );
ok( false !== strpos( $mail['message'], 'سارا' ), 'نام کاربر در ایمیل هست' );
ok( false !== strpos( $mail['message'], '09121112233' ), 'شمارهٔ تماس در ایمیل هست' );

/* ========================================================= */
head( '۳) بعد از handoff، AI پاسخ نمی‌دهد' );
/* ========================================================= */

$GLOBALS['wp_remote_calls'] = array();
$GLOBALS['wp_remote_response'] = array(
	'response' => array( 'code' => 200 ),
	'body'     => json_encode( array( 'choices' => array( array( 'message' => array( 'content' => 'پاسخ AI' ) ) ) ) ),
);

// پیام کاربر در حالت agent
Pasokhban_DB::add_message( (int) $sid->id, 'visitor', 'سلام پشتیبان' );
$ans = $live->handle_answer( new WP_REST_Request( array(), array( 'key' => $key ) ) );

ok( is_array( $ans ) && ! empty( $ans['queued'] ), 'در حالت agent، queued برمی‌گردد نه پاسخ AI' );
eq( count( $GLOBALS['wp_remote_calls'] ), 0, 'هیچ فراخوانی به API هوش مصنوعی انجام نشد' );

/* ========================================================= */
head( '۴) handoff تکراری پیام تکراری نمی‌سازد' );
/* ========================================================= */

$before = count( Pasokhban_DB::get_messages( (int) $sid->id ) );
$ho2 = $live->handle_handoff( new WP_REST_Request( array(), array( 'key' => $key, 'lang' => 'fa' ) ) );
eq( isset( $ho2['already'] ) ? $ho2['already'] : null, true, 'handoff تکراری علامت already می‌دهد' );
eq( count( Pasokhban_DB::get_messages( (int) $sid->id ) ), $before, 'پیام تکراری ساخته نشد' );

/* ========================================================= */
head( '۵) کنترل‌ها' );
/* ========================================================= */

// نشست ناموجود
$bad = $live->handle_handoff( new WP_REST_Request( array(), array( 'key' => 'deadbeefdeadbeefdeadbeefdeadbeef' ) ) );
ok( is_wp_error( $bad ), 'نشست ناموجود رد می‌شود' );

// پشتیبانی انسانی خاموش
$o2 = $opts;
$o2['live_human_enabled'] = 0;
$rp->setValue( $settings, $o2 );
$r2   = $live->handle_start( new WP_REST_Request( array(), array( 'lang' => 'fa' ) ) );
$bad2 = $live->handle_handoff( new WP_REST_Request( array(), array( 'key' => $r2['key'] ) ) );
ok( is_wp_error( $bad2 ) && 'pasokhban_no_human' === $bad2->get_error_code(), 'با پشتیبانی انسانی خاموش، ۴۰۳ می‌دهد' );

// زبان انگلیسی
$rp->setValue( $settings, $opts );
$r3  = $live->handle_start( new WP_REST_Request( array(), array( 'lang' => 'en' ) ) );
$ho3 = $live->handle_handoff( new WP_REST_Request( array(), array( 'key' => $r3['key'], 'lang' => 'en' ) ) );
ok( false !== strpos( $ho3['note'], 'human agent' ), 'پیام انگلیسی درست است', $ho3['note'] );

echo "\n" . str_repeat( '─', 52 ) . "\n";
if ( 0 === $FAIL ) {
	echo "\033[42;30m همهٔ {$PASS} تست handoff پاس شد \033[0m\n";
} else {
	echo "\033[41;97m {$FAIL} تست شکست خورد \033[0m (پاس: {$PASS})\n";
	foreach ( $FAILURES as $f ) {
		echo "   • {$f}\n";
	}
}
echo str_repeat( '─', 52 ) . "\n";
exit( 0 === $FAIL ? 0 : 1 );
