<?php
/**
 * آزمون جدا: رفتار RAG وقتی جدول ایندکس وجود ندارد.
 *
 * چرا فایل جدا: table_ready() نتیجه را در طول درخواست کش می‌کند، پس
 * «جدول نیست» باید قبل از اولین فراخوانی بررسی شود. در یک فرایند تازه
 * اجرا می‌شود.
 *
 * سناریوی واقعی: هاستی که کاربر MySQL حق CREATE TABLE ندارد؛ dbDelta
 * بی‌صدا رد می‌شود. بدون این محافظ، هر پیام چت یک خطای دیتابیس چاپ
 * می‌کرد و خروجی JSON را می‌شکست.
 */

require_once __DIR__ . '/wp-stubs.php';

$PASS = 0; $FAIL = 0; $FAILURES = array();
function ok( $cond, $label, $extra = '' ) {
	global $PASS, $FAIL, $FAILURES;
	if ( $cond ) { $PASS++; echo "  \033[32m✓\033[0m {$label}\n"; }
	else { $FAIL++; $FAILURES[] = $label; echo "  \033[31m✗\033[0m {$label}" . ( $extra ? "  → {$extra}" : '' ) . "\n"; }
}
function eq( $a, $b, $label ) { ok( $a === $b, $label, 'انتظار ' . var_export( $b, true ) . ' / دریافت ' . var_export( $a, true ) ); }
echo "\n\033[1mجدول ایندکس وجود ندارد\033[0m\n";

$GLOBALS['wp_posts'] = array(
	(object) array( 'ID' => 5, 'post_title' => 'نوشته', 'post_content' => str_repeat( 'متن نمونه. ', 20 ), 'post_type' => 'post', 'post_status' => 'publish' ),
);
update_option( 'pasokhban_options', array(
	'api_key' => 'sk-x', 'base_url' => 'https://api.example.test/v1', 'rag_vector' => 1, 'rag_dims' => 0,
) );
Pasokhban_Settings::instance();

// عمداً install() صدا زده نمی‌شود — جدول ساخته نمی‌شود.
$exists = $GLOBALS['wpdb']->get_var( "SELECT name FROM sqlite_master WHERE type='table' AND name='wp_pasokhban_chunks'" );
ok( ! $exists, 'جدول ایندکس واقعاً وجود ندارد (شرط آزمون)' );

$rag = Pasokhban_RAG::instance();

ok( ! $rag->table_ready(), 'table_ready() درست false می‌دهد' );
eq( $rag->count_chunks(), 0, 'شمارش روی جدول ناموجود ۰ است، نه خطا' );
eq( $rag->retrieve( 'چطور پولم را پس بگیرم؟' ), null, 'جست‌وجو null می‌دهد تا مسیر کلیدواژه‌ای کار کند' );

$res = $rag->build( array() );
eq( $res['ok'], false, 'ساخت ایندکس شکست می‌خورد' );
ok( ! empty( $res['errors'] ) && false !== strpos( $res['errors'][0], 'CREATE TABLE' ), 'دلیل شکست به فارسی و قابل‌فهم گزارش شد', isset( $res['errors'][0] ) ? $res['errors'][0] : '—' );
ok( false !== strpos( $rag->state()['error'], 'CREATE TABLE' ), 'خطا در وضعیت ثبت شد تا در پیشخوان دیده شود' );

// هیچ‌کدام از این‌ها نباید خروجی چاپ کنند (وگرنه JSON می‌شکست)
ob_start();
$rag->retrieve( 'سؤال' );
$rag->count_chunks();
$rag->on_delete_post( 5 );
$rag->clear();
$printed = ob_get_clean();
eq( trim( (string) $printed ), '', 'چیزی چاپ نشد (خروجی JSON نمی‌شکند)', trim( (string) $printed ) );

// و get_site_docs هم سالم می‌ماند
$docs = Pasokhban_API::instance()->get_site_docs( 'چطور پولم را پس بگیرم؟' );
eq( $docs['engine'], 'keyword', 'get_site_docs به مسیر کلیدواژه‌ای می‌افتد' );

echo "\n────────────────────────────────────────────────────\n";
if ( 0 === $FAIL ) {
	echo "\033[42;30m همهٔ {$PASS} تست «جدول ناموجود» پاس شد \033[0m\n";
} else {
	echo "\033[41;97m {$FAIL} تست شکست خورد \033[0m (پاس: {$PASS})\n";
	foreach ( $FAILURES as $f ) { echo "   • {$f}\n"; }
}
echo "────────────────────────────────────────────────────\n";
exit( $FAIL > 0 ? 1 : 0 );
