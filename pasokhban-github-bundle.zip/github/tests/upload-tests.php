<?php
/**
 * تست‌های ۲.۰.۰ — ارسال فایل و تصویر در چت.
 *
 * تمرکز روی امنیت است: این تنها بخشی از پلاگین است که ورودی باینری از
 * کاربر ناشناس می‌گیرد. هر آزمونی که اینجا هست، یک حملهٔ واقعی را
 * شبیه‌سازی می‌کند.
 */

require_once __DIR__ . '/wp-stubs.php';

$PASS = 0; $FAIL = 0; $FAILURES = array();

function ok( $cond, $label, $extra = '' ) {
	global $PASS, $FAIL, $FAILURES;
	if ( $cond ) { $PASS++; echo "  \033[32m✓\033[0m {$label}\n"; }
	else { $FAIL++; $FAILURES[] = $label . ( $extra ? " — {$extra}" : '' ); echo "  \033[31m✗\033[0m {$label}" . ( $extra ? "  → {$extra}" : '' ) . "\n"; }
}
function head( $t ) { echo "\n\033[1m{$t}\033[0m\n"; }
function eq( $a, $b, $label ) { ok( $a === $b, $label, 'انتظار ' . var_export( $b, true ) . ' / دریافت ' . var_export( $a, true ) ); }
function code( $r ) {
	if ( ! is_wp_error( $r ) ) { return 'no-error'; }
	$d = $r->get_error_data();
	return ( is_array( $d ) && isset( $d['status'] ) ) ? (int) $d['status'] : 0;
}

/* ---- فایل‌های آزمایشی واقعی ---- */
$TMP = PASOKHBAN_TESTS_DIR . '/tmp-uploads';
@mkdir( $TMP, 0777, true );
array_map( 'unlink', (array) glob( $TMP . '/*' ) );

/**
 * یک JPEG واقعی ۴۸×۳۲.
 *
 * چرا base64 و نه GD: این build از PHP بدون پشتیبانی JPEG کامپایل شده
 * (imagetypes() بیت IMG_JPG ندارد)، ولی تست MIME باید روی JPEG واقعی
 * اجرا شود — همان فرمتی که بیشترین آپلودها را دارد.
 */
function jpg_bytes() {
	return base64_decode( '/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCAAgADADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwDiqKKKZ+thRRRQAUUUUAFFFFABRRRQAUUUUAf/2Q==' );
}
function make_jpg( $name = 'shot.jpg' ) {
	global $TMP;
	$path = $TMP . '/' . $name;
	file_put_contents( $path, jpg_bytes() );
	return $path;
}
function make_png( $name = 'shot.png' ) {
	global $TMP;
	$im   = imagecreatetruecolor( 24, 18 );
	$path = $TMP . '/' . $name;
	imagepng( $im, $path );
	imagedestroy( $im );
	return $path;
}
function make_pdf( $name = 'doc.pdf' ) {
	global $TMP;
	$path = $TMP . '/' . $name;
	file_put_contents( $path, "%PDF-1.4\n1 0 obj<</Type/Catalog>>endobj\ntrailer<</Root 1 0 R>>\n%%EOF\n" );
	return $path;
}
function make_fake( $name, $body ) {
	global $TMP;
	$path = $TMP . '/' . $name;
	file_put_contents( $path, $body );
	return $path;
}

/** ساخت $_FILES و یک WP_REST_Request ساده. */
function upload_request( $path, $name, $key = 'sess-key-1', $size = null ) {
	$_FILES = array(
		'file' => array(
			'name'     => $name,
			'type'     => 'application/octet-stream',
			'tmp_name' => $path,
			'error'    => UPLOAD_ERR_OK,
			'size'     => ( null === $size ) ? filesize( $path ) : $size,
		),
	);
	$req = new WP_REST_Request( array( 'key' => $key ) );
	return $req;
}

/* ---- راه‌اندازی ---- */
wp_test_fake_uploads();

update_option( 'pasokhban_options', array(
	'api_key'           => 'sk-test',
	'live_enabled'      => 1,
	'live_upload'       => 1,
	'live_upload_max'   => 5,
	'live_upload_types' => 'jpg,jpeg,png,gif,webp,pdf,txt',
	'rate_limit'        => 0,   // محدودیت نرخ خاموش
) );
$settings = Pasokhban_Settings::instance();
$rp = new ReflectionProperty( 'Pasokhban_Settings', 'options' ); $rp->setAccessible( true );
$rp->setValue( $settings, get_option( 'pasokhban_options' ) );

Pasokhban_DB::install();
$session = Pasokhban_DB::create_session( array( 'visitor_name' => 'سارا' ) );
ok( ! empty( $session->session_key ), 'نشست آزمایشی ساخته شد' );

$UP = 'Pasokhban_Upload';

/* ========================================================= */
head( '۱) تنظیمات — فهرست سفید واقعاً سفید است' );
/* ========================================================= */

$d = $settings->defaults();
eq( $d['live_upload'], 1, 'ارسال فایل پیش‌فرض روشن است' );
eq( $d['live_upload_max'], 5, 'حداکثر حجم پیش‌فرض ۵ مگابایت' );
eq( $d['live_upload_types'], 'jpg,jpeg,png,gif,webp,pdf,txt', 'پسوندهای پیش‌فرض' );

$out = $settings->sanitize( array( 'live_upload_types' => 'jpg,png,php,phtml,svg,exe,sh,html,js' ) );
eq( $out['live_upload_types'], 'jpg,png', 'پسوندهای خطرناک حتی از تنظیمات هم رد می‌شوند' );

$out = $settings->sanitize( array( 'live_upload_types' => 'php,exe' ) );
eq( $out['live_upload_types'], 'jpg,jpeg,png,gif,webp,pdf,txt', 'اگر همهٔ ورودی خطرناک بود، به پیش‌فرض برمی‌گردد' );

$out = $settings->sanitize( array( 'live_upload_max' => 999 ) );
eq( $out['live_upload_max'], 25, 'حجم به سقف ۲۵ مگابایت چسبید' );
$out = $settings->sanitize( array( 'live_upload_max' => 0 ) );
eq( $out['live_upload_max'], 1, 'حجم صفر به ۱ تبدیل می‌شود' );

$out = $settings->sanitize( array( 'live_upload_types' => 'JPG, Pdf ,, TXT' ) );
eq( $out['live_upload_types'], 'jpg,pdf,txt', 'بزرگی/کوچکی حروف و فاصله نرمال شد' );

eq( $UP::allowed_exts( array( 'live_upload_types' => 'jpg,php,png' ) ), array( 'jpg', 'png' ), 'allowed_exts فقط فهرست سفید کد را برمی‌گرداند' );
eq( $UP::allowed_exts( array( 'live_upload_types' => '' ) ), array(), 'ورودی خالی → فهرست خالی' );

/* ========================================================= */
head( '۲) پاک‌سازی نام فایل' );
/* ========================================================= */

eq( $UP::safe_name( '../../etc/passwd' ), 'passwd', 'مسیر نسبی حذف شد' );
eq( $UP::safe_name( 'C:\\fakepath\\عکس من.png' ), 'عکس من.png', 'مسیر ویندوزی حذف شد' );
// `<script>alert(1)</script>.png` → بخش `</` مثل یک مسیر رفتار می‌کند و
// تا آخرین اسلش بریده می‌شود، بعد کاراکترهای تگ حذف می‌شوند.
eq( $UP::safe_name( '<script>alert(1)</script>.png' ), 'script.png', 'تگ HTML خنثی شد' );
$dirty = $UP::safe_name( '<script>alert(1)</script>.png' );
ok( false === strpbrk( $dirty, '/\\<>"\'' . '&\\' ), 'خروجی هیچ کاراکتر خطرناکی ندارد', $dirty );
eq( $UP::safe_name( "bad\0name.png" ), 'badname.png', 'بایت null حذف شد' );
eq( $UP::safe_name( '' ), 'file', 'نام خالی → file' );
ok( mb_strlen( $UP::safe_name( str_repeat( 'ا', 200 ) ) ) <= 80, 'نام خیلی بلند کوتاه شد' );

/* ========================================================= */
head( '۳) بررسی نوع فایل — حمله‌های واقعی' );
/* ========================================================= */

$opts = $settings->get_options();
$jpg  = make_jpg();

$r = $UP::check_file( $jpg, 'shot.jpg', $opts );
ok( is_array( $r ), 'تصویر واقعی پذیرفته شد', is_wp_error( $r ) ? $r->get_error_message() : '' );
eq( $r['ext'], 'jpg', 'پسوند درست تشخیص داده شد' );
eq( $r['mime'], 'image/jpeg', 'MIME واقعی از محتوا خوانده شد' );

// ★ حملهٔ ۱: اسکریپت PHP با پسوند .jpg
$evil = make_fake( 'evil.jpg', "<?php system(\$_GET['c']); ?>\n" );
$r = $UP::check_file( $evil, 'evil.jpg', $opts );
eq( code( $r ), 415, 'PHP با پسوند jpg رد شد' );
ok( is_wp_error( $r ) && 'pasokhban_mismatch' === $r->get_error_code(), 'دلیل رد: ناهمخوانی MIME با پسوند' );

// ★ حملهٔ ۲: پسوند دوگانه
$evil2 = make_jpg( 'shell.php.jpg' );
$r = $UP::check_file( $evil2, 'shell.php.jpg', $opts );
eq( code( $r ), 415, 'پسوند دوگانه shell.php.jpg رد شد' );

// ★ حملهٔ ۳: پسوند مستقیم .php
$evil3 = make_fake( 'shell.php', '<?php echo 1;' );
$r = $UP::check_file( $evil3, 'shell.php', $opts );
eq( code( $r ), 415, 'پسوند php رد شد' );

// ★ حملهٔ ۴: SVG (می‌تواند JavaScript داشته باشد)
$svg = make_fake( 'x.svg', '<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>' );
$r = $UP::check_file( $svg, 'x.svg', $opts );
eq( code( $r ), 415, 'SVG رد شد (می‌تواند در مرورگر اپراتور اجرا شود)' );

// ★ حملهٔ ۵: HTML
$h = make_fake( 'x.html', '<html><body>x</body></html>' );
$r = $UP::check_file( $h, 'x.html', $opts );
eq( code( $r ), 415, 'HTML رد شد' );

// ★ حملهٔ ۶: فایل با پسوند مجاز ولی محتوای نامعلوم
$bin = make_fake( 'x.txt', "\x00\x01\x02\x03\x04\x05random-binary" );
$r = $UP::check_file( $bin, 'x.txt', $opts );
ok( is_wp_error( $r ), 'فایل دودویی با پسوند txt رد شد' );

// فایل متنی سالم
$txt = make_fake( 'note.txt', "این یک یادداشت متنی ساده است.\nخط دوم.\n" );
$r = $UP::check_file( $txt, 'note.txt', $opts );
ok( is_array( $r ) && 'text/plain' === $r['mime'], 'فایل متنی سالم پذیرفته شد', is_wp_error( $r ) ? $r->get_error_message() : '' );

// PDF سالم
$pdf = make_pdf();
$r = $UP::check_file( $pdf, 'doc.pdf', $opts );
ok( is_array( $r ) && 'application/pdf' === $r['mime'], 'PDF سالم پذیرفته شد', is_wp_error( $r ) ? $r->get_error_message() : '' );

// تصویر خراب با پسوند png
$badpng = make_fake( 'broken.png', 'not really a png' );
$r = $UP::check_file( $badpng, 'broken.png', $opts );
eq( code( $r ), 415, 'فایل با پسوند png که واقعاً تصویر نیست رد شد' );

// پسوندی که اصلاً در فهرست نیست
$gz = make_fake( 'a.gz', "\x1f\x8b\x08\x00" );
$r = $UP::check_file( $gz, 'a.gz', $opts );
eq( code( $r ), 415, 'پسوند خارج از فهرست رد شد' );
ok( is_wp_error( $r ) && false !== strpos( $r->get_error_message(), 'jpg' ), 'پیام خطا، پسوندهای مجاز را نشان می‌دهد' );

/* ========================================================= */
head( '۴) اندپوینت /live/upload' );
/* ========================================================= */

// قابلیت خاموش
update_option( 'pasokhban_options', array_merge( get_option( 'pasokhban_options' ), array( 'live_upload' => 0 ) ) );
$rp->setValue( $settings, get_option( 'pasokhban_options' ) );
$r = $UP::handle_upload( upload_request( make_jpg( 'a1.jpg' ), 'a1.jpg', $session->session_key ) );
eq( code( $r ), 403, 'با قابلیت خاموش، ۴۰۳ می‌دهد' );

update_option( 'pasokhban_options', array_merge( get_option( 'pasokhban_options' ), array( 'live_upload' => 1 ) ) );
$rp->setValue( $settings, get_option( 'pasokhban_options' ) );

// نشست نامعتبر
$r = $UP::handle_upload( upload_request( make_jpg( 'a2.jpg' ), 'a2.jpg', 'کلید-اشتباه' ) );
eq( code( $r ), 404, 'با کلید نشست نامعتبر، ۴۰۴ می‌دهد' );

// بدون فایل
$_FILES = array();
$req = new WP_REST_Request( array( 'key' => $session->session_key ) );
$r = $UP::handle_upload( $req );
eq( code( $r ), 400, 'بدون فایل، ۴۰۰ می‌دهد' );

// فایل بزرگ‌تر از حد
$big = make_jpg( 'big.jpg' );
$r = $UP::handle_upload( upload_request( $big, 'big.jpg', $session->session_key, 99 * 1024 * 1024 ) );
eq( code( $r ), 413, 'فایل بزرگ‌تر از سقف، ۴۱۳ می‌دهد' );

// خطای آپلود PHP
$req = upload_request( make_jpg( 'e.jpg' ), 'e.jpg', $session->session_key );
$_FILES['file']['error'] = UPLOAD_ERR_PARTIAL;
$r = $UP::handle_upload( $req );
eq( code( $r ), 400, 'آپلود ناقص، ۴۰۰ می‌دهد' );

$req = upload_request( make_jpg( 'e2.jpg' ), 'e2.jpg', $session->session_key );
$_FILES['file']['error'] = UPLOAD_ERR_INI_SIZE;
$r = $UP::handle_upload( $req );
eq( code( $r ), 413, 'خطای INI_SIZE به پیام حجم مجاز تبدیل شد' );

// ★ آپلود موفق
$src = make_jpg( 'my screenshot (1).jpg' );
$res = $UP::handle_upload( upload_request( $src, 'my screenshot (1).jpg', $session->session_key ) );
ok( ! is_wp_error( $res ), 'آپلود موفق بود', is_wp_error( $res ) ? $res->get_error_message() : '' );
eq( $res['ok'], true, 'ok=true برگشت' );
ok( ! empty( $res['token'] ), 'توکن صادر شد' );
ok( 20 === strlen( $res['token'] ), 'توکن ۲۰ کاراکتر تصادفی است' );

$att = $res['attachment'];
eq( $att['mime'], 'image/jpeg', 'MIME در پاسخ' );
ok( $att['w'] > 0 && $att['h'] > 0, 'ابعاد تصویر خوانده شد', $att['w'] . 'x' . $att['h'] );
eq( $att['name'], 'my screenshot (1).jpg', 'نام اصلی برای نمایش نگه داشته شد' );

// ★ نام فایل روی دیسک تصادفی است، نه نام کاربر
$saved = basename( $att['url'] );
ok( false === strpos( $saved, 'screenshot' ), 'نام ذخیره‌شده نام کاربر نیست', $saved );
ok( (bool) preg_match( '/^[A-Za-z0-9]{24}\.jpg$/', $saved ), 'نام تصادفی ۲۴ کاراکتری + پسوند', $saved );
ok( is_file( $UP::dir() . '/' . $att['file'] ), 'فایل واقعاً روی دیسک نوشته شد' );
ok( 0 === strpos( $att['url'], 'http://example.test/wp-content/uploads/pasokhban/' ), 'آدرس عمومی درست است', $att['url'] );

// پوشه قفل شده است
ok( is_file( $UP::dir() . '/.htaccess' ), '.htaccess ساخته شد' );
ok( is_file( $UP::dir() . '/web.config' ), 'web.config ساخته شد' );
ok( is_file( $UP::dir() . '/index.php' ), 'index.php ساخته شد' );
$hta = file_get_contents( $UP::dir() . '/.htaccess' );
ok( false !== strpos( $hta, 'php_flag engine off' ), '.htaccess موتور PHP را خاموش می‌کند' );
ok( false !== strpos( $hta, 'Require all denied' ), '.htaccess دسترسی مستقیم را می‌بندد' );
ok( false !== strpos( $hta, '-ExecCGI' ), '.htaccess اجرای CGI را ممنوع می‌کند' );

// فایل اسکریپت‌پذیر هرگز ذخیره نشد
$files = glob( $UP::dir() . '/*' );
$bad = 0;
foreach ( $files as $f ) {
	$b = basename( $f );
	if ( preg_match( '/\.(php|phtml|phar|svg|html|js|sh|exe|cgi|pl|py)$/i', $b ) && 'index.php' !== $b ) { $bad++; }
}
eq( $bad, 0, 'هیچ فایل اسکریپت‌پذیری در پوشهٔ آپلود نیست' );

/* ========================================================= */
head( '۵) توکن — کلاینت هرگز URL نمی‌سازد' );
/* ========================================================= */

$resolved = $UP::resolve_tokens( (int) $session->id, array( $res['token'] ) );
eq( count( $resolved ), 1, 'توکن معتبر به ضمیمه تبدیل شد' );
eq( $resolved[0]['file'], $att['file'], 'فایل درست برگشت' );

// ★ یک توکن فقط یک‌بار مصرف می‌شود
eq( $UP::resolve_tokens( (int) $session->id, array( $res['token'] ) ), array(), 'توکن دوبار مصرف نمی‌شود' );

// ★ توکن ناشناخته → چیزی برنمی‌گردد (کاربر نمی‌تواند URL دلخواه جا بزند)
eq( $UP::resolve_tokens( (int) $session->id, array( 'دروغین' ) ), array(), 'توکن ناشناخته رد می‌شود' );

// ★ سقف ضمیمه در هر پیام
$toks = array();
for ( $i = 0; $i < 6; $i++ ) {
	$rr = $UP::handle_upload( upload_request( make_jpg( 'p' . $i . '.jpg' ), 'p' . $i . '.jpg', $session->session_key ) );
	if ( ! is_wp_error( $rr ) ) { $toks[] = $rr['token']; }
}
ok( count( $toks ) >= 5, 'چند فایل آپلود شد', count( $toks ) );
$resolved = $UP::resolve_tokens( (int) $session->id, $toks );
ok( count( $resolved ) <= $UP::MAX_PER_MESSAGE, 'بیش از سقف ضمیمه پذیرفته نمی‌شود', count( $resolved ) . ' <= ' . $UP::MAX_PER_MESSAGE );

// توکن نشست دیگر اعتبار ندارد
$other = Pasokhban_DB::create_session( array( 'visitor_name' => 'دیگری' ) );
$rr = $UP::handle_upload( upload_request( make_jpg( 'o.jpg' ), 'o.jpg', $other->session_key ) );
eq( $UP::resolve_tokens( (int) $session->id, array( $rr['token'] ) ), array(), 'توکن یک نشست در نشست دیگر کار نمی‌کند' );

/* ========================================================= */
head( '۶) توضیح ضمیمه برای مدل' );
/* ========================================================= */

eq( $UP::describe( (object) array( 'meta' => array() ) ), '', 'بدون ضمیمه، چیزی اضافه نمی‌شود' );
eq( $UP::describe( (object) array( 'meta' => array( 'attachments' => 'نه-آرایه' ) ) ), '', 'دادهٔ خراب باعث خطا نمی‌شود' );
eq( $UP::describe( array( 'meta' => array( 'attachments' => array( array( 'name' => 'a.png' ) ) ) ) ), "\n\n(کاربر این فایل‌ها را هم ارسال کرده است: a.png. توجه: تو محتوای این فایل‌ها را نمی‌بینی؛ هرگز حدس نزن داخلشان چیست. اگر برای پاسخ به محتوایشان نیاز داری، از کاربر بخواه توضیح دهد.)", 'آرایه هم پذیرفته می‌شود' );

$note = $UP::describe( (object) array( 'meta' => array( 'attachments' => array( array( 'name' => 'error.png' ) ) ) ) );
ok( false !== strpos( $note, 'error.png' ), 'نام فایل در توضیح هست' );
ok( false !== strpos( $note, 'نمی‌بینی' ), 'صریحاً به مدل می‌گوید فایل را نمی‌بیند (جلوگیری از توصیف خیالی)' );
ok( false !== strpos( $note, 'حدس نزن' ), 'از حدس‌زدن محتوا نهی می‌کند' );

/* ========================================================= */
head( '۷) یکپارچگی با /live/send و پاسخ AI' );
/* ========================================================= */

$lc = Pasokhban_LiveChat::instance();

$rr  = $UP::handle_upload( upload_request( make_jpg( 'invoice.jpg' ), 'invoice.jpg', $session->session_key ) );
$tok = $rr['token'];

$req = new WP_REST_Request( array( 'key' => $session->session_key ) );
$req->set_param( 'content', 'این فاکتور را ببین' );
$req->set_param( 'attachments', array( $tok ) );

// پاسخ AI را ساختگی می‌کنیم تا فقط مسیر ذخیره و prompt آزموده شود
$GLOBALS['wp_remote_response'] = array(
	'response' => array( 'code' => 200 ),
	'body'     => json_encode( array( 'choices' => array( array( 'message' => array( 'role' => 'assistant', 'content' => 'بله حتماً بررسی می‌کنم.' ) ) ) ) ),
);
$GLOBALS['wp_remote_calls'] = array();

$resp = $lc->handle_send( $req );
ok( ! is_wp_error( $resp ), 'ارسال پیام با ضمیمه موفق بود', is_wp_error( $resp ) ? $resp->get_error_message() : '' );
ok( ! empty( $resp['message']->meta['attachments'] ), 'ضمیمه در meta پیام ذخیره شد' );
eq( $resp['message']->meta['attachments'][0]['name'], 'invoice.jpg', 'نام فایل درست ذخیره شد' );

// ★ توکن دوباره مصرف نمی‌شود
$req2 = new WP_REST_Request( array( 'key' => $session->session_key ) );
$req2->set_param( 'content', 'دوباره همان فایل' );
$req2->set_param( 'attachments', array( $tok ) );
$resp2 = $lc->handle_send( $req2 );
ok( empty( $resp2['message']->meta['attachments'] ), 'توکن مصرف‌شده دوباره ضمیمه نمی‌سازد' );

// ★ توکن جعلی
$req3 = new WP_REST_Request( array( 'key' => $session->session_key ) );
$req3->set_param( 'content', 'فایل جعلی' );
$req3->set_param( 'attachments', array( 'http://evil.test/x.php' ) );
$resp3 = $lc->handle_send( $req3 );
ok( empty( $resp3['message']->meta['attachments'] ), 'آدرس دلخواه به‌عنوان ضمیمه پذیرفته نمی‌شود' );

// ★ prompt مدل شامل توضیح ضمیمه است
$found = false;
foreach ( $GLOBALS['wp_remote_calls'] as $c ) {
	if ( false === strpos( $c['url'], '/chat/completions' ) ) { continue; }
	$body = is_array( $c['body'] ) ? $c['body'] : json_decode( (string) $c['body'], true );
	foreach ( (array) $body['messages'] as $m ) {
		if ( false !== strpos( (string) $m['content'], 'invoice.jpg' ) && false !== strpos( (string) $m['content'], 'نمی‌بینی' ) ) {
			$found = true;
		}
	}
}
ok( $found, 'مدل در prompt می‌فهمد کاربر فایل فرستاده و آن را نمی‌بیند' );

/* ========================================================= */
head( '۸) پاک‌سازی فایل‌ها' );
/* ========================================================= */

$rr   = $UP::handle_upload( upload_request( make_jpg( 'keep.jpg' ), 'keep.jpg', $session->session_key ) );
$keep = $UP::dir() . '/' . $rr['attachment']['file'];
ok( is_file( $keep ), 'فایل برای آزمون پاک‌سازی هست' );

// به پیام بچسبان تا purge بتواند پیدایش کند
Pasokhban_DB::add_message( (int) $session->id, 'visitor', 'نگه دار', array( 'attachments' => array( $rr['attachment'] ) ) );

$n = $UP::purge_sessions( array( (int) $session->id ) );
ok( $n >= 1, 'حداقل یک فایل پاک شد', $n );
ok( ! is_file( $keep ), 'فایل ضمیمه از دیسک حذف شد' );

eq( $UP::purge_sessions( array() ), 0, 'فهرست خالی → بدون خطا' );

// ★ محافظت در برابر path traversal
eq( $UP::delete_file( '../../../wp-config.php' ), false, 'مسیر ../ رد می‌شود' );
eq( $UP::delete_file( '/etc/passwd' ), false, 'مسیر مطلق رد می‌شود' );
eq( $UP::delete_file( '..\\win.ini' ), false, 'مسیر ویندوزی رد می‌شود' );
eq( $UP::delete_file( '' ), false, 'نام خالی رد می‌شود' );
eq( $UP::delete_file( 'nope-1234.jpg' ), false, 'فایل ناموجود بدون خطا false می‌دهد' );

/* ========================================================= */
head( '۹) تنظیمات عمومی سمت کاربر' );
/* ========================================================= */

$pub = $lc->public_settings( 'fa' );
eq( $pub['upload'], true, 'upload در تنظیمات عمومی هست' );
eq( $pub['uploadMax'], 5, 'حداکثر حجم به کلاینت می‌رسد' );
eq( $pub['uploadTypes'], array( 'jpg', 'jpeg', 'png', 'gif', 'webp', 'pdf', 'txt' ), 'فهرست پسوندها به کلاینت می‌رسد' );
eq( $pub['uploadMaxPer'], $UP::MAX_PER_MESSAGE, 'سقف تعداد ضمیمه به کلاینت می‌رسد' );

update_option( 'pasokhban_options', array_merge( get_option( 'pasokhban_options' ), array( 'live_upload' => 0 ) ) );
$rp->setValue( $settings, get_option( 'pasokhban_options' ) );
$pub2 = $lc->public_settings( 'fa' );
eq( $pub2['upload'], false, 'با قابلیت خاموش، دکمه در کلاینت هم نمی‌آید' );

/* ========================================================= */
head( '۱۰) حذف مکالمه فایل‌ها را هم می‌برند' );
/* ========================================================= */

update_option( 'pasokhban_options', array_merge( get_option( 'pasokhban_options' ), array( 'live_upload' => 1 ) ) );
$rp->setValue( $settings, get_option( 'pasokhban_options' ) );

$s3  = Pasokhban_DB::create_session( array( 'visitor_name' => 'حذف‌شونده' ) );
$rr  = $UP::handle_upload( upload_request( make_jpg( 'gone.jpg' ), 'gone.jpg', $s3->session_key ) );
$path3 = $UP::dir() . '/' . $rr['attachment']['file'];
Pasokhban_DB::add_message( (int) $s3->id, 'visitor', 'با عکس', array( 'attachments' => array( $rr['attachment'] ) ) );
ok( is_file( $path3 ), 'فایل قبل از حذف مکالمه هست' );

$dreq = new WP_REST_Request( array( 'id' => (int) $s3->id ) );
$lc->admin_delete( $dreq );
ok( ! is_file( $path3 ), 'با حذف مکالمه، فایل ضمیمه هم از دیسک پاک شد' );

/* ========================================================= */
head( '۱۱) uninstall پوشهٔ آپلود را پاک می‌کند' );
/* ========================================================= */

$un = file_get_contents( PASOKHBAN_PATH . 'uninstall.php' );
ok( false !== strpos( $un, 'pasokhban' ) && false !== strpos( $un, 'rmdir' ), 'uninstall پوشهٔ آپلود را پاک می‌کند' );
ok( false !== strpos( $un, 'pasokhban_updir_hard' ), 'uninstall گزینهٔ قفل پوشه را پاک می‌کند' );

/* ---- پاک‌سازی ---- */
array_map( 'unlink', (array) glob( $TMP . '/*' ) );
@rmdir( $TMP );

echo "\n────────────────────────────────────────────────────\n";
if ( 0 === $FAIL ) {
	echo "\033[42;30m همهٔ {$PASS} تست آپلود فایل پاس شد \033[0m\n";
} else {
	echo "\033[41;97m {$FAIL} تست شکست خورد \033[0m (پاس: {$PASS})\n";
	foreach ( $FAILURES as $f ) { echo "   • {$f}\n"; }
}
echo "────────────────────────────────────────────────────\n";
exit( $FAIL > 0 ? 1 : 0 );
