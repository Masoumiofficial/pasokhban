<?php
/**
 * تست‌های ۳.۱.۰ — صفحهٔ بررسی سلامت.
 *
 * نکتهٔ مهم دربارهٔ این تست‌ها:
 * هدف صفحهٔ سلامت این است که وقتی چیزی خراب است، بگوید **چرا**. پس هر
 * بررسی دو بار سنجیده می‌شود: یک بار در حالت سالم (باید pass بدهد) و یک
 * بار در حالت خراب (باید fail بدهد و راهنمای رفع داشته باشد). تستی که
 * فقط حالت سالم را ببیند، یک صفحهٔ سبزِ همیشگی را هم تأیید می‌کند.
 *
 * هیچ فراخوانی شبکهٔ واقعی در این تست‌ها نیست: wp_remote_* با پاسخ
 * ساختگی جایگزین شده است.
 */

require_once __DIR__ . '/wp-stubs.php';

$PASS = 0; $FAIL = 0; $FAILURES = array();

function ok( $cond, $label, $extra = '' ) {
	global $PASS, $FAIL, $FAILURES;
	if ( $cond ) { $PASS++; echo "  \033[32m✓\033[0m {$label}\n"; }
	else { $FAIL++; $FAILURES[] = $label . ( $extra ? " — {$extra}" : '' ); echo "  \033[31m✗\033[0m {$label}" . ( $extra ? "  → {$extra}" : '' ) . "\n"; }
}
function head( $t ) { echo "\n\033[1m{$t}\033[0m\n"; }
function eq( $a, $b, $label ) { ok( $a === $b, $label, 'انتظار ' . var_export( $b, true ) . ' / دریافت ' . var_export( $a, true ) ); }

/* =========================================================
 * ابزار تست
 * =======================================================*/

$RP = new ReflectionProperty( 'Pasokhban_Settings', 'options' );
$RP->setAccessible( true );

/** تنظیمات را ست می‌کند (هم گزینه، هم کش نمونه). */
function set_opts( array $over = array() ) {
	global $RP;
	$o = array_merge( Pasokhban_Settings::instance()->defaults(), $over );
	update_option( 'pasokhban_options', $o );
	$RP->setValue( Pasokhban_Settings::instance(), $o );
	return $o;
}

/** یک بررسی را اجرا می‌کند و نتیجه را برمی‌گرداند. */
function hc( $id ) {
	return Pasokhban_Health::run_one( $id );
}
function st( $id ) { $r = hc( $id ); return $r['status']; }

/** پاسخ ساختگی HTTP. */
function http( $code, $body, $headers = array() ) {
	$GLOBALS['wp_remote_response'] = array(
		'response' => array( 'code' => $code ),
		'body'     => is_string( $body ) ? $body : wp_json_encode( $body ),
		'headers'  => $headers,
	);
}
function http_err( $msg ) {
	$GLOBALS['wp_remote_response'] = new WP_Error( 'http', $msg );
}
function reset_http() { $GLOBALS['wp_remote_response'] = null; $GLOBALS['wp_remote_calls'] = array(); }

/** آخرین آدرسی که پلاگین به آن درخواست زد. */
function last_url() {
	$c = $GLOBALS['wp_remote_calls'];
	return $c ? end( $c )['url'] : '';
}

// جداول را یک بار می‌سازیم — بیشتر بررسی‌ها به آن نیاز دارند.
Pasokhban_DB::install();
set_opts();

// منطقهٔ زمانی سایت — بررسی «ساعت کاری» به آن تکیه می‌کند.
update_option( 'timezone_string', 'Asia/Tehran' );
update_option( 'gmt_offset', 0 );

// وردپرس واقعی مسیرهای REST را هنگام رویداد rest_api_init ثبت می‌کند.
// هارنس این رویداد را خودش شلیک نمی‌کند، پس همان کاری را می‌کنیم که
// وردپرس می‌کند تا بررسی «مسیرهای REST» روی کد واقعی سنجیده شود.
foreach ( (array) ( isset( $GLOBALS['wp_actions']['rest_api_init'] ) ? $GLOBALS['wp_actions']['rest_api_init'] : array() ) as $cb ) {
	if ( is_callable( $cb ) ) {
		call_user_func( $cb );
	}
}
// نکته: بیشتر این callbackها به‌صورت array( $this, 'register_routes' )
// ثبت شده‌اند و چون $this یک نمونهٔ private static است، is_callable()
// روی آن‌ها false می‌دهد. پس هوک‌های نمونه‌ای را مستقیم صدا می‌زنیم —
// همان متدهایی که وردپرس واقعی در زمان rest_api_init اجرا می‌کند.
Pasokhban_API::instance()->register_routes();
Pasokhban_LiveChat::instance()->register_routes();
Pasokhban_Stream::instance()->register_routes();
Pasokhban_Upload::register_routes();
Pasokhban_Woo::register_routes();
Pasokhban_Team::register_routes();
Pasokhban_Copilot::register_routes();
Pasokhban_Bale::register_routes();
Pasokhban_Health::register_routes();

/* ========================================================= */
head( '۱) ساختار registry و ورودی REST' );
/* ========================================================= */

$reg = Pasokhban_Health::registry();
$groups = Pasokhban_Health::groups();

ok( count( $reg ) >= 30, '★ دست‌کم ۳۰ بررسی ثبت شده است (' . count( $reg ) . ')' );
ok( count( $groups ) === 8, '★ هشت گروه تعریف شده است', (string) count( $groups ) );

// هر بررسی باید به یک گروه معتبر وصل باشد و callback داشته باشد.
$orphans = array();
$nocb    = array();
foreach ( $reg as $id => $item ) {
	if ( ! isset( $groups[ $item['group'] ] ) ) { $orphans[] = $id; }
	if ( ! method_exists( 'Pasokhban_Health', $item['cb'] ) ) { $nocb[] = $id; }
}
ok( ! $orphans, '★ همهٔ بررسی‌ها به گروه معتبر وصل‌اند', implode( ',', $orphans ) );
ok( ! $nocb, '★ همهٔ callbackها موجودند', implode( ',', $nocb ) );

// شناسه‌ها باید یکتا و بی‌فاصله باشند (در URL می‌روند).
$badid = array();
foreach ( array_keys( $reg ) as $id ) {
	if ( ! preg_match( '/^[a-z][a-z0-9_]*$/', $id ) ) { $badid[] = $id; }
}
ok( ! $badid, 'شناسه‌ها برای URL امن‌اند', implode( ',', $badid ) );

// بررسی ناشناخته نباید fatal بدهد.
$unknown = hc( 'no_such_check' );
eq( $unknown['status'], Pasokhban_Health::FAIL, 'بررسی ناشناخته → fail (نه خطای ۵۰۰)' );
ok( false !== strpos( $unknown['msg'], 'ناشناخته' ), 'پیام روشن برای بررسی ناشناخته' );

// فیلتر گروه
$only_ai = Pasokhban_Health::handle( new WP_REST_Request( array( 'group' => 'ai' ) ) );
ok( ! empty( $only_ai['results'] ), 'فیلتر گروه کار می‌کند' );
$all_ai = true;
foreach ( $only_ai['results'] as $r ) { if ( 'ai' !== $r['group'] ) { $all_ai = false; } }
ok( $all_ai, '★ فیلتر گروه فقط همان گروه را برمی‌گرداند' );
ok( isset( $only_ai['summary']['total'] ), 'خلاصه در پاسخ هست' );

// فیلتر تک‌بررسی
$one = Pasokhban_Health::handle( new WP_REST_Request( array( 'check' => 'core_php' ) ) );
ok( isset( $one['result']['id'] ) && 'core_php' === $one['result']['id'], 'فیلتر تک‌بررسی کار می‌کند' );

$bad = Pasokhban_Health::handle( new WP_REST_Request( array( 'check' => 'zzz' ) ) );
ok( false === $bad['ok'], 'بررسی ناشناخته در REST → ok=false' );

// دسترسی
$GLOBALS['wp_user_caps'] = array( 'edit_posts' );
ok( false === Pasokhban_Health::permission(), '★ بدون manage_options دسترسی ندارد' );
$GLOBALS['wp_user_caps'] = array( 'manage_options' );
ok( true === Pasokhban_Health::permission(), 'با manage_options دسترسی دارد' );

// مسیر REST ثبت شده باشد
$server = rest_get_server();
$routes = $server->get_routes();
ok( isset( $routes['/pasokhban/v1/admin/health'] ), '★ مسیر /admin/health ثبت شده است' );

/* ========================================================= */
head( '۲) محیط وردپرس' );
/* ========================================================= */

$GLOBALS['wp_version'] = '6.7.1';
eq( st( 'core_wp' ), 'pass', 'وردپرس جدید → pass' );

$GLOBALS['wp_version'] = '5.2';
eq( st( 'core_wp' ), 'fail', '★ وردپرس قدیمی‌تر از ۵.۸ → fail' );
$GLOBALS['wp_version'] = '6.7.1';

eq( st( 'core_php' ), 'pass', 'PHP فعلی → pass' );

$ext = hc( 'core_ext' );
ok( in_array( $ext['status'], array( 'pass', 'fail' ), true ), 'بررسی افزونه‌ها نتیجه می‌دهد' );
ok( false !== strpos( $ext['detail'], 'mbstring' ) || 'pass' === $ext['status'], 'افزونه‌های اختیاری هم گزارش می‌شوند' );

$db = hc( 'core_db' );
eq( $db['status'], 'pass', '★ اتصال پایگاه‌داده برقرار است' );

// منطقهٔ زمانی
update_option( 'timezone_string', 'Asia/Tehran' );
$tzt = hc( 'core_tz' );
eq( $tzt['status'], 'pass', '★ منطقهٔ زمانی Tehran → pass' );
ok( false !== strpos( $tzt['msg'], 'Tehran' ), 'نام منطقه در پیام هست' );

// UTC باید هشدار بدهد: ساعت کاری سه‌ونیم ساعت جابه‌جا می‌شود و
// اپراتور فکر می‌کند سایت خراب است.
update_option( 'timezone_string', '' );
update_option( 'gmt_offset', 0 );
$tz_utc = hc( 'core_tz' );
eq( $tz_utc['status'], 'warn', '★ سایت روی UTC → هشدار' );
ok( false !== strpos( $tz_utc['fix'], 'Tehran' ), 'راهنما به تنظیم منطقهٔ زمانی اشاره می‌کند' );
update_option( 'timezone_string', 'Asia/Tehran' );

// cron
$GLOBALS['wp_cron'] = array();
$cron = hc( 'core_cron' );
eq( $cron['status'], 'warn', '★ زمان‌بندی ثبت‌نشده → هشدار' );
ok( false !== strpos( $cron['detail'], 'پاک‌سازی' ), 'نام زمان‌بندی جاافتاده در جزئیات هست' );
$GLOBALS['wp_cron'] = array( 'pasokhban_cleanup' => 'daily', Pasokhban_RAG::CRON_HOOK => 'hourly' );
eq( st( 'core_cron' ), 'pass', 'با زمان‌بندی ثبت‌شده → pass' );

/* ========================================================= */
head( '۳) پایگاه‌داده' );
/* ========================================================= */

eq( st( 'db_tables' ), 'pass', '★ جدول‌ها ساخته شده‌اند' );

// آزمون نوشتن/خواندن/حذف — مهم‌ترین بررسی، چون dbDelta ممکن است نصفه
// اجرا شده باشد و جدول هست ولی INSERT می‌شکند.
global $wpdb;
$before_s = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . Pasokhban_DB::sessions_table() );
$before_m = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . Pasokhban_DB::messages_table() );

$rt = hc( 'db_rw' );
eq( $rt['status'], 'pass', '★ نوشتن/خواندن/حذف کار کرد' );

$after_s = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . Pasokhban_DB::sessions_table() );
$after_m = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . Pasokhban_DB::messages_table() );
eq( $after_s, $before_s, '★ رد آزمایشی پاک شد (نشست)' );
eq( $after_m, $before_m, '★ رد آزمایشی پاک شد (پیام)' );

// نسخهٔ ساختار — این همان باگی است که در تنظیمات روی '1.3.0' قفل بود.
update_option( 'pasokhban_db_version', Pasokhban_DB::SCHEMA_VERSION );
eq( st( 'db_ver' ), 'pass', '★ ساختار مطابق کد → pass' );

update_option( 'pasokhban_db_version', '1.3.0' );
$old = hc( 'db_ver' );
eq( $old['status'], 'warn', '★ ساختار کهنه → هشدار (نه pass)' );
ok( false !== strpos( $old['msg'], '1.3.0' ), 'نسخهٔ فعلی در پیام هست' );
ok( false !== strpos( $old['msg'], Pasokhban_DB::SCHEMA_VERSION ), 'نسخهٔ مورد انتظار در پیام هست' );

delete_option( 'pasokhban_db_version' );
eq( st( 'db_ver' ), 'warn', 'نسخهٔ ثبت‌نشده → هشدار' );
update_option( 'pasokhban_db_version', Pasokhban_DB::SCHEMA_VERSION );

// جدول‌های نام قدیمی
$wpdb->tables = array( 'posts', 'options' );
eq( st( 'db_legacy' ), 'pass', '★ بدون جدول قدیمی → pass' );

$wpdb->tables = array( 'posts', 'etehadyar_sessions', 'etehadyar_messages' );
$leg = hc( 'db_legacy' );
eq( $leg['status'], 'warn', '★ جدول نام قدیمی → هشدار' );
ok( false !== strpos( $leg['detail'], 'etehadyar_sessions' ), 'نام جدول قدیمی در جزئیات هست' );

// مسیر دوم: SHOW TABLES LIKE با الگو
$wpdb->tables = array( 'posts' );
$wpdb->query( 'CREATE TABLE wp_etehadyar_chunks ( id INTEGER )' );
$leg2 = hc( 'db_legacy' );
eq( $leg2['status'], 'warn', '★ مسیر SHOW TABLES هم جدول قدیمی را پیدا می‌کند' );
$wpdb->query( 'DROP TABLE wp_etehadyar_chunks' );
eq( st( 'db_legacy' ), 'pass', 'پس از حذف، دوباره pass' );

$stats = hc( 'db_stats' );
eq( $stats['status'], 'info', 'حجم داده → اطلاع' );
ok( false !== strpos( $stats['msg'], 'نشست' ), 'شمار نشست‌ها در پیام هست' );

/* ========================================================= */
head( '۴) هوش مصنوعی' );
/* ========================================================= */

set_opts( array( 'api_key' => '', 'model' => 'gpt-4o' ) );
eq( st( 'ai_key' ), 'fail', '★ بدون کلید → fail' );

set_opts( array( 'api_key' => 'sk-proj-ABCDEFGHIJKLMNOP1234567890', 'model' => 'gpt-4o' ) );
eq( st( 'ai_key' ), 'pass', 'با کلید → pass' );

// پوشاندن کلید — نباید کلید کامل در گزارش بیاید.
$k = hc( 'ai_key' );
ok( false === strpos( $k['detail'], 'sk-proj-ABCDEFGHIJKLMNOP1234567890' ), '★ کلید کامل در گزارش نیست' );
ok( false !== strpos( $k['detail'], '•' ), 'کلید پوشانده شده است' );
eq( Pasokhban_Health::mask( 'short' ), '•••••', 'کلید کوتاه کاملاً پوشانده می‌شود' );
ok( false !== strpos( Pasokhban_Health::mask( 'sk-proj-ABCDEFGHIJKLMNOP1234567890' ), 'sk-pro' ), 'سر کلید برای شناسایی می‌ماند' );

set_opts( array( 'ai_provider' => 'gemini', 'base_url' => '', 'model' => 'gpt-4o' ) );
$m = hc( 'ai_model' );
eq( $m['status'], 'warn', '★ مدل سرویس قبلی روی سرویس تازه → هشدار' );
ok( false !== strpos( $m['detail'], 'gemini' ), 'مدل‌های مجاز در جزئیات هست' );

set_opts( array( 'ai_provider' => 'gemini', 'base_url' => '', 'model' => 'gemini-2.5-flash' ) );
eq( st( 'ai_model' ), 'pass', 'مدل درست → pass' );

set_opts( array( 'base_url' => 'http://api.example.com/v1', 'api_key' => 'k' ) );
eq( st( 'ai_base' ), 'warn', '★ آدرس غیر HTTPS → هشدار (کلید در مسیر روشن)' );

// اسلش اضافه در انتها: کد با untrailingslashit خودش درستش می‌کند، پس
// باید pass بدهد. اگر روزی آن untrailingslashit برداشته شود، مسیر
// //chat/completions ساخته می‌شود و این تست باید warn بگیرد.
set_opts( array( 'base_url' => 'https://api.example.com/v1/', 'api_key' => 'k' ) );
$sl = hc( 'ai_base' );
eq( $sl['status'], 'pass', '★ اسلش اضافه خودش اصلاح می‌شود (pass)' );
ok( '/' !== substr( $sl['msg'], -1 ), '★ آدرس گزارش‌شده اسلش انتهایی ندارد', $sl['msg'] );

set_opts( array( 'ai_provider' => 'openai', 'base_url' => '', 'api_key' => 'k' ) );
eq( st( 'ai_base' ), 'pass', 'آدرس درست → pass' );

// فراخوانی واقعی — با پاسخ ساختگی
reset_http();
http( 200, array( 'choices' => array( array( 'message' => array( 'content' => 'pong' ) ) ) ) );
$ping = hc( 'ai_ping' );
eq( $ping['status'], 'pass', '★ سرویس پاسخ داد → pass' );
ok( false !== strpos( last_url(), 'api.openai.com' ), '★ درخواست واقعاً به OpenAI رفت', last_url() );
ok( isset( $ping['ms'] ), 'زمان پاسخ اندازه‌گیری شد' );

// خطای ۴۰۱ باید پیام خودِ سرویس را بدهد، نه «پاسخ دریافت نشد»
http( 401, array( 'error' => array( 'message' => 'Incorrect API key provided' ) ) );
$p401 = hc( 'ai_ping' );
eq( $p401['status'], 'fail', '★ کلید رد شد → fail' );
ok( false !== strpos( $p401['msg'], 'Incorrect API key' ), '★ پیام خودِ سرویس به کاربر می‌رسد', $p401['msg'] );
ok( '' !== $p401['fix'], '★ راهنمای رفع دارد' );

// تایم‌اوت → باید بگوید احتمالاً فیلترینگ است
http_err( 'cURL error 28: Operation timed out' );
$pto = hc( 'ai_ping' );
eq( $pto['status'], 'fail', 'تایم‌اوت → fail' );
ok( false !== strpos( $pto['fix'], 'فیلتر' ) || false !== strpos( $pto['fix'], 'پروکسی' ), '★ راهنما به فیلترینگ/پروکسی اشاره می‌کند', $pto['fix'] );

// صفحهٔ HTML به‌جای JSON — نشانهٔ درگاه/پروکسی
http( 502, '<html><body>Bad Gateway</body></html>' );
$phtml = hc( 'ai_ping' );
eq( $phtml['status'], 'fail', 'پاسخ غیر JSON → fail' );

// بدون کلید باید skip شود، نه اینکه درخواست بزند
reset_http();
set_opts( array( 'api_key' => '' ) );
eq( st( 'ai_ping' ), 'skip', '★ بدون کلید آزمون زده نمی‌شود (skip)' );
eq( count( $GLOBALS['wp_remote_calls'] ), 0, '★ هیچ درخواستی ارسال نشد' );

/* ---- embedding ---- */
set_opts( array( 'api_key' => 'k', 'rag_vector' => 0 ) );
eq( st( 'ai_embed' ), 'skip', 'RAG خاموش → skip' );

set_opts( array( 'api_key' => 'k', 'rag_vector' => 1, 'rag_dims' => 4, 'rag_model' => 'text-embedding-3-small' ) );
reset_http();
http( 200, array( 'data' => array( array( 'embedding' => array( 0.1, 0.2, 0.3, 0.4 ) ) ) ) );
$emb = hc( 'ai_embed' );
eq( $emb['status'], 'pass', '★ بردار با ابعاد درست → pass' );
ok( false !== strpos( last_url(), '/embeddings' ), '★ درخواست به مسیر /embeddings رفت', last_url() );
ok( false !== strpos( $emb['msg'], '4' ), 'ابعاد در پیام هست' );

// ابعاد ناهمخوان — یعنی فهرست با ابعاد دیگری ساخته شده و جست‌وجو کار نمی‌کند
set_opts( array( 'api_key' => 'k', 'rag_vector' => 1, 'rag_dims' => 512, 'rag_model' => 'text-embedding-3-small' ) );
http( 200, array( 'data' => array( array( 'embedding' => array( 0.1, 0.2, 0.3, 0.4 ) ) ) ) );
$emb2 = hc( 'ai_embed' );
eq( $emb2['status'], 'warn', '★ ابعاد ناهمخوان با تنظیمات → هشدار' );
ok( false !== strpos( $emb2['fix'], 'فهرست' ), 'راهنما به فهرست‌سازی دوباره اشاره می‌کند' );

// درگاه بدون پشتیبانی embedding
set_opts( array( 'api_key' => 'k', 'rag_vector' => 1, 'rag_dims' => 4 ) );
http( 404, array( 'error' => array( 'message' => 'This endpoint does not support embeddings' ) ) );
eq( st( 'ai_embed' ), 'fail', '★ درگاه بدون embedding → fail' );

// RAG
set_opts( array( 'rag_vector' => 0 ) );
eq( st( 'ai_rag' ), 'skip', 'RAG خاموش → skip' );

set_opts( array( 'api_key' => 'k', 'rag_vector' => 1 ) );
$rag = Pasokhban_RAG::instance();
if ( $rag->table_ready() && 0 === $rag->count_chunks() ) {
	$empty = hc( 'ai_rag' );
	eq( $empty['status'], 'warn', '★ فهرست خالی → هشدار' );
}

// یک تکه واقعی می‌نویسیم تا مسیر «فهرست آماده» سنجیده شود.
$wpdb->query( 'DELETE FROM ' . Pasokhban_DB::chunks_table() );
$wpdb->insert( Pasokhban_DB::chunks_table(), array(
	'source_type'  => 'post',
	'source_id'    => '1',
	'title'        => 'هزینهٔ ارسال',
	'url'          => 'http://example.test/?p=1',
	'content'      => 'هزینهٔ ارسال برای تهران ۵۰ هزار تومان است.',
	'content_hash' => md5( 'a' ),
	'vector'       => Pasokhban_RAG::encode( array( 1.0, 0.0, 0.0, 0.0 ) ),
	'dims'         => 4,
	'model'        => 'text-embedding-3-small',
	'created_at'   => gmdate( 'Y-m-d H:i:s' ),
) );
Pasokhban_RAG::instance()->flush_query_cache();
$filled = hc( 'ai_rag' );
eq( $filled['status'], 'pass', '★ با فهرست پر → pass' );
ok( false !== strpos( $filled['detail'], 'تکه' ), 'تعداد تکه‌ها در جزئیات هست' );

// جست‌وجوی معنایی
reset_http();
http( 200, array( 'data' => array( array( 'embedding' => array( 1.0, 0.0, 0.0, 0.0 ) ) ) ) );
set_opts( array( 'api_key' => 'k', 'rag_vector' => 1, 'rag_dims' => 4, 'rag_min_score' => 0.1, 'rag_top_k' => 4 ) );
$ret = hc( 'ai_retrieve' );
eq( $ret['status'], 'pass', '★ جست‌وجو نتیجه برگرداند' );
ok( false !== strpos( $ret['msg'], 'شباهت' ), 'امتیاز شباهت در پیام هست' );

// آستانه را بالاتر از ۱ می‌گذاریم: بردار آزمون دقیقاً هم‌جهت با بردار
// فهرست است پس شباهت ۱.۰۰۰ می‌شود و آستانهٔ ۰.۹۹ هنوز رد می‌شد.
set_opts( array( 'api_key' => 'k', 'rag_vector' => 1, 'rag_dims' => 4, 'rag_min_score' => 1.5, 'rag_top_k' => 4 ) );
Pasokhban_RAG::instance()->flush_query_cache();
$ret2 = hc( 'ai_retrieve' );
eq( $ret2['status'], 'warn', '★ آستانه بالاتر از بیشترین شباهت → هشدار (نتیجه‌ای نیست)' );
ok( false !== strpos( $ret2['fix'], 'آستانه' ), 'راهنما به آستانه اشاره می‌کند' );
Pasokhban_RAG::instance()->flush_query_cache();

/* ========================================================= */
head( '۵) چت و آپلود' );
/* ========================================================= */

set_opts( array( 'widget_enabled' => 1, 'live_enabled' => 1 ) );
eq( st( 'chat_widget' ), 'pass', 'ویجت روشن → pass' );

set_opts( array( 'widget_enabled' => 0, 'live_enabled' => 0 ) );
$w = hc( 'chat_widget' );
eq( $w['status'], 'warn', '★ ویجت خاموش → هشدار' );
ok( false !== strpos( $w['msg'], 'ویجت شناور' ), 'نام بخش خاموش در پیام هست' );

set_opts();
$rt = hc( 'chat_routes' );
eq( $rt['status'], 'pass', '★ مسیرهای REST ثبت شده‌اند' );
ok( false !== strpos( $rt['detail'], 'pasokhban/v1' ), 'آدرس REST در جزئیات هست' );

// نکته: create_session() کلید داده‌شده را نادیده می‌گیرد و کلید تصادفی
// تازه می‌سازد (تا کلید دست‌کاری‌شده وارد جدول نشود). پس بازیابی با کلید
// باید با کلیدی سنجیده شود که واقعاً در جدول است — همان که نشست اول
// ساخته است. این دقیقاً مسیر واقعی است: کلاینت کلید را از پاسخ
// /live/start می‌گیرد و در درخواست بعدی همان را می‌فرستد.
$s = Pasokhban_DB::create_session();
if ( empty( $s ) || empty( $s->id ) ) {
	ok( false, '★ ساخت نشست آزمایشی ناموفق بود' );
} else {
	$again = Pasokhban_DB::get_or_create_session( $s->session_key );
	$same  = ( ! empty( $again ) && (int) $again->id === (int) $s->id );
	ok( $same, '★ نشست با همان کلید بازیابی شد (نه نشست تکراری)' );

	// اگر کلید نامعتبر داده شود، باید نشست تازه بسازد — نه اینکه بمیرد.
	$junk = Pasokhban_DB::get_or_create_session( 'short' );
	ok( ! empty( $junk ) && ! empty( $junk->id ), '★ کلید نامعتبر هم نشست معتبر می‌سازد' );
	if ( ! empty( $junk->id ) ) {
		$wpdb->delete( Pasokhban_DB::messages_table(), array( 'session_id' => (int) $junk->id ) );
		$wpdb->delete( Pasokhban_DB::sessions_table(), array( 'id' => (int) $junk->id ) );
	}

	$ses = hc( 'chat_session' );
	eq( $ses['status'], 'pass', '★ بررسی سلامتِ نشست → pass', $ses['msg'] );
}

// پوشهٔ آپلود
$dir = sys_get_temp_dir() . '/psb-health-test-uploads';
@mkdir( $dir, 0777, true );
$GLOBALS['wp_upload_dir'] = $dir;
set_opts( array( 'live_upload' => 1 ) );
$up = hc( 'chat_upload_dir' );
eq( $up['status'], 'pass', '★ پوشهٔ آپلود آماده است', $up['msg'] . ' ' . $up['detail'] );
ok( is_dir( $dir . '/pasokhban' ), '★ پوشهٔ pasokhban ساخته شد' );
ok( file_exists( $dir . '/pasokhban/.htaccess' ) || file_exists( $dir . '/pasokhban/web.config' ), '★ فایل قفل نوشته شد' );

set_opts( array( 'live_upload' => 0 ) );
eq( st( 'chat_upload_dir' ), 'skip', 'آپلود خاموش → skip' );

// پسوندهای مجاز — این یک بررسی امنیتی است
set_opts( array( 'live_upload' => 1, 'live_upload_types' => 'jpg,png,pdf' ) );
eq( st( 'chat_upload_types' ), 'pass', 'پسوندهای سالم → pass' );

set_opts( array( 'live_upload' => 1, 'live_upload_types' => 'jpg,php,pdf' ) );
$d = hc( 'chat_upload_types' );
eq( $d['status'], 'fail', '★ پسوند php → fail' );
ok( false !== strpos( $d['detail'], 'php' ), 'پسوند خطرناک نام برده شد' );

set_opts( array( 'live_upload' => 1, 'live_upload_types' => 'jpg,svg' ) );
eq( st( 'chat_upload_types' ), 'fail', '★ svg هم خطرناک است (می‌تواند اسکریپت داشته باشد)' );

set_opts( array( 'live_upload' => 1, 'live_upload_types' => '  ' ) );
eq( st( 'chat_upload_types' ), 'fail', '★ فهرست خالی → fail' );

/* ========================================================= */
head( '۶) اعلان‌ها' );
/* ========================================================= */

set_opts( array( 'notify_email' => 0 ) );
eq( st( 'notif_email' ), 'skip', 'ایمیل خاموش → skip' );

set_opts( array( 'notify_email' => 1, 'notify_email_to' => '' ) );
eq( st( 'notif_email' ), 'fail', '★ روشن ولی بدون گیرنده → fail' );

set_opts( array( 'notify_email' => 1, 'notify_email_to' => 'not-an-email' ) );
eq( st( 'notif_email' ), 'fail', '★ ایمیل نامعتبر → fail' );

set_opts( array( 'notify_email' => 1, 'notify_email_to' => 'a@b.com' ) );
eq( st( 'notif_email' ), 'pass', 'ایمیل معتبر → pass' );

// تلگرام
set_opts( array( 'notify_telegram' => 0 ) );
eq( st( 'notif_tg' ), 'skip', 'تلگرام خاموش → skip' );

set_opts( array( 'notify_telegram' => 1, 'notify_telegram_token' => '', 'notify_telegram_chat' => '-100' ) );
eq( st( 'notif_tg' ), 'fail', '★ بدون توکن → fail' );

set_opts( array( 'notify_telegram' => 1, 'notify_telegram_token' => '123:ABC', 'notify_telegram_chat' => '' ) );
eq( st( 'notif_tg' ), 'fail', '★ بدون شناسهٔ گفتگو → fail' );

set_opts( array( 'notify_telegram' => 1, 'notify_telegram_token' => '123:ABC', 'notify_telegram_chat' => '-100123', 'notify_telegram_relay' => '' ) );
reset_http();
http( 200, array( 'ok' => true, 'result' => array( 'username' => 'mybot' ) ) );
$tg = hc( 'notif_tg' );
eq( $tg['status'], 'pass', '★ توکن سالم → pass' );
ok( false !== strpos( last_url(), 'getMe' ), '★ از getMe استفاده شد (نه sendMessage)', last_url() );
ok( false !== strpos( $tg['msg'], '@mybot' ), 'نام ربات در پیام هست' );

// توکن رد شده
http( 401, array( 'ok' => false, 'description' => 'Unauthorized' ) );
eq( st( 'notif_tg' ), 'fail', '★ توکن رد شده → fail' );

// فیلترینگ → باید رله را پیشنهاد بدهد
http_err( 'cURL error 28: Connection timed out' );
$tgto = hc( 'notif_tg' );
eq( $tgto['status'], 'fail', 'تایم‌اوت تلگرام → fail' );
ok( false !== strpos( $tgto['fix'], 'رله' ), '★ راهنما رلهٔ گوگل را پیشنهاد می‌دهد', $tgto['fix'] );

// با رله فعال، تلگرام مستقیم آزمون نمی‌شود
set_opts( array( 'notify_telegram' => 1, 'notify_telegram_token' => '123:ABC', 'notify_telegram_chat' => '-100', 'notify_telegram_relay' => 'https://script.google.com/macros/s/xyz/exec' ) );
reset_http();
$tgr = hc( 'notif_tg' );
eq( $tgr['status'], 'info', '★ با رله فعال، تلگرام مستقیم skip می‌شود' );
eq( count( $GLOBALS['wp_remote_calls'] ), 0, '★ درخواستی به تلگرام نرفت' );

// رله
http( 200, '{"ok":true}' );
$relay = hc( 'notif_relay' );
eq( $relay['status'], 'pass', '★ رلهٔ در دسترس → pass' );

set_opts( array( 'notify_telegram' => 1, 'notify_telegram_relay' => 'https://example.com/notgoogle' ) );
eq( st( 'notif_relay' ), 'warn', '★ آدرس غیر گوگل → هشدار' );

set_opts( array( 'notify_telegram' => 1, 'notify_telegram_relay' => 'https://script.google.com/macros/s/xyz/exec' ) );
http( 403, 'Forbidden' );
eq( st( 'notif_relay' ), 'fail', '★ رلهٔ بدون دسترسی عمومی → fail' );

http_err( 'cURL error 6: Could not resolve host' );
eq( st( 'notif_relay' ), 'fail', 'رلهٔ بی‌دی‌ان‌اس → fail' );

// پیامک — باید مطمئن شویم پیامک واقعی نمی‌فرستد
set_opts( array( 'sms_enabled' => 0 ) );
eq( st( 'notif_sms' ), 'skip', 'پیامک خاموش → skip' );

set_opts( array( 'sms_enabled' => 1, 'sms_provider' => 'kavenegar', 'sms_api_key' => '', 'sms_sender' => '' ) );
$sms = hc( 'notif_sms' );
eq( $sms['status'], 'fail', '★ پیکربندی ناقص → fail' );
ok( false !== strpos( $sms['detail'], 'کلید API' ), 'قلم جاافتاده نام برده شد' );

set_opts( array( 'sms_enabled' => 1, 'sms_provider' => 'kavenegar', 'sms_api_key' => 'K', 'sms_sender' => '1000123', 'sms_notify_admin' => 1, 'sms_admin_phone' => '' ) );
eq( st( 'notif_sms' ), 'fail', '★ اعلان مدیر روشن بدون شماره → fail' );

reset_http();
set_opts( array( 'sms_enabled' => 1, 'sms_provider' => 'kavenegar', 'sms_api_key' => 'K', 'sms_sender' => '1000123', 'sms_notify_admin' => 1, 'sms_admin_phone' => '09121234567' ) );
$smsok = hc( 'notif_sms' );
eq( $smsok['status'], 'pass', 'پیکربندی کامل → pass' );
eq( count( $GLOBALS['wp_remote_calls'] ), 0, '★ هیچ پیامک واقعی ارسال نشد (هزینه نتراشید)' );

/* ========================================================= */
head( '۷) ووکامرس' );
/* ========================================================= */

// بدون ووکامرس
set_opts();
eq( st( 'shop_active' ), 'info', '★ بدون ووکامرس → اطلاع (نه خطا)' );
eq( st( 'shop_products' ), 'skip', 'محصولات → skip' );
eq( st( 'shop_lookup' ), 'skip', 'استعلام سفارش → skip' );

// با ووکامرس
require_once __DIR__ . '/wc-stubs.php';
$GLOBALS['wc_products'] = array(
	11 => array( 'name' => 'کفش', 'price' => 100, 'status' => 'publish' ),
	12 => array( 'name' => 'کلاه', 'price' => 50,  'status' => 'publish' ),
);
set_opts( array( 'woo_products' => 1, 'woo_order_lookup' => 1 ) );
eq( st( 'shop_active' ), 'pass', '★ ووکامرس فعال → pass' );

$wpdb->query( 'DELETE FROM ' . Pasokhban_DB::chunks_table() );
$wp = hc( 'shop_products' );
eq( $wp['status'], 'warn', '★ محصول هست ولی ایندکس نشده → هشدار' );
ok( false !== strpos( $wp['fix'], 'فهرست' ), 'راهنما به فهرست‌سازی اشاره می‌کند' );

$wpdb->insert( Pasokhban_DB::chunks_table(), array(
	'source_type'  => 'product',
	'source_id'    => '11',
	'title'        => 'کفش',
	'url'          => 'http://example.test/?p=11',
	'content'      => 'کفش — ۱۰۰ تومان',
	'content_hash' => md5( 'p' ),
	'vector'       => Pasokhban_RAG::encode( array( 0.0, 1.0, 0.0, 0.0 ) ),
	'dims'         => 4,
	'model'        => 'text-embedding-3-small',
	'created_at'   => gmdate( 'Y-m-d H:i:s' ),
) );
$wp2 = hc( 'shop_products' );
eq( $wp2['status'], 'pass', '★ محصول ایندکس‌شده → pass' );
ok( false !== strpos( $wp2['detail'], '2' ), 'تعداد محصولات در جزئیات هست', $wp2['detail'] );

$gl = hc( 'shop_lookup' );
eq( $gl['status'], 'pass', '★ استعلام سفارش فعال → pass' );

set_opts( array( 'woo_order_lookup' => 0 ) );
eq( st( 'shop_lookup' ), 'skip', 'استعلام سفارش خاموش → skip' );

/* ========================================================= */
head( '۸) کانال بله' );
/* ========================================================= */

set_opts( array( 'bale_enabled' => 0 ) );
eq( st( 'bale_cfg' ), 'skip', 'بله خاموش → skip' );
eq( st( 'bale_ping' ), 'skip', 'اعتبار توکن → skip' );

set_opts( array( 'bale_enabled' => 1, 'bale_token' => '', 'bale_chat' => '' ) );
$bc = hc( 'bale_cfg' );
eq( $bc['status'], 'fail', '★ بدون توکن و گروه → fail' );
ok( false !== strpos( $bc['detail'], 'توکن' ), 'قلم جاافتاده نام برده شد' );

set_opts( array( 'bale_enabled' => 1, 'bale_token' => 'B123', 'bale_chat' => '-100', 'bale_twoway' => 0 ) );
eq( st( 'bale_cfg' ), 'pass', 'پیکربندی کامل → pass' );

reset_http();
http( 200, array( 'ok' => true, 'result' => array( 'username' => 'balebot' ) ) );
$bp = hc( 'bale_ping' );
eq( $bp['status'], 'pass', '★ توکن بله سالم → pass' );
ok( false !== strpos( last_url(), 'tapi.bale.ai' ), '★ درخواست به دامنهٔ بله رفت', last_url() );
ok( false !== strpos( last_url(), 'getMe' ), '★ از getMe استفاده شد', last_url() );

http( 200, array( 'ok' => false, 'description' => 'bot token invalid' ) );
$bpf = hc( 'bale_ping' );
eq( $bpf['status'], 'fail', 'توکن رد شده → fail' );
ok( false !== strpos( $bpf['msg'], 'bot token invalid' ), 'پیام خودِ بله به کاربر می‌رسد' );

// webhook
set_opts( array( 'bale_enabled' => 1, 'bale_token' => 'B', 'bale_chat' => '-1', 'bale_twoway' => 0 ) );
eq( st( 'bale_wh' ), 'info', '★ حالت یک‌طرفه → webhook لازم نیست' );

set_opts( array( 'bale_enabled' => 1, 'bale_token' => 'B', 'bale_chat' => '-1', 'bale_twoway' => 1, 'bale_webhook_secret' => '' ) );
eq( st( 'bale_wh' ), 'fail', '★ دوطرفه بدون کلید → fail' );

set_opts( array( 'bale_enabled' => 1, 'bale_token' => 'B', 'bale_chat' => '-1', 'bale_twoway' => 1, 'bale_webhook_secret' => 'abc123' ) );
$want_wh = Pasokhban_Bale::webhook_url();

http( 200, array( 'ok' => true, 'result' => array( 'url' => '' ) ) );
$wh0 = hc( 'bale_wh' );
eq( $wh0['status'], 'fail', '★ webhook ثبت‌نشده → fail' );
ok( false !== strpos( $wh0['detail'], $want_wh ), 'نشانی مورد انتظار در جزئیات هست' );
ok( false !== strpos( $wh0['fix'], 'ثبت' ), 'راهنما به ثبت webhook اشاره می‌کند' );

http( 200, array( 'ok' => true, 'result' => array( 'url' => $want_wh ) ) );
eq( st( 'bale_wh' ), 'pass', '★ webhook ثبت و همسان → pass' );

http( 200, array( 'ok' => true, 'result' => array( 'url' => 'https://old-domain.com/wp-json/pasokhban/v1/bale/webhook/abc123' ) ) );
$whd = hc( 'bale_wh' );
eq( $whd['status'], 'warn', '★ نشانی متفاوت (دامنه عوض شده) → هشدار' );
ok( false !== strpos( $whd['fix'], 'دامنه' ), 'راهنما به تغییر دامنه اشاره می‌کند' );

http( 200, array( 'ok' => true, 'result' => array( 'url' => $want_wh, 'last_error_message' => 'Read timed out' ) ) );
$whe = hc( 'bale_wh' );
eq( $whe['status'], 'warn', '★ ثبت است ولی تحویل خطا دارد → هشدار' );
ok( false !== strpos( $whe['detail'], 'Read timed out' ), 'خطای بله نمایش داده می‌شود' );

// پورت — بله فقط ۴۴۳ و ۸۸
set_opts( array( 'bale_enabled' => 1, 'bale_token' => 'B', 'bale_twoway' => 1 ) );

$GLOBALS['wp_home_url'] = 'https://example.com';
eq( st( 'bale_port' ), 'pass', '★ https روی ۴۴۳ → pass' );

$GLOBALS['wp_home_url'] = 'https://example.com:8443';
$bport = hc( 'bale_port' );
eq( $bport['status'], 'fail', '★ پورت ۸۴۴۳ → fail (بله رد می‌کند)' );
ok( false !== strpos( $bport['msg'], '8443' ), 'پورت در پیام هست' );
ok( false !== strpos( $bport['msg'], '443' ), 'پورت‌های مجاز در پیام هست' );

$GLOBALS['wp_home_url'] = 'http://example.com';
eq( st( 'bale_port' ), 'fail', '★ بدون HTTPS → fail' );

$GLOBALS['wp_home_url'] = 'https://example.com:88';
eq( st( 'bale_port' ), 'pass', '★ پورت ۸۸ هم مجاز است' );

$GLOBALS['wp_home_url'] = 'http://example.test';

/* ========================================================= */
head( '۹) فایل‌ها و برند' );
/* ========================================================= */

eq( st( 'files_assets' ), 'pass', '★ همهٔ فایل‌های اصلی موجودند' );

$lr = hc( 'files_legacy' );
eq( $lr['status'], 'pass', '★ نام قدیمی در فایل‌های اصلی نمانده است', $lr['msg'] . ' ' . $lr['detail'] );

// این بررسی باید etehadwp (برند فروشنده) را با etehadyar اشتباه نگیرد.
$logo = hc( 'files_logo' );
ok( in_array( $logo['status'], array( 'pass', 'warn' ), true ), 'بررسی تصویر برند نتیجه می‌دهد' );

/* ========================================================= */
head( '۱۰) گزارش متنی' );
/* ========================================================= */

$all = Pasokhban_Health::handle();
$rep = Pasokhban_Health::report( $all['results'] );

ok( false !== strpos( $rep, 'پاسخ‌بان' ), 'نام پلاگین در گزارش هست' );
ok( false !== strpos( $rep, 'etehadwp.com' ), 'نشانی فروشنده در گزارش هست' );
ok( false !== strpos( $rep, 'جمع:' ), 'جمع‌بندی در گزارش هست' );
ok( false !== strpos( $rep, 'هوش مصنوعی' ), 'نام گروه‌ها در گزارش هست' );
ok( false !== strpos( $rep, '[OK' ) || false !== strpos( $rep, '[' ), 'برچسب وضعیت در گزارش هست' );

// خطاها باید با راهنمای رفع در گزارش باشند
$fake = array(
	array( 'id' => 'x', 'group' => 'ai', 'label' => 'آزمون', 'status' => 'fail', 'msg' => 'خراب است', 'detail' => 'کد ۵۰۰', 'fix' => 'فلان کار را بکنید', 'ms' => 0 ),
);
$rep2 = Pasokhban_Health::report( $fake );
ok( false !== strpos( $rep2, 'خراب است' ), 'پیام خطا در گزارش هست' );
ok( false !== strpos( $rep2, 'کد ۵۰۰' ), 'جزئیات خطا در گزارش هست' );
ok( false !== strpos( $rep2, 'فلان کار را بکنید' ), '★ راهنمای رفع در گزارش هست' );
ok( false !== strpos( $rep2, '1 خطا' ), 'شمار خطاها در جمع‌بندی هست' );

// کلید API نباید در گزارش بیاید
set_opts( array( 'api_key' => 'sk-SUPERSECRETKEYVALUE1234567890' ) );
$all2  = Pasokhban_Health::handle( new WP_REST_Request( array( 'group' => 'ai' ) ) );
$rep3  = Pasokhban_Health::report( $all2['results'] );
ok( false === strpos( $rep3, 'sk-SUPERSECRETKEYVALUE1234567890' ), '★ کلید API در گزارش نیست' );

/* ========================================================= */
head( '۱۱) پایداری در برابر خطا' );
/* ========================================================= */

// run_one باید هر Throwable را به نتیجه تبدیل کند، نه خطای ۵۰۰.
// یک بررسی را با callback ناموجود صدا می‌زنیم.
$ref = new ReflectionMethod( 'Pasokhban_Health', 'run_one' );
ok( $ref->isPublic(), 'run_one عمومی است (برای اجرای ترتیبی از REST)' );

// summarize با ورودی خالی
$s0 = Pasokhban_Health::summarize( array() );
eq( $s0['total'], 0, 'خلاصهٔ ورودی خالی → صفر' );
eq( $s0['pass'], 0, 'بدون خطا در خلاصه' );

// هر نتیجه باید فیلدهای لازم را داشته باشد (رابط کاربری به آن‌ها تکیه می‌کند)
$missing_fields = array();
foreach ( $all['results'] as $r ) {
	foreach ( array( 'id', 'group', 'label', 'status', 'msg', 'detail', 'fix', 'ms' ) as $f ) {
		if ( ! array_key_exists( $f, $r ) ) { $missing_fields[] = $r['id'] . ':' . $f; }
	}
}
ok( ! $missing_fields, '★ همهٔ نتایج فیلدهای لازم را دارند', implode( ',', array_slice( $missing_fields, 0, 5 ) ) );

// هیچ نتیجه‌ای نباید وضعیت نامعتبر داشته باشد
$valid  = array( 'pass', 'fail', 'warn', 'info', 'skip' );
$badst  = array();
foreach ( $all['results'] as $r ) {
	if ( ! in_array( $r['status'], $valid, true ) ) { $badst[] = $r['id'] . '=' . $r['status']; }
}
ok( ! $badst, '★ همهٔ وضعیت‌ها معتبرند', implode( ',', $badst ) );

/* ========================================================= */
echo "\n";
if ( $FAIL ) {
	echo "\033[41;30m {$FAIL} تست شکست خورد \033[0m (پاس: {$PASS})\n";
	foreach ( $FAILURES as $f ) { echo "  • {$f}\n"; }
	exit( 1 );
}
echo "\033[42;30m همهٔ " . ( $PASS ) . " تست پاس شد \033[0m\n";
