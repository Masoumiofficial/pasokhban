<?php
/**
 * تست‌های ۲.۴.۰ — ایرانی‌سازی (تقویم شمسی + پیامک + برندسازی سفید).
 *
 * مهم‌ترین بخش: درستی الگوریتم شمسی. یک تقویم که چند روز جابه‌جا باشد
 * از نداشتنش بدتر است، چون کاربر به آن اعتماد می‌کند.
 */

require_once __DIR__ . '/wp-stubs.php';

$PASS = 0; $FAIL = 0; $FAILURES = array();

function ok( $cond, $label, $extra = '' ) {
	global $PASS, $FAIL, $FAILURES;
	if ( $cond ) { $PASS++; echo "  \033[32m✓\033[0m {$label}\n"; }
	else { $FAIL++; $FAILURES[] = $label . ( $extra ? " — {$extra}" : '' ); echo "  \033[31m✗\033[0m {$label}" . ( $extra ? "  → {$extra}" : '' ) . "\n"; }
}
function head( $t ) { echo "\n\033[1m{$t}\033[0m\n"; }
function eq( $a, $b, $label ) { ok( $a === $b, $label, 'انتظار ' . var_export( $b, true ) . ' / دریافت ' . var_export( $a, true ) ); }

$BASE = array(
	'api_key' => 'sk', 'base_url' => 'https://api.example.test/v1',
	'live_enabled' => 1, 'live_human_enabled' => 1, 'rate_limit' => 0, 'live_history' => 20,
	'jalali_dates' => 1, 'jalali_digits' => 1,
	'sms_enabled' => 0, 'sms_provider' => 'kavenegar', 'sms_api_key' => '', 'sms_sender' => '',
	'sms_admin_phone' => '', 'sms_notify_admin' => 0, 'sms_notify_visitor' => 0, 'sms_min_gap' => 10,
	'brand_enabled' => 0, 'brand_name' => '', 'brand_url' => '', 'brand_hide_credit' => 1,
	'live_agent_name' => 'پشتیبانی',
);
function set_opts( array $over = array() ) {
	global $BASE;
	$o = array_merge( $BASE, $over );
	update_option( 'pasokhban_options', $o );
	$rp = new ReflectionProperty( 'Pasokhban_Settings', 'options' );
	$rp->setAccessible( true );
	$rp->setValue( Pasokhban_Settings::instance(), $o );
	return $o;
}
/** timestamp از یک تاریخ میلادی (نیمروز، تا خطای DST نباشد). */
function ts( $d ) { return strtotime( $d . ' 12:00:00 UTC' ); }

set_opts();
update_option( 'gmt_offset', 0 );
Pasokhban_DB::install();

$J = 'Pasokhban_Jalali';

/* ========================================================= */
head( '۱) الگوریتم شمسی — تاریخ‌های مرجع' );
/* ========================================================= */

$ref = array(
	array( '2024-03-20', array( 1403, 1, 1 ),  'نوروز ۱۴۰۳' ),
	array( '2025-03-21', array( 1404, 1, 1 ),  'نوروز ۱۴۰۴ (۱۴۰۳ کبیسه بود)' ),
	array( '2026-03-21', array( 1405, 1, 1 ),  'نوروز ۱۴۰۵' ),
	array( '2025-03-20', array( 1403, 12, 30 ), 'آخرین روز ۱۴۰۳ — اسفند کبیسه' ),
	array( '2026-03-20', array( 1404, 12, 29 ), 'آخرین روز ۱۴۰۴ — اسفند ۲۹ روزه' ),
	array( '2000-03-20', array( 1379, 1, 1 ),  'نوروز ۱۳۷۹ (سال کبیسهٔ میلادی)' ),
	array( '1999-03-21', array( 1378, 1, 1 ),  'نوروز ۱۳۷۸' ),
	array( '2026-09-16', array( 1405, 6, 25 ), 'امروز' ),
	array( '2026-01-01', array( 1404, 10, 11 ), 'اول ژانویه ۲۰۲۶' ),
	array( '1979-02-11', array( 1357, 11, 22 ), '۲۲ بهمن ۱۳۵۷' ),
);
foreach ( $ref as $r ) {
	$t   = ts( $r[0] );
	$got = $J::to_jalali( (int) gmdate( 'Y', $t ), (int) gmdate( 'n', $t ), (int) gmdate( 'j', $t ) );
	eq( $got, $r[1], $r[0] . ' — ' . $r[2] );
}

// رفت‌وبرگشت روی ۲۰۰۰۰ روز متوالی
$bad = 0; $sample = '';
for ( $i = 0; $i < 20000; $i++ ) {
	$t  = strtotime( '1970-01-01 12:00:00 UTC' ) + $i * 86400;
	$gy = (int) gmdate( 'Y', $t ); $gm = (int) gmdate( 'n', $t ); $gd = (int) gmdate( 'j', $t );
	$j  = $J::to_jalali( $gy, $gm, $gd );
	$b  = $J::to_gregorian( $j[0], $j[1], $j[2] );
	if ( $b !== array( $gy, $gm, $gd ) ) {
		$bad++;
		if ( '' === $sample ) { $sample = "$gy-$gm-$gd -> " . implode( '-', $j ) . ' -> ' . implode( '-', $b ); }
	}
}
eq( $bad, 0, '★ رفت‌وبرگشت میلادی↔شمسی روی ۲۰٬۰۰۰ روز متوالی درست است', $sample );

// ورودی نامعتبر
eq( $J::to_jalali( 2026, 13, 1 ), array( 0, 0, 0 ), 'ماه ۱۳ رد می‌شود' );
eq( $J::to_jalali( 2026, 0, 1 ), array( 0, 0, 0 ), 'ماه صفر رد می‌شود' );
eq( $J::to_jalali( 2026, 1, 32 ), array( 0, 0, 0 ), 'روز ۳۲ رد می‌شود' );
eq( $J::to_gregorian( 1405, 13, 1 ), array( 0, 0, 0 ), 'ورودی نامعتبر در تابع معکوس هم رد می‌شود' );

eq( $J::month_name( 1 ), 'فروردین', 'نام ماه ۱' );
eq( $J::month_name( 12 ), 'اسفند', 'نام ماه ۱۲' );
eq( $J::month_name( 99 ), '', 'ماه ناموجود → خالی، نه خطا' );
eq( $J::weekday_name( 6 ), 'شنبه', 'نام روز شنبه' );
eq( $J::weekday_name( 0 ), 'یکشنبه', 'نام روز یکشنبه' );

/* ========================================================= */
head( '۲) قالب‌بندی و ارقام' );
/* ========================================================= */

$t = ts( '2026-09-16' );
eq( $J::format( $t, 'date' ), '۱۴۰۵/۰۶/۲۵', 'تاریخ شمسی با ارقام فارسی' );
eq( $J::format( $t, 'long' ), '۲۵ شهریور ۱۴۰۵', 'قالب بلند با نام ماه' );
ok( false !== strpos( $J::format( $t, 'full' ), 'چهارشنبه' ), 'قالب کامل نام روز هفته دارد', $J::format( $t, 'full' ) );
ok( (bool) preg_match( '/۱۲:۰۰/', $J::format( $t, 'datetime' ) ), 'قالب پیش‌فرض ساعت هم دارد', $J::format( $t, 'datetime' ) );

set_opts( array( 'jalali_digits' => 0 ) );
eq( $J::format( $t, 'date' ), '1405/06/25', '★ با ارقام فارسی خاموش، عدد لاتین نمایش داده می‌شود' );

set_opts( array( 'jalali_dates' => 0 ) );
eq( $J::format( $t, 'date' ), '۲۰۲۶/۰۹/۱۶', '★ با شمسی خاموش، تاریخ میلادی (با ارقام فارسی) نمایش داده می‌شود' );
set_opts( array( 'jalali_dates' => 0, 'jalali_digits' => 0 ) );
eq( $J::format( $t, 'date' ), '2026/09/16', 'با هر دو خاموش، میلادی لاتین' );
set_opts();

// timestamp نامعتبر
eq( $J::format( 0 ), '', 'timestamp صفر → رشتهٔ خالی، نه خطا' );
eq( $J::format( -5 ), '', 'timestamp منفی → رشتهٔ خالی' );
eq( $J::format_mysql( '' ), '', 'رشتهٔ خالی → رشتهٔ خالی' );
eq( $J::format_mysql( 'not-a-date' ), '', 'رشتهٔ بی‌ربط → رشتهٔ خالی' );
eq( $J::ago( '' ), '', 'ago با ورودی خالی → خالی' );

// ★ رگرسیون: strtotime(' UTC') مقدار false نمی‌دهد بلکه زمان «الان» را
// برمی‌گرداند. پس یک رکورد با تاریخ خالی، تاریخ امروز را نشان می‌داد.
eq( $J::format_mysql( '   ' ), '', '★ تاریخ فقط فاصله → خالی (نه تاریخ امروز)' );
eq( $J::ago( '   ' ), '', '★ ago با فقط فاصله → خالی (نه «همین حالا»)' );
eq( $J::format_mysql( '0000-00-00 00:00:00' ), '', 'تاریخ صفر دیتابیس → خالی' );
eq( $J::ago( '0000-00-00 00:00:00' ), '', 'ago با تاریخ صفر → خالی' );

// ago
$now_utc = gmdate( 'Y-m-d H:i:s', time() - 120 );
ok( false !== strpos( $J::ago( $now_utc ), 'دقیقه پیش' ), 'ago فارسی است', $J::ago( $now_utc ) );
$old_utc = gmdate( 'Y-m-d H:i:s', time() - 86400 * 40 );
ok( (bool) preg_match( '/۱۴۰۵/', $J::ago( $old_utc ) ), 'ago برای تاریخ قدیمی، تاریخ شمسی می‌دهد', $J::ago( $old_utc ) );
$just = gmdate( 'Y-m-d H:i:s', time() - 5 );
eq( $J::ago( $just ), 'همین حالا', 'کمتر از یک دقیقه → «همین حالا»' );

// منطقهٔ زمانی
update_option( 'gmt_offset', 3.5 );
$t2 = strtotime( '2026-09-16 21:30:00 UTC' );   // = ۰۱:۰۰ روز بعد در تهران
eq( $J::format( $t2, 'date' ), '۱۴۰۵/۰۶/۲۶', '★ با gmt_offset=+3:30، ۲۱:۳۰ UTC یعنی فردا در تهران' );
update_option( 'gmt_offset', 0 );

// نام فایل خروجی
$stamp = $J::file_stamp( 'pasokhban-contacts' );
ok( 0 === strpos( $stamp, 'pasokhban-contacts-' ), 'پیشوند نام فایل حفظ شد', $stamp );
ok( (bool) preg_match( '/^pasokhban-contacts-\d{4}-\d{2}-\d{2}$/', $stamp ), '★ نام فایل ارقام لاتین دارد (سازگار با همهٔ سیستم‌عامل‌ها)', $stamp );
ok( false === strpos( $stamp, '۱' ), 'ارقام فارسی در نام فایل نیست' );

/* ========================================================= */
head( '۳) تاریخ‌ها در خروجی‌های واقعی پلاگین' );
/* ========================================================= */

$lc    = Pasokhban_LiveChat::instance();
$start = $lc->handle_start( new WP_REST_Request( array(), array( 'lang' => 'fa', 'name' => 'سارا', 'current_url' => 'http://e.test/x' ) ) );
$sid   = (int) Pasokhban_DB::get_session_by_key( $start['key'] )->id;

$list = $lc->admin_sessions( new WP_REST_Request( array( 'status' => 'all', 'per_page' => 10 ) ) );
$one  = $list['items'][0];
ok( (bool) preg_match( '/^۱۴۰۵/', $one['createdAt'] ), '★ تاریخ ایجاد در لیست اینباکس شمسی است', $one['createdAt'] );
ok( isset( $one['createdAtRaw'] ), 'تاریخ خام میلادی هم برای مرتب‌سازی در دسترس است' );

// تاریخ سفارش ووکامرس
require_once __DIR__ . '/wc-stubs.php';
$GLOBALS['wc_orders'][1001] = array( 'number' => '۱۰۰۱', 'status' => 'processing', 'ts' => ts( '2026-09-10' ), 'total' => 1000 );
$order = wc_get_order( 1001 );
$sum   = Pasokhban_Woo::safe_order_summary( $order );
ok( false !== strpos( $sum['date'], '۱۴۰۵' ), '★ تاریخ سفارش ووکامرس شمسی است', $sum['date'] );
ok( false !== strpos( $sum['date'], 'شهریور' ), 'نام ماه شمسی در تاریخ سفارش هست', $sum['date'] );

// پیام‌ها
$msg = Pasokhban_DB::add_message( $sid, 'visitor', 'سلام' );
ok( '' !== $msg->ago, 'فیلد ago پر شد' );
ok( false !== strpos( $msg->ago, 'حالا' ) || false !== strpos( $msg->ago, 'پیش' ), '★ ago فارسی است نه «min» انگلیسی', $msg->ago );

/* ========================================================= */
head( '۴) پیامک — نرمال‌سازی شماره' );
/* ========================================================= */

$S = 'Pasokhban_SMS';
eq( $S::normalize_phone( '09121234567' ), '09121234567', 'قالب استاندارد' );
eq( $S::normalize_phone( '9121234567' ), '09121234567', 'بدون صفر اول' );
eq( $S::normalize_phone( '+989121234567' ), '09121234567', 'با +98' );
eq( $S::normalize_phone( '989121234567' ), '09121234567', 'با 98' );
eq( $S::normalize_phone( '00989121234567' ), '09121234567', 'با 0098' );
eq( $S::normalize_phone( '0912-123-4567' ), '09121234567', 'با خط تیره' );
eq( $S::normalize_phone( '0912 123 4567' ), '09121234567', 'با فاصله' );
eq( $S::normalize_phone( '۰۹۱۲۱۲۳۴۵۶۷' ), '09121234567', 'ارقام فارسی' );
// ★ رگرسیون: الگوی \D فقط ارقام ASCII را می‌شناسد، پس ارقام فارسی را
// کامل حذف می‌کرد و کاربری که با کیبورد فارسی شماره زده بود هرگز پیامک نمی‌گرفت.
eq( $S::normalize_phone( '۰۹۱۲ ۱۲۳ ۴۵۶۷' ), '09121234567', '★ ارقام فارسی با فاصله هم درست خوانده می‌شود' );
eq( $S::normalize_phone( '٠٩١٢١٢٣٤٥٦٧' ), '09121234567', 'ارقام عربی هم خوانده می‌شود' );

eq( $S::normalize_phone( '02112345678' ), '', '★ شمارهٔ ثابت رد می‌شود (فقط موبایل)' );
eq( $S::normalize_phone( '08121234567' ), '', 'شمارهٔ غیر ۰۹ رد می‌شود' );
eq( $S::normalize_phone( '12345' ), '', 'شمارهٔ کوتاه رد می‌شود' );
eq( $S::normalize_phone( '' ), '', 'خالی رد می‌شود' );
eq( $S::normalize_phone( 'abc' ), '', 'رشتهٔ بی‌ربط رد می‌شود' );

/* ========================================================= */
head( '۵) پیامک — وضعیت و ساخت درخواست' );
/* ========================================================= */

eq( $S::enabled(), false, 'با قابلیت خاموش، فعال نیست' );
set_opts( array( 'sms_enabled' => 1 ) );
eq( $S::enabled(), false, '★ بدون کلید API فعال نیست' );
set_opts( array( 'sms_enabled' => 1, 'sms_api_key' => 'KEY', 'sms_provider' => 'badprovider' ) );
eq( $S::enabled(), false, '★ سرویس نامعتبر رد می‌شود' );
set_opts( array( 'sms_enabled' => 1, 'sms_api_key' => 'KEY' ) );
eq( $S::enabled(), true, 'با کلید و سرویس معتبر، فعال است' );

// ساخت درخواست برای هر سه سرویس
$m = new ReflectionMethod( 'Pasokhban_SMS', 'build_request' );
$m->setAccessible( true );

$r = $m->invoke( null, set_opts( array( 'sms_enabled' => 1, 'sms_api_key' => 'K123', 'sms_provider' => 'kavenegar', 'sms_sender' => '1000' ) ), '09121234567', 'سلام' );
ok( false !== strpos( $r['url'], 'api.kavenegar.com/v1/K123/sms/send.json' ), 'آدرس کاوه‌نگار با توکن در مسیر', $r['url'] );
ok( false !== strpos( $r['body'], 'receptor=09121234567' ), 'شماره در بدنهٔ کاوه‌نگار' );

$r = $m->invoke( null, set_opts( array( 'sms_enabled' => 1, 'sms_api_key' => 'K123', 'sms_provider' => 'melipayamak', 'sms_sender' => '3000' ) ), '09121234567', 'سلام' );
eq( $r['url'], 'https://rest.payamak-panel.com/api/SendSMS/SendSMS', 'آدرس ملی‌پیامک' );
ok( 0 === strpos( $r['headers']['Authorization'], 'Basic ' ), '★ احراز هویت ملی‌پیامک Base64 است' );
eq( base64_decode( substr( $r['headers']['Authorization'], 6 ) ), '3000:K123', 'محتوای احراز هویت درست است' );

$r = $m->invoke( null, set_opts( array( 'sms_enabled' => 1, 'sms_api_key' => 'K123', 'sms_provider' => 'smsir', 'sms_sender' => '3000' ) ), '09121234567', 'سلام' );
eq( $r['url'], 'https://api.sms.ir/v1/send/bulk', 'آدرس SMS.ir' );
eq( $r['headers']['x-api-key'], 'K123', 'کلید در هدر SMS.ir' );
ok( is_wp_error( $m->invoke( null, set_opts( array( 'sms_provider' => 'nope' ) ), '09121234567', 'سلام' ) ), 'سرویس ناشناخته WP_Error می‌دهد' );
set_opts();

/* ========================================================= */
head( '۶) پیامک — محدودیت هزینه (مهم‌ترین بخش)' );
/* ========================================================= */

// پاک‌کردن همهٔ transientهای پیامک
$GLOBALS['wp_transients'] = array();

set_opts( array( 'sms_enabled' => 1, 'sms_api_key' => 'K', 'sms_min_gap' => 10 ) );
eq( $S::allow( 1 ), true, 'اولین پیامک مجاز است' );
eq( $S::allow( 1 ), false, '★ دومی در فاصلهٔ زمانی رد می‌شود' );
eq( $S::allow( 2 ), true, 'نشست دیگر مستقل است' );

// فاصلهٔ صفر → سقف تعداد اعمال می‌شود
$GLOBALS['wp_transients'] = array();
set_opts( array( 'sms_enabled' => 1, 'sms_api_key' => 'K', 'sms_min_gap' => 0 ) );
$allowed = 0;
for ( $i = 0; $i < 10; $i++ ) {
	if ( $S::allow( 7 ) ) { $allowed++; }
}
eq( $allowed, $S::MAX_PER_SESSION, '★ سقف پیامک هر نشست اعمال می‌شود', $allowed );

// سقف کلی ساعتی
$GLOBALS['wp_transients'] = array();
set_opts( array( 'sms_enabled' => 1, 'sms_api_key' => 'K', 'sms_min_gap' => 0 ) );
$allowed = 0;
for ( $i = 0; $i < 200; $i++ ) {
	if ( $S::allow( $i + 100 ) ) { $allowed++; }
}
eq( $allowed, $S::MAX_PER_HOUR, '★ سقف کلی ساعتی اعمال می‌شود، حتی با نشست‌های متفاوت', $allowed );
$GLOBALS['wp_transients'] = array();

/* ========================================================= */
head( '۷) پیامک — مسیرهای اعلان' );
/* ========================================================= */

set_opts( array( 'sms_enabled' => 0 ) );
$sess = (object) array( 'id' => 5, 'visitor_name' => 'سارا', 'visitor_family' => 'رضایی', 'visitor_phone' => '09121234567' );
$msgo = (object) array( 'content' => 'سلام' );
eq( $S::on_visitor_message( $sess, $msgo ), false, 'با قابلیت خاموش پیامک نمی‌رود' );

set_opts( array( 'sms_enabled' => 1, 'sms_api_key' => 'K', 'sms_notify_admin' => 1, 'sms_admin_phone' => '' ) );
eq( $S::on_visitor_message( $sess, $msgo ), false, '★ بدون شمارهٔ مدیر پیامک نمی‌رود' );

set_opts( array( 'sms_enabled' => 1, 'sms_api_key' => 'K', 'sms_notify_admin' => 1, 'sms_admin_phone' => '02112345678' ) );
eq( $S::on_visitor_message( $sess, $msgo ), false, '★ شمارهٔ ثابت مدیر رد می‌شود' );

set_opts( array( 'sms_enabled' => 1, 'sms_api_key' => 'K', 'sms_notify_visitor' => 1 ) );
$no_phone = (object) array( 'id' => 6, 'visitor_phone' => '' );
eq( $S::notify_visitor( $no_phone, 'سلام' ), false, '★ بدون شمارهٔ بازدیدکننده پیامک نمی‌رود' );

set_opts( array( 'sms_enabled' => 1, 'sms_api_key' => 'K', 'sms_notify_admin' => 0 ) );
eq( $S::on_visitor_message( $sess, $msgo ), false, 'با خاموش‌بودن اعلان مدیر، پیامک نمی‌رود' );

// ارسال واقعی (با پاسخ ساختگی)
$GLOBALS['wp_transients'] = array();
set_opts( array( 'sms_enabled' => 1, 'sms_api_key' => 'K', 'sms_notify_admin' => 1, 'sms_admin_phone' => '09121234567', 'sms_min_gap' => 0 ) );
$GLOBALS['wp_remote_response'] = array(
	'response' => array( 'code' => 200 ),
	'body'     => json_encode( array( 'return' => array( 'status' => 200, 'message' => 'ok' ) ) ),
);
$GLOBALS['wp_remote_log'] = array();
eq( $S::on_visitor_message( $sess, $msgo ), true, 'پیامک موفق به مدیر رفت' );
ok( ! empty( $GLOBALS['wp_remote_log'] ), 'درخواست HTTP واقعاً زده شد' );
ok( false !== strpos( end( $GLOBALS['wp_remote_log'] )['url'], 'kavenegar' ), 'به کاوه‌نگار رفت' );

// خطای سرویس
$GLOBALS['wp_transients'] = array();
$GLOBALS['wp_remote_response'] = array(
	'response' => array( 'code' => 401 ),
	'body'     => json_encode( array( 'message' => 'Invalid api key' ) ),
);
eq( $S::on_visitor_message( $sess, $msgo ), false, 'خطای سرویس false برمی‌گرداند' );
ok( false !== strpos( $S::$last_error, 'Invalid api key' ), '★ متن خطای سرویس نگه داشته می‌شود', $S::$last_error );

$GLOBALS['wp_transients'] = array();
$GLOBALS['wp_remote_response'] = new WP_Error( 'http', 'timeout' );
eq( $S::on_visitor_message( $sess, $msgo ), false, 'خطای شبکه مدیریت می‌شود' );
$GLOBALS['wp_remote_response'] = null;
$GLOBALS['wp_transients'] = array();

/* ========================================================= */
head( '۸) برندسازی سفید' );
/* ========================================================= */

set_opts();
$pub = $lc->public_settings( 'fa' );
eq( $pub['brand'], '', 'با قابلیت خاموش، برند خالی است' );
eq( $pub['hideCredit'], false, '★ با قابلیت خاموش، پابرگ پاسخ‌بان باقی می‌ماند' );

set_opts( array( 'brand_enabled' => 1, 'brand_name' => 'پشتیبانی من', 'brand_url' => 'https://mysite.test', 'brand_hide_credit' => 1 ) );
$pub = $lc->public_settings( 'fa' );
eq( $pub['brand'], 'پشتیبانی من', 'نام برند به کلاینت می‌رسد' );
eq( $pub['brandUrl'], 'https://mysite.test', 'آدرس برند به کلاینت می‌رسد' );
eq( $pub['hideCredit'], true, '★ حذف اعتبار فعال شد' );

// نام برند خاموش ولی قابلیت روشن
set_opts( array( 'brand_enabled' => 1, 'brand_name' => '', 'brand_hide_credit' => 1 ) );
$pub = $lc->public_settings( 'fa' );
eq( $pub['brand'], '', 'نام برند خالی → رشتهٔ خالی' );
eq( $pub['hideCredit'], true, 'حذف اعتبار همچنان فعال است' );

// نام خیلی بلند
set_opts();
$s = Pasokhban_Settings::instance();
$out = $s->sanitize( array( 'brand_name' => str_repeat( 'ا', 200 ) ) );
ok( mb_strlen( $out['brand_name'] ) <= 40, 'نام برند به ۴۰ کاراکتر محدود شد', mb_strlen( $out['brand_name'] ) );

/* ========================================================= */
head( '۹) تنظیمات — sanitize' );
/* ========================================================= */

$d = $s->defaults();
eq( $d['jalali_dates'], 1, 'تقویم شمسی پیش‌فرض روشن' );
eq( $d['jalali_digits'], 1, 'ارقام فارسی پیش‌فرض روشن' );
eq( $d['sms_enabled'], 0, '★ پیامک پیش‌فرض خاموش (چون پول نقد است)' );
eq( $d['sms_provider'], 'kavenegar', 'سرویس پیش‌فرض کاوه‌نگار' );
eq( $d['brand_enabled'], 0, 'برندسازی پیش‌فرض خاموش' );

$out = $s->sanitize( array( 'sms_provider' => 'evil' ) );
eq( $out['sms_provider'], 'kavenegar', 'سرویس نامعتبر به پیش‌فرض برمی‌گردد' );
$out = $s->sanitize( array( 'sms_provider' => 'smsir' ) );
eq( $out['sms_provider'], 'smsir', 'سرویس معتبر پذیرفته شد' );
$out = $s->sanitize( array( 'sms_sender' => 'abc<script>1000' ) );
eq( $out['sms_sender'], '1000', '★ کاراکترهای غیررقمی از شمارهٔ فرستنده پاک شد' );
$out = $s->sanitize( array( 'sms_min_gap' => 99999 ) );
eq( $out['sms_min_gap'], 1440, 'فاصلهٔ پیامک به سقف چسبید' );
$out = $s->sanitize( array( 'sms_admin_phone' => '09121234567' ) );
eq( $out['sms_admin_phone'], '09121234567', 'شمارهٔ مدیر ذخیره شد' );
$out = $s->sanitize( array( 'jalali_dates' => 0, 'brand_hide_credit' => 0 ) );
eq( $out['jalali_dates'], 0, 'کلید boolean تقویم' );
eq( $out['brand_hide_credit'], 0, 'کلید boolean حذف اعتبار' );

/* ========================================================= */
head( '۱۰) صفحهٔ تنظیمات' );
/* ========================================================= */

set_opts( array( 'sms_enabled' => 1, 'sms_provider' => 'melipayamak', 'brand_enabled' => 1 ) );
ob_start();
Pasokhban_Settings::instance()->render_page();
$html = ob_get_clean();

$fields = array(
	'jalali_dates', 'jalali_digits',
	'sms_enabled', 'sms_provider', 'sms_api_key', 'sms_sender', 'sms_admin_phone',
	'sms_notify_admin', 'sms_notify_visitor', 'sms_min_gap',
	'brand_enabled', 'brand_hide_credit', 'brand_name', 'brand_url',
);
$missing = array();
foreach ( $fields as $f ) {
	if ( false === strpos( $html, 'pasokhban_options[' . $f . ']' ) ) { $missing[] = $f; }
}
eq( $missing, array(), 'همهٔ ۱۴ فیلد تازه در فرم تنظیمات هست' );

ok( false !== strpos( $html, 'psb-sms-test-form' ), 'فرم آزمایش پیامک هست' );
ok( false !== strpos( $html, 'pasokhban_test_sms' ), 'اکشن آزمایش پیامک درست است' );
ok( false !== strpos( $html, 'پیامک پول نقد است' ), 'هشدار هزینهٔ پیامک در تنظیمات هست' );
ok( false !== strpos( $html, 'value="melipayamak"' ), 'سرویس انتخاب‌شده رندر شد' );

// فرم تو‌در‌تو نشد
$nc = preg_replace( '/<!--.*?-->/s', '', $html );
preg_match_all( '/<form\b/', $nc, $m1 );
preg_match_all( '/<\/form>/', $nc, $m2 );
eq( count( $m1[0] ), count( $m2[0] ), 'تعداد <form> و </form> برابر است' );

echo "\n" . str_repeat( '─', 52 ) . "\n";
if ( 0 === $FAIL ) {
	echo "\033[42;30m همهٔ {$PASS} تست ایرانی‌سازی پاس شد \033[0m\n";
} else {
	echo "\033[41;97m {$FAIL} تست شکست خورد \033[0m (پاس: {$PASS})\n";
	foreach ( $FAILURES as $f ) { echo "   • {$f}\n"; }
}
echo str_repeat( '─', 52 ) . "\n";
exit( 0 === $FAIL ? 0 : 1 );
