<?php
/**
 * تست قابلیت‌های نسخهٔ ۱.۵.۰:
 * امتیاز رضایت (CSAT) · پاسخ‌های آماده · آمار · اعلان‌ها
 */

require_once __DIR__ . '/wp-stubs.php';

$PASS = 0; $FAIL = 0; $FAILURES = array();

function ok( $cond, $label, $extra = '' ) {
	global $PASS, $FAIL, $FAILURES;
	if ( $cond ) { $PASS++; echo "  \033[32m✓\033[0m {$label}\n"; }
	else { $FAIL++; $FAILURES[] = $label . ( $extra ? " — {$extra}" : '' ); echo "  \033[31m✗\033[0m {$label}" . ( $extra ? "  → {$extra}" : '' ) . "\n"; }
}
function head( $t ) { echo "\n\033[1m{$t}\033[0m\n"; }
function eq( $a, $b, $label ) { ok( $a === $b, $label, 'انتظار ' . var_export( $b, true ) . ' / دریافت ' . var_export( $a, true ) ); }

update_option( 'pasokhban_options', array(
	'api_key' => 'sk-test', 'base_url' => 'https://api.example.test/v1', 'model' => 'gpt-4o',
	'knowledge' => 0, 'live_enabled' => 1, 'rate_limit' => 0, 'live_history' => 20,
	'streaming' => 1, 'csat' => 1, 'accent' => '#22d3ee',
	'notify_email' => 1, 'notify_telegram' => 1, 'notify_min_gap' => 5, 'notify_only_offline' => 0,
) );
$settings = Pasokhban_Settings::instance();
$rp = new ReflectionProperty( 'Pasokhban_Settings', 'options' );
$rp->setAccessible( true );
$rp->setValue( $settings, get_option( 'pasokhban_options' ) );

Pasokhban_DB::install();

$GLOBALS['wp_remote_response'] = array(
	'response' => array( 'code' => 200 ),
	'body'     => json_encode( array( 'choices' => array( array( 'message' => array( 'content' => 'پاسخ دستیار' ) ) ) ) ),
);

$live = Pasokhban_LiveChat::instance();
$live->register_routes();

/* ========================================================= */
head( '۱) ساختار ۱.۵.۰' );
/* ========================================================= */

ok( isset( $GLOBALS['wp_rest_routes']['pasokhban/v1/live/feedback'] ), 'مسیر /live/feedback ثبت شد' );
Pasokhban_Stream::instance()->register_routes();
ok( isset( $GLOBALS['wp_rest_routes']['pasokhban/v1/live/stream'] ), 'مسیر /live/stream ثبت شد' );
ok( version_compare( Pasokhban_DB::SCHEMA_VERSION, '1.5.0', '>=' ), 'نسخهٔ ساختار بالا رفت', Pasokhban_DB::SCHEMA_VERSION );

global $wpdb;
$fb_tbl = Pasokhban_DB::feedback_table();
ok( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $fb_tbl ) ), 'جدول بازخورد ساخته شد: ' . $fb_tbl );
ok( Pasokhban_DB::tables_exist(), 'tables_exist هر سه جدول را می‌بیند' );

$pub = $live->public_settings( 'fa' );
eq( $pub['streaming'], true, 'streaming به کلاینت می‌رسد' );
eq( $pub['csat'], true, 'csat به کلاینت می‌رسد' );
ok( ! empty( $pub['streamUrl'] ), 'آدرس stream به کلاینت می‌رسد' );

/* ========================================================= */
head( '۲) پاسخ‌های آمادهٔ اپراتور' );
/* ========================================================= */

$o = get_option( 'pasokhban_options' );
$o['canned'] = "سلام! خوش آمدید 👋|خوش‌آمد\nبله، تماس می‌گیریم.|تماس\nمتن بدون عنوان\n" . str_repeat( 'x', 200 ) . "|طولانی";
update_option( 'pasokhban_options', $o );
$rp->setValue( $settings, $o );

$canned = $live->canned_responses();
ok( count( $canned ) >= 3, 'پاسخ‌های آماده پارس شد', 'تعداد: ' . count( $canned ) );
eq( $canned[0]['text'], 'سلام! خوش آمدید 👋', 'متن اول درست است' );
eq( $canned[0]['label'], 'خوش‌آمد', 'عنوان اول از بعد از | گرفته شد' );
eq( $canned[1]['label'], 'تماس', 'عنوان دوم درست است' );
ok( false !== strpos( $canned[2]['label'], 'متن بدون عنوان' ), 'بدون عنوان، از خود متن بریده می‌شود' );
ok( count( $canned ) <= 12, 'به ۱۲ مورد محدود می‌شود', 'تعداد: ' . count( $canned ) );

$o['canned'] = '';
update_option( 'pasokhban_options', $o );
$rp->setValue( $settings, $o );
eq( $live->canned_responses(), array(), 'خالی → آرایهٔ خالی' );

$o['canned'] = "سلام|خوش‌آمد";
update_option( 'pasokhban_options', $o );
$rp->setValue( $settings, $o );

/* ========================================================= */
head( '۳) امتیاز رضایت (CSAT)' );
/* ========================================================= */

$r = $live->handle_start( new WP_REST_Request( array(), array( 'lang' => 'fa', 'name' => 'سارا', 'family' => 'احمدی', 'phone' => '09121112233' ) ) );
$key = $r['key'];
$sid = Pasokhban_DB::get_session_by_key( $key );

$send = $live->handle_send( new WP_REST_Request( array(), array( 'key' => $key, 'content' => 'سلام', 'lang' => 'fa' ) ) );
$agent_msg = $send['reply'];
$mid = (int) ( is_object( $agent_msg ) ? $agent_msg->id : $agent_msg['id'] );

// امتیاز مثبت
$res = $live->handle_feedback( new WP_REST_Request( array(), array( 'key' => $key, 'message_id' => $mid, 'rating' => 1 ) ) );
ok( is_array( $res ) && ! empty( $res['ok'] ), 'امتیاز 👍 ثبت شد' );
$fbs = Pasokhban_DB::get_feedback( (int) $sid->id );
eq( isset( $fbs[ $mid ] ) ? $fbs[ $mid ] : null, 1, 'امتیاز ۱ ذخیره شد' );

// تغییر رأی باید جایگزین شود نه اضافه
$live->handle_feedback( new WP_REST_Request( array(), array( 'key' => $key, 'message_id' => $mid, 'rating' => -1 ) ) );
$fbs = Pasokhban_DB::get_feedback( (int) $sid->id );
eq( $fbs[ $mid ], -1, 'تغییر رأی جایگزین شد' );
eq( count( $wpdb->get_results( "SELECT * FROM {$fb_tbl}" ) ), 1, 'ردیف تکراری ساخته نشد' );

// امتیاز نامعتبر
$bad = $live->handle_feedback( new WP_REST_Request( array(), array( 'key' => $key, 'message_id' => $mid, 'rating' => 5 ) ) );
ok( is_wp_error( $bad ) && 'pasokhban_bad_rating' === $bad->get_error_code(), 'امتیاز نامعتبر رد می‌شود' );

// message_id نامعتبر
$bad2 = $live->handle_feedback( new WP_REST_Request( array(), array( 'key' => $key, 'message_id' => 0, 'rating' => 1 ) ) );
ok( is_wp_error( $bad2 ) && 'pasokhban_bad_message' === $bad2->get_error_code(), 'شناسهٔ پیام نامعتبر رد می‌شود' );

// امنیت: پیام مال نشست دیگری
$r2 = $live->handle_start( new WP_REST_Request( array(), array( 'lang' => 'fa', 'name' => 'دیگری' ) ) );
$attack = $live->handle_feedback( new WP_REST_Request( array(), array( 'key' => $r2['key'], 'message_id' => $mid, 'rating' => 1 ) ) );
ok( is_wp_error( $attack ) && 'pasokhban_forbidden' === $attack->get_error_code(), 'امتیاز به مکالمهٔ دیگر رد می‌شود (امنیت)' );

// نشست ناموجود
$noS = $live->handle_feedback( new WP_REST_Request( array(), array( 'key' => 'deadbeefdeadbeefdeadbeefdeadbeef', 'message_id' => 1, 'rating' => 1 ) ) );
ok( is_wp_error( $noS ), 'نشست ناموجود رد می‌شود' );

// csat خاموش
$o = get_option( 'pasokhban_options' );
$o['csat'] = 0;
update_option( 'pasokhban_options', $o );
$rp->setValue( $settings, $o );
$off = $live->handle_feedback( new WP_REST_Request( array(), array( 'key' => $key, 'message_id' => $mid, 'rating' => 1 ) ) );
ok( is_wp_error( $off ) && 'pasokhban_disabled' === $off->get_error_code(), 'با csat خاموش، اندپوینت ۴۰۳ می‌دهد' );
$o['csat'] = 1;
update_option( 'pasokhban_options', $o );
$rp->setValue( $settings, $o );

/* ========================================================= */
head( '۴) آمار' );
/* ========================================================= */

$st = Pasokhban_DB::get_stats( 30 );
ok( isset( $st['total_sessions'] ), 'آمار total_sessions دارد' );
ok( isset( $st['csat'] ), 'آمار csat دارد' );
ok( is_array( $st['daily'] ) && 30 === count( $st['daily'] ), 'سری روزانه ۳۰ روز دارد', 'تعداد: ' . count( $st['daily'] ) );
ok( is_array( $st['top_questions'] ), 'پرتکرارترین سؤال‌ها هست' );
eq( $st['thumbs_down'], 1, 'یک رأی منفی ثبت شده' );
eq( $st['csat'], 0, 'رضایت ۰٪ (فقط رأی منفی)' );
ok( $st['new_sessions'] >= 2, 'گفتگوی جدید شمرده شد', 'تعداد: ' . $st['new_sessions'] );
ok( $st['visitor_msgs'] >= 1, 'پیام کاربران شمرده شد' );
ok( $st['ai_msgs'] >= 1, 'پاسخ AI شمرده شد' );
eq( $st['with_contact'], 1, 'مخاطب با شمارهٔ تماس شمرده شد' );

// رأی مثبت اضافه کن و دوباره حساب کن
$live->handle_feedback( new WP_REST_Request( array(), array( 'key' => $key, 'message_id' => $mid, 'rating' => 1 ) ) );
$st2 = Pasokhban_DB::get_stats( 30 );
eq( $st2['csat'], 100, 'با تغییر رأی به مثبت، رضایت ۱۰۰٪ شد' );

// سقف بازه
$st3 = Pasokhban_DB::get_stats( 99999 );
eq( $st3['days'], 365, 'بازه به ۳۶۵ روز محدود می‌شود' );
$st4 = Pasokhban_DB::get_stats( 0 );
eq( $st4['days'], 1, 'بازهٔ صفر به ۱ روز می‌رسد' );

// صفحهٔ آمار رندر می‌شود
ob_start();
Pasokhban_Analytics::render();
$an = ob_get_clean();
ok( strpos( $an, 'psb-analytics' ) !== false, 'صفحهٔ آمار رندر شد' );
ok( strpos( $an, 'psb-an-svg' ) !== false, 'نمودار میله‌ای SVG ساخته شد' );
ok( strpos( $an, 'psb-an-donut' ) !== false, 'نمودار دونات ساخته شد' );
ok( strpos( $an, 'psb-an-cards' ) !== false, 'کارت‌های آمار هست' );
ok( strpos( $an, 'pasokhban_export_stats' ) !== false, 'دکمهٔ خروجی CSV هست' );
ok( strpos( $an, 'رضایت کاربران' ) !== false, 'کارت رضایت نمایش داده می‌شود' );
ok( substr_count( $an, '<rect class="b1"' ) >= 30, 'میله‌های نمودار برای هر روز ساخته شد' );

/* ========================================================= */
head( '۵) اعلان‌ها' );
/* ========================================================= */

// throttle: بار اول بله، بار دوم نه
delete_transient( 'pasokhban_notified_999' );
eq( Pasokhban_Notify::should_notify( 999, 5 ), true, 'اولین اعلان برای یک نشست مجاز است' );
eq( Pasokhban_Notify::should_notify( 999, 5 ), false, 'اعلان دوم در بازهٔ ۵ دقیقه رد می‌شود' );
delete_transient( 'pasokhban_notified_999' );
eq( Pasokhban_Notify::should_notify( 998, 0 ), true, 'با gap=0 همیشه مجاز است (۱)' );
eq( Pasokhban_Notify::should_notify( 998, 0 ), true, 'با gap=0 همیشه مجاز است (۲)' );

// فقط وقتی اپراتور آفلاین است
$o = get_option( 'pasokhban_options' );
$o['notify_only_offline'] = 1;
update_option( 'pasokhban_options', $o );
$rp->setValue( $settings, $o );

set_transient( Pasokhban_LiveChat::HEARTBEAT, 1, 25 );
delete_transient( 'pasokhban_notified_500' );
$sess500 = Pasokhban_DB::create_session( array( 'name' => 'تست' ) );
$sess500->id = 500;
$before = count( (array) $GLOBALS['wp_mails'] );
Pasokhban_Notify::on_visitor_message( $sess500, (object) array( 'content' => 'سلام' ) );
eq( count( (array) $GLOBALS['wp_mails'] ), $before, 'وقتی اپراتور آنلاین است، اعلان نمی‌رود' );

delete_transient( Pasokhban_LiveChat::HEARTBEAT );
Pasokhban_Notify::on_visitor_message( $sess500, (object) array( 'content' => 'سلام' ) );
ok( count( (array) $GLOBALS['wp_mails'] ) > $before, 'وقتی اپراتور آفلاین است، ایمیل می‌رود' );

// محتوای ایمیل
$last = end( $GLOBALS['wp_mails'] );
ok( false !== strpos( $last['message'], 'سلام' ), 'متن پیام در ایمیل هست' );
ok( false !== strpos( $last['subject'], 'تست' ), 'نام بازدیدکننده در موضوع ایمیل هست' );
ok( false !== strpos( $last['message'], 'admin.php?page=pasokhban-inbox' ), 'لینک اینباکس در ایمیل هست' );

// هر دو کانال خاموش → هیچ اعلانی
$o['notify_email'] = 0;
$o['notify_telegram'] = 0;
update_option( 'pasokhban_options', $o );
$rp->setValue( $settings, $o );
delete_transient( 'pasokhban_notified_501' );
$sess501 = Pasokhban_DB::create_session( array( 'name' => 'بی‌اعلان' ) );
$sess501->id = 501;
$b2 = count( (array) $GLOBALS['wp_mails'] );
Pasokhban_Notify::on_visitor_message( $sess501, (object) array( 'content' => 'سلام' ) );
eq( count( (array) $GLOBALS['wp_mails'] ), $b2, 'با هر دو کانال خاموش، اعلانی نمی‌رود' );

// تلگرام بدون تنظیمات
$o['notify_email'] = 0;
$o['notify_telegram'] = 1;
$o['notify_telegram_token'] = '';
update_option( 'pasokhban_options', $o );
$rp->setValue( $settings, $o );
Pasokhban_Notify::$last_result = array();
$ref = new ReflectionMethod( 'Pasokhban_Notify', 'send_telegram' );
$ref->setAccessible( true );
$ref->invoke( null, $o, 'تست', 'متن', (object) array( 'current_url' => '' ) );
eq( Pasokhban_Notify::$last_result['telegram'], 'unconfigured', 'تلگرام بدون توکن، unconfigured می‌دهد' );

/* ========================================================= */
head( '۵.۵) پروکسی تلگرام' );
/* ========================================================= */

// پاک‌سازی آدرس پروکسی
eq( Pasokhban_Settings::sanitize_proxy( 'socks5://127.0.0.1:9050' ), 'socks5://127.0.0.1:9050', 'socks5 قبول می‌شود' );
eq( Pasokhban_Settings::sanitize_proxy( 'socks5h://127.0.0.1:9050' ), 'socks5h://127.0.0.1:9050', 'socks5h قبول می‌شود' );
eq( Pasokhban_Settings::sanitize_proxy( 'http://185.1.2.3:8080' ), 'http://185.1.2.3:8080', 'http قبول می‌شود' );
eq( Pasokhban_Settings::sanitize_proxy( 'https://proxy.example.com:443' ), 'https://proxy.example.com:443', 'https قبول می‌شود' );
eq( Pasokhban_Settings::sanitize_proxy( 'http://user:pass@185.1.2.3:8080' ), 'http://user:pass@185.1.2.3:8080', 'کاربر/رمز حفظ می‌شود' );
eq( Pasokhban_Settings::sanitize_proxy( '  socks5://127.0.0.1:9050  ' ), 'socks5://127.0.0.1:9050', 'فاصلهٔ اضافه حذف می‌شود' );
eq( Pasokhban_Settings::sanitize_proxy( '127.0.0.1:9050' ), 'http://127.0.0.1:9050', 'بدون scheme، http پیش‌فرض می‌شود' );
eq( Pasokhban_Settings::sanitize_proxy( '' ), '', 'خالی → خالی' );
eq( Pasokhban_Settings::sanitize_proxy( 'ftp://127.0.0.1:21' ), '', 'scheme نامعتبر رد می‌شود' );
eq( Pasokhban_Settings::sanitize_proxy( 'javascript:alert(1)' ), '', 'javascript رد می‌شود (امنیت)' );
eq( Pasokhban_Settings::sanitize_proxy( 'not a url' ), '', 'رشتهٔ بی‌معنی رد می‌شود' );
eq( Pasokhban_Settings::sanitize_proxy( 'http://<script>x</script>' ), '', 'تگ HTML رد می‌شود' );

// ذخیره در تنظیمات
$o = get_option( 'pasokhban_options' );
$o['notify_telegram_proxy'] = 'socks5h://127.0.0.1:9050';
$o['notify_telegram_base']  = 'https://tg-mirror.example.com/';
update_option( 'pasokhban_options', $o );
$san = Pasokhban_Settings::instance()->sanitize( $o );
eq( $san['notify_telegram_proxy'], 'socks5h://127.0.0.1:9050', 'پروکسی در sanitize حفظ می‌شود' );
eq( $san['notify_telegram_base'], 'https://tg-mirror.example.com', 'اسلش انتهایی آدرس پایه حذف می‌شود' );

$bad = Pasokhban_Settings::instance()->sanitize( array( 'notify_telegram_proxy' => 'ftp://x:1' ) );
eq( $bad['notify_telegram_proxy'], '', 'پروکسی نامعتبر در sanitize خالی می‌شود' );

// تلگرام بدون توکن هنوز unconfigured می‌دهد (نه خطای پروکسی)
$o2 = get_option( 'pasokhban_options' );
$o2['notify_telegram'] = 1;
$o2['notify_telegram_token'] = '';
update_option( 'pasokhban_options', $o2 );
$rp->setValue( $settings, $o2 );
Pasokhban_Notify::$last_result = array();
$ref = new ReflectionMethod( 'Pasokhban_Notify', 'send_telegram' );
$ref->setAccessible( true );
$ref->invoke( null, Pasokhban_Settings::instance()->sanitize( $o2 ), 'ت', 'م', (object) array( 'current_url' => '' ) );
eq( Pasokhban_Notify::$last_result['telegram'], 'unconfigured', 'بدون توکن، unconfigured (نه تلاش برای اتصال)' );

// مسیر cURL وجود دارد
ok( method_exists( 'Pasokhban_Notify', 'send_via_curl' ), 'متد send_via_curl وجود دارد' );
$m = new ReflectionMethod( 'Pasokhban_Notify', 'send_via_curl' );
eq( $m->getNumberOfParameters(), 3, 'send_via_curl سه پارامتر دارد' );

/* ========================================================= */
head( '۵.۷) بازیابی پاسخ (/live/answer)' );
/* ========================================================= */

$live->register_routes();
ok( isset( $GLOBALS['wp_rest_routes']['pasokhban/v1/live/answer'] ), 'مسیر /live/answer ثبت شد' );

$o = get_option( 'pasokhban_options' );
$o['live_enabled'] = 1; $o['api_key'] = 'sk-test'; $o['rate_limit'] = 0; $o['live_history'] = 20; $o['knowledge'] = 0;
update_option( 'pasokhban_options', $o );
$rp->setValue( $settings, $o );

$GLOBALS['wp_remote_response'] = array(
	'response' => array( 'code' => 200 ),
	'body'     => json_encode( array( 'choices' => array( array( 'message' => array( 'content' => 'پاسخ بازیابی‌شده' ) ) ) ) ),
);

// نشست با یک پیام بی‌پاسخ از کاربر (شبیه حالتی که جریان قطع شده)
$r = $live->handle_start( new WP_REST_Request( array(), array( 'lang' => 'fa', 'name' => 'سارا' ) ) );
$rkey = $r['key'];
$rsid = Pasokhban_DB::get_session_by_key( $rkey );
Pasokhban_DB::add_message( (int) $rsid->id, 'visitor', 'سؤال بی‌پاسخ' );

$before = count( Pasokhban_DB::get_messages( (int) $rsid->id ) );
$ans = $live->handle_answer( new WP_REST_Request( array(), array( 'key' => $rkey ) ) );

ok( is_array( $ans ) && ! is_wp_error( $ans ), '/live/answer موفق بود', is_wp_error( $ans ) ? $ans->get_error_message() : '' );
eq( isset( $ans['content'] ) ? $ans['content'] : null, 'پاسخ بازیابی‌شده', 'محتوای پاسخ درست است' );
ok( ! empty( $ans['id'] ), 'شناسهٔ پاسخ برگشت' );
ok( isset( $ans['ms'] ) && $ans['ms'] >= 0, 'زمان پاسخ اندازه‌گیری شد' );

$after = count( Pasokhban_DB::get_messages( (int) $rsid->id ) );
eq( $after, $before + 1, 'فقط یک پیام (پاسخ) اضافه شد — پیام کاربر دوباره ذخیره نشد' );

$last_msgs = Pasokhban_DB::get_messages( (int) $rsid->id );
$lastone = $last_msgs[ count( $last_msgs ) - 1 ];
eq( $lastone->sender, 'agent', 'پیام جدید نقش agent دارد' );
eq( isset( $lastone->meta['recovered'] ) ? $lastone->meta['recovered'] : null, true, 'علامت recovered ثبت شد' );

// صدای دوم: دیگر پیام بی‌پاسخی نیست
$again = $live->handle_answer( new WP_REST_Request( array(), array( 'key' => $rkey ) ) );
ok( is_wp_error( $again ) && 'pasokhban_no_pending' === $again->get_error_code(), 'وقتی پیام بی‌پاسخی نیست، ۴۰۹ می‌دهد' );

// نشست ناموجود
$noS = $live->handle_answer( new WP_REST_Request( array(), array( 'key' => 'deadbeefdeadbeefdeadbeefdeadbeef' ) ) );
ok( is_wp_error( $noS ), 'نشست ناموجود رد می‌شود' );

// حالت اپراتور انسانی → AI پاسخ نمی‌دهد
Pasokhban_DB::update_session( (int) $rsid->id, array( 'mode' => 'agent' ) );
Pasokhban_DB::add_message( (int) $rsid->id, 'visitor', 'سؤال در حالت اپراتور' );
$agent_mode = $live->handle_answer( new WP_REST_Request( array(), array( 'key' => $rkey ) ) );
ok( is_array( $agent_mode ) && ! empty( $agent_mode['queued'] ), 'در حالت اپراتور، queued برمی‌گردد نه پاسخ AI' );

/* ========================================================= */
head( '۶) مسیر جریان‌دار' );
/* ========================================================= */

$stream = Pasokhban_Stream::instance();

// emit() عمداً بافر را flush می‌کند (رفتار درست SSE)، پس دو لایه بافر
// می‌گذاریم تا محتوا در لایهٔ بیرونی بماند.
$rm = new ReflectionMethod( 'Pasokhban_Stream', 'emit' );
$rm->setAccessible( true );
ob_start();
ob_start();
$rm->invoke( $stream, array( 't' => 'سلام' ) );
ob_end_flush();
$out = ob_get_clean();
ok( 0 === strpos( $out, 'data: ' ), 'رویداد با «data: » شروع می‌شود' );
ok( "\n\n" === substr( $out, -2 ), 'رویداد با دو خط جدید تمام می‌شود' );
$decoded = json_decode( trim( substr( $out, 6 ) ), true );
eq( isset( $decoded['t'] ) ? $decoded['t'] : null, 'سلام', 'payload درست encode شد' );

// متن فارسی نباید escape شود (JSON_UNESCAPED_UNICODE)
ok( false !== strpos( $out, 'سلام' ), 'فارسی به‌صورت خوانا encode شد (نه \\uXXXX)' );

echo "\n" . str_repeat( '─', 52 ) . "\n";
if ( 0 === $FAIL ) {
	echo "\033[42;30m همهٔ {$PASS} تست نسخهٔ ۱.۵.۰ پاس شد \033[0m\n";
} else {
	echo "\033[41;97m {$FAIL} تست شکست خورد \033[0m (پاس: {$PASS})\n";
	foreach ( $FAILURES as $f ) {
		echo "   • {$f}\n";
	}
}
echo str_repeat( '─', 52 ) . "\n";
exit( 0 === $FAIL ? 0 : 1 );
