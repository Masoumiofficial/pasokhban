/**
 * تست حالت inline (شورت‌کد [pasokhban]).
 *
 * باگ ۱.۵.۳: applySettings کلاس sheet را بدون توجه به حالت اضافه می‌کرد
 * و قاعدهٔ موبایل !important داشت، پس در موبایل نسخهٔ شورت‌کد به ورق
 * تمام‌صفحهٔ ثابت تبدیل می‌شد و از جریان صفحه بیرون می‌زد.
 */
const fs = require('fs');
const { JSDOM } = require('jsdom');

const JS = fs.readFileSync(__dirname + '/../plugin/assets/js/pasokhban-chat.js', 'utf8');
const CSS = fs.readFileSync(__dirname + '/../plugin/assets/css/pasokhban-chat.css', 'utf8');

let pass = 0, fail = 0; const fails = [];
const ok = (c, l, x) => { if (c) { pass++; console.log(`  \x1b[32m✓\x1b[0m ${l}`); } else { fail++; fails.push(l + (x ? ' — ' + x : '')); console.log(`  \x1b[31m✗\x1b[0m ${l}` + (x ? '  → ' + x : '')); } };
const eq = (a, b, l) => ok(JSON.stringify(a) === JSON.stringify(b), l, `انتظار ${JSON.stringify(b)} / دریافت ${JSON.stringify(a)}`);
const head = t => console.log(`\n\x1b[1m${t}\x1b[0m`);
const wait = ms => new Promise(r => setTimeout(r, ms));

const SETTINGS = {
  title: 'چت', agentName: 'پشتیبانی', greeting: 'سلام', placeholder: 'بنویس',
  accent: '#22d3ee', position: 'start', autoOpen: false, autoDelay: 5, starter: ['سؤال نمونه'],
  humanHandoff: true, sound: false, offlineNote: '',
  offsetBottom: 18, offsetSide: 18, launcherSize: 62, panelWidth: 384, panelHeight: 620,
  radius: 28, blur: 30, glassOpacity: 62, launcherLabel: '', teaser: true, teaserText: 'x',
  mobileSheet: true, maximize: true, showFooter: true, theme: 'auto',
  prechat: false, streaming: false, csat: true
};

function makeDom(mode, viewportWidth) {
  const dom = new JSDOM(
    `<!DOCTYPE html><html dir="rtl"><head><style>${CSS}</style></head>
     <body><main><p>محتوای صفحه</p><div id="pasokhban-live" data-mode="${mode}" aria-live="polite"></div></main></body></html>`,
    { url: 'http://e.test/shortcode-page/', pretendToBeVisual: true, runScripts: 'dangerously' }
  );
  const w = dom.window;
  w.innerWidth = viewportWidth || 1200;
  w.Response = class {
    constructor(b, o) { o = o || {}; this.body = b; this.status = o.status || 200; this.ok = true;
      const raw = o.headers || {}, lower = {}; Object.keys(raw).forEach(k => lower[k.toLowerCase()] = raw[k]);
      this.headers = { get: k => lower[String(k).toLowerCase()] || null }; }
    json() { return Promise.resolve(JSON.parse(this.body)); }
  };
  w.PASOKHBAN_CHAT = { restUrl: '/wp-json/pasokhban/v1', nonce: 'n', lang: 'fa' };
  w.PASOKHBAN_CHAT_SETTINGS = SETTINGS;
  w.fetch = (url, opt) => {
    const path = String(url).replace(/^.*\/v1/, '');
    let data = { ok: true };
    if (path.indexOf('/live/start') === 0) data = { key: 'a1b2c3d4e5f60718293a4b5c6d7e8f90', mode: 'ai', status: 'open', messages: [], agentOnline: false, settings: SETTINGS };
    if (path.indexOf('/live/poll') === 0) data = { messages: [], mode: 'ai', status: null, typing: false, agentOnline: false };
    return Promise.resolve(new w.Response(JSON.stringify(data), { status: 200, headers: { 'Content-Type': 'application/json' } }));
  };
  const s = w.document.createElement('script');
  s.textContent = JS;
  w.document.body.appendChild(s);
  return { w, d: w.document };
}

(async () => {
  head('۱) حالت inline در دسکتاپ');
  let t = makeDom('inline', 1200);
  await wait(350);
  let root = t.d.getElementById('pasokhban-live');
  let panel = t.d.querySelector('.psb-panel');

  ok(!!panel, 'پنل ساخته شد');
  ok(root.classList.contains('is-inline'), 'کلاس is-inline اضافه شد');
  ok(!root.classList.contains('sheet'), 'کلاس sheet در حالت inline اضافه نشد');
  ok(root.classList.contains('is-open'), 'پنل بدون کلیک باز است');

  const cs = t.w.getComputedStyle(panel);
  eq(cs.position, 'relative', 'پنل position:relative است (داخل جریان صفحه، نه ثابت)');
  eq(cs.visibility, 'visible', 'پنل دیده می‌شود');
  eq(cs.maxWidth, '760px', 'سقف عرض برای خوانایی دارد');

  // حباب و هاله نباید در حالت inline باشند
  eq(t.w.getComputedStyle(t.d.querySelector('.psb-launcher')).display, 'none', 'حباب راه‌انداز پنهان است');
  eq(t.w.getComputedStyle(t.d.querySelector('.psb-aura')).display, 'none', 'هالهٔ پس‌زمینه پنهان است');
  eq(t.w.getComputedStyle(t.d.querySelector('.psb-teaser')).display, 'none', 'برچسب دعوت پنهان است');

  // محتوا باید رندر شده باشد
  ok(!!t.d.querySelector('.psb-msg.agent'), 'پیام خوش‌آمد رندر شد');
  ok(!!t.d.querySelector('.psb-composer'), 'کادر ورودی هست');
  ok(t.d.querySelectorAll('.psb-chip').length >= 1, 'دکمه‌های شروع هستند');

  head('۲) حالت inline در موبایل (باگ اصلی)');
  t = makeDom('inline', 390);
  await wait(350);
  root = t.d.getElementById('pasokhban-live');
  panel = t.d.querySelector('.psb-panel');

  ok(!root.classList.contains('sheet'), 'در موبایل هم کلاس sheet اضافه نشد');
  ok(root.classList.contains('is-inline'), 'کلاس is-inline هست');
  eq(t.w.getComputedStyle(panel).position, 'relative', 'در موبایل هم پنل داخل جریان صفحه است (نه ورق ثابت)');

  head('۳) حالت widget هنوز sheet می‌گیرد');
  t = makeDom('widget', 390);
  await wait(350);
  root = t.d.getElementById('pasokhban-live');
  ok(root.classList.contains('sheet'), 'در حالت ویجت موبایل، کلاس sheet اضافه می‌شود');
  ok(!root.classList.contains('is-inline'), 'کلاس is-inline ندارد');

  t = makeDom('widget', 1200);
  await wait(350);
  root = t.d.getElementById('pasokhban-live');
  ok(root.classList.contains('sheet'), 'کلاس sheet مستقل از عرض اضافه می‌شود (CSS آن را در موبایل فعال می‌کند)');
  ok(!root.classList.contains('is-open'), 'ویجت بدون کلیک بسته است');

  console.log('\n' + '─'.repeat(52));
  if (fail === 0) console.log(`\x1b[42;30m همهٔ ${pass} تست حالت inline پاس شد \x1b[0m`);
  else { console.log(`\x1b[41;97m ${fail} تست شکست خورد \x1b[0m (پاس: ${pass})`); fails.forEach(f => console.log('   • ' + f)); }
  console.log('─'.repeat(52));
  process.exit(fail === 0 ? 0 : 1);
})();
