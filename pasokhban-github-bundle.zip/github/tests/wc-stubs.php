<?php
/**
 * شبیه‌سازی حداقلی ووکامرس برای تست.
 *
 * عمداً در wp-stubs.php نیست: بقیهٔ تست‌ها باید بتوانند حالت
 * «ووکامرس نصب نیست» را هم بررسی کنند، پس این فایل را فقط تست‌های
 * ووکامرس require می‌کنند.
 */

$GLOBALS['wc_products'] = array();
$GLOBALS['wc_orders']   = array();
$GLOBALS['wc_terms']    = array();

class WooCommerce {}

class WC_Stub_Attribute {
	private $name; private $options;
	public function __construct( $name, $options ) { $this->name = $name; $this->options = $options; }
	public function get_name() { return $this->name; }
	public function get_options() { return $this->options; }
}

class WC_Stub_Product {
	private $d;
	public function __construct( array $d ) { $this->d = $d; }
	public function get_name() { return isset( $this->d['name'] ) ? $this->d['name'] : ''; }
	public function get_price_html() { return isset( $this->d['price'] ) ? $this->d['price'] : ''; }
	public function is_in_stock() { return ! empty( $this->d['in_stock'] ); }
	public function get_stock_quantity() { return isset( $this->d['qty'] ) ? $this->d['qty'] : null; }
	public function get_sku() { return isset( $this->d['sku'] ) ? $this->d['sku'] : ''; }
	public function get_category_ids() { return isset( $this->d['cats'] ) ? (array) $this->d['cats'] : array(); }
	public function get_attributes() {
		$out = array();
		foreach ( (array) ( isset( $this->d['attrs'] ) ? $this->d['attrs'] : array() ) as $n => $o ) {
			$out[] = new WC_Stub_Attribute( $n, (array) $o );
		}
		return $out;
	}
	public function get_short_description() { return isset( $this->d['short'] ) ? $this->d['short'] : ''; }
	public function get_description() { return isset( $this->d['desc'] ) ? $this->d['desc'] : ''; }
}

class WC_Stub_DateTime {
	private $ts;
	public function __construct( $ts ) { $this->ts = (int) $ts; }
	public function getTimestamp() { return $this->ts; }
}

class WC_Stub_Item {
	private $name; private $qty;
	public function __construct( $name, $qty ) { $this->name = $name; $this->qty = $qty; }
	public function get_name() { return $this->name; }
	public function get_quantity() { return $this->qty; }
}

class WC_Stub_Order {
	private $d;
	public function __construct( array $d ) { $this->d = $d; }
	public function get_order_number() { return isset( $this->d['number'] ) ? $this->d['number'] : ''; }
	public function get_status() { return isset( $this->d['status'] ) ? $this->d['status'] : 'pending'; }
	public function get_date_created() { return new WC_Stub_DateTime( isset( $this->d['ts'] ) ? $this->d['ts'] : 1700000000 ); }
	public function get_total() { return isset( $this->d['total'] ) ? $this->d['total'] : 0; }
	public function get_billing_email() { return isset( $this->d['email'] ) ? $this->d['email'] : ''; }
	public function get_billing_phone() { return isset( $this->d['phone'] ) ? $this->d['phone'] : ''; }
	public function get_billing_city() { return isset( $this->d['bcity'] ) ? $this->d['bcity'] : ''; }
	public function get_shipping_city() { return isset( $this->d['scity'] ) ? $this->d['scity'] : ''; }
	public function get_shipping_method() { return isset( $this->d['ship'] ) ? $this->d['ship'] : ''; }
	// این‌ها عمداً وجود دارند تا مطمئن شویم هیچ‌کدام به خروجی راه نمی‌یابند
	public function get_billing_address_1() { return 'خیابان مخفی، پلاک ۱'; }
	public function get_payment_method_title() { return 'کارت به کارت'; }
	public function get_customer_ip_address() { return '1.2.3.4'; }
	public function get_items() {
		$out = array();
		foreach ( (array) ( isset( $this->d['items'] ) ? $this->d['items'] : array() ) as $n => $q ) {
			$out[] = new WC_Stub_Item( $n, $q );
		}
		return $out;
	}
}

function wc_get_product( $id ) {
	$id = (int) $id;
	return isset( $GLOBALS['wc_products'][ $id ] ) ? new WC_Stub_Product( $GLOBALS['wc_products'][ $id ] ) : false;
}

/**
 * شبیه‌سازی wc_get_products.
 *
 * صفحهٔ بررسی سلامت از آن با return=ids استفاده می‌کند تا بفهمد چند
 * محصول منتشرشده وجود دارد.
 */
function wc_get_products( $args = array() ) {
	$all = isset( $GLOBALS['wc_products'] ) ? (array) $GLOBALS['wc_products'] : array();
	$want = isset( $args['status'] ) ? (string) $args['status'] : '';
	$limit = isset( $args['limit'] ) ? (int) $args['limit'] : -1;
	$out = array();
	foreach ( $all as $id => $p ) {
		$st = isset( $p['status'] ) ? (string) $p['status'] : 'publish';
		if ( '' !== $want && $st !== $want ) {
			continue;
		}
		$out[] = ( isset( $args['return'] ) && 'ids' === $args['return'] ) ? (int) $id : new WC_Stub_Product( $p );
		if ( $limit > 0 && count( $out ) >= $limit ) {
			break;
		}
	}
	return $out;
}
$GLOBALS['wc_orders_by_phone'] = array();
$GLOBALS['wc_orders_by_email'] = array();

/** شبیه‌سازی wc_get_orders برای «آخرین سفارش مشتری». */
function wc_get_orders( $args = array() ) {
	$phone = isset( $args['billing_phone'] ) ? (string) $args['billing_phone'] : '';
	$email = isset( $args['billing_email'] ) ? strtolower( (string) $args['billing_email'] ) : '';
	if ( '' !== $phone && isset( $GLOBALS['wc_orders_by_phone'][ $phone ] ) ) {
		return array( new WC_Stub_Order( $GLOBALS['wc_orders_by_phone'][ $phone ] ) );
	}
	if ( '' !== $email && isset( $GLOBALS['wc_orders_by_email'][ $email ] ) ) {
		return array( new WC_Stub_Order( $GLOBALS['wc_orders_by_email'][ $email ] ) );
	}
	return array();
}

function wc_get_order( $id ) {
	$id = (int) $id;
	return isset( $GLOBALS['wc_orders'][ $id ] ) ? new WC_Stub_Order( $GLOBALS['wc_orders'][ $id ] ) : false;
}
function wc_get_order_statuses() {
	return array(
		'wc-pending'    => 'در انتظار پرداخت',
		'wc-processing' => 'در حال پردازش',
		'wc-completed'  => 'تکمیل شده',
		'wc-cancelled'  => 'لغو شده',
		'wc-refunded'   => 'مسترد شده',
	);
}
function wc_price( $n ) { return number_format( (float) $n ) . ' تومان'; }

if ( ! function_exists( 'get_term' ) ) {
	function get_term( $id, $tax = '' ) {
		$id = (int) $id;
		return isset( $GLOBALS['wc_terms'][ $id ] ) ? (object) array( 'term_id' => $id, 'name' => $GLOBALS['wc_terms'][ $id ] ) : null;
	}
}
