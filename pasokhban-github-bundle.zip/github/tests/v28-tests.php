<?php
/**
 * تست‌های ۲.۸.۰.
 *
 * این فایل دو کار می‌کند:
 *
 * ۱) موارد تازهٔ ۲.۸.۰ را می‌سنجد (لایهٔ wp_check_filetype_and_ext،
 *    ایندکس مرکب، آخرین سفارش ووکامرس، unicode-bidi، رزولوشن‌های کوچک).
 *
 * ۲) ★ محافظ رگرسیون برای چیزهایی که در گزارش تغییرات پیشنهاد شده بود
 *    ولی «قبلاً انجام شده بودند». اگر روزی کسی آن‌ها را حذف کند، این
 *    تست‌ها قرمز می‌شوند. این مهم است، چون اگر کش RAG یا هدر
 *    X-Accel-Buffering بی‌صدا حذف شوند، هیچ تست دیگری نمی‌فهمد.
 */

require_once __DIR__ . '/wp-stubs.php';
require_once __DIR__ . '/wc-stubs.php';

$PASS = 0; $FAIL = 0; $FAILURES = array();

function ok( $cond, $label, $extra = '' ) {
	global $PASS, $FAIL, $FAILURES;
	if ( $cond ) { $PASS++; echo "  \033[32m✓\033[0m {$label}\n"; }
	else { $FAIL++; $FAILURES[] = $label . ( $extra ? " — {$extra}" : '' ); echo "  \033[31m✗\033[0m {$label}" . ( $extra ? "  → {$extra}" : '' ) . "\n"; }
}
function head( $t ) { echo "\n\033[1m{$t}\033[0m\n"; }
function eq( $a, $b, $label ) { ok( $a === $b, $label, 'انتظار ' . var_export( $b, true ) . ' / دریافت ' . var_export( $a, true ) ); }

update_option( 'pasokhban_options', array(
	'api_key' => 'sk', 'base_url' => 'https://api.example.test/v1',
	'live_enabled' => 1, 'rate_limit' => 10, 'live_history' => 20,
	'rag_vector' => 1, 'woo_products' => 1, 'woo_order_lookup' => 1,
	'live_upload' => 1,
) );
$rp = new ReflectionProperty( 'Pasokhban_Settings', 'options' );
$rp->setAccessible( true );
$rp->setValue( Pasokhban_Settings::instance(), get_option( 'pasokhban_options' ) );
Pasokhban_DB::install();

$CHAT_CSS  = file_get_contents( PASOKHBAN_PATH . 'assets/css/pasokhban-chat.css' );
$INBOX_CSS = file_get_contents( PASOKHBAN_PATH . 'assets/css/pasokhban-inbox.css' );
$INBOX_JS  = file_get_contents( PASOKHBAN_PATH . 'assets/js/pasokhban-inbox.js' );

/* ========================================================= */
head( '۱) ★ محافظ رگرسیون: چیزهایی که «قبلاً» انجام شده بودند' );
/* ========================================================= */

// کش RAG — از ۱.۹.۰ هست
$rag_src = file_get_contents( PASOKHBAN_PATH . 'includes/class-rag.php' );
ok( false !== strpos( $rag_src, 'get_transient( $ckey )' ), '★ کش RAG هنوز هست (get_transient)' );
ok( false !== strpos( $rag_src, 'set_transient( $ckey, $result' ), '★ کش RAG هنوز نوشته می‌شود' );
ok( false !== strpos( $rag_src, "md5( \$query . '|' . \$this->signature()" ), '★ کلید کش به امضای ایندکس وابسته است' );

// هدرهای استریم برای nginx
$stream_src = file_get_contents( PASOKHBAN_PATH . 'includes/class-stream.php' );
ok( false !== strpos( $stream_src, 'X-Accel-Buffering: no' ), '★ هدر X-Accel-Buffering برای nginx هست' );
ok( false !== strpos( $stream_src, 'nocache_headers' ), '★ nocache_headers صدا زده می‌شود' );
ok( false !== strpos( $stream_src, 'ob_flush' ), '★ ob_flush هست' );
ok( false !== strpos( $stream_src, 'flush()' ), '★ flush هست' );
ok( false !== strpos( $stream_src, 'text/event-stream' ), '★ Content-Type درست است' );

// MIME با finfo
$upload_src = file_get_contents( PASOKHBAN_PATH . 'includes/class-upload.php' );
ok( false !== strpos( $upload_src, 'finfo_open( FILEINFO_MIME_TYPE )' ), '★ اعتبارسنجی MIME با finfo هست' );
ok( false !== strpos( $upload_src, 'getimagesize' ), '★ بررسی تصویر واقعی هست' );

// پاک‌سازی ورودی پیام
$live_src = file_get_contents( PASOKHBAN_PATH . 'includes/class-livechat.php' );
ok( substr_count( $live_src, 'sanitize_textarea_field' ) >= 2, '★ ورودی پیام با sanitize_textarea_field پاک‌سازی می‌شود' );
ok( false !== strpos( $stream_src, 'sanitize_textarea_field' ), '★ مسیر استریم هم پاک‌سازی می‌کند' );

// ★ مهم: wp_kses_post روی پیام چت استفاده نشده باشد!
ok( false === strpos( $live_src, 'wp_kses_post' ), '★ wp_kses_post روی پیام چت استفاده نشده (اجازهٔ HTML یعنی XSS)' );
ok( false === strpos( $stream_src, 'wp_kses_post' ), '★ مسیر استریم هم HTML مجاز نمی‌کند' );

// ★ اندپوینت‌های عمومی نباید edit_posts بخواهند
ok( false === strpos( $live_src, "current_user_can( 'edit_posts' )" ), '★ اندپوینت عمومی چت edit_posts نمی‌خواهد (وگرنه ویجت برای بازدیدکننده می‌شکست)' );
$api_src = file_get_contents( PASOKHBAN_PATH . 'includes/class-api.php' );
ok( false === strpos( $api_src, "current_user_can( 'edit_posts' )" ), '★ اندپوینت /chat هم edit_posts نمی‌خواهد' );

// z-index بالا
ok( false !== strpos( $CHAT_CSS, 'z-index: 2147483000' ), '★ z-index ویجت بالاتر از منوهای چسبان قالب است' );
ok( false === strpos( $CHAT_CSS, 'z-index: 999999' ), 'z-index روی ۹۹۹۹۹۹ تنظیم نشده (کمتر از خیلی قالب‌هاست)' );

// متغیرهای CSS — بازنامی --ecl به --ey انجام نشده (churn بیهوده بود)
ok( substr_count( $CHAT_CSS, '--psb-' ) > 50, '★ متغیرهای CSS موجودند (--psb-*)' );
ok( false === strpos( $CHAT_CSS, '--ey-primary-color' ), 'بازنامی متغیرها انجام نشده (اسلایدرهای تنظیمات را می‌شکست)' );

// اسکیپ خروجی در اینباکس
ok( false !== strpos( $INBOX_JS, 'function esc(s)' ), '★ تابع esc در اینباکس هست' );
ok( substr_count( $INBOX_JS, 'esc(m.content)' ) >= 1, '★ محتوای پیام در اینباکس escape می‌شود' );

/* ========================================================= */
head( '۲) تازهٔ ۲.۸.۰: لایهٔ چهارم آپلود' );
/* ========================================================= */

ok( false !== strpos( $upload_src, 'wp_check_filetype_and_ext' ), '★ wp_check_filetype_and_ext اضافه شد' );
ok( false !== strpos( $upload_src, 'pasokhban_badext' ), 'خطای پسوند نامعتبر تعریف شده' );
ok( false !== strpos( $upload_src, 'pasokhban_badname' ), 'خطای پسوند تودرتو تعریف شده' );
ok( false !== strpos( $upload_src, "function_exists( 'wp_check_filetype_and_ext' )" ), '★ اگر تابع موجود نبود، سکوت می‌کند (نه fatal)' );

// با stub واقعی وردپرس تست شود
if ( ! function_exists( 'wp_check_filetype_and_ext' ) ) {
	function wp_check_filetype_and_ext( $file, $filename, $mimes = null ) {
		$ext = strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) );
		// پسوند تودرتو → proper_filename متفاوت
		if ( preg_match( '/\.(php|phtml|phar|exe)\./i', $filename ) ) {
			return array( 'ext' => $ext, 'type' => 'image/jpeg', 'proper_filename' => preg_replace( '/\.(php|phtml|phar|exe)\./i', '.', $filename ) );
		}
		if ( 'pdf' === $ext ) {
			return array( 'ext' => $ext, 'type' => 'application/pdf', 'proper_filename' => false );
		}
		if ( 'exe' === $ext || 'php' === $ext ) {
			return array( 'ext' => false, 'type' => false, 'proper_filename' => false );
		}
		return array( 'ext' => $ext, 'type' => 'image/jpeg', 'proper_filename' => false );
	}
}

$U   = 'Pasokhban_Upload';
$TMP = PASOKHBAN_TESTS_DIR . '/tmp-v28';
@mkdir( $TMP, 0777, true );

// تصویر واقعی JPEG
$jpg_path = $TMP . '/ok.jpg';
file_put_contents( $jpg_path, base64_decode(
	'/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/wAALCAABAAEBAREA/8QAFAABAAAAAAAAAAAAAAAAAAAACf/EABQQAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQEAAD8AKp//2Q=='
) );

$opts = Pasokhban_Settings::instance()->get_options();
$r = $U::check_file( $jpg_path, 'ok.jpg', $opts );
ok( is_array( $r ), 'تصویر سالم با لایهٔ چهارم هم پذیرفته می‌شود', is_wp_error( $r ) ? $r->get_error_message() : '' );

// پسوند تودرتو → proper_filename متفاوت → رد
$nested = $TMP . '/shell.php.jpg';
copy( $jpg_path, $nested );
$r = $U::check_file( $nested, 'shell.php.jpg', $opts );
ok( is_wp_error( $r ), '★ پسوند تودرتو با لایهٔ چهارم رد می‌شود' );
eq( is_wp_error( $r ) ? $r->get_error_code() : '', 'pasokhban_badtype', 'با لایهٔ دوم (regex) رد شد، قبل از رسیدن به لایهٔ چهارم' );

// exe → ext=false
$exe = $TMP . '/bad.exe';
copy( $jpg_path, $exe );
$r = $U::check_file( $exe, 'bad.exe', $opts );
ok( is_wp_error( $r ), 'فایل exe رد می‌شود' );

array_map( 'unlink', (array) glob( $TMP . '/*' ) );
@rmdir( $TMP );

/* ========================================================= */
head( '۳) تازهٔ ۲.۸.۰: ایندکس مرکب دیتابیس' );
/* ========================================================= */

$db_src = file_get_contents( PASOKHBAN_PATH . 'includes/class-db.php' );
ok( false !== strpos( $db_src, 'KEY inbox_list (status, unread_agent, updated_at)' ), '★ ایندکس مرکب برای کوئری لیست اینباکس اضافه شد' );
eq( Pasokhban_DB::SCHEMA_VERSION, '1.8.0', 'نسخهٔ ساختار به ۱.۸.۰ رفت' );

// ایندکس‌های قبلی هنوز سر جایشان‌اند
foreach ( array( 'KEY status (status)', 'KEY mode (mode)', 'KEY assigned_to (assigned_to)', 'KEY updated_at (updated_at)' ) as $idx ) {
	ok( false !== strpos( $db_src, $idx ), 'ایندکس ' . $idx . ' هنوز هست' );
}

/* ========================================================= */
head( '۴) تازهٔ ۲.۸.۰: آخرین سفارش ووکامرس' );
/* ========================================================= */

$GLOBALS['wc_orders_by_phone']['9121234567'] = array(
	'number' => '۲۰۵۰', 'status' => 'processing', 'ts' => 1789000000, 'total' => 1250000,
	'phone'  => '09121234567', 'email' => 'maryam@example.test',
	'ship'   => 'پست پیشتاز', 'scity' => 'تهران',
	'items'  => array( 'هندزفری بلوتوث' => 1 ),
);
$GLOBALS['wc_orders_by_email']['ali@example.test'] = array(
	'number' => '۲۰۵۱', 'status' => 'completed', 'ts' => 1789100000, 'total' => 450000,
	'email'  => 'ali@example.test', 'items' => array( 'کابل type-c' => 2 ),
);

$o = Pasokhban_Woo::latest_order_for( '09121234567', '' );
ok( is_array( $o ), '★ آخرین سفارش از روی شمارهٔ تماس پیدا شد' );
eq( $o['number'], '۲۰۵۰', 'سفارش درست برگشت' );
eq( $o['status'], 'در حال پردازش', 'وضعیت ترجمه شد' );
ok( ! isset( $o['phone'] ), '★ شمارهٔ تماس در خلاصه نیست (سانسور)' );
ok( ! isset( $o['email'] ), '★ ایمیل در خلاصه نیست (سانسور)' );

$o = Pasokhban_Woo::latest_order_for( '', 'ali@example.test' );
eq( $o['number'], '۲۰۵۱', 'از روی ایمیل هم پیدا شد' );

eq( Pasokhban_Woo::latest_order_for( '', '' ), null, 'بدون شماره و ایمیل → null' );
eq( Pasokhban_Woo::latest_order_for( '09999999999', '' ), null, 'شمارهٔ بدون سفارش → null' );
eq( Pasokhban_Woo::latest_order_for( '09121234567', '' )['city'], 'تهران', 'شهر مقصد در خلاصه هست' );

/* ========================================================= */
head( '۵) تازهٔ ۲.۸.۰: RTL/LTR و رزولوشن‌های کوچک' );
/* ========================================================= */

ok( false !== strpos( $CHAT_CSS, 'unicode-bidi: plaintext' ), '★ unicode-bidi: plaintext به متن پیام اضافه شد' );
ok( false !== strpos( $CHAT_CSS, 'text-align: start' ), 'text-align: start اضافه شد' );
ok( false !== strpos( $CHAT_CSS, 'unicode-bidi: isolate' ), 'برای کد/عدد از isolate استفاده شد (نه plaintext)' );
ok( false !== strpos( $CHAT_CSS, 'ui-monospace' ), 'فونت مونو برای تکهٔ کد' );
ok( false !== strpos( $CHAT_CSS, 'font-variant-numeric: tabular-nums' ), 'اعداد هم‌عرض' );

ok( false !== strpos( $CHAT_CSS, 'calc(100vw - 24px)' ), '★ عرض پنل در موبایل با calc' );
ok( false !== strpos( $CHAT_CSS, '@media (max-width: 480px)' ), 'بریک‌پوینت ۴۸۰' );
ok( false !== strpos( $CHAT_CSS, '@media (max-width: 380px)' ), '★ بریک‌پوینت ۳۸۰ برای گوشی‌های باریک' );
ok( false !== strpos( $CHAT_CSS, 'dvh' ), '★ ارتفاع با dvh (کیبورد موبایل)' );
ok( false !== strpos( $CHAT_CSS, 'prefers-reduced-motion' ), 'احترام به کاهش انیمیشن' );
ok( false !== strpos( $CHAT_CSS, 'max-width: 92%' ), '★ حباب پیام در موبایل عریض‌تر' );

// اینباکس: رزولوشن‌های میانی
ok( false !== strpos( $INBOX_CSS, '@media (min-width: 861px) and (max-width: 1100px)' ), '★ بریک‌پوینت تبلت ۸۶۱–۱۱۰۰' );
ok( false !== strpos( $INBOX_CSS, '@media (min-width: 1101px) and (max-width: 1280px)' ), '★ بریک‌پوینت ۱۱۰۱–۱۲۸۰' );
ok( false !== strpos( $INBOX_CSS, '@media (min-width: 601px) and (max-width: 860px)' ), '★ بریک‌پوینت تبلت عمودی' );
ok( false !== strpos( $INBOX_CSS, 'unicode-bidi: plaintext' ), 'متن مخلوط در اینباکس هم plaintext' );

/* ========================================================= */
head( '۶) تازهٔ ۲.۸.۰: محکم‌کاری copilotOut' );
/* ========================================================= */

ok( false !== strpos( $INBOX_JS, 'function copilotOut(text, cls, mark)' ), '★ copilotOut متن می‌گیرد نه HTML' );
ok( false !== strpos( $INBOX_JS, 'box.textContent =' ), '★ با textContent نوشته می‌شود (نه innerHTML)' );
ok( false === strpos( $INBOX_JS, "copilotOut('<" ), '★ هیچ فراخوانی HTML خام به copilotOut نمی‌دهد' );
ok( false === strpos( $INBOX_JS, "copilotOut('<pre>'" ), 'هیچ فراخوانی <pre> خام نیست' );

/* ========================================================= */
head( '۷) تاریخ شمسی در لیست اینباکس' );
/* ========================================================= */

$inbox_src = file_get_contents( PASOKHBAN_PATH . 'includes/class-inbox.php' );
ok( false !== strpos( $inbox_src, 'Pasokhban_Jalali::format_mysql( $s->updated_at' ), '★ تاریخ لیست اینباکس شمسی است' );
ok( false !== strpos( $inbox_src, "gmdate( 'Y-m-d' ) === substr" ), '★ مکالمهٔ امروز فقط ساعت، وگرنه تاریخ کامل' );

// رفتار واقعی
$today = gmdate( 'Y-m-d H:i:s' );
$old   = gmdate( 'Y-m-d H:i:s', time() - 5 * 86400 );
$t_fmt = Pasokhban_Jalali::format_mysql( $today, 'time' );
$d_fmt = Pasokhban_Jalali::format_mysql( $old, 'date' );
ok( (bool) preg_match( '/^\d{1,2}:\d{2}$/u', str_replace( array( '۰','۱','۲','۳','۴','۵','۶','۷','۸','۹' ), range(0,9), $t_fmt ) ), 'قالب ساعت درست است', $t_fmt );
ok( false !== strpos( $d_fmt, '۱۴۰' ) || false !== strpos( $d_fmt, '140' ), 'قالب تاریخ شمسی درست است', $d_fmt );

echo "\n" . str_repeat( '─', 52 ) . "\n";
if ( 0 === $FAIL ) {
	echo "\033[42;30m همهٔ {$PASS} تست ۲.۸.۰ پاس شد \033[0m\n";
} else {
	echo "\033[41;97m {$FAIL} تست شکست خورد \033[0m (پاس: {$PASS})\n";
	foreach ( $FAILURES as $f ) { echo "   • {$f}\n"; }
}
echo str_repeat( '─', 52 ) . "\n";
exit( 0 === $FAIL ? 0 : 1 );
