/**
 * تست مسیر بازیابی: جریان بعد از ذخیرهٔ پیام کاربر شکست می‌خورد.
 *
 * باگ ۱.۵.۴: در این حالت کلاینت فقط می‌گفت «منتظر بمان» ولی هیچ‌کس
 * پاسخ تولید نمی‌کرد — کاربر تا ابد منتظر می‌ماند.
 * حالا کلاینت /live/answer را صدا می‌زند تا به همان پیامِ ذخیره‌شده
 * پاسخ داده شود، بدون POST دوبارهٔ پیام.
 */
const fs = require('fs');
const { JSDOM } = require('jsdom');
const { ReadableStream } = require('stream/web');
const { TextDecoder } = require('util');

const JS = fs.readFileSync(__dirname + '/../plugin/assets/js/pasokhban-chat.js', 'utf8');

let pass = 0, fail = 0; const fails = [];
const ok = (c, l, x) => { if (c) { pass++; console.log(`  \x1b[32m✓\x1b[0m ${l}`); } else { fail++; fails.push(l + (x ? ' — ' + x : '')); console.log(`  \x1b[31m✗\x1b[0m ${l}` + (x ? '  → ' + x : '')); } };
const eq = (a, b, l) => ok(JSON.stringify(a) === JSON.stringify(b), l, `انتظار ${JSON.stringify(b)} / دریافت ${JSON.stringify(a)}`);
const head = t => console.log(`\n\x1b[1m${t}\x1b[0m`);
const wait = ms => new Promise(r => setTimeout(r, ms));

const SETTINGS = {
  title: 'چت', agentName: 'پشتیبانی', greeting: 'سلام', placeholder: 'بنویس',
  accent: '#22d3ee', position: 'start', autoOpen: false, autoDelay: 5, starter: [],
  humanHandoff: true, sound: false, offlineNote: '',
  offsetBottom: 18, offsetSide: 18, launcherSize: 62, panelWidth: 384, panelHeight: 620,
  radius: 28, blur: 30, glassOpacity: 62, launcherLabel: '', teaser: false, teaserText: '',
  mobileSheet: true, maximize: true, showFooter: true, theme: 'auto',
  prechat: false, streaming: true, csat: true,
  streamUrl: 'http://e.test/wp-json/pasokhban/v1/live/stream'
};

const dom = new JSDOM('<!DOCTYPE html><html><body><div id="pasokhban-live" data-mode="widget"></div></body></html>',
  { url: 'http://e.test/', pretendToBeVisual: true, runScripts: 'dangerously' });
const w = dom.window, d = w.document;

w.ReadableStream = ReadableStream;
w.TextDecoder = TextDecoder;
w.Response = class {
  constructor(body, o) {
    o = o || {}; this.body = body; this.status = o.status || 200;
    this.ok = this.status >= 200 && this.status < 300;
    const raw = o.headers || {}, lower = {};
    Object.keys(raw).forEach(k => { lower[k.toLowerCase()] = raw[k]; });
    this.headers = { get: k => (lower[String(k).toLowerCase()] || null) };
  }
  json() { return Promise.resolve(JSON.parse(this.body)); }
};

w.PASOKHBAN_CHAT = { restUrl: '/wp-json/pasokhban/v1', nonce: 'n', lang: 'fa' };
w.PASOKHBAN_CHAT_SETTINGS = SETTINGS;

const DB = [];
let nextId = 700;
const calls = [];
const RECOVERED = 'پاسخ از راه بازیابی رسید.';

w.fetch = (url, opt) => {
  opt = opt || {};
  const path = String(url).replace(/^.*\/v1/, '');
  const body = opt.body ? JSON.parse(opt.body) : {};
  calls.push(path);

  if (path.indexOf('/live/stream') === 0) {
    const enc = new TextEncoder();
    // سرور پیام کاربر را ذخیره می‌کند و {visitor} می‌فرستد، بعد جریان قطع می‌شود
    const vmsg = { id: nextId++, sender: 'visitor', content: body.content, meta: {}, time: new Date().toISOString() };
    DB.push(vmsg);
    let sent = false;
    const stream = new ReadableStream({
      pull(c) {
        if (!sent) {
          sent = true;
          c.enqueue(enc.encode('data: ' + JSON.stringify({ visitor: vmsg.id }) + '\n\n'));
          return new Promise(r => setTimeout(r, 30));
        }
        // شبیه‌سازی قطع شدن جریان بدون {done}
        c.close();
      }
    });
    return Promise.resolve(new Response(stream, { status: 200, headers: { 'Content-Type': 'text/event-stream' } }));
  }

  if (path.indexOf('/live/answer') === 0) {
    // سرور به آخرین پیام بی‌پاسخ پاسخ می‌دهد
    const lastVisitor = DB.filter(m => m.sender === 'visitor').pop();
    const amsg = { id: nextId++, sender: 'agent', content: RECOVERED, meta: { via: 'ai', recovered: true }, time: new Date().toISOString() };
    DB.push(amsg);
    return Promise.resolve(new Response(JSON.stringify({
      id: amsg.id, content: RECOVERED, sources: [{ title: 'منبع بازیابی', url: 'http://e.test/r' }], ms: 1200
    }), { status: 200, headers: { 'Content-Type': 'application/json' } }));
  }

  if (path.indexOf('/live/send') === 0) {
    // اگر این صدا زده شود یعنی باگ برگشته (POST دوباره)
    const m = { id: nextId++, sender: 'visitor', content: body.content, meta: {}, time: new Date().toISOString() };
    DB.push(m);
    return Promise.resolve(new Response(JSON.stringify({
      message: m, mode: 'ai', reply: { id: nextId++, sender: 'agent', content: 'پاسخ معمولی', meta: {}, time: new Date().toISOString() }
    }), { status: 200, headers: { 'Content-Type': 'application/json' } }));
  }

  if (path.indexOf('/live/poll') === 0) {
    const after = parseInt((String(url).match(/after=(\d+)/) || [0, 0])[1], 10);
    return Promise.resolve(new Response(JSON.stringify({
      messages: DB.filter(m => m.id > after), mode: 'ai', status: null, typing: false, agentOnline: false
    }), { status: 200, headers: { 'Content-Type': 'application/json' } }));
  }

  if (path.indexOf('/live/start') === 0) {
    return Promise.resolve(new Response(JSON.stringify({ key: 'a1b2c3d4e5f60718293a4b5c6d7e8f90', mode: 'ai', status: 'open', messages: [], agentOnline: false, settings: SETTINGS }),
      { status: 200, headers: { 'Content-Type': 'application/json' } }));
  }

  return Promise.resolve(new Response(JSON.stringify({ ok: true }), { status: 200, headers: { 'Content-Type': 'application/json' } }));
};

const s = d.createElement('script');
s.textContent = JS;
d.body.appendChild(s);

(async () => {
  await wait(250);
  d.querySelector('.psb-launcher').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
  await wait(300);

  head('۱) جریان بعد از ذخیرهٔ پیام کاربر قطع می‌شود');
  const inp = d.querySelector('.psb-input');
  inp.value = 'سؤال من';
  d.querySelector('.psb-send').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
  await wait(120);

  ok(calls.some(p => p.indexOf('/live/stream') === 0), 'جریان شروع شد');
  eq(DB.filter(m => m.sender === 'visitor').length, 1, 'پیام کاربر یک بار ذخیره شد');

  head('۲) بازیابی: /live/answer صدا زده می‌شود');
  await wait(400);
  ok(calls.some(p => p.indexOf('/live/answer') === 0), 'کلاینت /live/answer را صدا زد');
  ok(!calls.some(p => p.indexOf('/live/send') === 0), 'پیام دوباره POST نشد (رکورد تکراری ساخته نشد)');
  eq(DB.filter(m => m.sender === 'visitor').length, 1, 'در دیتابیس هم فقط یک پیام کاربر هست');

  head('۳) پاسخ به کاربر می‌رسد (نه بن‌بست)');
  const agents = Array.from(d.querySelectorAll('.psb-msg.agent')).filter(b => !b.textContent.startsWith('سلام'));
  eq(agents.length, 1, 'یک حباب پاسخ نمایش داده شد');
  eq(agents[0].querySelector('.psb-msg-text').textContent, RECOVERED, 'متن پاسخ بازیابی‌شده درست است');
  ok(!!agents[0].getAttribute('data-mid'), 'شناسهٔ پاسخ به حباب چسبید');
  ok(!!agents[0].querySelector('.psb-csat'), 'دکمه‌های امتیاز زیر پاسخ هست');
  ok(!!agents[0].querySelector('.psb-srcbtn'), 'دکمهٔ «مشاهدهٔ منابع» زیر پاسخ هست');

  head('۴) پیام «منتظر بمان» دیگر نشان داده نمی‌شود');
  const errs = d.querySelectorAll('.psb-err');
  const waitMsg = Array.from(errs).filter(e => /منتظر بمان/.test(e.textContent));
  eq(waitMsg.length, 0, 'بن‌بست «منتظر بمان» حذف شد');

  head('۵) حباب نیمه‌کارهٔ جریان پاک شد');
  eq(d.querySelectorAll('.psb-msg.agent.is-streaming').length, 0, 'حباب is-streaming باقی نمانده');

  head('۶) دکمهٔ ارسال دوباره فعال است');
  const sendBtn = d.querySelector('#psb-send');
  ok(!sendBtn.disabled, 'دکمهٔ ارسال قفل نمانده');

  console.log('\n' + '─'.repeat(52));
  if (fail === 0) console.log(`\x1b[42;30m همهٔ ${pass} تست بازیابی پاس شد \x1b[0m`);
  else { console.log(`\x1b[41;97m ${fail} تست شکست خورد \x1b[0m (پاس: ${pass})`); fails.forEach(f => console.log('   • ' + f)); }
  console.log('─'.repeat(52));
  process.exit(fail === 0 ? 0 : 1);
})();
