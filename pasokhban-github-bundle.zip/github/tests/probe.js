const fs=require('fs');const {JSDOM}=require('jsdom');
const CSS=fs.readFileSync(__dirname + '/../plugin/assets/css/pasokhban-chat.css','utf8');
const JS=fs.readFileSync(__dirname + '/../plugin/assets/js/pasokhban-chat.js','utf8');
const S={mobileSheet:true,panelWidth:384,panelHeight:620,offsetBottom:18,offsetSide:18,launcherSize:62,
  title:'t',agentName:'a',greeting:'g',placeholder:'p',accent:'#22d3ee',position:'start',starter:[],
  teaser:true,teaserText:'',maximize:true,showFooter:true,theme:'light',prechat:false,streaming:false,csat:false,upload:false,autoOpen:false,autoDelay:5,sound:false,offlineNote:'',humanHandoff:true,prechatRequired:false,prechatNote:'',radius:28,blur:30,glassOpacity:62,launcherLabel:''};
function mk(w,h){
  const dom=new JSDOM(`<!DOCTYPE html><html dir="rtl"><head><style>${CSS}</style></head><body><div id="pasokhban-live" data-mode="widget"></div></body></html>`,
    {url:'http://example.test/',pretendToBeVisual:true,runScripts:'dangerously'});
  const w2=dom.window;
  Object.defineProperty(w2,'innerWidth',{value:w,configurable:true});
  Object.defineProperty(w2,'innerHeight',{value:h,configurable:true});
  w2.PASOKHBAN_CHAT={restUrl:'/x',nonce:'n',lang:'fa'};
  w2.PASOKHBAN_CHAT_SETTINGS=S;
  w2.fetch=()=>Promise.resolve({ok:true,status:200,json:()=>Promise.resolve({key:'k',mode:'ai',status:'open',messages:[],agentOnline:false,agentName:'a',settings:S})});
  const s=w2.document.createElement('script');s.textContent=JS;w2.document.body.appendChild(s);
  return {w:w2,d:w2.document};
}
(async()=>{
  for(const [w,h] of [[1440,900],[375,667]]){
    const {w:win,d}=mk(w,h);
    await new Promise(r=>setTimeout(r,80));
    const root=d.getElementById('pasokhban-live');
    const rs=win.getComputedStyle(root);
    const ps=win.getComputedStyle(d.querySelector('.psb-panel'));
    console.log(`\n--- ${w}x${h} ---`);
    console.log('  root --psb-panel-w :', rs.getPropertyValue('--psb-panel-w'));
    console.log('  root --psb-panel-h :', rs.getPropertyValue('--psb-panel-h'));
    console.log('  root --psb-off-side:', rs.getPropertyValue('--psb-off-side'));
    console.log('  panel width  raw   :', ps.width);
    console.log('  panel height raw   :', ps.height);
    console.log('  panel max-width    :', ps.maxWidth);
    console.log('  panel max-height   :', ps.maxHeight);
    console.log('  root classes       :', root.className);
  }
})();
