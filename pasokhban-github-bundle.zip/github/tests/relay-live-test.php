<?php
/**
 * آزمون واقعیِ رلهٔ تلگرام روی endpoint زندهٔ گوگل.
 *
 * چرا این فایل لازم است: باگ اصلی دقیقاً در لایهٔ HTTP بود (ریدایرکت
 * POST به script.googleusercontent.com). هارنس تست، wp_remote_post را
 * stub می‌کند و این لایه را نمی‌بیند. پس اینجا همان منطق send_via_relay
 * را با cURL واقعی روی آدرس زنده اجرا می‌کنیم.
 *
 * استفاده: php tests/relay-live-test.php [آدرس-رله]
 */

error_reporting( E_ALL );
ini_set( 'display_errors', '1' );

$RELAY = isset( $argv[1] )
	? $argv[1]
	: 'https://script.google.com/macros/s/AKfycbzjelYnf_oq0wavGpS1v3VburpPKdOQR2BPIPt85gbeMftat4AFfEktpwCNQ_GeenmLwA/exec';

/* ---- حداقل توابع وردپرس، ولی HTTP واقعی با cURL ---- */
class WP_Error {
	public $code; public $message;
	public function __construct( $c = '', $m = '' ) { $this->code = $c; $this->message = $m; }
	public function get_error_message() { return $this->message; }
	public function get_error_code() { return $this->code; }
}
function is_wp_error( $t ) { return $t instanceof WP_Error; }
function add_action( ...$a ) { return true; }
function __( $s, $d = null ) { return $s; }
function sanitize_text_field( $s ) { return trim( strip_tags( (string) $s ) ); }
function wp_strip_all_tags( $s, $r = false ) { return trim( strip_tags( (string) $s ) ); }
function admin_url( $p = '' ) { return 'http://example.test/wp-admin/' . $p; }

function ety_curl( $url, $method, $body = null ) {
	$ch = curl_init();
	curl_setopt_array( $ch, array(
		CURLOPT_URL            => $url,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_HEADER         => true,
		CURLOPT_FOLLOWLOCATION => false,   // مثل redirection=0
		CURLOPT_TIMEOUT        => 30,
		CURLOPT_CUSTOMREQUEST  => $method,
	) );
	if ( null !== $body ) {
		curl_setopt( $ch, CURLOPT_POSTFIELDS, $body );
		curl_setopt( $ch, CURLOPT_HTTPHEADER, array( 'Content-Type: application/x-www-form-urlencoded' ) );
	}
	$raw  = curl_exec( $ch );
	$err  = curl_error( $ch );
	$code = (int) curl_getinfo( $ch, CURLINFO_HTTP_CODE );
	$hsz  = (int) curl_getinfo( $ch, CURLINFO_HEADER_SIZE );
	curl_close( $ch );

	if ( false === $raw ) {
		return new WP_Error( 'http', $err );
	}
	$head = substr( (string) $raw, 0, $hsz );
	$body_out = substr( (string) $raw, $hsz );
	$headers = array();
	foreach ( explode( "\n", $head ) as $line ) {
		if ( false !== strpos( $line, ':' ) ) {
			list( $k, $v ) = explode( ':', $line, 2 );
			$headers[ strtolower( trim( $k ) ) ] = trim( $v );
		}
	}
	return array(
		'response' => array( 'code' => $code ),
		'headers'  => $headers,
		'body'     => $body_out,
	);
}

function wp_remote_post( $url, $args = array() ) {
	return ety_curl( $url, 'POST', isset( $args['body'] ) ? $args['body'] : null );
}
function wp_remote_get( $url, $args = array() ) {
	return ety_curl( $url, 'GET', null );
}
function wp_remote_retrieve_response_code( $r ) { return isset( $r['response']['code'] ) ? (int) $r['response']['code'] : 0; }
function wp_remote_retrieve_body( $r ) { return isset( $r['body'] ) ? $r['body'] : ''; }
function wp_remote_retrieve_header( $r, $h ) {
	$h = strtolower( $h );
	return isset( $r['headers'][ $h ] ) ? $r['headers'][ $h ] : '';
}

// class-notify.php بدون ABSPATH با exit بی‌صدا بیرون می‌رود
if ( ! defined( 'ABSPATH' ) ) { define( 'ABSPATH', '/tmp/' ); }
require_once __DIR__ . '/../repo/pasokhban/includes/class-notify.php';

$m = new ReflectionMethod( 'Pasokhban_Notify', 'send_via_relay' );
$m->setAccessible( true );

$fields = array(
	'chat_id'    => '123456',
	'text'       => "🔔 *آزمون*\n\nاین یک آزمون است.",
	'parse_mode' => 'Markdown',
);

echo "\nرله: " . substr( $RELAY, 0, 70 ) . "…\n";
echo str_repeat( '─', 60 ) . "\n";

/* ---- ۱) مسیر تازه: POST با redirection=0، بعد GET روی Location ---- */
$rp = new ReflectionProperty( 'Pasokhban_Notify', 'last_result' );
$rp->setAccessible( true );
$rp->setValue( null, array() );

$ok = $m->invoke( null, $RELAY, 'FAKE-TOKEN-FOR-DIAGNOSIS', $fields, '' );
$res = $rp->getValue();

echo "روش تازه (POST → GET روی Location)\n";
echo '  نتیجهٔ بازگشتی : ' . var_export( $ok, true ) . "\n";
echo '  last_result     : ' . ( isset( $res['telegram'] ) ? $res['telegram'] : '—' ) . "\n";

$html_bug = isset( $res['telegram'] ) && false !== strpos( $res['telegram'], 'HTML برگرداند' );
echo '  خطای «صفحهٔ HTML»: ' . ( $html_bug ? '❌ هنوز هست' : '✅ برطرف شد' ) . "\n";

/* ---- ۲) مقایسه با روش قدیمی: POST و دنبال‌کردن ریدایرکت با همان POST ---- */
echo "\nروش قدیمی (برای مقایسه)\n";
$ch = curl_init();
curl_setopt_array( $ch, array(
	CURLOPT_URL            => $RELAY,
	CURLOPT_RETURNTRANSFER => true,
	CURLOPT_FOLLOWLOCATION => true,   // ریدایرکت را با همان POST دنبال می‌کند
	CURLOPT_POSTREDIR      => 7,      // POST را روی ریدایرکت حفظ کن (بدترین حالت)
	CURLOPT_TIMEOUT        => 30,
	CURLOPT_POST           => true,
	CURLOPT_POSTFIELDS     => http_build_query( array( 'token' => 'FAKE', 'chat_id' => '1', 'text' => 'hi' ) ),
	CURLOPT_HTTPHEADER     => array( 'Content-Type: application/x-www-form-urlencoded' ),
) );
$raw  = curl_exec( $ch );
$code = (int) curl_getinfo( $ch, CURLINFO_HTTP_CODE );
curl_close( $ch );
echo '  کد HTTP         : ' . $code . "\n";
echo '  بدنه HTML است؟  : ' . ( 0 === stripos( ltrim( (string) $raw ), '<!doctype' ) ? 'بله ← همان باگ' : 'نه' ) . "\n";
echo '  ppConfig دارد؟  : ' . ( false !== strpos( (string) $raw, 'ppConfig' ) ? 'بله ← همان صفحه‌ای که کاربر می‌دید' : 'نه' ) . "\n";

echo "\n" . str_repeat( '─', 60 ) . "\n";
if ( ! $html_bug ) {
	echo "\033[42;30m باگ «رله صفحهٔ HTML برگرداند» با روش تازه برطرف شد \033[0m\n";
	exit( 0 );
}
echo "\033[41;97m هنوز خطای HTML دریافت می‌شود \033[0m\n";
exit( 1 );
