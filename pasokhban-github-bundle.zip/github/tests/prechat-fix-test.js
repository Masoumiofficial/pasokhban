/**
 * تست رفع باگ فرم پیش‌گفتگو:
 * هدر نباید زیر فرم برود و کاربر باید همیشه بتواند ببندد.
 * CSS واقعی پلاگین تزریق می‌شود تا z-index واقعاً محاسبه شود.
 */
const fs = require('fs');
const { JSDOM } = require('jsdom');

const CSS = fs.readFileSync(__dirname + '/../plugin/assets/css/pasokhban-chat.css', 'utf8');
const JS  = fs.readFileSync(__dirname + '/../plugin/assets/js/pasokhban-chat.js', 'utf8');

let pass = 0, fail = 0; const fails = [];
const ok = (c, l, x) => { if (c) { pass++; console.log(`  \x1b[32m✓\x1b[0m ${l}`); } else { fail++; fails.push(l + (x ? ' — ' + x : '')); console.log(`  \x1b[31m✗\x1b[0m ${l}` + (x ? '  → ' + x : '')); } };
const eq = (a, b, l) => ok(a === b, l, `انتظار ${JSON.stringify(b)} / دریافت ${JSON.stringify(a)}`);
const head = t => console.log(`\n\x1b[1m${t}\x1b[0m`);
const wait = ms => new Promise(r => setTimeout(r, ms));

const SETTINGS = {
  title: 'چت', agentName: 'پشتیبانی', greeting: 'سلام', placeholder: 'بنویس',
  accent: '#22d3ee', position: 'start', autoOpen: false, autoDelay: 5, starter: [],
  humanHandoff: true, sound: false, offlineNote: '', offsetBottom: 18, offsetSide: 18,
  launcherSize: 62, panelWidth: 384, panelHeight: 620, radius: 28, blur: 30, glassOpacity: 62,
  launcherLabel: '', teaser: false, teaserText: '', mobileSheet: true, maximize: true,
  showFooter: true, theme: 'auto', prechat: true, prechatRequired: true, prechatNote: 'مشخصاتت را وارد کن'
};

const dom = new JSDOM('<!DOCTYPE html><html><body><div id="pasokhban-live" data-mode="widget"></div></body></html>',
  { url: 'http://e.test/', pretendToBeVisual: true, runScripts: 'dangerously' });
const w = dom.window;

// CSS واقعی پلاگین
const st = w.document.createElement('style');
st.textContent = CSS;
w.document.head.appendChild(st);

w.PASOKHBAN_CHAT = { restUrl: '/wp-json/pasokhban/v1', nonce: 'n', lang: 'fa' };
w.PASOKHBAN_CHAT_SETTINGS = SETTINGS;
if (!w.Response) w.Response = class { constructor(b,o){ this._b=b; this.status=(o||{}).status||200; this.ok=this.status>=200&&this.status<300; } json(){ return Promise.resolve(JSON.parse(this._b)); } };
w.fetch = (u, o) => {
  o = o || {}; const path = String(u).replace(/^.*\/v1/, ''); const body = o.body ? JSON.parse(o.body) : {};
  return Promise.resolve({ ok: true, status: 200, json: () => {
    if (path.startsWith('/live/start')) return Promise.resolve({ key: 'a1b2c3d4e5f60718293a4b5c6d7e8f90', mode: 'ai', status: 'open', messages: [], agentOnline: false, settings: SETTINGS });
    if (path.startsWith('/live/contact')) return Promise.resolve({ ok: true });
    if (path.startsWith('/live/send')) return Promise.resolve({ message: { id: 11, sender: 'visitor', content: body.content, meta: {} }, mode: 'ai', reply: { id: 12, sender: 'agent', content: 'پاسخ', meta: {} } });
    if (path.startsWith('/live/poll')) return Promise.resolve({ messages: [], mode: 'ai', status: null, typing: false, agentOnline: false });
    return Promise.resolve({ ok: true });
  }});
};

const s = w.document.createElement('script');
s.textContent = JS;
w.document.body.appendChild(s);

(async () => {
  await wait(300);
  const d = w.document;
  const cs = el => w.getComputedStyle(el);

  head('۱) لایه‌بندی: هدر نباید زیر فرم برود');
  const pc = d.querySelector('#psb-prechat');
  const hd = d.querySelector('.psb-head');
  ok(!!pc, 'فرم پیش‌گفتگو وجود دارد');
  ok(!!hd, 'هدر وجود دارد');
  const zPc = parseInt(cs(pc).zIndex, 10);
  const zHd = parseInt(cs(hd).zIndex, 10);
  ok(zHd > zPc, `z-index هدر (${zHd}) بالاتر از فرم (${zPc}) است`);
  eq(cs(pc).position, 'absolute', 'فرم absolute است');
  eq(cs(pc).inset || cs(pc).top, '0px', 'فرم کل پنل را می‌پوشاند (پس z-index هدر حیاتی است)');

  head('۲) دکمهٔ بستن داخل خودِ فرم');
  const pcClose = d.querySelector('#psb-pc-close');
  ok(!!pcClose, 'دکمهٔ بستن داخل کارت فرم هست');
  ok(!!(pcClose && pcClose.querySelector('svg')), 'آیکون ✕ دارد');
  ok(!!pcClose.getAttribute('aria-label'), 'aria-label برای دسترس‌پذیری دارد');
  eq(cs(d.querySelector('.psb-pc-card')).position, 'relative', 'کارت relative است تا دکمه درست جای‌گیری شود');

  head('۳) بستن از راه فرم → کل پنل بسته می‌شود');
  d.querySelector('.psb-launcher').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
  await wait(120);
  eq(pc.hidden, false, 'فرم نمایش داده شد');
  ok(d.getElementById('pasokhban-live').classList.contains('is-open'), 'پنل باز است');

  pcClose.dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
  await wait(80);
  ok(!d.getElementById('pasokhban-live').classList.contains('is-open'), 'با ✕ فرم، کل پنل بسته شد');
  eq(pc.hidden, true, 'فرم هم پنهان شد');

  head('۴) دکمه‌های هدر در دسترس می‌مانند');
  d.querySelector('.psb-launcher').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
  await wait(120);
  eq(pc.hidden, false, 'فرم دوباره نمایش داده شد');
  // هدر باید بالای فرم باشد → دکمه‌هایش قابل کلیک‌اند
  const elAtPoint = d.elementFromPoint ? null : null; // jsdom layout ندارد؛ z-index کافی است
  ok(zHd > zPc, 'هدر بالای فرم است پس دکمهٔ بستن هدر هم کار می‌کند');
  const closeBtn = d.querySelector('#psb-close');
  ok(!!closeBtn, 'دکمهٔ بستن هدر وجود دارد');
  closeBtn.dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
  await wait(80);
  ok(!d.getElementById('pasokhban-live').classList.contains('is-open'), 'دکمهٔ بستن هدر پنل را بست');

  head('۵) Escape هم فرم را می‌بندد');
  d.querySelector('.psb-launcher').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
  await wait(120);
  eq(pc.hidden, false, 'فرم نمایش داده شد');
  d.dispatchEvent(new w.KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
  await wait(80);
  ok(!d.getElementById('pasokhban-live').classList.contains('is-open'), 'با Escape پنل بسته شد');
  eq(pc.hidden, true, 'فرم هم پنهان شد');

  head('۶) فرم اسکرول‌پذیر است (موبایل)');
  eq(cs(pc).overflowY, 'auto', 'فرم در ارتفاع کم اسکرول می‌شود');
  ok(cs(d.querySelector('.psb-pc-card')).maxHeight !== 'none', 'کارت سقف ارتفاع دارد');

  console.log('\n' + '─'.repeat(52));
  if (fail === 0) console.log(`\x1b[42;30m همهٔ ${pass} تست رفع فرم پیش‌گفتگو پاس شد \x1b[0m`);
  else { console.log(`\x1b[41;97m ${fail} تست شکست خورد \x1b[0m (پاس: ${pass})`); fails.forEach(f => console.log('   • ' + f)); }
  console.log('─'.repeat(52));
  process.exit(fail === 0 ? 0 : 1);
})();
