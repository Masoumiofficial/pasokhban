<?php
/**
 * تست‌های ۲.۲.۰ — آگاهی از ووکامرس.
 *
 * تمرکز اصلی روی امنیت استعلام سفارش است: شمارهٔ سفارش در ووکامرس یک
 * عدد ترتیبی ساده است، پس بدون تأیید هویت هر کسی می‌توانست سفارش‌های
 * همه را بخواند.
 */

require_once __DIR__ . '/wp-stubs.php';

$PASS = 0; $FAIL = 0; $FAILURES = array();

function ok( $cond, $label, $extra = '' ) {
	global $PASS, $FAIL, $FAILURES;
	if ( $cond ) { $PASS++; echo "  \033[32m✓\033[0m {$label}\n"; }
	else { $FAIL++; $FAILURES[] = $label . ( $extra ? " — {$extra}" : '' ); echo "  \033[31m✗\033[0m {$label}" . ( $extra ? "  → {$extra}" : '' ) . "\n"; }
}
function head( $t ) { echo "\n\033[1m{$t}\033[0m\n"; }
function eq( $a, $b, $label ) { ok( $a === $b, $label, 'انتظار ' . var_export( $b, true ) . ' / دریافت ' . var_export( $a, true ) ); }
function code( $r ) {
	if ( ! is_wp_error( $r ) ) { return 'no-error'; }
	$d = $r->get_error_data();
	return ( is_array( $d ) && isset( $d['status'] ) ) ? (int) $d['status'] : 0;
}

/* ---- اول بدون ووکامرس ---- */
head( '۱) وقتی ووکامرس نصب نیست' );
eq( Pasokhban_Woo::active(), false, 'active() درست false می‌دهد' );
eq( Pasokhban_Woo::enabled( 'woo_products' ), false, 'قابلیت‌ها خاموش‌اند' );
eq( Pasokhban_Woo::add_product_sources( array( 'x' ), array() ), array( 'x' ), 'فیلتر منابع چیزی اضافه نمی‌کند' );

$settings = Pasokhban_Settings::instance();
$rp = new ReflectionProperty( 'Pasokhban_Settings', 'options' ); $rp->setAccessible( true );
$d = $settings->defaults();
eq( $d['woo_products'], 1, 'ایندکس محصولات پیش‌فرض روشن' );
eq( $d['woo_order_lookup'], 1, 'استعلام سفارش پیش‌فرض روشن' );

ob_start();
Pasokhban_Settings::instance()->render_page();
$html = ob_get_clean();
ok( false !== strpos( $html, 'ووکامرس روی این سایت فعال نیست' ), 'هشدار «ووکامرس فعال نیست» در تنظیمات نمایش داده می‌شود' );

/* ---- حالا ووکامرس را فعال کن ---- */
require_once __DIR__ . '/wc-stubs.php';

$GLOBALS['wc_terms'] = array( 7 => 'لوازم جانبی', 8 => 'موبایل' );

$GLOBALS['wc_products'][101] = array(
	'name'     => 'هندزفری بلوتوث مدل X200',
	'price'    => '۱٬۲۵۰٬۰۰۰ تومان',
	'in_stock' => true,
	'qty'      => 12,
	'sku'      => 'X200-BLK',
	'cats'     => array( 7, 8 ),
	'attrs'    => array( 'رنگ' => array( 'مشکی', 'سفید' ), 'گارانتی' => array( '۱۸ ماه' ) ),
	'short'    => 'هندزفری بی‌سیم با کیفیت بالا.',
	'desc'     => 'این هندزفری با بلوتوث نسخهٔ ۵ کار می‌کند و تا ۱۰ متر برد دارد.',
);
$GLOBALS['wc_products'][102] = array(
	'name'     => 'کابل شارژ type-c',
	'price'    => '۱۸۰٬۰۰۰ تومان',
	'in_stock' => false,
	'sku'      => 'TC-1M',
	'short'    => 'کابل یک متری.',
);

$GLOBALS['wc_orders'][1001] = array(
	'number' => '۱۰۰۱', 'status' => 'processing', 'ts' => 1735689600, 'total' => 1430000,
	'email'  => 'sara@example.test', 'phone' => '09121234567',
	'bcity'  => 'تهران', 'scity' => 'کرج', 'ship' => 'پست پیشتاز',
	'items'  => array( 'هندزفری بلوتوث مدل X200' => 1, 'کابل شارژ type-c' => 2 ),
);
$GLOBALS['wc_orders'][1002] = array(
	'number' => '1002', 'status' => 'completed', 'ts' => 1735776000, 'total' => 500000,
	'email'  => 'ali@example.test', 'phone' => '+989351112233',
	'ship'   => 'تیپاکس',
);

// محصولات هم باید به‌عنوان post_type=product در فهرست نوشته‌ها باشند،
// چون add_product_sources اول با get_posts آن‌ها را پیدا می‌کند و بعد
// wc_get_product را صدا می‌زند — دقیقاً همان کاری که در وردپرس واقعی
// اتفاق می‌افتد.
$GLOBALS['wp_posts'] = array();
foreach ( array_keys( $GLOBALS['wc_products'] ) as $pid ) {
	$GLOBALS['wp_posts'][] = (object) array(
		'ID'           => (int) $pid,
		'post_title'   => $GLOBALS['wc_products'][ $pid ]['name'],
		'post_content' => '',
		'post_type'    => 'product',
		'post_status'  => 'publish',
	);
}

$BASE = array(
	'api_key' => 'sk', 'base_url' => 'https://api.example.test/v1',
	'live_enabled' => 1, 'rate_limit' => 0, 'live_history' => 20,
	'woo_products' => 1, 'woo_order_lookup' => 1,
);
function set_opts( array $over = array() ) {
	global $BASE;
	$o = array_merge( $BASE, $over );
	update_option( 'pasokhban_options', $o );
	$rp = new ReflectionProperty( 'Pasokhban_Settings', 'options' );
	$rp->setAccessible( true );
	$rp->setValue( Pasokhban_Settings::instance(), $o );
}
set_opts();
Pasokhban_DB::install();

/* ========================================================= */
head( '۲) فعال‌شدن و ایندکس محصولات' );
/* ========================================================= */

eq( Pasokhban_Woo::active(), true, 'ووکامرس فعال تشخیص داده شد' );
eq( Pasokhban_Woo::enabled( 'woo_products' ), true, 'ایندکس محصولات روشن است' );

$src = Pasokhban_Woo::add_product_sources( array(), array() );
eq( count( $src ), 2, 'هر دو محصول به منابع اضافه شدند' );
eq( $src[0]['type'], 'product', 'نوع منبع product است' );
eq( $src[0]['id'], '101', 'شناسهٔ محصول درست است' );

$body = $src[0]['body'];
ok( false !== strpos( $body, 'هندزفری بلوتوث' ), 'نام محصول در متن تکه' );
ok( false !== strpos( $body, '۱٬۲۵۰٬۰۰۰ تومان' ), '★ قیمت در متن تکه (در post_content نبود)' );
ok( false !== strpos( $body, 'موجود (12 عدد)' ), '★ موجودی با تعداد در متن تکه' );
ok( false !== strpos( $body, 'X200-BLK' ), 'SKU در متن تکه' );
ok( false !== strpos( $body, 'لوازم جانبی' ) && false !== strpos( $body, 'موبایل' ), 'دسته‌بندی‌ها در متن تکه' );
ok( false !== strpos( $body, 'رنگ: مشکی، سفید' ), 'گزینه‌ها در متن تکه' );
ok( false !== strpos( $body, 'گارانتی' ), 'ویژگی دوم هم هست' );
ok( false !== strpos( $body, 'توضیح کوتاه' ), 'توضیح کوتاه قبل از توضیحات کامل آمده' );

ok( false !== strpos( $src[1]['body'], 'ناموجود' ), 'محصول ناموجود درست علامت خورد' );

// hash با تغییر قیمت عوض می‌شود
$h1 = $src[0]['hash'];
$GLOBALS['wc_products'][101]['price'] = '۱٬۳۰۰٬۰۰۰ تومان';
$src2 = Pasokhban_Woo::add_product_sources( array(), array() );
ok( $src2[0]['hash'] !== $h1, '★ با تغییر قیمت، hash عوض می‌شود (پس دوباره ایندکس می‌شود)' );
$GLOBALS['wc_products'][101]['price'] = '۱٬۲۵۰٬۰۰۰ تومان';

// خاموش → چیزی اضافه نمی‌شود
set_opts( array( 'woo_products' => 0 ) );
eq( Pasokhban_Woo::add_product_sources( array( 'x' ), array() ), array( 'x' ), 'با قابلیت خاموش، محصولی اضافه نمی‌شود' );
set_opts();

// فیلتر واقعاً به RAG وصل است
$all = Pasokhban_RAG::instance()->sources();
$types = array();
foreach ( $all as $x ) { $types[ $x['type'] ] = true; }
ok( isset( $types['product'] ), 'فیلتر pasokhban_rag_sources محصولات را به RAG می‌رساند' );

/* ========================================================= */
head( '۳) نرمال‌سازی ورودی' );
/* ========================================================= */

eq( Pasokhban_Woo::parse_order_id( '۱۰۰۱' ), 1001, 'رقم فارسی خوانده شد' );
eq( Pasokhban_Woo::parse_order_id( 'سفارش ۱۰۰۱' ), 1001, 'از متن کامل استخراج شد' );
eq( Pasokhban_Woo::parse_order_id( '#1002' ), 1002, 'قالب #1002' );
eq( Pasokhban_Woo::parse_order_id( 'order 1002 please' ), 1002, 'متن انگلیسی' );
eq( Pasokhban_Woo::parse_order_id( '' ), 0, 'ورودی خالی → ۰' );
eq( Pasokhban_Woo::parse_order_id( 'سلام' ), 0, 'بدون رقم → ۰' );

eq( Pasokhban_Woo::normalize_phone( '09121234567' ), '9121234567', 'پیشوند صفر حذف شد' );
eq( Pasokhban_Woo::normalize_phone( '+989121234567' ), '9121234567', 'پیشوند +98 حذف شد' );
eq( Pasokhban_Woo::normalize_phone( '989121234567' ), '9121234567', 'پیشوند 98 حذف شد' );
eq( Pasokhban_Woo::normalize_phone( '۰۹۱۲۱۲۳۴۵۶۷' ), '9121234567', 'ارقام فارسی نرمال شد' );
eq( Pasokhban_Woo::normalize_phone( '0912-123-4567' ), '9121234567', 'خط تیره حذف شد' );
eq( Pasokhban_Woo::normalize_phone( '00989121234567' ), '9121234567', 'پیشوند 0098 حذف شد' );
eq( Pasokhban_Woo::normalize_phone( '' ), '', 'خالی → خالی' );

eq( Pasokhban_Woo::match_email( 'Sara@Example.test', 'sara@example.test' ), true, 'مقایسهٔ ایمیل بی‌توجه به بزرگی حرف' );
eq( Pasokhban_Woo::match_email( 'other@example.test', 'sara@example.test' ), false, 'ایمیل اشتباه رد شد' );
eq( Pasokhban_Woo::match_email( '', 'sara@example.test' ), false, 'ایمیل خالی رد شد' );
eq( Pasokhban_Woo::match_phone( '09121234567', '+989121234567' ), true, 'شماره با قالب متفاوت قبول شد' );
eq( Pasokhban_Woo::match_phone( '09121234567', '09351112233' ), false, 'شمارهٔ اشتباه رد شد' );
eq( Pasokhban_Woo::match_phone( '123', '09121234567' ), false, 'شمارهٔ خیلی کوتاه رد شد (جلوگیری از حدس)' );

/* ========================================================= */
head( '۴) استعلام سفارش — مسیر عمومی' );
/* ========================================================= */

$lc = Pasokhban_LiveChat::instance();
$start = $lc->handle_start( new WP_REST_Request( array(), array( 'lang' => 'fa', 'name' => 'سارا' ) ) );
$KEY   = $start['key'];

$ask = function ( $params ) { return new WP_REST_Request( $params ); };

/**
 * پاک‌کردن هر دو شمارندهٔ قفل.
 *
 * نکته: client_ip() در هارنس رشتهٔ خالی می‌دهد، پس کلید IP را از خودِ
 * کد می‌گیریم نه از یک مقدار حدس‌زده. (همین اختلاف باعث شد یک باگ واقعی
 * پیدا شود: با IP خالی همهٔ بازدیدکننده‌ها یک شمارندهٔ مشترک داشتند.)
 */
function clear_lock( $session_id = 0 ) {
	$ip = (string) Pasokhban_DB::client_ip();
	if ( '' !== $ip ) {
		delete_transient( 'pasokhban_woo_lock_i_' . md5( $ip ) );
	}
	if ( $session_id ) {
		delete_transient( 'pasokhban_woo_lock_s_' . (int) $session_id );
	}
}
function clear_all_locks() {
	$ip = (string) Pasokhban_DB::client_ip();
	if ( '' !== $ip ) {
		delete_transient( 'pasokhban_woo_lock_i_' . md5( $ip ) );
	}
	foreach ( (array) array_keys( $GLOBALS['wp_transients'] ) as $k ) {
		if ( 0 === strpos( (string) $k, 'pasokhban_woo_lock_s_' ) ) {
			delete_transient( $k );
		}
	}
}

// قابلیت خاموش
set_opts( array( 'woo_order_lookup' => 0 ) );
eq( code( Pasokhban_Woo::handle_order( $ask( array( 'key' => $KEY, 'order_id' => '1001', 'verify' => 'sara@example.test' ) ) ) ), 403, 'با قابلیت خاموش، ۴۰۳' );
set_opts();

// نشست نامعتبر
eq( code( Pasokhban_Woo::handle_order( $ask( array( 'key' => 'bad', 'order_id' => '1001', 'verify' => 'x' ) ) ) ), 404, 'نشست نامعتبر، ۴۰۴' );

// شمارهٔ سفارش نامعتبر
clear_all_locks();
eq( code( Pasokhban_Woo::handle_order( $ask( array( 'key' => $KEY, 'order_id' => 'abc', 'verify' => 'x' ) ) ) ), 400, 'شمارهٔ نامعتبر، ۴۰۰' );

// بدون تأیید هویت
clear_all_locks();
eq( code( Pasokhban_Woo::handle_order( $ask( array( 'key' => $KEY, 'order_id' => '1001', 'verify' => '' ) ) ) ), 400, 'بدون تأیید هویت، ۴۰۰' );

// ★ سفارش موجود ولی تأیید هویت اشتباه
clear_all_locks();
$r = Pasokhban_Woo::handle_order( $ask( array( 'key' => $KEY, 'order_id' => '1001', 'verify' => 'hacker@evil.test' ) ) );
eq( code( $r ), 403, 'تأیید هویت اشتباه رد شد' );

// ★ سفارش ناموجود — باید دقیقاً همان پیام را بدهد (جلوگیری از شمارش)
clear_all_locks();
$r2 = Pasokhban_Woo::handle_order( $ask( array( 'key' => $KEY, 'order_id' => '99999', 'verify' => 'hacker@evil.test' ) ) );
eq( code( $r2 ), 403, 'سفارش ناموجود هم ۴۰۳ می‌دهد' );
eq( $r->get_error_message(), $r2->get_error_message(), '★ پیام خطای «ناموجود» و «تأیید نشد» یکی است (شمارش ممکن نیست)' );

// ★ تأیید هویت موفق با ایمیل
clear_all_locks();
$res = Pasokhban_Woo::handle_order( $ask( array( 'key' => $KEY, 'order_id' => '1001', 'verify' => 'sara@example.test' ) ) );
ok( ! is_wp_error( $res ), 'با ایمیل درست، استعلام موفق بود', is_wp_error( $res ) ? $res->get_error_message() : '' );
eq( $res['ok'], true, 'ok=true' );
$o = $res['order'];
eq( $o['number'], '۱۰۰۱', 'شمارهٔ سفارش برگشت' );
eq( $o['status'], 'در حال پردازش', 'وضعیت از ترجمهٔ ووکامرس خوانده شد' );
ok( false !== strpos( $o['date'], '۱۴۰۳' ), '★ تاریخ ثبت سفارش شمسی است (از ۲.۴.۰)', $o['date'] );
ok( false !== strpos( $o['total'], 'تومان' ), 'مبلغ با واحد پول برگشت', $o['total'] );
eq( $o['shipping'], 'پست پیشتاز', 'روش ارسال' );
eq( $o['city'], 'کرج', 'شهر مقصد (نه آدرس کامل)' );
eq( count( $o['items'] ), 2, 'اقلام برگشتند' );
eq( $o['items'][1]['qty'], 2, 'تعداد قلم درست است' );

// ★ سانسور: اطلاعات حساس نباید در خروجی باشد
$json = json_encode( $o, JSON_UNESCAPED_UNICODE );
ok( false === strpos( $json, 'sara@example.test' ), '★ ایمیل مشتری در خروجی نیست' );
ok( false === strpos( $json, '9121234567' ) && false === strpos( $json, '09121234567' ), '★ شمارهٔ تماس در خروجی نیست' );
ok( false === strpos( $json, 'خیابان مخفی' ), '★ آدرس کامل در خروجی نیست' );
ok( false === strpos( $json, 'کارت به کارت' ), '★ اطلاعات پرداخت در خروجی نیست' );
ok( false === strpos( $json, '1.2.3.4' ), '★ IP مشتری در خروجی نیست' );

// ★ تأیید هویت با شمارهٔ تماس (قالب متفاوت)
clear_all_locks();
$res2 = Pasokhban_Woo::handle_order( $ask( array( 'key' => $KEY, 'order_id' => '1001', 'verify' => '+98 912 123 4567' ) ) );
ok( ! is_wp_error( $res2 ), 'با شمارهٔ تماس (قالب متفاوت) هم موفق بود', is_wp_error( $res2 ) ? $res2->get_error_message() : '' );

// سفارش دوم با پیشوند +98
clear_all_locks();
$res3 = Pasokhban_Woo::handle_order( $ask( array( 'key' => $KEY, 'order_id' => '1002', 'verify' => '09351112233' ) ) );
ok( ! is_wp_error( $res3 ), 'پیشوند +98 روی سفارش با ۰۹۳۵ مطابقت یافت', is_wp_error( $res3 ) ? $res3->get_error_message() : '' );

// ★ استعلام در مکالمه ثبت می‌شود تا اپراتور ببیند
$msgs = Pasokhban_DB::get_messages( (int) Pasokhban_DB::get_session_by_key( $KEY )->id );
$found_order_msg = false;
foreach ( $msgs as $m ) {
	if ( isset( $m->meta['note'] ) && 'order' === $m->meta['note'] ) { $found_order_msg = true; }
}
ok( $found_order_msg, '★ استعلام در مکالمه ثبت شد تا اپراتور و AI ببینند' );

/* ========================================================= */
head( '۵) قفل ضد شمارش' );
/* ========================================================= */

clear_all_locks();
for ( $i = 0; $i < Pasokhban_Woo::MAX_FAILED; $i++ ) {
	Pasokhban_Woo::handle_order( $ask( array( 'key' => $KEY, 'order_id' => '1001', 'verify' => 'wrong' . $i . '@x.test' ) ) );
}
$r = Pasokhban_Woo::handle_order( $ask( array( 'key' => $KEY, 'order_id' => '1001', 'verify' => 'sara@example.test' ) ) );
eq( code( $r ), 429, '★ بعد از سقف تلاش ناموفق، حتی درخواست درست هم رد می‌شود' );
ok( false !== strpos( $r->get_error_message(), 'یک ساعت' ), 'مدت قفل در پیام گفته شد' );

// موفقیت شمارنده را صفر می‌کند
clear_all_locks();
Pasokhban_Woo::handle_order( $ask( array( 'key' => $KEY, 'order_id' => '1001', 'verify' => 'wrong@x.test' ) ) );
Pasokhban_Woo::handle_order( $ask( array( 'key' => $KEY, 'order_id' => '1001', 'verify' => 'sara@example.test' ) ) );
Pasokhban_Woo::handle_order( $ask( array( 'key' => $KEY, 'order_id' => '1001', 'verify' => 'wrong@x.test' ) ) );
clear_all_locks();
$rr = Pasokhban_Woo::handle_order( $ask( array( 'key' => $KEY, 'order_id' => '1001', 'verify' => 'sara@example.test' ) ) );
ok( ! is_wp_error( $rr ), 'بعد از یک موفقیت، شمارنده صفر شد و قفل نمی‌کند' );

// ★ رگرسیون: با IP خالی، قفل یک نشست نباید نشست دیگر را ببندد.
// (این دقیقاً همان باگی بود که موقع نوشتن تست پیدا شد: client_ip()
//  وقتی هدر IP نباشد رشتهٔ خالی می‌دهد و اگر فقط یک شمارندهٔ IP
//  داشتیم، همهٔ بازدیدکننده‌های سایت یک شمارندهٔ مشترک داشتند.)
eq( (string) Pasokhban_DB::client_ip(), '', 'شرط آزمون: IP در دسترس نیست' );
$s2 = $lc->handle_start( new WP_REST_Request( array(), array( 'lang' => 'fa', 'name' => 'قربانی' ) ) );
$K2 = $s2['key'];
clear_all_locks();
for ( $i = 0; $i < Pasokhban_Woo::MAX_FAILED; $i++ ) {
	Pasokhban_Woo::handle_order( $ask( array( 'key' => $KEY, 'order_id' => '1001', 'verify' => 'bad' . $i . '@x.test' ) ) );
}
eq( code( Pasokhban_Woo::handle_order( $ask( array( 'key' => $KEY, 'order_id' => '1001', 'verify' => 'sara@example.test' ) ) ) ), 429, 'نشست متخلف بسته شد' );
$innocent = Pasokhban_Woo::handle_order( $ask( array( 'key' => $K2, 'order_id' => '1002', 'verify' => 'ali@example.test' ) ) );
ok( ! is_wp_error( $innocent ), '★ با IP خالی، قفل یک نشست بقیهٔ سایت را نمی‌بندد', is_wp_error( $innocent ) ? $innocent->get_error_message() : '' );

// ★ این محدودیت مستقل از rate_limit پلاگین است
set_opts( array( 'rate_limit' => 0 ) );
clear_all_locks();
for ( $i = 0; $i < Pasokhban_Woo::MAX_FAILED; $i++ ) {
	Pasokhban_Woo::handle_order( $ask( array( 'key' => $KEY, 'order_id' => '1001', 'verify' => 'w' . $i . '@x.test' ) ) );
}
eq( code( Pasokhban_Woo::handle_order( $ask( array( 'key' => $KEY, 'order_id' => '1001', 'verify' => 'sara@example.test' ) ) ) ), 429, '★ با rate_limit=0 هم قفل کار می‌کند' );
clear_all_locks();
set_opts();

/* ========================================================= */
head( '۶) مسیر مدیر (بدون تأیید هویت)' );
/* ========================================================= */

$GLOBALS['wp_current_user_can'] = true;
Pasokhban_Woo::register_routes();
ok( isset( $GLOBALS['wp_rest_routes']['pasokhban/v1/live/order'] ), 'مسیر /live/order ثبت شد' );
ok( isset( $GLOBALS['wp_rest_routes']['pasokhban/v1/admin/order'] ), 'مسیر /admin/order ثبت شد' );

$GLOBALS['wp_current_user_can'] = false;
eq( Pasokhban_Woo::admin_permission(), false, 'کاربر غیرمدیر به /admin/order دسترسی ندارد' );
$GLOBALS['wp_current_user_can'] = true;
eq( Pasokhban_Woo::admin_permission(), true, 'مدیر دسترسی دارد' );

$res = Pasokhban_Woo::handle_admin_order( $ask( array( 'order_id' => '۱۰۰۱' ) ) );
ok( ! is_wp_error( $res ), 'مدیر بدون تأیید هویت استعلام می‌گیرد' );
eq( $res['order']['status'], 'در حال پردازش', 'وضعیت برگشت' );
$j = json_encode( $res['order'], JSON_UNESCAPED_UNICODE );
ok( false === strpos( $j, 'sara@example.test' ), '★ حتی برای مدیر، ایمیل و آدرس کامل برگردانده نمی‌شود' );

eq( code( Pasokhban_Woo::handle_admin_order( $ask( array( 'order_id' => '99999' ) ) ) ), 404, 'سفارش ناموجود برای مدیر ۴۰۴ است' );

/* ========================================================= */
head( '۷) رسیدن وضعیت سفارش به مدل' );
/* ========================================================= */

$order = wc_get_order( 1001 );
$sum   = Pasokhban_Woo::safe_order_summary( $order );
$note  = Pasokhban_Woo::describe( $sum );
ok( false !== strpos( $note, '۱۰۰۱' ), 'شماره در توضیح هست' );
ok( false !== strpos( $note, 'در حال پردازش' ), 'وضعیت در توضیح هست' );
ok( false !== strpos( $note, 'اقلام' ), 'اقلام در توضیح هست' );
ok( false !== strpos( $note, 'هیچ جزئیات دیگری از خودت نساز' ), '★ مدل از ساختن جزئیات نهی شده' );

eq( Pasokhban_Woo::latest_from_messages( array() ), null, 'بدون پیام، null' );
eq( Pasokhban_Woo::latest_from_messages( array(
	(object) array( 'meta' => array( 'note' => 'handoff' ) ),
) ), null, 'پیام غیرسفارش نادیده گرفته می‌شود' );
eq( Pasokhban_Woo::latest_from_messages( array(
	(object) array( 'meta' => array( 'note' => 'order', 'order' => $sum ) ),
) ), $sum, 'آخرین سفارش از پیام‌ها پیدا شد' );

// واقعاً به prompt مدل می‌رسد
set_opts();
$GLOBALS['wp_remote_calls'] = array();
$GLOBALS['wp_remote_response'] = array(
	'response' => array( 'code' => 200 ),
	'body'     => json_encode( array( 'choices' => array( array( 'message' => array( 'content' => 'سفارشت در حال پردازش است.' ) ) ) ) ),
);
$sid = (int) Pasokhban_DB::get_session_by_key( $KEY )->id;
Pasokhban_DB::add_message( $sid, 'visitor', 'سفارشم کجاست؟' );
Pasokhban_DB::add_message( $sid, 'system', 'مشتری وضعیت سفارش را دید', array( 'note' => 'order', 'order' => $sum ) );

$m = new ReflectionMethod( 'Pasokhban_LiveChat', 'ai_reply' );
$m->setAccessible( true );
$m->invoke( $lc, Pasokhban_DB::get_session( $sid ), 'fa' );

$payload = null;
foreach ( array_reverse( (array) $GLOBALS['wp_remote_calls'] ) as $c ) {
	if ( false !== strpos( $c['url'], '/chat/completions' ) ) {
		$payload = is_array( $c['body'] ) ? $c['body'] : json_decode( (string) $c['body'], true );
		break;
	}
}
$has_order = false;
foreach ( (array) $payload['messages'] as $mm ) {
	if ( false !== strpos( (string) $mm['content'], 'در حال پردازش' ) && 'system' === $mm['role'] ) { $has_order = true; }
}
ok( $has_order, '★ وضعیت سفارش به‌صورت پیام system به مدل رسید' );

/* ========================================================= */
head( '۸) وضعیت سفارش با قالب‌های مختلف' );
/* ========================================================= */

eq( Pasokhban_Woo::status_label( new WC_Stub_Order( array( 'status' => 'completed' ) ) ), 'تکمیل شده', 'وضعیت completed ترجمه شد' );
eq( Pasokhban_Woo::status_label( new WC_Stub_Order( array( 'status' => 'refunded' ) ) ), 'مسترد شده', 'وضعیت refunded ترجمه شد' );
eq( Pasokhban_Woo::status_label( new WC_Stub_Order( array( 'status' => 'weird-custom' ) ) ), 'weird-custom', 'وضعیت ناشناخته خام برمی‌گردد نه خطا' );

$noCity = Pasokhban_Woo::safe_order_summary( new WC_Stub_Order( array( 'number' => '5', 'status' => 'pending', 'bcity' => 'شیراز' ) ) );
eq( $noCity['city'], 'شیراز', 'اگر شهر ارسال خالی بود، شهر صورتحساب استفاده می‌شود' );

/* ========================================================= */
head( '۹) تنظیمات عمومی سمت کاربر' );
/* ========================================================= */

$pub = $lc->public_settings( 'fa' );
eq( $pub['wooOrder'], true, 'wooOrder به کلاینت می‌رسد' );
set_opts( array( 'woo_order_lookup' => 0 ) );
eq( $lc->public_settings( 'fa' )['wooOrder'], false, 'با قابلیت خاموش، کارت استعلام در چت نمی‌آید' );

echo "\n" . str_repeat( '─', 52 ) . "\n";
if ( 0 === $FAIL ) {
	echo "\033[42;30m همهٔ {$PASS} تست ووکامرس پاس شد \033[0m\n";
} else {
	echo "\033[41;97m {$FAIL} تست شکست خورد \033[0m (پاس: {$PASS})\n";
	foreach ( $FAILURES as $f ) { echo "   • {$f}\n"; }
}
echo str_repeat( '─', 52 ) . "\n";
exit( 0 === $FAIL ? 0 : 1 );
