<?php
/**
 * بنچمارک جست‌وجوی برداری — پاسخ‌بان ۱.۹.۰
 *
 * سؤال عملی: جست‌وجو خطی و در PHP است، پس روی سایت بزرگ چقدر طول می‌کشد؟
 * این اسکریپت همان کد واقعی Pasokhban_RAG::retrieve() را روی ایندکس‌های
 * مصنوعی با اندازه‌های مختلف اجرا می‌کند و زمان را گزارش می‌دهد.
 *
 * استفاده:  php tests/rag-bench.php [تعداد-تکه] [ابعاد]
 */

require_once __DIR__ . '/wp-stubs.php';

$TARGET = isset( $argv[1] ) ? (int) $argv[1] : 2000;
$DIMS   = isset( $argv[2] ) ? (int) $argv[2] : 512;

$GLOBALS['wp_remote_response'] = function ( $url, $args ) use ( $DIMS ) {
	$payload = json_decode( $args['body'], true );
	$data    = array();
	foreach ( (array) $payload['input'] as $i => $t ) {
		// بردار شبه‌تصادفی ولی قطعی (بر اساس hash متن) تا تکرارپذیر باشد.
		$seed = crc32( $t );
		mt_srand( $seed );
		$v = array();
		for ( $k = 0; $k < $DIMS; $k++ ) {
			$v[] = ( mt_rand() / mt_getrandmax() ) - 0.5;
		}
		$data[] = array( 'index' => $i, 'embedding' => Pasokhban_RAG::normalize( $v ) );
	}
	return array( 'response' => array( 'code' => 200 ), 'body' => json_encode( array( 'data' => $data ) ) );
};

update_option( 'pasokhban_options', array(
	'api_key' => 'sk-bench', 'base_url' => 'https://api.example.test/v1',
	'rag_vector' => 1, 'rag_dims' => 0, 'rag_top_k' => 4, 'rag_min_score' => -1,
	'rag_chunk_size' => 1200, 'rag_chunk_overlap' => 200, 'rag_post_types' => 'post',
) );
Pasokhban_Settings::instance();
Pasokhban_DB::install();
$rag = Pasokhban_RAG::instance();

$topics = array( 'بازگشت وجه', 'ارسال و پست', 'قیمت و تخفیف', 'دربارهٔ شرکت', 'گارانتی محصول', 'روش پرداخت' );
$posts  = array();
$pid    = 100;

while ( true ) {
	$body = '';
	for ( $p = 0; $p < 12; $p++ ) {
		$t = $topics[ ( $pid + $p ) % count( $topics ) ];
		$body .= "پاراگراف {$p} دربارهٔ {$t}. " . str_repeat( "این یک جملهٔ نمونه برای پرکردن متن است. ", 14 ) . "\n\n";
	}
	$posts[] = (object) array(
		'ID' => $pid, 'post_title' => 'نوشتهٔ آزمایشی ' . $pid,
		'post_content' => $body, 'post_type' => 'post', 'post_status' => 'publish',
	);
	$pid++;
	if ( count( $posts ) * 12 >= $TARGET || $pid > 400 ) {
		break;
	}
}
$GLOBALS['wp_posts'] = $posts;

$t0  = microtime( true );
$res = $rag->build( array( 'reset' => true ) );
$bt  = microtime( true ) - $t0;

$n = $rag->count_chunks();
printf( "ایندکس: %d تکه · %d منبع · ابعاد %d\n", $n, $res['sources'], $DIMS );
printf( "زمان ساخت ایندکس: %.1f ثانیه (%.0f میلی‌ثانیه به ازای هر تکه)\n", $bt, ( $bt * 1000 ) / max( 1, $n ) );

$sizes = $GLOBALS['wpdb']->get_var( 'SELECT SUM(LENGTH(vector)) FROM ' . Pasokhban_DB::chunks_table() );
printf( "حجم بردارها در جدول: %.1f مگابایت\n", $sizes / 1048576 );

// ---- زمان جست‌وجو ----
$GLOBALS['wp_transients'] = array();
$times = array();
for ( $i = 0; $i < 5; $i++ ) {
	$GLOBALS['wp_transients'] = array(); // کش خاموش، تا واقعاً اسکن کند
	$q  = 'شرایط بازگشت وجه شماره ' . $i;
	$t1 = microtime( true );
	$r  = $rag->retrieve( $q );
	$times[] = ( microtime( true ) - $t1 ) * 1000;
}
sort( $times );
printf( "زمان جست‌وجو (میانهٔ ۵ اجرا، بدون کش): %.0f میلی‌ثانیه\n", $times[ (int) floor( count( $times) / 2 ) ] );
printf( "کمینه/بیشینه: %.0f / %.0f میلی‌ثانیه\n", $times[0], end( $times ) );

// ---- با کش ----
$GLOBALS['wp_transients'] = array();
$rag->retrieve( 'سؤال تکراری' );
$t1 = microtime( true );
$rag->retrieve( 'سؤال تکراری' );
printf( "زمان جست‌وجو با کش: %.2f میلی‌ثانیه\n", ( microtime( true ) - $t1 ) * 1000 );

printf( "حافظهٔ اوج PHP: %.1f مگابایت\n", memory_get_peak_usage( true ) / 1048576 );
