<?php
/**
 * ساخت پیش‌نمایش تب «بررسی سلامت» از کد واقعی PHP/CSS/JS پلاگین.
 *
 * ابزار توسعه است، نه بخشی از پلاگین. همان render_page() واقعی را صدا
 * می‌زند، بعد نتایج نمونه را با همان قالبی که JS واقعی می‌سازد داخل
 * DOM می‌گذارد تا دیده شود صفحه پس از اجرای بررسی‌ها چه شکلی است.
 *
 * استفاده: php tests/make-health-preview.php
 */

require_once __DIR__ . '/wp-stubs.php';

update_option( 'pasokhban_options', array(
	'api_key'             => 'sk-demo-1234567890abcdefgh',
	'model'               => 'gpt-4o',
	'ai_provider'         => 'gapgpt',
	'base_url'            => 'https://api.gapgpt.app/v1',
	'widget_style'        => 'chat',
	'rag_vector'          => 1,
	'rag_dims'            => 512,
	'notify_email'        => 1,
	'notify_email_to'     => 'support@example.com',
	'notify_telegram'     => 1,
	'notify_telegram_token' => '123456:ABC-DEMO',
	'notify_telegram_chat'  => '-1001234567890',
	'bale_enabled'        => 1,
	'bale_token'          => 'BALE-DEMO',
	'bale_chat'           => '-100999',
	'sms_enabled'         => 0,
) );
update_option( 'timezone_string', 'Asia/Tehran' );
Pasokhban_Settings::instance();
Pasokhban_DB::install();
update_option( 'pasokhban_db_version', Pasokhban_DB::SCHEMA_VERSION );
$GLOBALS['wp_cron'] = array( 'pasokhban_cleanup' => 'daily', Pasokhban_RAG::CRON_HOOK => 'hourly' );
$GLOBALS['wpdb']->tables = array( 'posts', 'options', 'users' );

ob_start();
Pasokhban_Settings::instance()->render_page();
$body = ob_get_clean();

/* ---------------------------------------------------------------------
 * نتایج نمونه — ترکیبی از هر پنج وضعیت تا رنگ‌ها و چیدمان دیده شود.
 * ------------------------------------------------------------------- */
$demo = array(
	'core_wp'          => array( 'pass', 'وردپرس 6.7.1', '', '', 0 ),
	'core_php'         => array( 'pass', 'PHP 8.3.14', '', '', 0 ),
	'core_ext'         => array( 'pass', 'mbstring و json فعال‌اند.', 'curl ✓ · fileinfo ✓ · gd ✓', '', 0 ),
	'core_db'          => array( 'pass', 'اتصال برقرار است.', 'MySQL 8.0.36', '', 0 ),
	'core_tz'          => array( 'pass', 'Asia/Tehran — ساعت سرور 1404/07/15 16:20', '', '', 0 ),
	'core_cron'        => array( 'pass', 'زمان‌بندی‌ها ثبت شده‌اند.', '', '', 0 ),

	'db_tables'        => array( 'pass', 'هر پنج جدول ساخته شده‌اند.', 'wp_pasokhban_sessions · wp_pasokhban_messages · wp_pasokhban_feedback · wp_pasokhban_chunks · wp_pasokhban_bale_links', '', 0 ),
	'db_rw'            => array( 'pass', 'نوشتن، خواندن و حذف هر سه کار کردند.', '', '', 41 ),
	'db_ver'           => array( 'pass', 'ساختار 1.8.0 — مطابق کد.', '', '', 0 ),
	'db_legacy'        => array( 'pass', 'جدول قدیمی باقی نمانده است.', '', '', 0 ),
	'db_stats'         => array( 'info', '۱٬۲۸۴ نشست · ۹٬۴۳۱ پیام · ۳۱۲ تکهٔ دانش', '۷ پیام خوانده‌نشده', '', 0 ),

	'ai_key'           => array( 'pass', 'کلید وارد شده است.', 'sk-dem••••••••efgh', '', 0 ),
	'ai_model'         => array( 'pass', 'gpt-4o روی gapgpt', '', '', 0 ),
	'ai_base'          => array( 'pass', 'https://api.gapgpt.app/v1', 'قالب: openai', '', 0 ),
	'ai_ping'          => array( 'pass', 'سرویس پاسخ داد — ۸۴۲ میلی‌ثانیه', '', '', 842 ),
	'ai_embed'         => array( 'pass', 'text-embedding-3-small — بردار ۵۱۲ بعدی', '۳۱۰ میلی‌ثانیه', '', 310 ),
	'ai_rag'           => array( 'pass', 'فهرست دانش آماده است.', '۳۱۲ تکه از post,page,product', '', 0 ),
	'ai_retrieve'      => array( 'pass', '۴ تکه یافت شد — بیشترین شباهت 0.812 در ۲۹۵ میلی‌ثانیه', 'روش‌های ارسال', '', 295 ),

	'chat_widget'      => array( 'pass', 'ویجت و گفتگوی آنلاین فعال‌اند.', 'سبک: چت شیشه‌ای', '', 0 ),
	'chat_routes'      => array( 'pass', '۶ مسیر حیاتی ثبت شده است.', 'https://example.com/wp-json/pasokhban/v1', '', 0 ),
	'chat_session'     => array( 'pass', 'نشست ساخته و با همان کلید بازیابی شد.', '', '', 12 ),
	'chat_upload_dir'  => array( 'warn', 'لایهٔ اعتبارسنجی محتوا در دسترس نیست.', 'fileinfo — قفل اجرای اسکریپت فعال است.', 'افزونهٔ fileinfo را در PHP فعال کنید.', 0 ),
	'chat_upload_types'=> array( 'pass', 'jpg, jpeg, png, gif, webp, pdf, txt', 'سقف ۵ مگابایت', '', 0 ),

	'notif_email'      => array( 'pass', 'support@example.com', 'ایمیل واقعی ارسال نشد تا صندوق شما پر نشود.', '', 0 ),
	'notif_tg'         => array( 'fail', 'cURL error 28: Connection timed out after 20001 milliseconds', '', 'تلگرام از این سرور در دسترس نیست (فیلترینگ). رلهٔ گوگل را در تب «اعلان‌ها» تنظیم کنید.', 0 ),
	'notif_relay'      => array( 'skip', 'اعلان تلگرام خاموش است.', '', '', 0 ),
	'notif_sms'        => array( 'skip', 'پیامک خاموش است.', '', '', 0 ),

	'shop_active'      => array( 'pass', 'ووکامرس فعال است.', '', '', 0 ),
	'shop_products'    => array( 'warn', 'محصولات در فهرست دانش نیستند.', '۲۴ محصول منتشرشده · ۰ تکه در فهرست دانش', 'در تب «دستیار و دانش» فهرست را دوباره بسازید تا قیمت و موجودی هم ایندکس شود.', 0 ),
	'shop_lookup'      => array( 'pass', 'مشتری می‌تواند با شمارهٔ تماس یا ایمیل، آخرین سفارشش را بپرسد.', 'بدون نیاز به دانستن شمارهٔ سفارش.', '', 0 ),

	'bale_cfg'         => array( 'pass', 'پیکربندی کامل است.', 'دوطرفه (پاسخ از داخل بله)', '', 0 ),
	'bale_ping'        => array( 'pass', 'ربات @myshopbot پاسخ داد — ۲۱۸ میلی‌ثانیه', '', '', 218 ),
	'bale_wh'          => array( 'warn', 'webhook ثبت است ولی بله در تحویل آخرین پیام خطا داده است.', 'Read timed out', 'یعنی سایت شما به درخواست بله پاسخ درست نداده — لاگ خطا را ببینید.', 0 ),
	'bale_port'        => array( 'pass', 'پورت ۴۴۳ — مورد قبول بله.', 'https://example.com/', '', 0 ),

	'files_assets'     => array( 'pass', 'هر ۶ فایل اصلی موجود است.', 'نسخهٔ فایل‌ها: 3.1.0', '', 0 ),
	'files_legacy'     => array( 'pass', 'نام‌گذاری یکدست است و کلاس قدیمی نمانده.', '', '', 0 ),
	'files_logo'       => array( 'pass', 'تصویرهای برند موجودند.', 'پابرگ برند پنهان است.', '', 0 ),
);

$ICON = array( 'pass' => '✅', 'fail' => '❌', 'warn' => '⚠️', 'info' => 'ℹ️', 'skip' => '⏭' );

foreach ( $demo as $id => $d ) {
	list( $status, $msg, $detail, $fix, $ms ) = $d;

	$extra = '';
	if ( ( 'fail' === $status || 'warn' === $status ) && '' !== $detail ) {
		$extra .= "\n↳ " . $detail;
	}
	if ( ( 'fail' === $status || 'warn' === $status ) && '' !== $fix ) {
		$extra .= "\n→ " . $fix;
	}

	$search = '<li class="psb-hc-item" data-check="' . $id . '">';
	if ( false === strpos( $body, $search ) ) {
		continue;
	}

	// همان ساختاری که JS واقعی می‌سازد.
	$replace = '<li class="psb-hc-item is-' . $status . '" data-check="' . $id . '">'
		. '<span class="psb-hc-dot" aria-hidden="true">' . $ICON[ $status ] . '</span>'
		. '<span class="psb-hc-label">%%LABEL%%</span>'
		. '<span class="psb-hc-msg">' . esc_html( $msg )
		. ( '' !== $extra ? '<span class="psb-hc-extra">' . esc_html( $extra ) . '</span>' : '' )
		. '</span>'
		. '<span class="psb-hc-ms">' . ( $ms ? $ms . ' ms' : '' ) . '</span>';

	// برچسب اصلی را از همان HTML بردار و دست‌نخورده نگه دار.
	$start = strpos( $body, $search );
	$lab_s = strpos( $body, '<span class="psb-hc-label">', $start );
	$lab_e = strpos( $body, '</span>', $lab_s );
	$label = substr( $body, $lab_s + strlen( '<span class="psb-hc-label">' ), $lab_e - $lab_s - strlen( '<span class="psb-hc-label">' ) );
	$replace = str_replace( '%%LABEL%%', $label, $replace );

	// کل <li> قدیمی را تا </li> جایگزین کن.
	$li_end = strpos( $body, '</li>', $start ) + strlen( '</li>' );
	$body   = substr( $body, 0, $start ) . $replace . '</li>' . substr( $body, $li_end );
}

// گزارش متنی نمونه
$report = implode( "\n", array(
	'پاسخ‌بان 3.1.0 — گزارش سلامت 2026-10-07 12:50',
	'PHP 8.3.14 · WP 6.7.1',
	'──────────────────────────────────────────────',
	'',
	'هوش مصنوعی',
	'  [OK  ] کلید API — کلید وارد شده است.',
	'  [OK  ] فراخوانی واقعی سرویس — سرویس پاسخ داد — ۸۴۲ میلی‌ثانیه (842 ms)',
	'  [OK  ] ساخت بردار (embedding) — text-embedding-3-small — بردار ۵۱۲ بعدی',
	'',
	'اعلان‌ها',
	'  [FAIL] تلگرام — اعتبار توکن — cURL error 28: Connection timed out after 20001 milliseconds',
	'         → تلگرام از این سرور در دسترس نیست (فیلترینگ). رلهٔ گوگل را در تب «اعلان‌ها» تنظیم کنید.',
	'  [SKIP] رلهٔ گوگل — اعلان تلگرام خاموش است.',
	'',
	'کانال بله',
	'  [WARN] ثبت webhook روی بله — webhook ثبت است ولی بله در تحویل آخرین پیام خطا داده است.',
	'         Read timed out',
	'         → یعنی سایت شما به درخواست بله پاسخ درست نداده — لاگ خطا را ببینید.',
	'',
	'──────────────────────────────────────────────',
	'جمع: ۳۷ بررسی — ۳۱ سالم، ۱ خطا، ۳ هشدار',
	'etehadwp.com',
) );
$body = preg_replace(
	'/(<textarea id="psb-hc-report"[^>]*>)(<\/textarea>)/s',
	'$1' . esc_textarea( $report ) . '$2',
	$body
);

// شمارنده
$body = preg_replace(
	'/(<span class="psb-hc-count" id="psb-hc-count">)(<\/span>)/',
	'$1۳۷/۳۷ · سالم ۳۱ · خطا ۱ · هشدار ۳$2',
	$body
);

$css = file_get_contents( PASOKHBAN_PLUGIN_DIR . '/assets/css/pasokhban-admin.css' );
$js  = file_get_contents( PASOKHBAN_PLUGIN_DIR . '/assets/js/pasokhban-settings.js' );

$nav = '<nav id="adminmenu">'
	. '<a class="m on" href="../preview/settings.html">⚙️ تنظیمات</a>'
	. '<a class="m" href="../preview/inbox.html">💬 گفتگوها</a>'
	. '<a class="m" href="../preview/contacts.html">👥 مخاطبین</a>'
	. '<a class="m" href="../preview/analytics.html">📊 آمار</a>'
	. '</nav>';

$shell_css = '
#wpwrap{display:flex;gap:0;background:#f1f5f9;min-height:100vh}
#adminmenu{flex:none;width:190px;background:#0b1120;padding:16px 10px;display:flex;flex-direction:column;gap:4px}
#adminmenu a.m{color:#cbd5e1;text-decoration:none;padding:9px 12px;border-radius:9px;font-size:13px}
#adminmenu a.m.on{background:rgba(34,211,238,.16);color:#22d3ee}
#wpbody{flex:1;min-width:0;padding:20px}
body{margin:0;background:#f1f5f9}
';

// تب سلامت را از همان اول فعال کن تا بدون کلیک دیده شود.
$activate = '
(function(){
  var b = document.querySelector(\'[data-tab="health"]\');
  if (b) { setTimeout(function(){ b.click(); }, 60); }
})();';

$html = '<!DOCTYPE html><html dir="rtl" lang="fa"><head><meta charset="utf-8">'
	. '<meta name="viewport" content="width=device-width, initial-scale=1">'
	. '<title>بررسی سلامت — پاسخ‌بان ۳.۱.۰</title>'
	. '<style>' . $css . $shell_css . '</style>'
	. '</head><body><div id="wpwrap">' . $nav . '<div id="wpbody">' . $body . '</div></div>'
	. '<script>' . $js . $activate . '</script>'
	. '</body></html>';

@mkdir( PASOKHBAN_TESTS_DIR . '/../preview', 0777, true );
file_put_contents( PASOKHBAN_TESTS_DIR . '/../preview/health.html', $html );
echo 'preview/health.html نوشته شد — ' . strlen( $html ) . " بایت\n";
echo 'نتایج نمونهٔ جای‌گذاری‌شده: ';
$n = 0;
foreach ( $demo as $id => $d ) {
	if ( false !== strpos( $html, 'is-' . $d[0] . '" data-check="' . $id ) ) { $n++; }
}
echo $n . ' از ' . count( $demo ) . "\n";
