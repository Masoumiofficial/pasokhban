/**
 * تست صفحهٔ تنظیمات — HTML واقعیِ رندرشده توسط PHP + JS واقعی تب‌ها + CSS واقعی
 */
const fs = require('fs');
const { execFileSync } = require('child_process');
const { JSDOM } = require('jsdom');

const HTML = execFileSync((process.env.PASOKHBAN_PHP || 'php'), ['-r', `
  require_once __DIR__ . '/wp-stubs.php';
  update_option("pasokhban_options", array("api_key"=>"sk-test","model"=>"gpt-4o","widget_style"=>"brain","live_prechat"=>0,"accent"=>"#ff00aa"));
  $rp=new ReflectionProperty("Pasokhban_Settings","options"); $rp->setAccessible(true);
  $rp->setValue(Pasokhban_Settings::instance(), get_option("pasokhban_options"));
  Pasokhban_DB::install();
  ob_start(); Pasokhban_Settings::instance()->render_page(); echo ob_get_clean();
`], { encoding: 'utf8' });

const CSS = fs.readFileSync(__dirname + '/../plugin/assets/css/pasokhban-admin.css', 'utf8');
const JS  = fs.readFileSync(__dirname + '/../plugin/assets/js/pasokhban-settings.js', 'utf8');

let pass = 0, fail = 0; const fails = [];
const ok = (c, l, x) => { if (c) { pass++; console.log(`  \x1b[32m✓\x1b[0m ${l}`); } else { fail++; fails.push(l + (x ? ' — ' + x : '')); console.log(`  \x1b[31m✗\x1b[0m ${l}` + (x ? '  → ' + x : '')); } };
const eq = (a, b, l) => ok(JSON.stringify(a) === JSON.stringify(b), l, `انتظار ${JSON.stringify(b)} / دریافت ${JSON.stringify(a)}`);
const head = t => console.log(`\n\x1b[1m${t}\x1b[0m`);

console.log(`\x1b[2mHTML از PHP: ${HTML.length} بایت\x1b[0m`);

const dom = new JSDOM('<!DOCTYPE html><html dir="rtl"><head><meta charset="utf-8"></head><body>' + HTML + '</body></html>',
  { url: 'http://e.test/wp-admin/admin.php?page=pasokhban', pretendToBeVisual: true, runScripts: 'dangerously' });
const w = dom.window;
const d = w.document;

const st = d.createElement('style'); st.textContent = CSS; d.head.appendChild(st);

(async () => {
  const wait = ms => new Promise(r => setTimeout(r, ms));

  head('۱) ساختار صفحه');
  ok(!!d.querySelector('.psb-set-hero'), 'هدر شیشه‌ای رندر شد');
  ok(!!d.querySelector('#psb-set-tabs'), 'نوار تب‌ها هست');
  eq(d.querySelectorAll('.psb-set-tab').length, 10, 'ده تب ساخته شد');
  eq(d.querySelectorAll('.psb-set-panel').length, 10, 'ده پنل ساخته شد');
  ok(d.querySelectorAll('.psb-set-card').length >= 12, 'کارت‌های بخش‌بندی‌شده', String(d.querySelectorAll('.psb-set-card').length));
  ok(!!d.querySelector('.psb-set-diag'), 'جدول تشخیص هست');
  const theForm = d.getElementById('psb-set-form');
  ok(!!theForm, 'فرم تنظیمات هست');
  eq(theForm ? theForm.getAttribute('action') : null, 'options.php', 'فرم به options.php POST می‌شود (Settings API)');
  ok(!!d.querySelector('input[name="option_page"]'), 'فیلد پنهان option_page هست');
  ok(!!d.querySelector('input[name="_wpnonce"]'), 'فیلد پنهان nonce هست');

  head('۲) همهٔ ۱۱۲ فیلد در فرم هستند');
  const names = new Set();
  d.querySelectorAll('input, textarea, select').forEach(el => {
    const nm = el.getAttribute('name') || '';
    if (nm.indexOf('pasokhban_options[') === 0) {
      names.add(nm.replace('pasokhban_options[', '').replace(']', ''));
    }
  });
  eq(names.size, 112, 'تعداد فیلدهای یکتا', String(names.size));
  // ۹ فیلد تازهٔ ۱.۹.۰ (جست‌وجوی معنایی)
  const RAG_FIELDS = ['rag_vector','rag_model','rag_dims','rag_top_k','rag_min_score','rag_chunk_size','rag_chunk_overlap','rag_post_types','rag_auto_sync'];
  RAG_FIELDS.forEach(f => ok(names.has(f), 'فیلد RAG در فرم هست: ' + f));
  // ۳ فیلد تازهٔ ۲.۰.۰ (ارسال فایل)
  ['live_upload','live_upload_max','live_upload_types'].forEach(f => ok(names.has(f), 'فیلد آپلود در فرم هست: ' + f));
  // ۴ فیلد تازهٔ ۲.۱.۰ (دستیار اپراتور)
  ['copilot_enabled','copilot_tone','copilot_max_msgs','copilot_summary'].forEach(f => ok(names.has(f), 'فیلد دستیار اپراتور در فرم هست: ' + f));
  // ۲ فیلد تازهٔ ۲.۲.۰ (ووکامرس)
  ['woo_products','woo_order_lookup'].forEach(f => ok(names.has(f), 'فیلد ووکامرس در فرم هست: ' + f));
  // ۹ فیلد تازهٔ ۲.۳.۰ (تیم و ساعت کاری)
  ['team_auto_assign','team_restrict','hours_enabled','hours_ai_outside','hours_days','hours_from','hours_to','hours_offline_msg']
    .forEach(f => ok(names.has(f), 'فیلد تیم/ساعت کاری در فرم هست: ' + f));
  // ۱۴ فیلد تازهٔ ۲.۴.۰ (ایرانی‌سازی)
  ['jalali_dates','jalali_digits','sms_enabled','sms_provider','sms_api_key','sms_sender',
   'sms_admin_phone','sms_notify_admin','sms_notify_visitor','sms_min_gap',
   'brand_enabled','brand_hide_credit','brand_name','brand_url']
    .forEach(f => ok(names.has(f), 'فیلد ایرانی‌سازی در فرم هست: ' + f));
  // ۵ فیلد تازهٔ ۲.۶.۰ (کانال بله) — bale_webhook_secret عمداً UI ندارد
  ['bale_enabled','bale_token','bale_chat','bale_notify','bale_twoway']
    .forEach(f => ok(names.has(f), 'فیلد کانال بله در فرم هست: ' + f));
  // فیلد تازهٔ ۲.۹.۰ (چندسرویسی)
  ok(names.has('ai_provider'), 'فیلد انتخاب سرویس هوش مصنوعی در فرم هست');
  ok(!names.has('bale_webhook_secret'), '★ رمز webhook در فرم نیست (فقط در مسیر URL)');
  ok(!!d.querySelector('[data-tab="team"]'), 'تب «تیم و ساعت کاری» در نوار تب هست');
  ok(!!d.querySelector('[data-panel="team"]'), 'پنل «تیم و ساعت کاری» وجود دارد');
  ok(names.has('max_tokens') && names.has('temperature'), 'max_tokens و temperature که قبلاً UI نداشتند حالا دارند');

  head('۳) تب‌ها کار می‌کنند');
  const s = d.createElement('script'); s.textContent = JS; d.body.appendChild(s);
  await wait(60);

  const activePanels = () => Array.from(d.querySelectorAll('.psb-set-panel.is-active')).map(p => p.getAttribute('data-panel'));
  eq(activePanels(), ['general'], 'در ابتدا تب «عمومی» فعال است');

  d.querySelector('[data-tab="look"]').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
  await wait(30);
  eq(activePanels(), ['look'], 'با کلیک تب «ظاهر» فعال شد');
  ok(d.querySelector('[data-tab="look"]').classList.contains('is-active'), 'دکمهٔ تب هم is-active گرفت');
  eq(d.querySelector('[data-tab="look"]').getAttribute('aria-selected'), 'true', 'aria-selected تنظیم شد');

  d.querySelector('[data-tab="chat"]').dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
  await wait(30);
  eq(activePanels(), ['chat'], 'رفتن به تب «چت آنلاین»');

  // hash
  w.location.hash = 'sec';
  const dom2 = new JSDOM('<!DOCTYPE html><html><body>' + HTML + '</body></html>',
    { url: 'http://e.test/wp-admin/admin.php?page=pasokhban#sec', pretendToBeVisual: true, runScripts: 'dangerously' });
  const s2 = dom2.window.document.createElement('script');
  s2.textContent = JS; dom2.window.document.body.appendChild(s2);
  await wait(60);
  const act2 = Array.from(dom2.window.document.querySelectorAll('.psb-set-panel.is-active')).map(p => p.getAttribute('data-panel'));
  eq(act2, ['sec'], 'با hash، تب درست باز می‌شود (بعد از ذخیرهٔ فرم همان تب می‌ماند)');

  // hash ای که نام تب نیست ولی id یک کارت داخل یک تب است
  // (مسیر بازگشت از دکمه‌های RAG: #pasokhban-rag)
  const dom3 = new JSDOM('<!DOCTYPE html><html><body>' + HTML + '</body></html>',
    { url: 'http://e.test/wp-admin/admin.php?page=pasokhban#pasokhban-rag', pretendToBeVisual: true, runScripts: 'dangerously' });
  const s3 = dom3.window.document.createElement('script');
  s3.textContent = JS; dom3.window.document.body.appendChild(s3);
  await wait(60);
  const act3 = Array.from(dom3.window.document.querySelectorAll('.psb-set-panel.is-active')).map(p => p.getAttribute('data-panel'));
  eq(act3, ['assistant'], 'با hashِ یک کارت، تبِ والدش فعال می‌شود');

  // ★ رگرسیون: hash نامعتبر قبلاً هیچ پنلی را فعال نمی‌کرد و صفحهٔ تنظیمات
  //   کاملاً سفید دیده می‌شد.
  const dom4 = new JSDOM('<!DOCTYPE html><html><body>' + HTML + '</body></html>',
    { url: 'http://e.test/wp-admin/admin.php?page=pasokhban#nacho-ke-vojood-nadare', pretendToBeVisual: true, runScripts: 'dangerously' });
  const s4 = dom4.window.document.createElement('script');
  s4.textContent = JS; dom4.window.document.body.appendChild(s4);
  await wait(60);
  const act4 = Array.from(dom4.window.document.querySelectorAll('.psb-set-panel.is-active')).map(p => p.getAttribute('data-panel'));
  eq(act4, ['general'], 'با hash نامعتبر، تب اول فعال می‌شود (صفحه سفید نمی‌ماند)');

  head('۴) رادیوهای انتخاب حالت');
  const brainRadio = d.querySelector('input[value="brain"]');
  ok(!!brainRadio, 'رادیوی «مغز کیهانی» هست');
  ok(brainRadio.closest('.psb-set-pick').classList.contains('is-on'), 'کارت انتخاب‌شده is-on دارد (چون widget_style=brain)');
  const chatRadio = d.querySelector('input[value="chat"]');
  chatRadio.checked = true;
  chatRadio.dispatchEvent(new w.Event('change', { bubbles: true }));
  await wait(30);
  ok(chatRadio.closest('.psb-set-pick').classList.contains('is-on'), 'با تغییر رادیو، is-on جابه‌جا شد');
  ok(!brainRadio.closest('.psb-set-pick').classList.contains('is-on'), 'کارت قبلی is-on را از دست داد');

  head('۵) CSS واقعی اعمال می‌شود');
  const cs = el => w.getComputedStyle(el);
  eq(cs(d.querySelector('.psb-set-tabs')).position, 'sticky', 'نوار تب چسبان است');
  eq(cs(d.querySelector('.psb-set-panel')).display, 'none', 'پنل غیرفعال پنهان است');
  eq(cs(d.querySelector('.psb-set-panel.is-active')).display, 'flex', 'پنل فعال نمایش داده می‌شود');
  eq(cs(d.querySelector('.psb-set-layout')).gridTemplateColumns.split(' ').length >= 2, true, 'چیدمان دوستونی است');
  ok(cs(d.querySelector('.psb-set-switch > span')).borderRadius !== '0px', 'کلید روشن/خاموش گرد است');

  head('۶) نوار وضعیت');
  const status = d.querySelector('.psb-set-status');
  ok(!!status, 'نوار وضعیت هست');
  ok(status.classList.contains('ok'), 'با کلید API تنظیم‌شده، سبز است', status.className);

  /* ========================================================= */
head('۸) جست‌وجوی زنده');
/* ========================================================= */

const q = d.getElementById('psb-set-q');
ok(!!q, 'جعبهٔ جست‌وجو هست');

// جست‌وجو برای «تلگرام» باید کارت تلگرام را نشان دهد و بقیه را پنهان
q.value = 'تلگرام';
q.dispatchEvent(new w.Event('input', { bubbles: true }));
await wait(250);

const visible = () => Array.from(d.querySelectorAll('.psb-set-card')).filter(c => !c.classList.contains('is-hidden'));
const vis = visible();
ok(vis.length > 0, 'کارت‌های مطابق نمایش داده می‌شوند', String(vis.length));
ok(vis.every(c => (c.textContent || '').toLowerCase().includes('تلگرام') ||
                  Array.from(c.querySelectorAll('input,select,textarea')).some(el =>
                    String(el.value || '').includes('تلگرام') ||
                    (el.getAttribute('name') || '').includes('telegram'))),
   '★ فقط کارت‌های دارای تطبیق دیده می‌شوند');

const matched = d.querySelectorAll('.psb-set-card.is-match');
ok(matched.length > 0, 'کارت‌های مطابق علامت is-match گرفتند');
ok(d.querySelectorAll('mark.psb-q').length > 0, '★ تطبیق‌ها در متن برجسته شدند');
ok(d.querySelectorAll('.psb-set-tab.has-hit').length > 0, '★ تب‌های دارای نتیجه نقطهٔ آبی گرفتند');

// اگر تب فعال نتیجه نداشت، خودکار به تب دارای نتیجه می‌رود
const activeP = Array.from(d.querySelectorAll('.psb-set-panel.is-active')).map(x => x.getAttribute('data-panel'));
ok(activeP.length === 1, 'دقیقاً یک تب فعال است');
ok(!d.querySelector('.psb-set-panel.is-active').classList.contains('is-empty'),
   '★ تب فعال خالی نیست (خودکار جابه‌جا شد)');

// پاک‌کردن جست‌وجو
q.value = '';
q.dispatchEvent(new w.Event('input', { bubbles: true }));
await wait(250);
eq(visible().length, d.querySelectorAll('.psb-set-card').length, 'با پاک‌کردن جست‌وجو همهٔ کارت‌ها برمی‌گردند');
eq(d.querySelectorAll('mark.psb-q').length, 0, 'برجستگی‌ها پاک شدند');
eq(d.querySelectorAll('.psb-set-tab.has-hit').length, 0, 'نقطه‌های آبی پاک شدند');

// جست‌وجوی بی‌نتیجه
q.value = 'zzzz-چنین-چیزی-نیست';
q.dispatchEvent(new w.Event('input', { bubbles: true }));
await wait(250);
eq(visible().length, 0, 'با جست‌وجوی بی‌نتیجه هیچ کارتی نمی‌ماند');
const qc = d.getElementById('psb-set-qcount');
ok(qc && qc.classList.contains('is-zero'), 'شمارنده صفر قرمز می‌شود');
q.value = '';
q.dispatchEvent(new w.Event('input', { bubbles: true }));
await wait(250);

/* ========================================================= */
head('۹) کارت جمع‌شونده');
/* ========================================================= */

const someCard = d.querySelector('.psb-set-panel .psb-set-card h2');
ok(!!someCard, 'کارتی برای آزمون پیدا شد');
const foldBtn = someCard.querySelector('.psb-set-fold');
ok(!!foldBtn, 'دکمهٔ جمع/باز به عنوان کارت اضافه شد');

const card = someCard.parentNode;
ok(!card.classList.contains('is-folded'), 'در ابتدا باز است');
foldBtn.dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
await wait(50);
ok(card.classList.contains('is-folded'), '★ با کلیک، کارت جمع شد');
eq(foldBtn.getAttribute('aria-expanded'), 'false', 'aria-expanded درست تنظیم شد');
ok(CSS.indexOf('.is-folded') > -1, 'CSS کارت جمع‌شده وجود دارد');

// وضعیت در localStorage ذخیره می‌شود
const saved = w.localStorage.getItem('pasokhban_collapsed');
ok(!!saved && saved.includes(card.id), '★ وضعیت جمع‌شدن در localStorage ماند');

foldBtn.dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
await wait(50);
ok(!card.classList.contains('is-folded'), 'با کلیک دوم باز شد');

/* ========================================================= */
head('۱۰) نوار ذخیرهٔ چسبان');
/* ========================================================= */

const bar = d.getElementById('psb-set-savebar');
ok(!!bar, 'نوار ذخیره هست');
ok(CSS.indexOf('.psb-set-savebar') > -1 && CSS.indexOf('position: sticky') > -1, 'نوار چسبان است');

// «در ابتدا تمیز است» باید روی DOM تازه سنجیده شود — تست‌های قبلیِ همین
// فایل فیلدها را تغییر داده‌اند، پس این DOM دیگر تمیز نیست.
const domClean = new JSDOM('<!DOCTYPE html><html><body>' + HTML + '</body></html>',
  { url: 'http://e.test/wp-admin/admin.php?page=pasokhban', pretendToBeVisual: true, runScripts: 'dangerously' });
const sc = domClean.window.document.createElement('script');
sc.textContent = JS; domClean.window.document.body.appendChild(sc);
await wait(80);
const barClean = domClean.window.document.getElementById('psb-set-savebar');
ok(barClean && !barClean.classList.contains('is-dirty'), '★ در ابتدا «همه‌چیز ذخیره شده» است');

// با تغییر یک فیلد، کثیف می‌شود
const anyInput = d.querySelector('#psb-set-form input[type=text], #psb-set-form input[type=password]');
if (anyInput) {
  anyInput.value = 'تغییر آزمایشی';
  anyInput.dispatchEvent(new w.Event('input', { bubbles: true }));
  await wait(50);
  ok(bar.classList.contains('is-dirty'), '★ با تغییر فیلد، نوار «ذخیره‌نشده» می‌شود');
  ok(d.body.classList.contains('psb-dirty'), 'کلاس هشدار به body اضافه شد');
}

/* ========================================================= */
head('۱۱) لینک مستقیم به کارت');
/* ========================================================= */

const dom5 = new JSDOM('<!DOCTYPE html><html><body>' + HTML + '</body></html>',
  { url: 'http://e.test/wp-admin/admin.php?page=pasokhban#pasokhban-rag', pretendToBeVisual: true, runScripts: 'dangerously' });
const s5 = dom5.window.document.createElement('script');
s5.textContent = JS; dom5.window.document.body.appendChild(s5);
await wait(120);
const act5 = Array.from(dom5.window.document.querySelectorAll('.psb-set-panel.is-active')).map(x => x.getAttribute('data-panel'));
eq(act5, ['assistant'], '★ با #pasokhban-rag تب «دستیار و دانش» باز می‌شود');
const ragCard = dom5.window.document.getElementById('pasokhban-rag');
ok(ragCard && !ragCard.classList.contains('is-folded'), 'کارت مقصد باز است');

console.log('\n' + '─'.repeat(52));
  if (fail === 0) console.log(`\x1b[42;30m همهٔ ${pass} تست صفحهٔ تنظیمات پاس شد \x1b[0m`);
  else { console.log(`\x1b[41;97m ${fail} تست شکست خورد \x1b[0m (پاس: ${pass})`); fails.forEach(f => console.log('   • ' + f)); }
  console.log('─'.repeat(52));
  process.exit(fail === 0 ? 0 : 1);
})();
