<?php
/**
 * تست‌های ۲.۶.۰ — کانال بله.
 *
 * تمرکز اصلی روی امنیت webhook است: آن endpoint عمومی است (بله باید
 * بتواند صدا بزند)، پس اگر رمز یا نگاشت درست کار نکند، هر کسی می‌تواند
 * به نام اپراتور در چت سایت پیام بگذارد.
 */

require_once __DIR__ . '/wp-stubs.php';

$PASS = 0; $FAIL = 0; $FAILURES = array();

function ok( $cond, $label, $extra = '' ) {
	global $PASS, $FAIL, $FAILURES;
	if ( $cond ) { $PASS++; echo "  \033[32m✓\033[0m {$label}\n"; }
	else { $FAIL++; $FAILURES[] = $label . ( $extra ? " — {$extra}" : '' ); echo "  \033[31m✗\033[0m {$label}" . ( $extra ? "  → {$extra}" : '' ) . "\n"; }
}
function head( $t ) { echo "\n\033[1m{$t}\033[0m\n"; }
function eq( $a, $b, $label ) { ok( $a === $b, $label, 'انتظار ' . var_export( $b, true ) . ' / دریافت ' . var_export( $a, true ) ); }

$BASE = array(
	'api_key' => 'sk', 'live_enabled' => 1, 'live_human_enabled' => 1,
	'rate_limit' => 0, 'live_history' => 20,
	'bale_enabled' => 1, 'bale_token' => '123456:TOKEN', 'bale_chat' => '-100999',
	'bale_notify' => 1, 'bale_twoway' => 1, 'bale_webhook_secret' => 'SECRET123',
);
function set_opts( array $over = array() ) {
	global $BASE;
	$o = array_merge( $BASE, $over );
	update_option( 'pasokhban_options', $o );
	$rp = new ReflectionProperty( 'Pasokhban_Settings', 'options' );
	$rp->setAccessible( true );
	$rp->setValue( Pasokhban_Settings::instance(), $o );
	return $o;
}
set_opts();
Pasokhban_DB::install();

$B  = 'Pasokhban_Bale';
$lc = Pasokhban_LiveChat::instance();

/** پاسخ ساختگی بله. */
function bale_ok( $message_id = 777 ) {
	$GLOBALS['wp_remote_response'] = array(
		'response' => array( 'code' => 200 ),
		'body'     => json_encode( array( 'ok' => true, 'result' => array( 'message_id' => $message_id ) ) ),
	);
	$GLOBALS['wp_remote_log'] = array();
}

/* ========================================================= */
head( '۱) تنظیمات' );
/* ========================================================= */

$d = Pasokhban_Settings::instance()->defaults();
eq( $d['bale_enabled'], 0, '★ کانال بله پیش‌فرض خاموش است' );
eq( $d['bale_twoway'], 0, '★ پاسخ دوطرفه پیش‌فرض خاموش است (نیاز به webhook دارد)' );
eq( $d['bale_notify'], 1, 'اعلان یک‌طرفه پیش‌فرض روشن' );

$s = Pasokhban_Settings::instance();
$out = $s->sanitize( array( 'bale_webhook_secret' => '' ) );
ok( '' !== $out['bale_webhook_secret'], '★ رمز webhook خالی بود → خودکار ساخته شد' );
eq( strlen( $out['bale_webhook_secret'] ), 32, 'طول رمز ۳۲ کاراکتر' );
ok( (bool) preg_match( '/^[a-zA-Z0-9]{32}$/', $out['bale_webhook_secret'] ), 'فقط کاراکتر امن (برای گذاشتن در مسیر URL)' );

$out = $s->sanitize( array( 'bale_webhook_secret' => 'abc/../etc<script>' ) );
eq( $out['bale_webhook_secret'], 'abcetcscript', '★ کاراکترهای مسیرشکن از رمز پاک شد' );

// شناسهٔ گفتگوی بله یا عدد است یا @username، پس رقم/حرف/@/_/- مجازند.
// کاراکترهای خطرناک (فاصله، <، >، نقل‌قول، اسلش) حذف می‌شوند.
$out = $s->sanitize( array( 'bale_chat' => '-100999 <script>' ) );
eq( $out['bale_chat'], '-100999script', '★ کاراکترهای خطرناک حذف شدند (حروف برای username مجازند)' );
$out = $s->sanitize( array( 'bale_chat' => '@etehad_support' ) );
eq( $out['bale_chat'], '@etehad_support', 'username با @ سالم می‌ماند' );
$out = $s->sanitize( array( 'bale_chat' => '-100999" onload="x' ) );
eq( $out['bale_chat'], '-100999onloadx', '★ نقل‌قول و = حذف شدند (تزریق صفت ممکن نیست)' );
$out = $s->sanitize( array( 'bale_chat' => '../../etc/passwd' ) );
eq( $out['bale_chat'], 'etcpasswd', '★ اسلش حذف شد (پیمایش مسیر ممکن نیست)' );
$out = $s->sanitize( array( 'bale_token' => str_repeat( 'x', 500 ) ) );
ok( strlen( $out['bale_token'] ) <= 200, 'توکن به ۲۰۰ کاراکتر محدود شد' );

eq( $B::enabled(), true, 'با توکن، فعال است' );
set_opts( array( 'bale_enabled' => 0 ) );
eq( $B::enabled(), false, 'با قابلیت خاموش، فعال نیست' );
set_opts( array( 'bale_token' => '' ) );
eq( $B::enabled(), false, '★ بدون توکن، فعال نیست' );
set_opts();

/* ========================================================= */
head( '۲) ارسال به بله' );
/* ========================================================= */

bale_ok( 777 );
$mid = $B::send( '-100999', 'سلام' );
eq( $mid, 777, 'شناسهٔ پیام برگشت' );
ok( ! empty( $GLOBALS['wp_remote_log'] ), 'درخواست زده شد' );
$url = end( $GLOBALS['wp_remote_log'] )['url'];
ok( false !== strpos( $url, 'https://tapi.bale.ai/bot' ), '★ به دامنهٔ رسمی بله رفت', $url );
ok( false !== strpos( $url, '/sendMessage' ), 'متد sendMessage' );
ok( false !== strpos( $url, '123456%3ATOKEN' ) || false !== strpos( $url, '123456:TOKEN' ), 'توکن در آدرس encode شد' );

// پاسخ ناموفق
$GLOBALS['wp_remote_response'] = array(
	'response' => array( 'code' => 400 ),
	'body'     => json_encode( array( 'ok' => false, 'description' => 'chat not found' ) ),
);
eq( $B::send( '-100999', 'سلام' ), false, 'خطای بله false برمی‌گرداند' );
eq( $B::$last_error, 'chat not found', '★ متن خطای بله نگه داشته می‌شود' );

// پاسخ غیر JSON
$GLOBALS['wp_remote_response'] = array( 'response' => array( 'code' => 502 ), 'body' => '<html>bad gateway</html>' );
eq( $B::send( '-100999', 'سلام' ), false, 'پاسخ غیر JSON مدیریت می‌شود' );
ok( false !== strpos( $B::$last_error, 'JSON نبود' ), 'پیام خطا روشن است', $B::$last_error );

// خطای شبکه
$GLOBALS['wp_remote_response'] = new WP_Error( 'http', 'timeout' );
eq( $B::send( '-100999', 'سلام' ), false, 'خطای شبکه مدیریت می‌شود' );
eq( $B::$last_error, 'timeout', 'پیام خطای شبکه' );

// متن خالی
bale_ok();
eq( $B::send( '-100999', '   ' ), false, 'متن خالی ارسال نمی‌شود' );

$GLOBALS['wp_remote_response'] = null;

/* ========================================================= */
head( '۳) نگاشت پیام بله → مکالمهٔ سایت' );
/* ========================================================= */

eq( Pasokhban_DB::bale_session_for( 99999 ), 0, 'نگاشت ناشناخته → ۰' );
eq( Pasokhban_DB::bale_session_for( 0 ), 0, 'شناسهٔ صفر → ۰' );
eq( Pasokhban_DB::bale_link( 0, 5 ), false, 'شناسهٔ پیام صفر رد می‌شود' );
eq( Pasokhban_DB::bale_link( 5, 0 ), false, 'مکالمهٔ صفر رد می‌شود' );

ok( Pasokhban_DB::bale_link( 5001, 42 ), 'نگاشت ثبت شد' );
eq( Pasokhban_DB::bale_session_for( 5001 ), 42, 'نگاشت خوانده شد' );
Pasokhban_DB::bale_link( 5001, 43 );
eq( Pasokhban_DB::bale_session_for( 5001 ), 43, '★ نگاشت دوباره → به مکالمهٔ تازه منتقل شد (تکراری ساخته نشد)' );
$cnt = (int) $GLOBALS['wpdb']->get_var( 'SELECT COUNT(*) FROM wp_pasokhban_bale_links WHERE bale_message_id = 5001' );
eq( $cnt, 1, 'فقط یک ردیف برای هر پیام بله' );

/* ========================================================= */
head( '۴) اعلان‌ها' );
/* ========================================================= */

$start = $lc->handle_start( new WP_REST_Request( array(), array( 'lang' => 'fa', 'name' => 'سارا', 'family' => 'رضایی', 'phone' => '09121234567' ) ) );
$KEY   = $start['key'];
$sess  = Pasokhban_DB::get_session_by_key( $KEY );
$SID   = (int) $sess->id;

bale_ok( 8001 );
$msg = (object) array( 'content' => 'سلام، سفارشم کجاست؟' );

// در حالت AI اعلان نمی‌رود
eq( $B::on_visitor_message( $sess, $msg ), false, '★ در حالت AI اعلان نمی‌رود (وگرنه برای هر پیام به گروه می‌رفت)' );
eq( count( $GLOBALS['wp_remote_log'] ), 0, 'هیچ درخواستی زده نشد' );

// در حالت اپراتور اعلان می‌رود
Pasokhban_DB::update_session( $SID, array( 'mode' => 'agent' ) );
$sess = Pasokhban_DB::get_session( $SID );
bale_ok( 8001 );
eq( $B::on_visitor_message( $sess, $msg ), true, 'در حالت اپراتور اعلان رفت' );
eq( Pasokhban_DB::bale_session_for( 8001 ), $SID, '★ نگاشت پیام→مکالمه ثبت شد' );
$sent = json_decode( end( $GLOBALS['wp_remote_log'] )['body'], true );
ok( false !== strpos( $sent['text'], 'سارا' ), 'نام بازدیدکننده در پیام' );
ok( false !== strpos( $sent['text'], 'reply' ), '★ راهنمای «reply بزن» در پیام هست' );
ok( false !== strpos( $sent['text'], '09121234567' ), 'شمارهٔ تماس در پیام' );

// handoff
bale_ok( 8002 );
eq( $B::on_handoff( $sess ), true, 'اعلان handoff رفت' );
eq( Pasokhban_DB::bale_session_for( 8002 ), $SID, 'نگاشت handoff ثبت شد' );

// با قابلیت خاموش
set_opts( array( 'bale_notify' => 0 ) );
bale_ok( 8003 );
eq( $B::on_visitor_message( $sess, $msg ), false, 'با اعلان خاموش، چیزی نمی‌رود' );
eq( $B::on_handoff( $sess ), false, 'با اعلان خاموش، handoff هم نمی‌رود' );
set_opts();

/* ========================================================= */
head( '۵) webhook — امنیت' );
/* ========================================================= */

Pasokhban_Bale::register_routes();
ok( isset( $GLOBALS['wp_rest_routes']['pasokhban/v1/bale/webhook/(?P<secret>[a-zA-Z0-9]+)'] ), 'مسیر webhook ثبت شد' );
eq( $GLOBALS['wp_rest_routes']['pasokhban/v1/bale/webhook/(?P<secret>[a-zA-Z0-9]+)']['permission_callback'], '__return_true', 'webhook عمومی است (احراز هویت با رمز در مسیر)' );

function wh_req( $secret, $body ) {
	$r = new WP_REST_Request( array( 'secret' => $secret ) );
	$r->set_body( json_encode( $body ) );
	return $r;
}

// ★ رمز اشتباه
$res = $B::handle_webhook( wh_req( 'WRONG', array( 'message' => array( 'text' => 'هک' ) ) ) );
eq( $res['ok'], false, '★ رمز اشتباه رد شد' );
eq( $res['error'], 'forbidden', 'خطای forbidden' );

// ★ رمز خالی در تنظیمات = هیچ‌وقت نپذیر
set_opts( array( 'bale_webhook_secret' => '' ) );
$res = $B::handle_webhook( wh_req( '', array( 'message' => array( 'text' => 'هک' ) ) ) );
eq( $res['error'], 'forbidden', '★ با رمز خالی در تنظیمات، حتی درخواست با رمز خالی رد می‌شود' );
set_opts();

// دوطرفه خاموش
set_opts( array( 'bale_twoway' => 0 ) );
$res = $B::handle_webhook( wh_req( 'SECRET123', array( 'message' => array( 'text' => 'سلام' ) ) ) );
eq( $res['error'], 'disabled', '★ با دوطرفه خاموش، پاسخ ثبت نمی‌شود' );
set_opts();

// ساختار نامعتبر
$res = $B::handle_webhook( wh_req( 'SECRET123', array( 'foo' => 'bar' ) ) );
eq( $res['ignored'], 'not-a-message', 'آپدیت بدون message نادیده گرفته می‌شود' );

// آرایهٔ خالی در PHP «empty» است، پس not-a-message برمی‌گردد — که درست است.
$res = $B::handle_webhook( wh_req( 'SECRET123', array( 'message' => array() ) ) );
eq( $res['ignored'], 'not-a-message', 'آرایهٔ message خالی → not-a-message' );

// پیام واقعی ولی بدون فیلد متن (مثلاً فقط استیکر)
$res = $B::handle_webhook( wh_req( 'SECRET123', array( 'message' => array( 'message_id' => 5, 'sticker' => array( 'file_id' => 'x' ) ) ) ) );
eq( $res['ignored'], 'no-text', '★ پیام بدون متن (استیکر/عکس) نادیده گرفته می‌شود' );

// ★ بدون reply target
$res = $B::handle_webhook( wh_req( 'SECRET123', array(
	'message' => array( 'message_id' => 9001, 'text' => 'پیام بی‌ربط در گروه' ),
) ) );
eq( $res['ignored'], 'no-reply-target', '★ پیام بدون reply نادیده گرفته می‌شود (نه تزریق به مکالمهٔ تصادفی)' );
$cnt = (int) $GLOBALS['wpdb']->get_var( "SELECT COUNT(*) FROM wp_pasokhban_messages WHERE sender='agent' AND content='پیام بی‌ربط در گروه'" );
eq( $cnt, 0, '★ پیام بدون reply در دیتابیس ثبت نشد' );

// ★ reply به پیام ناشناس
$res = $B::handle_webhook( wh_req( 'SECRET123', array(
	'message' => array(
		'message_id'       => 9002,
		'text'             => 'پاسخ به پیام ناشناس',
		'reply_to_message' => array( 'message_id' => 999999 ),
	),
) ) );
eq( $res['ignored'], 'unknown-target', '★ reply به پیام ناشناس نادیده گرفته می‌شود' );

/* ========================================================= */
head( '۶) webhook — مسیر موفق' );
/* ========================================================= */

// مکالمهٔ دوم، در حالت AI، با پیام خوانده‌نشده
$s2    = $lc->handle_start( new WP_REST_Request( array(), array( 'lang' => 'fa', 'name' => 'علی' ) ) );
$sess2 = Pasokhban_DB::get_session_by_key( $s2['key'] );
$SID2  = (int) $sess2->id;
Pasokhban_DB::update_session( $SID2, array( 'mode' => 'ai', 'unread_visitor' => 3 ) );
Pasokhban_DB::bale_link( 8500, $SID2 );

$res = $B::handle_webhook( wh_req( 'SECRET123', array(
	'message' => array(
		'message_id'       => 9100,
		'text'             => 'سلام علی جان، سفارشت فردا می‌رسه.',
		'from'             => array( 'first_name' => 'پشتیبان' ),
		'reply_to_message' => array( 'message_id' => 8500 ),
	),
) ) );
eq( $res['ok'], true, 'webhook موفق بود' );
eq( $res['delivered'], true, 'پاسخ تحویل داده شد' );
eq( $res['session'], $SID2, '★ به مکالمهٔ درست رفت' );

$after = Pasokhban_DB::get_session( $SID2 );
eq( $after->mode, 'agent', '★ حالت مکالمه به اپراتور رفت' );
eq( (int) $after->unread_visitor, 4, '★ شمار خوانده‌نشدهٔ بازدیدکننده زیاد شد' );
eq( (int) $after->unread_agent, 0, 'شمار خوانده‌نشدهٔ اپراتور صفر شد' );

$msgs = Pasokhban_DB::get_messages( $SID2 );
$last = end( $msgs );
eq( $last->sender, 'agent', 'پیام به‌عنوان اپراتور ثبت شد' );
eq( $last->content, 'سلام علی جان، سفارشت فردا می‌رسه.', 'متن درست ذخیره شد' );
eq( $last->meta['via'], 'bale', '★ منبع پیام «bale» ثبت شد' );
eq( $last->meta['bale_from'], 'پشتیبان', 'نام فرستندهٔ بله ثبت شد' );
eq( $last->meta['bale_mid'], 9100, 'شناسهٔ پیام بله ثبت شد' );

// متن خیلی بلند کوتاه می‌شود
Pasokhban_DB::bale_link( 8501, $SID2 );
$long = str_repeat( 'ا', 6000 );
$B::handle_webhook( wh_req( 'SECRET123', array(
	'message' => array(
		'message_id' => 9101, 'text' => $long,
		'reply_to_message' => array( 'message_id' => 8501 ),
	),
) ) );
$msgs = Pasokhban_DB::get_messages( $SID2 );
$last = end( $msgs );
ok( mb_strlen( $last->content ) <= 4000, 'متن بلند به ۴۰۰۰ کاراکتر محدود شد', mb_strlen( $last->content ) );

// مکالمهٔ حذف‌شده
Pasokhban_DB::bale_link( 8502, 999999 );
$res = $B::handle_webhook( wh_req( 'SECRET123', array(
	'message' => array(
		'message_id' => 9102, 'text' => 'به مکالمهٔ حذف‌شده',
		'reply_to_message' => array( 'message_id' => 8502 ),
	),
) ) );
eq( $res['ignored'], 'no-session', '★ reply به مکالمهٔ حذف‌شده خطا نمی‌دهد' );

/* ========================================================= */
head( '۷) webhook URL و پورت' );
/* ========================================================= */

eq( $B::webhook_url(), rest_url( 'pasokhban/v1/bale/webhook/SECRET123' ), 'آدرس webhook با رمز در مسیر' );
set_opts( array( 'bale_webhook_secret' => '' ) );
eq( $B::webhook_url(), '', '★ بدون رمز، آدرس خالی است (endpoint بی‌رمز ساخته نمی‌شود)' );
set_opts();

/* ========================================================= */
head( '۸) صفحهٔ تنظیمات' );
/* ========================================================= */

ob_start();
Pasokhban_Settings::instance()->render_page();
$h = ob_get_clean();

$fields = array( 'bale_enabled', 'bale_token', 'bale_chat', 'bale_notify', 'bale_twoway' );
$missing = array();
foreach ( $fields as $f ) {
	if ( false === strpos( $h, 'pasokhban_options[' . $f . ']' ) ) { $missing[] = $f; }
}
eq( $missing, array(), 'همهٔ فیلدهای بله در فرم هست' );

// ★ رمز webhook نباید به‌عنوان فیلد قابل ویرایش لو برود
ok( false === strpos( $h, 'pasokhban_options[bale_webhook_secret]' ), '★ رمز webhook در فرم نیست (فقط در مسیر URL)' );

// کارت بله در پنل اعلان‌ها
$cur = '?'; $map = array();
preg_match_all( '/data-panel="([a-z]+)"|<h2>(.*?)<\/h2>/u', $h, $m, PREG_SET_ORDER );
foreach ( $m as $x ) {
	if ( ! empty( $x[1] ) ) { $cur = $x[1]; }
	else { $map[ trim( $x[2] ) ] = $cur; }
}
$bale_panel = null;
foreach ( $map as $t => $p ) {
	if ( false !== strpos( $t, 'بله' ) ) { $bale_panel = $p; }
}
eq( $bale_panel, 'notify', '★ کارت بله در تب «اعلان‌ها» است (نه جای دیگر)' );

// توازن مارکاپ
$nc = preg_replace( '/<!--.*?-->/s', '', $h );
eq( substr_count( $nc, '<section' ), substr_count( $nc, '</section>' ), '<section> balanced است' );
eq( preg_match_all( '/<form\b/', $nc ), preg_match_all( '/<\/form>/', $nc ), '<form> balanced است' );

foreach ( array( 'psb-bale-set-form', 'psb-bale-info-form', 'psb-bale-del-form', 'psb-bale-test-form' ) as $fid ) {
	ok( false !== strpos( $h, 'id="' . $fid . '"' ), 'فرم ' . $fid . ' هست' );
}

// کلیدهای defaults همه UI دارند (رگرسیون تست قبلی)
preg_match_all( '/pasokhban_options\[([a-z0-9_]+)\]/u', $h, $mm );
$c = array_count_values( $mm[1] );
$defaults = Pasokhban_Settings::instance()->defaults();
$no_ui = array();
foreach ( $defaults as $k => $v ) {
	// bale_webhook_secret عمداً UI ندارد
	if ( 'bale_webhook_secret' === $k ) { continue; }
	if ( ! isset( $c[ $k ] ) ) { $no_ui[] = $k; }
}
eq( $no_ui, array(), 'همهٔ کلیدهای defaults (جز رمز webhook) UI دارند', implode( ', ', $no_ui ) );

/* ========================================================= */
head( '۹) ساختار دیتابیس' );
/* ========================================================= */

ok( version_compare( Pasokhban_DB::SCHEMA_VERSION, '1.7.0', '>=' ), 'نسخهٔ ساختار حداقل ۱.۷.۰ است', Pasokhban_DB::SCHEMA_VERSION );
ok( (bool) $GLOBALS['wpdb']->get_var( "SELECT name FROM sqlite_master WHERE type='table' AND name='wp_pasokhban_bale_links'" ), 'جدول نگاشت بله ساخته شد' );
$un = file_get_contents( PASOKHBAN_PATH . 'uninstall.php' );
ok( false !== strpos( $un, 'bale' ), 'uninstall منابع بله را پاک می‌کند' );

echo "\n" . str_repeat( '─', 52 ) . "\n";
if ( 0 === $FAIL ) {
	echo "\033[42;30m همهٔ {$PASS} تست کانال بله پاس شد \033[0m\n";
} else {
	echo "\033[41;97m {$FAIL} تست شکست خورد \033[0m (پاس: {$PASS})\n";
	foreach ( $FAILURES as $f ) { echo "   • {$f}\n"; }
}
echo str_repeat( '─', 52 ) . "\n";
exit( 0 === $FAIL ? 0 : 1 );
