<?php
/**
 * هارنس تست — شبیه‌سازی حداقلی وردپرس روی SQLite
 * تا کد واقعی پلاگین (نه یک نسخهٔ بازنویسی‌شده) اجرا شود.
 */

error_reporting( E_ALL );
ini_set( 'display_errors', '1' );

// مسیرها نسبی به مکان همین فایل‌اند تا مخزن هر جا clone شود کار کند.
// ساختار انتظار: <repo>/tests/wp-stubs.php و <repo>/plugin/pasokhban.php
if ( ! defined( 'PASOKHBAN_TESTS_DIR' ) ) {
	define( 'PASOKHBAN_TESTS_DIR', __DIR__ );
}
if ( ! defined( 'PASOKHBAN_PLUGIN_DIR' ) ) {
	define( 'PASOKHBAN_PLUGIN_DIR', getenv( 'PASOKHBAN_PLUGIN_DIR' )
		? rtrim( getenv( 'PASOKHBAN_PLUGIN_DIR' ), '/' )
		: dirname( __DIR__ ) . '/plugin' );
}

define( 'ABSPATH', PASOKHBAN_TESTS_DIR . '/fakewp/' );
define( 'MINUTE_IN_SECONDS', 60 );
define( 'HOUR_IN_SECONDS', 3600 );
define( 'DAY_IN_SECONDS', 86400 );
define( 'PASOKHBAN_VERSION', '1.1.0' );
define( 'PASOKHBAN_FILE', PASOKHBAN_PLUGIN_DIR . '/pasokhban.php' );
define( 'PASOKHBAN_PATH', PASOKHBAN_PLUGIN_DIR . '/' );
define( 'PASOKHBAN_URL', 'http://example.test/wp-content/plugins/pasokhban/' );

@mkdir( ABSPATH . 'wp-admin/includes', 0777, true );

/* =========================================================
 * ذخیره‌سازی گزینه‌ها و transient
 * =======================================================*/
$GLOBALS['wp_options']    = array();
$GLOBALS['wp_transients'] = array();
$GLOBALS['wp_actions']    = array();
$GLOBALS['wp_rest_routes'] = array();
$GLOBALS['wp_current_user_can'] = true;
$GLOBALS['wp_remote_response']  = null;   // پاسخ ساختگی wp_remote_post
$GLOBALS['wp_remote_calls']     = array();

function get_option( $k, $default = false ) {
	return array_key_exists( $k, $GLOBALS['wp_options'] ) ? $GLOBALS['wp_options'][ $k ] : $default;
}
function update_option( $k, $v ) { $GLOBALS['wp_options'][ $k ] = $v; return true; }
function delete_option( $k ) { unset( $GLOBALS['wp_options'][ $k ] ); return true; }

function get_transient( $k ) {
	if ( ! isset( $GLOBALS['wp_transients'][ $k ] ) ) return false;
	list( $v, $exp ) = $GLOBALS['wp_transients'][ $k ];
	if ( $exp && $exp < time() ) { unset( $GLOBALS['wp_transients'][ $k ] ); return false; }
	return $v;
}
function set_transient( $k, $v, $ttl = 0 ) {
	$GLOBALS['wp_transients'][ $k ] = array( $v, $ttl ? time() + $ttl : 0 );
	return true;
}
function delete_transient( $k ) { unset( $GLOBALS['wp_transients'][ $k ] ); return true; }

/* =========================================================
 * هوک‌ها و REST
 * =======================================================*/
function add_action( $h, $cb, $p = 10, $a = 1 ) { $GLOBALS['wp_actions'][ $h ][] = $cb; return true; }
function add_filter( $h, $cb, $p = 10, $a = 1 ) { return add_action( $h, $cb, $p, $a ); }
function do_action( $h ) { $GLOBALS['wp_actions']['fired'][] = $h; }
function apply_filters( $h, $v, ...$args ) {
	// قبلاً همیشه مقدار را دست‌نخورده برمی‌گرداند؛ حالا callbackهای
	// ثبت‌شده را هم اجرا می‌کند تا رفتار واقعی وردپرس شبیه‌سازی شود.
	if ( empty( $GLOBALS['wp_actions'][ $h ] ) ) { return $v; }
	foreach ( (array) $GLOBALS['wp_actions'][ $h ] as $cb ) {
		if ( is_callable( $cb ) ) { $v = call_user_func( $cb, $v, ...$args ); }
	}
	return $v;
}
function register_activation_hook( $f, $cb ) { return true; }
function register_rest_route( $ns, $route, $args ) { $GLOBALS['wp_rest_routes'][ $ns . $route ] = $args; return true; }
class Pasokhban_Test_RestServer {
	public function get_routes() {
		$out = array();
		foreach ( array_keys( $GLOBALS['wp_rest_routes'] ) as $k ) { $out[ '/' . $k ] = array(); }
		return $out;
	}
}
function rest_get_server() { return new Pasokhban_Test_RestServer(); }
function add_shortcode( $t, $cb ) { return true; }
function rest_url( $p = '' ) { return 'http://example.test/wp-json/' . $p; }
function rest_ensure_response( $d ) { return $d; }
function admin_url( $p = '' ) { return 'http://example.test/wp-admin/' . $p; }
function esc_url( $u ) { return filter_var( (string) $u, FILTER_SANITIZE_URL ); }
function nocache_headers() { /* no-op در تست */ }
$GLOBALS['wp_cron'] = array();
function wp_next_scheduled( $hook ) { return isset( $GLOBALS['wp_cron'][ $hook ] ) ? $GLOBALS['wp_cron'][ $hook ] : false; }
function wp_schedule_event( $ts, $recurrence, $hook ) { $GLOBALS['wp_cron'][ $hook ] = $recurrence; return true; }
function wp_unschedule_event( $ts, $hook ) { unset( $GLOBALS['wp_cron'][ $hook ] ); return true; }
function wp_parse_url( $url, $component = -1 ) {
	$url = (string) $url;
	if ( '' === trim( $url ) ) { return false; }
	// وردپرس پیش از parse_url کاراکترهای کنترل را پاک می‌کند
	$url = preg_replace( '/[\x00-\x1F\x7F]/', '', $url );
	// parse_url با ثابت جزئی، فقط همان جزء را برمی‌گرداند (مثل وردپرس واقعی)
	return @parse_url( $url, $component );
}
function untrailingslashit( $s ) { return rtrim( (string) $s, '/\\' ); }
function wp_mail( $to, $subject, $message, $headers = '', $attachments = array() ) {
	$GLOBALS['wp_mails'][] = compact( 'to', 'subject', 'message', 'headers' );
	return true;
}
function home_url( $p = '' ) {
	// تست‌ها می‌توانند آدرس سایت را عوض کنند تا مثلاً بررسی «پورت بله»
	// با https://site.com:8443 سنجیده شود.
	$base = isset( $GLOBALS['wp_home_url'] ) ? $GLOBALS['wp_home_url'] : 'http://example.test';
	return rtrim( $base, '/' ) . $p;
}
function rawurlencode_helper( $s ) { return rawurlencode( $s ); }
function wp_kses_post( $d ) { return $d; }
function checked_helper() { return ''; }
function wp_nonce_url( $u, $a = -1, $n = '_wpnonce' ) { return $u . ( strpos( $u, '?' ) === false ? '?' : '&' ) . $n . '=nonce'; }
function wp_nonce_field( $a = -1, $n = '_wpnonce', $r = true, $e = true ) { $h = '<input type="hidden" name="' . $n . '" value="nonce" />'; if ( $e ) echo $h; return $h; }
function check_admin_referer( $a = -1, $q = '_wpnonce' ) { return true; }
function wp_safe_redirect( $u, $s = 302 ) { $GLOBALS['wp_redirect'] = $u; return true; }
function add_query_arg( ...$a ) {
	// شکل‌های واقعی وردپرس: (k, v, url) | (array, url) | (array)
	if ( 3 === count( $a ) ) {
		return _qs_add( array( $a[0] => $a[1] ), $a[2] );
	}
	if ( 2 === count( $a ) && is_array( $a[0] ) ) {
		return _qs_add( $a[0], (string) $a[1] );
	}
	if ( 1 === count( $a ) && is_array( $a[0] ) ) {
		return _qs_add( $a[0], 'http://example.test/' );
	}
	return is_string( $a[0] ) ? $a[0] : 'http://example.test/';
}
function _qs_add( $pairs, $url ) {
	$sep = ( false === strpos( $url, '?' ) ) ? '?' : '&';
	$qs  = array();
	foreach ( $pairs as $k => $v ) { $qs[] = rawurlencode( $k ) . '=' . rawurlencode( (string) $v ); }
	return $url . $sep . implode( '&', $qs );
}

/* =========================================================
 * WP_Error / WP_REST_Request
 * =======================================================*/
class WP_Error {
	public $code; public $message; public $data;
	public function __construct( $c = '', $m = '', $d = array() ) { $this->code = $c; $this->message = $m; $this->data = $d; }
	public function get_error_message() { return $this->message; }
	public function get_error_code() { return $this->code; }
	public function get_error_data() { return $this->data; }
}
function is_wp_error( $t ) { return $t instanceof WP_Error; }

class WP_REST_Request implements ArrayAccess {
	private $params; private $json;
	public function __construct( $params = array(), $json = null ) { $this->params = $params; $this->json = $json; }
	public function get_param( $k ) {
		if ( null !== $this->json && is_array( $this->json ) && array_key_exists( $k, $this->json ) ) return $this->json[ $k ];
		return isset( $this->params[ $k ] ) ? $this->params[ $k ] : null;
	}
	public function set_param( $k, $v ) { $this->params[ $k ] = $v; return $this; }
	public function set_body( $b ) { $this->json = is_array( $b ) ? $b : json_decode( (string) $b, true ); return $this; }
	public function get_json_params() { return is_array( $this->json ) ? $this->json : null; }
	public function get_params() { return $this->params; }
	// وردپرس واقعی هم ArrayAccess پیاده می‌کند ($request['lang'] معتبر است)
	#[\ReturnTypeWillChange] public function offsetExists( $k ) { return null !== $this->get_param( $k ); }
	#[\ReturnTypeWillChange] public function offsetGet( $k ) { return $this->get_param( $k ); }
	#[\ReturnTypeWillChange] public function offsetSet( $k, $v ) { $this->params[ $k ] = $v; }
	#[\ReturnTypeWillChange] public function offsetUnset( $k ) { unset( $this->params[ $k ] ); }
}

class WP_Query {
	public $posts = array();
	public function __construct( $a = array() ) {}
	public function have_posts() { return false; }
}
function wp_reset_postdata() {}

/* =========================================================
 * پاک‌سازی و ابزارها (رفتار مطابق هستهٔ وردپرس)
 * =======================================================*/
function wp_unslash( $v ) { return is_string( $v ) ? stripslashes( $v ) : $v; }
function sanitize_text_field( $s ) {
	$s = (string) $s;
	$s = preg_replace( '/[\r\n\t ]+/', ' ', strip_tags( $s ) );
	return trim( preg_replace( '/[^\P{C}\s]/u', '', $s ) );
}
function sanitize_textarea_field( $s ) {
	$s = (string) $s;
	$s = str_replace( array( "\r\n", "\r" ), "\n", strip_tags( $s ) );
	return trim( preg_replace( '/\n{3,}/', "\n\n", $s ) );
}
function sanitize_key( $k ) { return preg_replace( '/[^a-z0-9_\-]/', '', strtolower( (string) $k ) ); }
function sanitize_email( $e ) { return filter_var( trim( (string) $e ), FILTER_SANITIZE_EMAIL ); }
function sanitize_hex_color( $c ) { return preg_match( '/^#([A-Fa-f0-9]{3}){1,2}$/', (string) $c ) ? $c : null; }
/**
 * وردپرس واقعی اسکیم‌های ناامن (javascript:, data: و…) را دور می‌اندازد.
 * stub قبلی فقط sanitize می‌کرد، پس تست نمی‌توانست این محافظت را بسنجد.
 */
function esc_url_raw( $u ) {
	$u = trim( (string) $u );
	if ( '' === $u ) { return ''; }
	$low = strtolower( preg_replace( '/[\x00-\x20]+/', '', $u ) );
	foreach ( array( 'javascript:', 'data:', 'vbscript:', 'file:' ) as $bad ) {
		if ( 0 === strpos( $low, $bad ) ) { return ''; }
	}
	if ( ! preg_match( '#^(https?|mailto|/)#i', $u ) ) { return ''; }
	return filter_var( $u, FILTER_SANITIZE_URL );
}
function esc_attr( $s ) { return htmlspecialchars( (string) $s, ENT_QUOTES ); }
function esc_html( $s ) { return htmlspecialchars( (string) $s, ENT_QUOTES ); }
function esc_textarea( $s ) { return htmlspecialchars( (string) $s, ENT_QUOTES ); }
function wp_strip_all_tags( $s, $r = false ) { return trim( strip_tags( (string) $s ) ); }
function strip_shortcodes( $s ) { return preg_replace( '/\[[^\]]*\]/', '', (string) $s ); }
function wp_parse_args( $a, $d = array() ) { return array_merge( $d, (array) $a ); }
function wp_json_encode( $d, $f = 0 ) { return json_encode( $d, $f ); }
function trailingslashit( $s ) { return rtrim( (string) $s, '/' ) . '/'; }
function wp_trim_words( $t, $n = 55, $more = '…' ) {
	$w = preg_split( '/\s+/u', trim( wp_strip_all_tags( $t ) ) );
	return implode( ' ', array_slice( $w, 0, $n ) ) . ( count( $w ) > $n ? $more : '' );
}
function wp_generate_uuid4() {
	return sprintf( '%04x%04x-%04x-%04x-%04x-%04x%04x%04x', mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ),
		mt_rand( 0, 0xffff ), mt_rand( 0, 0x0fff ) | 0x4000, mt_rand( 0, 0x3fff ) | 0x8000,
		mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ) );
}
function wp_generate_password( $l = 12, $s = true ) { return substr( md5( uniqid( '', true ) ), 0, $l ); }
function wp_create_nonce( $a = -1 ) { return 'nonce_' . md5( $a ); }
function number_format_i18n( $n ) { return number_format( (float) $n ); }
function mysql2date( $f, $m, $t = true ) { return $m ? gmdate( $f, strtotime( $m ) ) : false; }
function human_time_diff( $from, $to = 0 ) {
	$d = abs( (int) $to - (int) $from );
	if ( $d < 60 ) return $d . ' ثانية';
	if ( $d < 3600 ) return floor( $d / 60 ) . ' دقيقة';
	if ( $d < 86400 ) return floor( $d / 3600 ) . ' ساعة';
	return floor( $d / 86400 ) . ' يوم';
}
function get_bloginfo( $s = 'name' ) {
	if ( 'version' === $s ) {
		return isset( $GLOBALS['wp_version'] ) ? $GLOBALS['wp_version'] : '6.7.1';
	}
	return 'Example Site';
}

/**
 * منطقهٔ زمانی سایت.
 *
 * رفتار وردپرس واقعی: اول timezone_string، و اگر خالی بود gmt_offset
 * (که می‌تواند منفی یا اعشاری باشد).
 */
function wp_timezone() {
	$tz = (string) get_option( 'timezone_string', '' );
	if ( '' !== $tz ) {
		return new DateTimeZone( $tz );
	}
	$off = (float) get_option( 'gmt_offset', 0 );
	$sign = $off < 0 ? '-' : '+';
	$abs  = abs( $off );
	$h    = (int) $abs;
	$m    = (int) round( ( $abs - $h ) * 60 );
	return new DateTimeZone( sprintf( '%s%02d:%02d', $sign, $h, $m ) );
}

/**
 * تاریخ در منطقهٔ زمانی داده‌شده.
 *
 * فقط برای صفحهٔ بررسی سلامت لازم است؛ همان قالب‌بندی date() کافی است
 * چون هدف تست، تشخیص منطقهٔ زمانی است نه صحت تقویم.
 */
function wp_date( $format, $ts = null, $tz = null ) {
	if ( null === $ts ) { $ts = time(); }
	if ( $tz instanceof DateTimeZone ) {
		$d = new DateTime( '@' . $ts );
		$d->setTimezone( $tz );
		return $d->format( $format );
	}
	return gmdate( $format, $ts );
}

function is_email( $email ) {
	$email = trim( (string) $email );
	return (bool) filter_var( $email, FILTER_VALIDATE_EMAIL );
}
/*
 * کاربران و نقش‌ها.
 *
 * $GLOBALS['wp_user_caps'] اگر آرایه باشد، همان فهرست قابلیت‌ها ملاک است
 * (برای تست چنداپراتوری لازم است). اگر null باشد، رفتار قدیمی با
 * $GLOBALS['wp_current_user_can'] حفظ می‌شود تا تست‌های موجود نشکنند.
 */
$GLOBALS['wp_user_caps']    = null;
$GLOBALS['wp_users']        = array();
$GLOBALS['wp_roles']        = array(
	'administrator' => array( 'name' => 'Administrator', 'caps' => array( 'read', 'manage_options' ) ),
);
$GLOBALS['wp_current_user'] = (object) array( 'ID' => 1, 'display_name' => 'Admin', 'user_login' => 'admin' );

function current_user_can( $c ) {
	if ( is_array( $GLOBALS['wp_user_caps'] ) ) {
		return in_array( $c, $GLOBALS['wp_user_caps'], true );
	}
	return (bool) $GLOBALS['wp_current_user_can'];
}
function wp_get_current_user() { return $GLOBALS['wp_current_user']; }

function get_users( $args = array() ) {
	$want = array();
	if ( ! empty( $args['capability'] ) ) { $want = (array) $args['capability']; }
	$out  = array();
	foreach ( (array) $GLOBALS['wp_users'] as $u ) {
		$caps = isset( $u['caps'] ) ? (array) $u['caps'] : array();
		$hit  = true;
		foreach ( $want as $w ) {
			if ( ! in_array( $w, $caps, true ) ) { $hit = false; break; }
		}
		if ( $hit ) {
			$out[] = (object) array(
				'ID'           => (int) $u['ID'],
				'display_name' => isset( $u['display_name'] ) ? $u['display_name'] : '',
				'user_login'   => isset( $u['user_login'] ) ? $u['user_login'] : '',
			);
		}
	}
	return $out;
}
function get_userdata( $id ) {
	$id = (int) $id;
	foreach ( (array) $GLOBALS['wp_users'] as $u ) {
		if ( (int) $u['ID'] === $id ) {
			return (object) array(
				'ID'           => $id,
				'display_name' => isset( $u['display_name'] ) ? $u['display_name'] : '',
				'user_login'   => isset( $u['user_login'] ) ? $u['user_login'] : '',
			);
		}
	}
	return false;
}

class WP_Stub_Role {
	public $name; public $caps;
	private $key;
	public function __construct( $key, $name, $caps ) {
		$this->key  = $key;
		$this->name = $name;
		$this->caps = (array) $caps;
	}
	// وردپرس get_role() را به همان ساختار سراسری وصل می‌کند، پس تغییرات
	// باید برگردند — وگرنه add_cap روی یک آبجکت دورریختنی اثر می‌کرد.
	private function sync() {
		if ( isset( $GLOBALS['wp_roles'][ $this->key ] ) ) {
			$GLOBALS['wp_roles'][ $this->key ]['caps'] = $this->caps;
		}
	}
	public function has_cap( $c ) { return in_array( $c, $this->caps, true ); }
	public function add_cap( $c ) { if ( ! $this->has_cap( $c ) ) { $this->caps[] = $c; $this->sync(); } }
	public function remove_cap( $c ) { $this->caps = array_values( array_diff( $this->caps, array( $c ) ) ); $this->sync(); }
}
function get_role( $r ) {
	return isset( $GLOBALS['wp_roles'][ $r ] )
		? new WP_Stub_Role( $r, $GLOBALS['wp_roles'][ $r ]['name'], $GLOBALS['wp_roles'][ $r ]['caps'] )
		: null;
}
function add_role( $r, $label, $caps = array() ) {
	if ( isset( $GLOBALS['wp_roles'][ $r ] ) ) { return get_role( $r ); }
	$GLOBALS['wp_roles'][ $r ] = array( 'name' => $label, 'caps' => array_keys( array_filter( (array) $caps ) ) );
	return get_role( $r );
}
function remove_role( $r ) { unset( $GLOBALS['wp_roles'][ $r ] ); }
function wp_list_pluck( $list, $f ) { $o = array(); foreach ( (array) $list as $k => $v ) { $o[ $k ] = is_array( $v ) && isset( $v[ $f ] ) ? $v[ $f ] : null; } return $o; }
/* ---------------------------------------------------------
 * نوشته‌های ساختگی.
 * تست‌ها $GLOBALS['wp_posts'] را با آرایه‌ای از آبجکت پست پر می‌کنند؛
 * اگر خالی باشد، رفتار قدیمی (مقادیر ثابت) حفظ می‌شود تا تست‌های
 * موجود نشکنند.
 * -------------------------------------------------------*/
$GLOBALS['wp_posts'] = array();

function wp_test_get_post_obj( $p ) {
	$id = is_object( $p ) && isset( $p->ID ) ? (int) $p->ID : (int) $p;
	foreach ( (array) $GLOBALS['wp_posts'] as $post ) {
		if ( (int) $post->ID === $id ) { return $post; }
	}
	return null;
}
function get_posts( $args = array() ) {
	$args = wp_parse_args( $args, array( 'post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 5, 'offset' => 0 ) );
	$types = (array) $args['post_type'];
	$out = array();
	foreach ( (array) $GLOBALS['wp_posts'] as $post ) {
		if ( ! in_array( $post->post_type, $types, true ) ) { continue; }
		if ( isset( $args['post_status'] ) && $post->post_status !== $args['post_status'] ) { continue; }
		$out[] = $post;
	}
	usort( $out, function ( $a, $b ) { return $a->ID - $b->ID; } );
	if ( ! empty( $args['offset'] ) ) { $out = array_slice( $out, (int) $args['offset'] ); }
	if ( isset( $args['posts_per_page'] ) && (int) $args['posts_per_page'] > 0 ) {
		$out = array_slice( $out, 0, (int) $args['posts_per_page'] );
	}
	return $out;
}
function has_excerpt( $p ) { return false; }
function get_the_excerpt( $p ) { return ''; }
function get_the_title( $p ) {
	$post = wp_test_get_post_obj( $p );
	return $post ? $post->post_title : 'Title';
}
function get_permalink( $p ) {
	$post = wp_test_get_post_obj( $p );
	return $post ? 'http://example.test/?p=' . (int) $post->ID : 'http://example.test/?p=1';
}
function is_singular() { return false; }
function get_post( $p = null ) { return $p ? wp_test_get_post_obj( $p ) : null; }
function wp_is_post_revision( $id ) { return false; }
function wp_is_post_autosave( $id ) { return false; }

/* ---------------------------------------------------------
 * آپلود فایل.
 * تست‌ها با $GLOBALS['wp_fake_upload']=1 وانمود می‌کنند فایل از راه
 * HTTP آمده است؛ وگرنه is_uploaded_file همیشه false می‌دهد.
 * -------------------------------------------------------*/
$GLOBALS['wp_upload_dir'] = PASOKHBAN_TESTS_DIR . '/fakeuploads';

function wp_upload_dir() {
	$d = isset( $GLOBALS['wp_upload_dir'] ) ? $GLOBALS['wp_upload_dir'] : '/tmp/wp-uploads';
	return array(
		'basedir' => $d,
		'baseurl' => 'http://example.test/wp-content/uploads',
		'error'   => false,
	);
}
function wp_mkdir_p( $dir ) { return is_dir( $dir ) ? true : @mkdir( $dir, 0777, true ); }

/**
 * لایهٔ چهارم اعتبارسنجی آپلود (مقایسهٔ پسوند با MIME واقعی).
 *
 * وردپرس این را با getimagesize و fileinfo انجام می‌دهد. در هارنس فقط
 * همان قرارداد ورودی/خروجی لازم است، چون هدف تست وجودِ این لایه است
 * نه دقت تشخیص MIME.
 */
function wp_check_filetype_and_ext( $file, $filename, $mimes = null ) {
	$ext = strtolower( pathinfo( (string) $filename, PATHINFO_EXTENSION ) );
	$type = '';
	$map = array(
		'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png',
		'gif' => 'image/gif', 'webp' => 'image/webp',
		'pdf' => 'application/pdf', 'txt' => 'text/plain',
	);
	if ( isset( $map[ $ext ] ) ) {
		$type = $map[ $ext ];
	}
	return array(
		'ext'             => $type ? $ext : false,
		'type'            => $type ? $type : false,
		'proper_filename' => $filename,
	);
}
function __return_true() { return true; }
function __return_false() { return false; }

/**
 * ثبت میان‌برهای آپلود برای تست.
 *
 * is_uploaded_file و move_uploaded_file تابع داخلی PHP هستند و قابل
 * تعریف مجدد نیستند، پس پلاگین این دو نقطه را با فیلترِ pre_ باز
 * گذاشته است (همان الگوی وردپرس). تست‌ها این را صدا می‌کنند.
 */
function wp_test_fake_uploads() {
	$GLOBALS['wp_fake_upload'] = 1;
	add_filter( 'pasokhban_pre_is_upload', function ( $pre, $path ) {
		return is_file( $path );
	}, 10, 2 );
	add_filter( 'pasokhban_pre_move_upload', function ( $pre, $from, $to ) {
		return @rename( $from, $to ) ? true : ( @copy( $from, $to ) ? true : false );
	}, 10, 3 );
}
function has_shortcode( $c, $t ) { return false; }
function load_plugin_textdomain( $d, $x = false, $p = false ) { return true; }
function plugin_dir_path( $f ) { return rtrim( dirname( $f ), '/' ) . '/'; }
function plugin_dir_url( $f ) { return 'http://example.test/wp-content/plugins/' . basename( dirname( $f ) ) . '/'; }
function plugin_basename( $f ) { return basename( dirname( $f ) ) . '/' . basename( $f ); }

function __( $s, $d = null ) { return $s; }
function _e( $s, $d = null ) { echo $s; }
function esc_html__( $s, $d = null ) { return esc_html( $s ); }
function esc_html_e( $s, $d = null ) { echo esc_html( $s ); }
function esc_attr__( $s, $d = null ) { return esc_attr( $s ); }
function esc_attr_e( $s, $d = null ) { echo esc_attr( $s ); }
// رفتار واقعی وردپرس: وقتی دو مقدار یکی باشند صفت را چاپ می‌کند.
// قبلاً همیشه رشتهٔ خالی برمی‌گرداند و تست‌ها نمی‌توانستند بررسی کنند
// کدام گزینه از قبل انتخاب‌شده رندر شده است.
function checked( $a, $b = true, $e = true ) {
	$out = ( (string) $a === (string) $b ) ? " checked='checked'" : '';
	if ( $e ) { echo $out; }
	return $out;
}
function selected( $a, $b = true, $e = true ) {
	$out = ( (string) $a === (string) $b ) ? " selected='selected'" : '';
	if ( $e ) { echo $out; }
	return $out;
}
function disabled( $a, $b = true, $e = true ) {
	$out = ( (string) $a === (string) $b ) ? " disabled='disabled'" : '';
	if ( $e ) { echo $out; }
	return $out;
}
function submit_button( $text = 'Save Changes', $type = 'primary', $name = 'submit', $wrap = true, $other = '' ) {
	$html = '<input type="submit" name="' . esc_attr( $name ) . '" id="' . esc_attr( $name ) . '" class="button button-' . esc_attr( $type ) . '" value="' . esc_attr( $text ) . '" />';
	if ( $wrap ) { $html = '<p class="submit">' . $html . '</p>'; }
	echo $html;
}
function settings_fields( $g ) {
	echo '<input type="hidden" name="option_page" value="' . esc_attr( $g ) . '" />';
	echo '<input type="hidden" name="action" value="update" />';
	echo '<input type="hidden" name="_wpnonce" value="testnonce" />';
	echo '<input type="hidden" name="_wp_http_referer" value="/wp-admin/" />';
}
// شبیه‌سازی دقیق رفتار وردپرس برای ساخت hookname
$GLOBALS['admin_page_hooks'] = array();

function wp_sanitize_title_like( $title ) {
	// remove_accents + sanitize_title_with_dashes: کاراکترهای غیر ASCII حذف می‌شوند
	$t = preg_replace( '/[^a-zA-Z0-9_ -]/', '', (string) $title );
	$t = strtolower( trim( preg_replace( '/[^a-zA-Z0-9_-]/', '', $t ) ) );
	return $t;
}

function add_menu_page( $page_title, $menu_title, $cap, $menu_slug, $cb = '', $icon = '', $pos = null ) {
	// وردپرس: $admin_page_hooks[ $menu_slug ] = sanitize_title( $menu_title );
	$GLOBALS['admin_page_hooks'][ $menu_slug ] = wp_sanitize_title_like( $menu_title );
	return 'toplevel_page_' . $menu_slug;
}

function add_submenu_page( $parent_slug, $page_title, $menu_title, $cap, $submenu_slug, $cb = '', $pos = null ) {
	// وردپرس: get_plugin_page_hookname( $submenu_slug, $parent_slug )
	if ( isset( $GLOBALS['admin_page_hooks'][ $parent_slug ] ) ) {
		$hook = $GLOBALS['admin_page_hooks'][ $parent_slug ] . '_page_' . $submenu_slug;
	} else {
		$hook = $parent_slug . '_page_' . $submenu_slug;
	}
	return wp_sanitize_title_like( $hook );
}
function register_setting() { return true; }
function wp_enqueue_style( $h = '', $s = '', $d = array(), $v = false ) { $GLOBALS['wp_styles_enq'][] = $h; }
function wp_enqueue_script( $h = '', $s = '', $d = array(), $v = false, $f = false ) { $GLOBALS['wp_scripts_enq'][] = $h; }
function wp_localize_script() {}
function wp_add_inline_script() {}
function wp_die( $m = '' ) { throw new Exception( 'wp_die: ' . $m ); }
function wp_remote_retrieve_response_code( $r ) { return isset( $r['response']['code'] ) ? $r['response']['code'] : 200; }
function wp_remote_retrieve_body( $r ) { return isset( $r['body'] ) ? $r['body'] : ''; }
function wp_remote_retrieve_headers( $r ) { return isset( $r['headers'] ) ? $r['headers'] : array(); }
function wp_remote_retrieve_header( $r, $h ) {
	$h = strtolower( (string) $h );
	if ( isset( $r['headers'][ $h ] ) ) { return $r['headers'][ $h ]; }
	// وردپرس هدرها را case-insensitive نگه می‌دارد
	foreach ( (array) ( isset( $r['headers'] ) ? $r['headers'] : array() ) as $k => $v ) {
		if ( strtolower( (string) $k ) === $h ) { return $v; }
	}
	return '';
}
/** مثل wp_remote_post ولی GET — برای آزمون ریدایرکت رلهٔ گوگل لازم است. */
function wp_remote_get( $url, $args = array() ) {
	$GLOBALS['wp_remote_calls'][] = array( 'url' => $url, 'body' => null, 'method' => 'GET' );
	if ( ! isset( $GLOBALS['wp_remote_log'] ) ) { $GLOBALS['wp_remote_log'] = array(); }
	$GLOBALS['wp_remote_log'][] = array( 'url' => $url, 'body' => '', 'args' => $args, 'method' => 'GET' );
	if ( is_wp_error( $GLOBALS['wp_remote_response'] ) ) { return $GLOBALS['wp_remote_response']; }
	if ( $GLOBALS['wp_remote_response'] instanceof \Closure ) {
		return call_user_func( $GLOBALS['wp_remote_response'], $url, $args );
	}
	return $GLOBALS['wp_remote_response'];
}

/** پاسخ ساختگی — تست‌ها آن را تنظیم می‌کنند. */
function wp_remote_post( $url, $args = array() ) {
	$raw = isset( $args['body'] ) ? $args['body'] : null;
	// بدنه می‌تواند رشتهٔ JSON، رشتهٔ form-encoded، یا آرایه باشد
	$decoded = null;
	if ( is_string( $raw ) ) {
		$decoded = json_decode( $raw, true );
		if ( null === $decoded ) { parse_str( $raw, $decoded ); }
	} elseif ( is_array( $raw ) ) {
		$decoded = $raw;
	}
	$GLOBALS['wp_remote_calls'][] = array( 'url' => $url, 'body' => $decoded, 'method' => 'POST', 'args' => $args );
	if ( ! isset( $GLOBALS['wp_remote_log'] ) ) { $GLOBALS['wp_remote_log'] = array(); }
	$GLOBALS['wp_remote_log'][] = array( 'url' => $url, 'body' => isset( $args['body'] ) ? $args['body'] : '', 'args' => $args );
	if ( is_wp_error( $GLOBALS['wp_remote_response'] ) ) return $GLOBALS['wp_remote_response'];
	// اگر تست یک Closure گذاشته باشد، پاسخ بر اساس خودِ درخواست ساخته
	// می‌شود — برای شبیه‌سازی endpoint هایی مثل /embeddings که خروجی‌شان
	// به ورودی وابسته است.
	if ( $GLOBALS['wp_remote_response'] instanceof \Closure ) {
		return call_user_func( $GLOBALS['wp_remote_response'], $url, $args );
	}
	return $GLOBALS['wp_remote_response'];
}

/* =========================================================
 * $wpdb روی SQLite
 * =======================================================*/
class Pasokhban_Test_WPDB {
	public $prefix = 'wp_';
	public $insert_id = 0;
	public $last_error = '';

	/**
	 * فهرست جدول‌های این نصب.
	 *
	 * وردپرس واقعی این را پر می‌کند و کد پلاگین (بررسی «جدول‌های نام
	 * قدیمی») از رویش می‌خواند. تست‌ها می‌توانند مقدارش را عوض کنند.
	 *
	 * @var array
	 */
	public $tables = array( 'posts', 'postmeta', 'options', 'users', 'usermeta' );

	/** نسخهٔ سرور — برای نمایش در گزارش سلامت. */
	public $db_server_info = '8.0.36';

	private $pdo;

	public function __construct() {
		$this->pdo = new PDO( 'sqlite::memory:' );
		$this->pdo->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
		$this->pdo->setAttribute( PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ );
	}

	public function get_charset_collate() { return ''; }
	public function esc_like( $s ) { return str_replace( array( '%', '_' ), array( '\%', '\_' ), $s ); }

	public function prepare( $sql, ...$argv ) {
		if ( ! $argv ) return $sql;
		// وردپرس هم prepare($sql, $a, $b) را قبول می‌کند هم prepare($sql, array($a,$b))
		$args = ( count( $argv ) === 1 && is_array( $argv[0] ) ) ? array_values( $argv[0] ) : $argv;
		$i = 0;
		$pdo = $this->pdo;
		return preg_replace_callback( '/%[sdf]/', function () use ( &$i, $args, $pdo ) {
			$v = array_key_exists( $i, $args ) ? $args[ $i ] : '';
			$i++;
			if ( is_int( $v ) || is_float( $v ) ) return (string) $v;
			return $pdo->quote( (string) $v );
		}, $sql );
	}

	public function query( $sql ) {
		$this->last_error = '';
		try { $this->pdo->exec( $sql ); return true; }
		catch ( Exception $e ) { $this->last_error = $e->getMessage(); return false; }
	}

	public function insert( $table, $data, $fmt = null ) {
		$cols = array_keys( $data );
		$ph   = array();
		foreach ( $data as $v ) { $ph[] = ( null === $v ) ? 'NULL' : $this->pdo->quote( (string) $v ); }
		$sql = 'INSERT INTO ' . $table . ' (' . implode( ',', $cols ) . ') VALUES (' . implode( ',', $ph ) . ')';
		if ( ! $this->query( $sql ) ) return false;
		$this->insert_id = (int) $this->pdo->lastInsertId();
		return 1;
	}

	public function update( $table, $data, $where ) {
		$set = array();
		foreach ( $data as $k => $v ) { $set[] = $k . '=' . ( ( null === $v ) ? 'NULL' : $this->pdo->quote( (string) $v ) ); }
		$w = array();
		foreach ( $where as $k => $v ) { $w[] = $k . '=' . $this->pdo->quote( (string) $v ); }
		return $this->query( 'UPDATE ' . $table . ' SET ' . implode( ',', $set ) . ' WHERE ' . implode( ' AND ', $w ) );
	}

	public function delete( $table, $where ) {
		$w = array();
		foreach ( $where as $k => $v ) { $w[] = $k . '=' . $this->pdo->quote( (string) $v ); }
		return $this->query( 'DELETE FROM ' . $table . ' WHERE ' . implode( ' AND ', $w ) );
	}

	public function get_results( $sql ) {
		$this->last_error = '';
		try { $r = $this->pdo->query( $sql ); return $r ? $r->fetchAll() : array(); }
		catch ( Exception $e ) { $this->last_error = $e->getMessage(); return null; }
	}

	public function get_row( $sql ) {
		$this->last_error = '';
		try { $r = $this->pdo->query( $sql ); $row = $r ? $r->fetch() : false; return $row ? $row : null; }
		catch ( Exception $e ) { $this->last_error = $e->getMessage(); return null; }
	}

	private function translate( $sql ) {
		// SHOW TABLES LIKE 'x'  →  معادل SQLite
		// الگو می‌تواند % داشته باشد (مثل wp_etehadyar_%)؛ در آن صورت
		// از GLOB استفاده می‌شود که % را به * نگاشت می‌دهیم.
		if ( preg_match( "/^SHOW TABLES LIKE '([^']*)'/i", trim( $sql ), $m ) ) {
			$pat = $m[1];
			if ( false !== strpos( $pat, '%' ) || false !== strpos( $pat, '_' ) ) {
				// esc_like() زیرخط را به \_ فرار می‌کند. در MySQL این یعنی
				// «خودِ زیرخط»، ولی GLOB در SQLite این فرار را نمی‌شناسد.
				// پس اول فرارها را برمی‌داریم تا رفتار دو سرور یکی شود.
				$plain = str_replace( array( '\\%', '\\_' ), array( '%', '_' ), $pat );
				$glob  = str_replace( array( '%', '_' ), array( '*', '?' ), $plain );
				return "SELECT name FROM sqlite_master WHERE type='table' AND name GLOB " . $this->pdo->quote( $glob );
			}
			return "SELECT name FROM sqlite_master WHERE type='table' AND name=" . $this->pdo->quote( $pat );
		}
		return $sql;
	}

	public function get_col( $sql ) {
		$this->last_error = '';
		$sql = $this->translate( $sql );
		try {
			$r = $this->pdo->query( $sql );
			return $r ? $r->fetchAll( PDO::FETCH_COLUMN, 0 ) : array();
		} catch ( Exception $e ) { $this->last_error = $e->getMessage(); return array(); }
	}

	public function get_var( $sql ) {
		$this->last_error = '';
		$sql = $this->translate( $sql );
		try { $r = $this->pdo->query( $sql ); $row = $r ? $r->fetch( PDO::FETCH_NUM ) : false; return $row ? $row[0] : null; }
		catch ( Exception $e ) { $this->last_error = $e->getMessage(); return null; }
	}
}
$GLOBALS['wpdb'] = new Pasokhban_Test_WPDB();

/* dbDelta: DDL واقعی مای‌اس‌کیوال پلاگین را به SQLite ترجمه می‌کند
   تا همان رشتهٔ SQL که install() می‌سازد واقعاً اجرا شود. */
function dbDelta( $sql ) {
	// شبیه‌سازی هاستی که کاربر MySQL حق CREATE TABLE ندارد
	if ( ! empty( $GLOBALS['wp_dbdelta_fail'] ) ) {
		$GLOBALS['wpdb']->last_error = "CREATE command denied to user 'x'@'localhost' for table 'wp_pasokhban_sessions'";
		return array();
	}
	$sql = preg_replace( '/BIGINT\(\d+\) UNSIGNED NOT NULL AUTO_INCREMENT/i', 'INTEGER PRIMARY KEY AUTOINCREMENT', $sql );
	$sql = preg_replace( '/BIGINT\(\d+\) UNSIGNED/i', 'INTEGER', $sql );
	$sql = preg_replace( '/SMALLINT\(\d+\) UNSIGNED/i', 'INTEGER', $sql );
	$sql = preg_replace( '/LONGTEXT/i', 'TEXT', $sql );
	$sql = preg_replace( '/^\s*PRIMARY KEY\s+\(id\),\s*$/mi', '', $sql );
	$sql = preg_replace( '/UNIQUE KEY \w+ \(([^)]+)\)/i', 'UNIQUE ($1)', $sql );
	$sql = preg_replace( '/^\s*KEY \w+ \([^)]+\),?\s*$/mi', '', $sql );
	$sql = preg_replace( '/,(\s*\))/', '$1', $sql );
	$GLOBALS['wpdb']->query( $sql );
	return array();
}

file_put_contents( ABSPATH . 'wp-admin/includes/upgrade.php', "<?php // dbDelta در هارنس تعریف شده است.\n" );

/* =========================================================
 * بارگذاری پلاگین
 * =======================================================*/
require_once PASOKHBAN_PATH . 'includes/class-settings.php';
require_once PASOKHBAN_PATH . 'includes/class-db.php';
require_once PASOKHBAN_PATH . 'includes/class-providers.php';
require_once PASOKHBAN_PATH . 'includes/class-api.php';
require_once PASOKHBAN_PATH . 'includes/class-rag.php';
require_once PASOKHBAN_PATH . 'includes/class-upload.php';
require_once PASOKHBAN_PATH . 'includes/class-copilot.php';
require_once PASOKHBAN_PATH . 'includes/class-woo.php';
require_once PASOKHBAN_PATH . 'includes/class-team.php';
require_once PASOKHBAN_PATH . 'includes/class-hours.php';
require_once PASOKHBAN_PATH . 'includes/class-jalali.php';
require_once PASOKHBAN_PATH . 'includes/class-sms.php';
require_once PASOKHBAN_PATH . 'includes/class-bale.php';

/*
 * هوک‌هایی که در سازندهٔ Pasokhban ثبت می‌شوند.
 * بدون این، فیلتر pasokhban_rag_sources وصل نمی‌شد و محصولات هرگز به
 * ایندکس نمی‌رسیدند — همان کاری که پلاگین واقعی موقع بوت می‌کند.
 */
Pasokhban_Upload::hooks();
Pasokhban_Copilot::hooks();
Pasokhban_Woo::hooks();
require_once PASOKHBAN_PATH . 'includes/class-livechat.php';
require_once PASOKHBAN_PATH . 'includes/class-inbox.php';
require_once PASOKHBAN_PATH . 'includes/class-contacts.php';
require_once PASOKHBAN_PATH . 'includes/class-stream.php';
require_once PASOKHBAN_PATH . 'includes/class-notify.php';
require_once PASOKHBAN_PATH . 'includes/class-analytics.php';
require_once PASOKHBAN_PATH . 'includes/class-health.php';
