/**
 * تست رگرسیون: ساختار فرم تنظیمات.
 *
 * باگ ۱.۵.۰: فرم «آزمایش تلگرام» داخل فرم تنظیمات بود. HTML فرم تو‌در‌تو
 * را قبول ندارد و </form> آن باعث بسته‌شدن زودهنگام فرم تنظیمات می‌شد؛
 * در نتیجه دکمهٔ «ذخیرهٔ تنظیمات» بیرون فرم می‌افتاد و ذخیره کار نمی‌کرد.
 */
const fs = require('fs');
const { execFileSync } = require('child_process');
const { JSDOM } = require('jsdom');

const HTML = execFileSync((process.env.PASOKHBAN_PHP || 'php'), ['-r', `
  require_once __DIR__ . '/wp-stubs.php';
  ob_start(); Pasokhban_Settings::instance()->render_page(); echo ob_get_clean();
`], { encoding: 'utf8' });

const d = new JSDOM('<!DOCTYPE html><html><body>' + HTML + '</body></html>').window.document;

let pass = 0, fail = 0; const fails = [];
const ok = (c, l, x) => { if (c) { pass++; console.log(`  \x1b[32m✓\x1b[0m ${l}`); } else { fail++; fails.push(l + (x ? ' — ' + x : '')); console.log(`  \x1b[31m✗\x1b[0m ${l}` + (x ? '  → ' + x : '')); } };
const eq = (a, b, l) => ok(JSON.stringify(a) === JSON.stringify(b), l, `انتظار ${JSON.stringify(b)} / دریافت ${JSON.stringify(a)}`);
const head = t => console.log(`\n\x1b[1m${t}\x1b[0m`);

head('۱) فرم تنظیمات سالم است');
const main = d.getElementById('psb-set-form');
ok(!!main, 'فرم تنظیمات وجود دارد');
eq(main.getAttribute('action'), 'options.php', 'فرم به options.php می‌رود (Settings API)');
eq(main.getAttribute('method'), 'post', 'متد POST است');
ok(!!d.querySelector('input[name="option_page"]'), 'فیلد پنهان option_page هست');
ok(!!d.querySelector('input[name="_wpnonce"]'), 'فیلد پنهان nonce هست');
eq(d.querySelector('input[name="option_page"]').value, 'pasokhban_group', 'گروه تنظیمات درست است');

head('۲) دکمهٔ ذخیره به فرم وصل است (باگ اصلی)');
const footerBtn = main.querySelector('input[type=submit]');
ok(!!footerBtn, 'دکمهٔ ذخیرهٔ پایین صفحه هست');
ok(footerBtn && footerBtn.form === main, 'دکمهٔ پایین به فرم تنظیمات وصل است');

const topBtn = d.querySelector('.psb-set-save-top');
ok(!!topBtn, 'دکمهٔ ذخیرهٔ بالای صفحه هست');
eq(topBtn && topBtn.tagName, 'BUTTON', 'دکمهٔ بالا یک <button> است (نه <a> که فقط اسکرول کند)');
eq(topBtn && topBtn.getAttribute('type'), 'submit', 'دکمهٔ بالا type=submit دارد');
ok(topBtn && topBtn.form === main, 'دکمهٔ بالا به فرم تنظیمات وصل است (کلیک واقعاً ذخیره می‌کند)');

head('۳) فرم تو‌در‌تو وجود ندارد');
eq(d.querySelectorAll('#psb-set-form form').length, 0, 'هیچ فرمی داخل فرم تنظیمات نیست');
const testForm = d.getElementById('psb-test-notify-form');
ok(!!testForm, 'فرم آزمایش اعلان وجود دارد');
ok(testForm && testForm.parentNode !== main, 'فرم آزمایش بیرون از فرم تنظیمات است');
eq(testForm && testForm.getAttribute('action').indexOf('admin-post.php') >= 0, true, 'فرم آزمایش به admin-post.php می‌رود');

const testBtn = d.querySelector('button[form="psb-test-notify-form"]');
ok(!!testBtn, 'دکمهٔ «ارسال پیام آزمایشی» هست');
ok(testBtn && testBtn.form === testForm, 'دکمهٔ آزمایش به فرم خودش وصل است (نه فرم تنظیمات)');

head('۴) همهٔ فیلدها به فرم تنظیمات متصل‌اند');
let inside = 0, outside = 0; const outNames = [];
d.querySelectorAll('input, textarea, select').forEach(el => {
  const nm = el.getAttribute('name') || '';
  if (nm.indexOf('pasokhban_options[') !== 0) return;
  if (el.form === main) inside++;
  else { outside++; outNames.push(nm.replace('pasokhban_options[', '').replace(']', '')); }
});
eq(outside, 0, 'هیچ فیلدی از فرم قطع نشده', outNames.join(', '));
ok(inside >= 57, 'دست‌کم ۵۷ فیلد به فرم وصل است', String(inside));

head('۵) هر هفت تب داخل فرم‌اند');
['conn', 'assistant', 'chat', 'notify', 'look', 'brain', 'sec'].forEach(p => {
  const sec = d.querySelector('[data-panel="' + p + '"]');
  ok(!!sec && main.contains(sec), 'پنل «' + p + '» داخل فرم است');
});

head('۶) چکیدهٔ ساختار');
const formKids = Array.from(main.children).map(c => c.tagName.toLowerCase() + (c.id ? '#' + c.id : '') + (c.className ? '.' + String(c.className).split(' ').join('.') : ''));
console.log('  \x1b[2mفرزندان form: ' + formKids.join(', ') + '\x1b[0m');
ok(!!main.querySelector(':scope > .psb-set-layout'), 'چیدمان تب‌ها فرزند مستقیم فرم است');
const footer = d.getElementById('psb-set-submit');
ok(footer && main.contains(footer), 'پابرگ (شامل دکمهٔ ذخیره) داخل فرم است');

console.log('\n' + '─'.repeat(52));
if (fail === 0) console.log(`\x1b[42;30m همهٔ ${pass} تست ساختار فرم پاس شد \x1b[0m`);
else { console.log(`\x1b[41;97m ${fail} تست شکست خورد \x1b[0m (پاس: ${pass})`); fails.forEach(f => console.log('   • ' + f)); }
console.log('─'.repeat(52));
process.exit(fail === 0 ? 0 : 1);
