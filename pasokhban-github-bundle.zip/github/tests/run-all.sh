#!/usr/bin/env bash
# اجرای کامل مجموعهٔ تست اتحادیار.
# استفاده: bash tests/run-all.sh
set -u
cd "$(dirname "$0")"
# PHP را از محیط بگیر؛ وگرنه هر php که روی PATH است.
PHP="${PASOKHBAN_PHP:-php}"

TOTAL=0
FAILED=0

run_php() {
  local f="$1"
  local out
  out=$("$PHP" "$f" 2>&1)
  local code=$?
  local n
  n=$(printf '%s' "$out" | sed 's/\x1b\[[0-9;]*m//g' | grep -oE 'همهٔ [0-9]+ تست' | grep -oE '[0-9]+' | head -1)
  [ -z "$n" ] && n=$(printf '%s' "$out" | sed 's/\x1b\[[0-9;]*m//g' | grep -oE '\(پاس: [0-9]+\)' | grep -oE '[0-9]+' | head -1)
  [ -z "$n" ] && n=0
  if [ "$code" -eq 0 ]; then
    printf "  \033[32m✓\033[0m %-24s %s تست\n" "$f" "$n"
  else
    printf "  \033[31m✗\033[0m %-24s %s تست (شکست)\n" "$f" "$n"
    printf '%s' "$out" | sed 's/\x1b\[[0-9;]*m//g' | grep -E '^\s+•' | sed 's/^/       /'
    FAILED=$((FAILED+1))
  fi
  TOTAL=$((TOTAL+n))
}

run_js() {
  local f="$1"
  local out
  out=$(node "$f" 2>&1)
  local code=$?
  local n
  n=$(printf '%s' "$out" | sed 's/\x1b\[[0-9;]*m//g' | grep -oE 'همهٔ [0-9]+ تست' | grep -oE '[0-9]+' | head -1)
  [ -z "$n" ] && n=$(printf '%s' "$out" | sed 's/\x1b\[[0-9;]*m//g' | grep -oE '\(پاس: [0-9]+\)' | grep -oE '[0-9]+' | head -1)
  [ -z "$n" ] && n=0
  if [ "$code" -eq 0 ]; then
    printf "  \033[32m✓\033[0m %-24s %s تست\n" "$f" "$n"
  else
    printf "  \033[31m✗\033[0m %-24s %s تست (شکست)\n" "$f" "$n"
    printf '%s' "$out" | sed 's/\x1b\[[0-9;]*m//g' | grep -E '^\s+•' | sed 's/^/       /'
    FAILED=$((FAILED+1))
  fi
  TOTAL=$((TOTAL+n))
}

echo
echo "══ بک‌اند (PHP روی هارنس وردپرس/SQLite) ══"
for f in run-tests.php v15-tests.php weak-tests.php relay-tests.php handoff-tests.php rag-tests.php rag-notable-tests.php upload-tests.php copilot-tests.php woo-tests.php team-tests.php localize-tests.php settings-ia-tests.php bale-tests.php v28-tests.php providers-tests.php health-tests.php; do
  [ -f "$f" ] && run_php "$f"
done

echo
echo "══ فرانت‌اند (jsdom + کد واقعی JS/CSS پلاگین) ══"
for f in front-tests.js chat-size-tests.js upload-front-tests.js woo-front-tests.js stream-tests.js dupe-tests.js recover-tests.js sources-tests.js speed-tests.js inline-tests.js inbox-front-tests.js prechat-fix-test.js settings-ui-test.js settings-form-test.js layout-handoff-tests.js; do
  [ -f "$f" ] && run_js "$f"
done

echo
echo "════════════════════════════════════════════"
if [ "$FAILED" -eq 0 ]; then
  printf "\033[42;30m همهٔ %s تست پاس شد \033[0m\n" "$TOTAL"
else
  printf "\033[41;97m %s فایل تست شکست خورد \033[0m (مجموع تست‌ها: %s)\n" "$FAILED" "$TOTAL"
fi
echo "════════════════════════════════════════════"
exit "$FAILED"
