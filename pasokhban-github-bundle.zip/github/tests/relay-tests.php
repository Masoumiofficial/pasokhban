<?php
/**
 * تست رلهٔ تلگرام (Google Apps Script) — عبور از فیلترینگ.
 */

require_once __DIR__ . '/wp-stubs.php';

$PASS = 0; $FAIL = 0; $FAILURES = array();

function ok( $cond, $label, $extra = '' ) {
	global $PASS, $FAIL, $FAILURES;
	if ( $cond ) { $PASS++; echo "  \033[32m✓\033[0m {$label}\n"; }
	else { $FAIL++; $FAILURES[] = $label . ( $extra ? " — {$extra}" : '' ); echo "  \033[31m✗\033[0m {$label}" . ( $extra ? "  → {$extra}" : '' ) . "\n"; }
}
function head( $t ) { echo "\n\033[1m{$t}\033[0m\n"; }
function eq( $a, $b, $label ) { ok( $a === $b, $label, 'انتظار ' . var_export( $b, true ) . ' / دریافت ' . var_export( $a, true ) ); }

$opts = array(
	'notify_telegram'        => 1,
	'notify_telegram_token'  => 'TOKEN123',
	'notify_telegram_chat'   => '-1001234567890',
	'notify_telegram_relay'  => 'https://script.google.com/macros/s/AKfycbz/exec',
	'notify_telegram_secret' => 'MY-SECRET',
);
update_option( 'pasokhban_options', $opts );
$settings = Pasokhban_Settings::instance();
$rp = new ReflectionProperty( 'Pasokhban_Settings', 'options' );
$rp->setAccessible( true );
$rp->setValue( $settings, $opts );

/* ========================================================= */
head( '۱) اعتبارسنجی آدرس رله' );
/* ========================================================= */

$s = $settings->sanitize( array( 'notify_telegram_relay' => 'https://script.google.com/macros/s/AKfycbz/exec' ) );
eq( $s['notify_telegram_relay'], 'https://script.google.com/macros/s/AKfycbz/exec', 'آدرس script.google.com پذیرفته می‌شود' );

$s = $settings->sanitize( array( 'notify_telegram_relay' => 'https://evil.com/relay' ) );
eq( $s['notify_telegram_relay'], '', 'دامنهٔ ناشناس رد می‌شود (امنیت)' );

$s = $settings->sanitize( array( 'notify_telegram_relay' => 'javascript:alert(1)' ) );
eq( $s['notify_telegram_relay'], '', 'javascript رد می‌شود' );

$s = $settings->sanitize( array( 'notify_telegram_relay' => 'https://script.google.com.evil.com/x' ) );
eq( $s['notify_telegram_relay'], '', 'دامنهٔ جعلی با پسوند مشابه رد می‌شود' );

$s = $settings->sanitize( array( 'notify_telegram_secret' => str_repeat( 'a', 300 ) ) );
eq( strlen( $s['notify_telegram_secret'] ), 128, 'کلید به ۱۲۸ نویسه محدود می‌شود' );

/* ========================================================= */
head( '۲) ارسال از راه رله' );
/* ========================================================= */

// پاسخ موفق رله
$GLOBALS['wp_remote_response'] = array(
	'response' => array( 'code' => 200 ),
	'body'     => json_encode( array( 'ok' => true ) ),
);
$GLOBALS['wp_remote_log'] = array();

Pasokhban_Notify::$last_result = array();
$ref = new ReflectionMethod( 'Pasokhban_Notify', 'send_telegram' );
$ref->setAccessible( true );
$res = $ref->invoke( null, $opts, 'پیام تازه', 'متن پیام', (object) array( 'current_url' => '' ) );

eq( $res, true, 'ارسال از راه رله موفق بود' );
eq( Pasokhban_Notify::$last_result['telegram'], 'ok (relay)', 'نتیجه به‌درستی ثبت شد' );

// آیا واقعاً به رله درخواست رفت نه به تلگرام؟
$last = end( $GLOBALS['wp_remote_log'] );
ok( $last && false !== strpos( $last['url'], 'script.google.com' ), 'درخواست به رلهٔ گوگل رفت' );
ok( $last && false === strpos( $last['url'], 'api.telegram.org' ), 'به api.telegram.org نرفت (چون از ایران قابل دسترسی نیست)' );

$body = array();
parse_str( $last['body'], $body );
eq( $body['token'], 'TOKEN123', 'توکن به رله فرستاده شد' );
eq( $body['chat_id'], '-1001234567890', 'شناسهٔ چت فرستاده شد' );
eq( $body['secret'], 'MY-SECRET', 'کلید مشترک فرستاده شد' );
ok( ! empty( $body['text'] ), 'متن پیام فرستاده شد' );
// ★ این انتظار تا ۲.۰.۰ عدد ۵ بود و خودش عامل باگ بود: گوگل پاسخ POST را
// با ۳۰۲ به script.googleusercontent.com/macros/echo می‌دهد و آن endpoint
// فقط GET قبول می‌کند. با redirection=5 کلاینت HTTP ریدایرکت را با همان
// POST دنبال می‌کرد و گوگل ۴۰۵/۴۰۰ با صفحهٔ HTML برمی‌گرداند.
eq( $last['args']['redirection'], 0, 'redirection=0 — ریدایرکت را خودمان با GET دنبال می‌کنیم' );

/* ========================================================= */
head( '۳) گزارش خطای رله' );
/* ========================================================= */

$GLOBALS['wp_remote_response'] = array(
	'response' => array( 'code' => 200 ),
	'body'     => json_encode( array( 'ok' => false, 'error' => 'unauthorized' ) ),
);
Pasokhban_Notify::$last_result = array();
$res = $ref->invoke( null, $opts, 'ت', 'م', (object) array( 'current_url' => '' ) );
eq( $res, false, 'با خطای رله، false برمی‌گردد' );
eq( Pasokhban_Notify::$last_result['telegram'], 'relay: unauthorized', 'پیام خطای رله گزارش می‌شود' );

$GLOBALS['wp_remote_response'] = array(
	'response' => array( 'code' => 400 ),
	'body'     => json_encode( array( 'ok' => false, 'description' => 'Bad Request: chat not found' ) ),
);
Pasokhban_Notify::$last_result = array();
$ref->invoke( null, $opts, 'ت', 'م', (object) array( 'current_url' => '' ) );
eq( Pasokhban_Notify::$last_result['telegram'], 'relay: Bad Request: chat not found', 'خطای تلگرام از راه رله منتقل می‌شود' );

$GLOBALS['wp_remote_response'] = new WP_Error( 'http_request_failed', 'cURL error 28: timed out' );
Pasokhban_Notify::$last_result = array();
$res = $ref->invoke( null, $opts, 'ت', 'م', (object) array( 'current_url' => '' ) );
eq( $res, false, 'با خطای شبکه، false برمی‌گردد' );
ok( false !== strpos( Pasokhban_Notify::$last_result['telegram'], 'relay:' ), 'خطای شبکه با پیشوند relay گزارش می‌شود' );

/* ========================================================= */
head( '۳.۵) تشخیص صفحهٔ HTML گوگل (دیپلوی اشتباه)' );
/* ========================================================= */

// دقیقاً همان چیزی که کاربر دید: ۴۰۳ + صفحهٔ HTML گوگل
$GLOBALS['wp_remote_response'] = array(
	'response' => array( 'code' => 403 ),
	'body'     => "<!DOCTYPE html><html><script>window['ppConfig'] = {productName: 'Apps Script'};</script></html>",
);
Pasokhban_Notify::$last_result = array();
$res = $ref->invoke( null, $opts, 'ت', 'م', (object) array( 'current_url' => '' ) );
eq( $res, false, 'با پاسخ HTML گوگل، false برمی‌گردد' );
$msg = Pasokhban_Notify::$last_result['telegram'];
ok( false !== strpos( $msg, 'HTML' ), 'پیام می‌گوید پاسخ HTML بوده نه JSON' );
ok( false !== strpos( $msg, '/exec' ), 'راهنمای /exec در پیام هست' );
ok( false !== strpos( $msg, 'Anyone' ), 'راهنمای Anyone در پیام هست' );
ok( false === strpos( $msg, 'ppConfig' ), 'HTML خام در پیام نشت نمی‌کند' );

// پاسخ JSON سالم نباید HTML تشخیص داده شود
$GLOBALS['wp_remote_response'] = array( 'response' => array( 'code' => 200 ), 'body' => json_encode( array( 'ok' => true ) ) );
Pasokhban_Notify::$last_result = array();
$res = $ref->invoke( null, $opts, 'ت', 'م', (object) array( 'current_url' => '' ) );
eq( $res, true, 'پاسخ JSON سالم درست کار می‌کند' );

/* ========================================================= */
head( '۴) اولویت مسیرها' );
/* ========================================================= */

// اگر رله باشد، پروکسی نادیده گرفته می‌شود
$opts2 = $opts;
$opts2['notify_telegram_proxy'] = 'socks5://127.0.0.1:9050';
$rp->setValue( $settings, $opts2 );
$GLOBALS['wp_remote_response'] = array( 'response' => array( 'code' => 200 ), 'body' => json_encode( array( 'ok' => true ) ) );
$GLOBALS['wp_remote_log'] = array();
$ref->invoke( null, $opts2, 'ت', 'م', (object) array( 'current_url' => '' ) );
$last = end( $GLOBALS['wp_remote_log'] );
ok( false !== strpos( $last['url'], 'script.google.com' ), 'با وجود رله، پروکسی نادیده گرفته می‌شود' );

// اگر رله نباشد، مسیر مستقیم استفاده می‌شود
$opts3 = $opts;
$opts3['notify_telegram_relay'] = '';
$GLOBALS['wp_remote_log'] = array();
$GLOBALS['wp_remote_response'] = array( 'response' => array( 'code' => 200 ), 'body' => json_encode( array( 'ok' => true ) ) );
$ref->invoke( null, $opts3, 'ت', 'م', (object) array( 'current_url' => '' ) );
$last = end( $GLOBALS['wp_remote_log'] );
ok( false !== strpos( $last['url'], 'api.telegram.org' ), 'بدون رله، مستقیم به تلگرام می‌رود' );

/* ========================================================= */
head( '۵) فیلدها در فرم تنظیمات' );
/* ========================================================= */

$rp->setValue( $settings, $opts );
ob_start();
$settings->render_page();
$html = ob_get_clean();
foreach ( array( 'notify_telegram_relay', 'notify_telegram_secret' ) as $k ) {
	ok( false !== strpos( $html, "pasokhban_options[$k]" ), "فیلد $k در فرم هست" );
}
ok( false !== strpos( $html, 'AKfycbz' ), 'آدرس رلهٔ ذخیره‌شده در فیلد نمایش داده می‌شود' );


/* ========================================================= */
head( '۶) باگ ۲.۰.۱ — ریدایرکت رلهٔ گوگل باید با GET دنبال شود' );
/* ========================================================= */

/**
 * شبیه‌سازی دقیق رفتار واقعی گوگل (با curl روی endpoint زنده تأیید شد):
 *   POST /exec            → 302 + Location: script.googleusercontent.com/...
 *   GET  روی Location     → 200 + خروجی واقعی اسکریپت
 *   POST روی Location     → 405/400 + صفحهٔ HTML با window['ppConfig']
 */
$RELAY_EXEC = 'https://script.google.com/macros/s/AKfycbz/exec';
$ECHO_URL   = 'https://script.googleusercontent.com/macros/echo?user_content_key=ABC';

$send = new ReflectionMethod( 'Pasokhban_Notify', 'send_via_relay' );
$send->setAccessible( true );
$lr = new ReflectionProperty( 'Pasokhban_Notify', 'last_result' );
$lr->setAccessible( true );

$fields = array( 'chat_id' => '-100123', 'text' => 'سلام', 'parse_mode' => 'Markdown' );

/** اجرای send_via_relay با پاسخ‌های دلخواه و برگرداندن last_result */
function relay_run( $send, $lr, $relay, $fields, $responder ) {
	$GLOBALS['wp_remote_response'] = $responder;
	$GLOBALS['wp_remote_calls']    = array();
	$lr->setValue( null, array() );
	$ok = $send->invoke( null, $relay, 'TOKEN123', $fields, 'MY-SECRET' );
	$res = $lr->getValue();
	return array(
		'ok'     => $ok,
		'msg'    => isset( $res['telegram'] ) ? $res['telegram'] : '',
		'calls'  => $GLOBALS['wp_remote_calls'],
	);
}

// ── الف) ریدایرکت با GET دنبال می‌شود و JSON موفق می‌آید ──
$r = relay_run( $send, $lr, $RELAY_EXEC, $fields, function ( $url, $args ) use ( $RELAY_EXEC, $ECHO_URL ) {
	if ( $url === $RELAY_EXEC ) {
		return array(
			'response' => array( 'code' => 302 ),
			'headers'  => array( 'location' => $ECHO_URL ),
			'body'     => '',
		);
	}
	return array( 'response' => array( 'code' => 200 ), 'headers' => array(), 'body' => '{"ok":true}' );
} );
eq( $r['ok'], true, 'ریدایرکت با GET دنبال شد و ارسال موفق شد' );
eq( $r['msg'], 'ok (relay)', 'نتیجهٔ موفقیت ثبت شد' );
eq( count( $r['calls'] ), 2, 'دو درخواست زده شد (POST سپس GET)' );
eq( $r['calls'][0]['method'], 'POST', 'درخواست اول POST است' );
eq( $r['calls'][1]['method'], 'GET', 'درخواست دوم GET است، نه POST' );
eq( $r['calls'][1]['url'], $ECHO_URL, 'درخواست دوم به آدرس Location رفت' );
eq( $r['calls'][0]['args']['redirection'], 0, 'درخواست اول redirection=0 دارد تا خودمان ریدایرکت را کنترل کنیم' );

// ── ب) ★ رگرسیون اصلی: صفحهٔ HTML با ppConfig دیگر «دیپلوی خراب» گزارش نمی‌شود ──
$r = relay_run( $send, $lr, $RELAY_EXEC, $fields, function ( $url ) use ( $RELAY_EXEC ) {
	if ( $url === $RELAY_EXEC ) {
		return array(
			'response' => array( 'code' => 302 ),
			'headers'  => array( 'location' => 'https://script.googleusercontent.com/macros/echo?user_content_key=X' ),
			'body'     => '',
		);
	}
	return array(
		'response' => array( 'code' => 405 ),
		'headers'  => array(),
		'body'     => "<!DOCTYPE html><html><head><script>window['ppConfig'] = {productName: 'x'};",
	);
} );
eq( $r['ok'], false, 'پاسخ HTML شکست است' );
ok( false === strpos( $r['msg'], 'درست دیپلوی نشده' ), 'پیام گمراه‌کنندهٔ «دیپلوی خراب» حذف شد' );
ok( false !== strpos( $r['msg'], 'اگر پیام آزمایشی به تلگرامت رسید' ), 'پیام تازه راهنمای درست می‌دهد' );

// ── پ) پاسخ متنی سالم (بعضی رله‌ها JSON برنمی‌گردانند) ──
$r = relay_run( $send, $lr, $RELAY_EXEC, $fields, function ( $url ) use ( $RELAY_EXEC, $ECHO_URL ) {
	if ( $url === $RELAY_EXEC ) {
		return array( 'response' => array( 'code' => 302 ), 'headers' => array( 'location' => $ECHO_URL ), 'body' => '' );
	}
	return array( 'response' => array( 'code' => 200 ), 'headers' => array(), 'body' => 'OK' );
} );
eq( $r['ok'], true, 'رله‌ای که متن «OK» می‌دهد هم موفق حساب می‌شود' );
eq( $r['msg'], 'ok (relay)', 'نتیجهٔ موفقیت برای پاسخ متنی' );

// ── ت) ★ پاسخ متنیِ خطا با کد 200 نباید موفق حساب شود ──
// (دقیقاً همان چیزی که روی endpoint زندهٔ کاربر دیده شد)
$r = relay_run( $send, $lr, $RELAY_EXEC, $fields, function ( $url ) use ( $RELAY_EXEC, $ECHO_URL ) {
	if ( $url === $RELAY_EXEC ) {
		return array( 'response' => array( 'code' => 302 ), 'headers' => array( 'location' => $ECHO_URL ), 'body' => '' );
	}
	return array( 'response' => array( 'code' => 200 ), 'headers' => array(), 'body' => 'Error! Bot token not provided' );
} );
eq( $r['ok'], false, '«Error! …» با کد 200 موفق حساب نمی‌شود' );
ok( false !== strpos( $r['msg'], 'Bot token not provided' ), 'متن خطای واقعی اسکریپت به کاربر نشان داده می‌شود' );

// ── ث) JSON با خطا ──
$r = relay_run( $send, $lr, $RELAY_EXEC, $fields, function ( $url ) use ( $RELAY_EXEC, $ECHO_URL ) {
	if ( $url === $RELAY_EXEC ) {
		return array( 'response' => array( 'code' => 302 ), 'headers' => array( 'location' => $ECHO_URL ), 'body' => '' );
	}
	return array( 'response' => array( 'code' => 200 ), 'headers' => array(), 'body' => '{"ok":false,"error":"unauthorized"}' );
} );
eq( $r['ok'], false, 'خطای unauthorized شکست است' );
eq( $r['msg'], 'relay: unauthorized', 'متن خطای JSON منتقل شد' );

// ── ج) بدون ریدایرکت (پاسخ مستقیم) ──
$r = relay_run( $send, $lr, $RELAY_EXEC, $fields, function () {
	return array( 'response' => array( 'code' => 200 ), 'headers' => array(), 'body' => '{"ok":true}' );
} );
eq( $r['ok'], true, 'پاسخ مستقیم 200 بدون ریدایرکت هم کار می‌کند' );
eq( count( $r['calls'] ), 1, 'درخواست اضافه‌ای زده نشد' );

// ── چ) خطای شبکه در گام دوم ──
$GLOBALS['step'] = 0;
$r = relay_run( $send, $lr, $RELAY_EXEC, $fields, function ( $url ) use ( $RELAY_EXEC, $ECHO_URL ) {
	if ( $url === $RELAY_EXEC ) {
		return array( 'response' => array( 'code' => 302 ), 'headers' => array( 'location' => $ECHO_URL ), 'body' => '' );
	}
	return new WP_Error( 'http_request_failed', 'Operation timed out' );
} );
eq( $r['ok'], false, 'خطای شبکه در گام GET مدیریت می‌شود' );
ok( false !== strpos( $r['msg'], 'timed out' ), 'پیام خطای شبکه منتقل شد' );

// ── خ) خطای شبکه در گام اول ──
$r = relay_run( $send, $lr, $RELAY_EXEC, $fields, function () {
	return new WP_Error( 'http_request_failed', 'Could not resolve host' );
} );
eq( $r['ok'], false, 'خطای شبکه در گام POST مدیریت می‌شود' );
ok( false !== strpos( $r['msg'], 'Could not resolve host' ), 'پیام خطا منتقل شد' );

/* ========================================================= */
head( '۷) نمایش نتیجه در صفحهٔ تنظیمات' );
/* ========================================================= */

// ★ باگ: 'ok (relay)' با «ok» مقایسهٔ دقیق می‌شد و ❌ نشان می‌داد
set_transient( 'pasokhban_notify_test', array( 'telegram' => 'ok (relay)' ), 60 );
ob_start();
Pasokhban_Settings::instance()->render_page();
$html = ob_get_clean();
ok( false !== strpos( $html, '✅ ارسال شد' ), 'موفقیت از راه رله با ✅ نمایش داده می‌شود' );
ok( false === strpos( $html, '❌ ok (relay)' ), 'موفقیت دیگر با ❌ نشان داده نمی‌شود' );

// transient یک‌بارمصرف است — خطای قدیمی در صفحه نمی‌ماند
set_transient( 'pasokhban_notify_test', array( 'telegram' => 'relay: unauthorized' ), 60 );
ob_start();
Pasokhban_Settings::instance()->render_page();
$html = ob_get_clean();
ok( false !== strpos( $html, '❌ relay: unauthorized' ), 'خطا نمایش داده می‌شود' );

ob_start();
Pasokhban_Settings::instance()->render_page();
$html = ob_get_clean();
ok( false === strpos( $html, 'relay: unauthorized' ), 'نتیجه یک‌بارمصرف است — در بارگذاری بعدی صفحه نمی‌ماند' );

// سازگاری با query string قدیمی
$_GET['notify_telegram'] = 'no-route';
ob_start();
Pasokhban_Settings::instance()->render_page();
$html = ob_get_clean();
unset( $_GET['notify_telegram'] );
ok( false !== strpos( $html, '❌ no-route' ), 'آدرس‌های قدیمی با query string هم کار می‌کنند' );

echo "\n" . str_repeat( '─', 52 ) . "\n";
if ( 0 === $FAIL ) {
	echo "\033[42;30m همهٔ {$PASS} تست رلهٔ تلگرام پاس شد \033[0m\n";
} else {
	echo "\033[41;97m {$FAIL} تست شکست خورد \033[0m (پاس: {$PASS})\n";
	foreach ( $FAILURES as $f ) {
		echo "   • {$f}\n";
	}
}
echo str_repeat( '─', 52 ) . "\n";
exit( 0 === $FAIL ? 0 : 1 );
