<?php
/**
 * پاک‌سازی داده‌ها هنگام حذف پلاگین پاسخ‌بان.
 *
 * @package Pasokhban
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;

// بررسی تنظیم «حذف داده‌ها هنگام حذف» — اگر خاموش باشد، فقط جداول دیتابیس و نقش‌ها پاک می‌شوند، اما داده‌های کاربر (مکالمات، مخاطبین، ایندکس، آپلودها) حفظ می‌شوند
$opts = get_option( 'pasokhban_options', array() );
$delete_data = empty( $opts['uninstall_delete_data'] ) ? false : true; // پیش‌فرض: true (حذف شود)

$upload_dirs = function_exists( 'wp_upload_dir' ) ? wp_upload_dir() : array();

// همیشه: جداول دیتابیس، نقش‌ها و transientها پاک می‌شوند
$wpdb->query( 'DROP TABLE IF EXISTS ' . $wpdb->prefix . 'pasokhban_bale_links' ); // phpcs:ignore WordPress.DB
$wpdb->query( 'DROP TABLE IF EXISTS ' . $wpdb->prefix . 'pasokhban_chunks' );    // phpcs:ignore WordPress.DB
$wpdb->query( 'DROP TABLE IF EXISTS ' . $wpdb->prefix . 'pasokhban_feedback' );  // phpcs:ignore WordPress.DB
$wpdb->query( 'DROP TABLE IF EXISTS ' . $wpdb->prefix . 'pasokhban_messages' );  // phpcs:ignore WordPress.DB
$wpdb->query( 'DROP TABLE IF EXISTS ' . $wpdb->prefix . 'pasokhban_sessions' );  // phpcs:ignore WordPress.DB

// گزینه‌های اصلی همیشه پاک می‌شوند (برای نصب تمیز در آینده)
delete_option( 'pasokhban_options' );
delete_option( 'pasokhban_db_version' );
delete_option( 'pasokhban_db_error' );

// وضعیت ایندکس برداری
delete_option( 'pasokhban_rag_state' );
delete_option( 'pasokhban_rag_dirty' );
delete_option( 'pasokhban_rag_cursor' );

// اعلان‌های موقت بله
delete_transient( 'pasokhban_bale_notice' );

// نقش و گزینه‌های تیم
delete_option( 'pasokhban_agents_online' );
delete_option( 'pasokhban_rr_index' );
if ( function_exists( 'remove_role' ) ) {
	remove_role( 'pasokhban_agent' );
}
$ety_admin = get_role( 'administrator' );
if ( $ety_admin ) {
	$ety_admin->remove_cap( 'pasokhban_reply' );
}

// فقط اگر حذف داده‌ها فعال باشد: فایل‌های آپلود و transientهای داده پاک می‌شوند
if ( $delete_data ) {
	// فایل‌های آپلودشدهٔ بازدیدکننده‌ها
	$ety_updir = trailingslashit( isset( $upload_dirs['basedir'] ) ? $upload_dirs['basedir'] : WP_CONTENT_DIR . '/uploads' ) . 'pasokhban';
	if ( is_dir( $ety_updir ) ) {
		foreach ( (array) glob( $ety_updir . '/*' ) as $ety_f ) {
			if ( is_file( $ety_f ) ) {
				@unlink( $ety_f );
			}
		}
		@rmdir( $ety_updir );
	}
	delete_option( 'pasokhban_updir_hard' );

	// transientهای باقی‌مانده (اعلان‌ها، کش پرس‌وجوها، rate-limit و اعلان)
	$wpdb->query( // phpcs:ignore WordPress.DB
		"DELETE FROM {$wpdb->options} WHERE option_name LIKE '\\\\_transient\\\\_pasokhban\\\\_%' OR option_name LIKE '\\\\_transient\\\\_timeout\\\\_pasokhban\\\\_%'"
	);
} else {
	// داده‌ها حفظ می‌شوند — فقط transientهای غیرداده‌ای پاک می‌شوند
	$wpdb->query( // phpcs:ignore WordPress.DB
		"DELETE FROM {$wpdb->options} WHERE option_name LIKE '\\\\_transient\\\\_pasokhban\\\\_notice%' OR option_name LIKE '\\\\_transient\\\\_timeout\\\\_pasokhban\\\\_notice%'"
	);
}